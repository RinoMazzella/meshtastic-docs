# -*- coding: utf-8 -*-
"""
📡 Meshtastic Italia Network — Parametri Ufficiali
Tutti i parametri, link, canali, driver e configurazioni del network italiano.
Questo file è la FONTE DI VERITÀ per l'intera app.
"""

# ═══════════════════════════════════════════════════════════
# CONFIGURAZIONE NETWORK STANDARD
# ═══════════════════════════════════════════════════════════

NETWORK_CONFIG = {
    "name": "Meshtastic Italia Network",
    "website": "https://www.meshtasticitalia.it",
    "email": "info@meshtasticitalia.it",
    "region": "EU_868",
    "frequency": "868 MHz",
    "modem_preset": "MEDIUM_FAST",
    "hop_limit": 3,
    "tx_power": 27,
    "max_power_legal": "27 dBm (500 mW ERP)",
    "duty_cycle": "10%",
    "mqtt_server": "mqtt.meshtastic.org",
    "mqtt_root_topic": "msh/EU_868/IT",
    "mqtt_encryption": True,
    "psk_network": "hJ7/x9L+qJ5kL2nF8dG7hJ1vK4xM3nB5vC6xZ1aS2dQ=",
}

# ═══════════════════════════════════════════════════════════
# CANALI UFFICIALI
# ═══════════════════════════════════════════════════════════

CHANNELS = [
    {"index": 0, "name": "MediumFast",  "psk": "AQ==",          "role": "PRIMARY", "uplink": True, "downlink": True},
    {"index": 1, "name": "Ita-Nord",    "psk": "PSK_NETWORK",   "role": "SECONDARY", "uplink": True, "downlink": True},
    {"index": 2, "name": "Ita-Centro",  "psk": "PSK_NETWORK",   "role": "SECONDARY", "uplink": True, "downlink": True},
    {"index": 3, "name": "Ita-Sud",     "psk": "PSK_NETWORK",   "role": "SECONDARY", "uplink": True, "downlink": True},
    {"index": 4, "name": "Ita-Help",    "psk": "PSK_NETWORK",   "role": "SECONDARY", "uplink": True, "downlink": True},
    {"index": 5, "name": "Ita-Test",    "psk": "PSK_NETWORK",   "role": "SECONDARY", "uplink": True, "downlink": True},
    {"index": 6, "name": "Ita-Shop",    "psk": "PSK_NETWORK",   "role": "SECONDARY", "uplink": True, "downlink": True},
    {"index": 7, "name": "Italia",      "psk": "mQ==",          "role": "SECONDARY", "uplink": True, "downlink": True},
]

AUTOCONFIG_URL = (
    "https://meshtastic.org/e/#CgsSAQEoATABOgIIIAo0EiCEnv_H0v6onmQvacXx0buEnW8rjEzecHm8LrFn"
    "VpLZ1BoISXRhLU5vcmQoATABOgIIIAo2EiCEnv_H0v6onmQvacXx0buEnW8rjEzecHm8LrFnVpLZ1BoKSXRh"
    "LUNlbnRybygBMAE6AgggCjMSIISe_8fS_qieZC9pxfHRu4SdbyuMTN5webwusWdWktnUGgdJdGEtU3VkKAEw"
    "AToCCCAKNBIghJ7_x9L-qJ5kL2nF8dG7hJ1vK4xM3nB5vC6xZ1aS2dQaCEl0YS1IZWxwKAEwAToCCCAKNBIg"
    "hJ7_x9L-qJ5kL2nF8dG7hJ1vK4xM3nB5vC6xZ1aS2dQaCEl0YS1UZXN0KAEwAToCCCAKNBIghJ7_x9L-qJ5k"
    "L2nF8dG7hJ1vK4xM3nB5vC6xZ1aS2dQaCEl0YS1TaG9wKAEwAToCCCAKExIBmRoGSXRhbGlhKAEwAToCCCAS"
    "GAgBEAQY-gEgCygFOANABEgBUBtoAcgGAQ"
)

# ═══════════════════════════════════════════════════════════
# 12 RUOLI DISPOSITIVO (firmware 2.7.x)
# ═══════════════════════════════════════════════════════════

DEVICE_ROLES = {
    "CLIENT": {
        "name": "Client",
        "emoji": "🟢",
        "description": "Nodo utente standard. Invia, riceve e ritrasmette messaggi solo se nessun altro nodo lo ha già fatto.",
        "retransmit": "Sì (se nessun altro l'ha fatto)",
        "priority": "Normale",
        "display": True,
        "ble_wifi": True,
        "visible": True,
        "power": "Normale",
        "ideal_for": "Uso quotidiano, portatile, casa",
        "warning": None,
        "command": 'meshtastic --set device.role CLIENT'
    },
    "CLIENT_MUTE": {
        "name": "Client Mute",
        "emoji": "🟢",
        "description": "Come Client ma NON ritrasmette messaggi degli altri. Invia e riceve solo i propri.",
        "retransmit": "No",
        "priority": "—",
        "display": True,
        "ble_wifi": True,
        "visible": True,
        "power": "Minimo",
        "ideal_for": "Zone dense con tanti nodi, chi ha più dispositivi",
        "warning": None,
        "command": 'meshtastic --set device.role CLIENT_MUTE'
    },
    "CLIENT_HIDDEN": {
        "name": "Client Hidden",
        "emoji": "🟢",
        "description": "Come Client ma INVISIBILE nella lista nodi altrui. Trasmette solo lo stretto necessario.",
        "retransmit": "Solo locale",
        "priority": "—",
        "display": True,
        "ble_wifi": True,
        "visible": False,
        "power": "Minimo",
        "ideal_for": "Stealth, privacy, risparmio energetico",
        "warning": None,
        "command": 'meshtastic --set device.role CLIENT_HIDDEN'
    },
    "CLIENT_BASE": {
        "name": "Client Base",
        "emoji": "🟡",
        "description": "Base station personale. Ritrasmette SEMPRE i pacchetti dei nodi nei tuoi 'Preferiti'. Per tutti gli altri si comporta come Client.",
        "retransmit": "Sì per preferiti, Client per altri",
        "priority": "Preferiti",
        "display": True,
        "ble_wifi": True,
        "visible": True,
        "power": "Normale",
        "ideal_for": "Nodo sul tetto/mansarda che serve i tuoi nodi interni",
        "warning": "NON usare come sostituto di ROUTER! Serve solo per i tuoi nodi personali.",
        "command": 'meshtastic --set device.role CLIENT_BASE'
    },
    "TRACKER": {
        "name": "Tracker",
        "emoji": "🔵",
        "description": "Ottimizzato per invio posizione GPS. Si sveglia, invia posizione, torna a dormire. Radio LoRa SPENTA in sleep.",
        "retransmit": "Solo da sveglio",
        "priority": "—",
        "display": False,
        "ble_wifi": True,
        "visible": True,
        "power": "Basso",
        "ideal_for": "Tracciamento veicoli, bici, zaini, animali",
        "warning": None,
        "command": 'meshtastic --set device.role TRACKER'
    },
    "LOST_AND_FOUND": {
        "name": "Lost and Found",
        "emoji": "🔵",
        "description": "Invia la propria posizione come messaggio di testo sul canale primario, regolarmente. Per ritrovare un nodo perso.",
        "retransmit": "Sì",
        "priority": "—",
        "display": False,
        "ble_wifi": True,
        "visible": True,
        "power": "Normale",
        "ideal_for": "Recupero dispositivo perso",
        "warning": None,
        "command": 'meshtastic --set device.role LOST_AND_FOUND'
    },
    "SENSOR": {
        "name": "Sensor",
        "emoji": "🔵",
        "description": "Ottimizzato per invio dati sensori ambientali. Si sveglia, legge sensore, invia telemetria, dorme. Radio SPENTA in sleep.",
        "retransmit": "Solo da sveglio",
        "priority": "—",
        "display": False,
        "ble_wifi": True,
        "visible": True,
        "power": "Basso",
        "ideal_for": "Stazioni meteo, sensori BME280, BME680, SHT40",
        "warning": None,
        "command": 'meshtastic --set device.role SENSOR'
    },
    "TAK": {
        "name": "TAK",
        "emoji": "🟤",
        "description": "Ottimizzato per comunicazione con sistema ATAK (Android Team Awareness Kit). Riduce trasmissioni di routine.",
        "retransmit": "Sì",
        "priority": "—",
        "display": True,
        "ble_wifi": True,
        "visible": True,
        "power": "Normale",
        "ideal_for": "Integrazione con ATAK tramite plugin Meshtastic",
        "warning": None,
        "command": 'meshtastic --set device.role TAK'
    },
    "TAK_TRACKER": {
        "name": "TAK Tracker",
        "emoji": "🟤",
        "description": "Come TAK ma con invio automatico posizione (PLI). Standalone senza connessione all'app ATAK.",
        "retransmit": "Sì",
        "priority": "—",
        "display": True,
        "ble_wifi": True,
        "visible": True,
        "power": "Normale",
        "ideal_for": "Tracciamento posizione in ambiente ATAK senza smartphone",
        "warning": None,
        "command": 'meshtastic --set device.role TAK_TRACKER'
    },
    "ROUTER": {
        "name": "Router",
        "emoji": "🔴",
        "description": "Infrastruttura. Ritrasmette SEMPRE con PRIORITÀ ALTA. Display spento, BLE/WiFi spenti. Sleep automatico.",
        "retransmit": "SEMPRE",
        "priority": "Alta",
        "display": False,
        "ble_wifi": False,
        "visible": True,
        "power": "Alto",
        "ideal_for": "SOLO posizioni eccezionali: cima montagna, torre, traliccio con vista 360°",
        "warning": "IL RUOLO PIÙ ABUSATO! Router mal posizionati sono la PRIMA causa di degrado della rete. Se non sei su una montagna, usa CLIENT_BASE o ROUTER_LATE.",
        "command": 'meshtastic --set device.role ROUTER'
    },
    "ROUTER_LATE": {
        "name": "Router Late",
        "emoji": "🟡",
        "description": "Ritrasmette SEMPRE ma ASPETTA. Se sente un altro nodo ritrasmettere, rimanda alla 'finestra tardiva'. Display e BLE/WiFi attivi.",
        "retransmit": "SEMPRE (ma aspetta)",
        "priority": "Normale",
        "display": True,
        "ble_wifi": True,
        "visible": True,
        "power": "Alto",
        "ideal_for": "Nodi fissi in posizioni buone ma non eccellenti. Tetto in città che copre zona morta, ponte per cluster isolati.",
        "warning": "Consuma più airtime di CLIENT. Non usare se non c'è reale necessità di copertura aggiuntiva.",
        "command": 'meshtastic --set device.role ROUTER_LATE'
    },
    "REPEATER": {
        "name": "Repeater",
        "emoji": "🔴",
        "description": "Infrastruttura fantasma. Come ROUTER ma completamente invisibile. Non trasmette telemetria né posizione. Puro relay silenzioso.",
        "retransmit": "SEMPRE",
        "priority": "Alta",
        "display": False,
        "ble_wifi": True,
        "visible": False,
        "power": "Alto",
        "ideal_for": "Nodi remoti inaccessibili (solare su montagna). 'Metti e dimentica'.",
        "warning": None,
        "command": 'meshtastic --set device.role REPEATER'
    },
}

DEPRECATED_ROLES = ["ROUTER_CLIENT"]

# ═══════════════════════════════════════════════════════════
# PRESET MODEM RADIO
# ═══════════════════════════════════════════════════════════

MODEM_PRESETS = {
    "LONG_FAST":     {"name": "Long Fast",     "range": "Lunga",  "speed": "Media",   "note": "Default Meshtastic"},
    "LONG_MODERATE": {"name": "Long Moderate", "range": "Lunga",  "speed": "Moderata","note": ""},
    "LONG_SLOW":     {"name": "Long Slow",     "range": "Massima","speed": "Bassa",   "note": "Massima portata"},
    "MEDIUM_FAST":   {"name": "Medium Fast",   "range": "Media",  "speed": "Alta",    "note": "⭐ STANDARD ITALIA"},
    "MEDIUM_SLOW":   {"name": "Medium Slow",   "range": "Media",  "speed": "Bassa",   "note": ""},
    "SHORT_FAST":    {"name": "Short Fast",    "range": "Corta",  "speed": "Massima", "note": "Usato da reti dense"},
    "SHORT_SLOW":    {"name": "Short Slow",    "range": "Corta",  "speed": "Bassa",   "note": ""},
    "SHORT_TURBO":   {"name": "Short Turbo",   "range": "Corta",  "speed": "Estrema", "note": "Per eventi/conferenze"},
}

# ═══════════════════════════════════════════════════════════
# DRIVER USB
# ═══════════════════════════════════════════════════════════

DRIVER_LINKS = {
    "CP210x": {
        "name": "CP210x (Silicon Labs)",
        "devices": "Heltec V3, V4, T-Beam, la maggior parte dei dispositivi",
        "all": "https://www.silabs.com/developer-tools/usb-to-uart-bridge-vcp-drivers?tab=downloads",
    },
    "CH340": {
        "name": "CH340 / CH341 (WCH)",
        "devices": "Cloni, dispositivi economici, alcune board",
        "windows": "https://www.wch-ic.com/downloads/CH341SER_EXE.html",
        "mac": "https://www.wch-ic.com/downloads/CH341SER_MAC_ZIP.html",
        "linux": "Integrato nel kernel Linux (nessun download necessario)",
    },
}

# ═══════════════════════════════════════════════════════════
# HARDWARE SUPPORTATO
# ═══════════════════════════════════════════════════════════

SUPPORTED_DEVICES = [
    # ESP32-S3
    {"name": "Heltec LoRa 32 V3",      "chip": "ESP32-S3",  "lora": "SX1262", "gps": False, "display": "OLED 0.96\"", "price": "~30€",  "note": "Lo standard economico", "cat": "starter"},
    {"name": "Heltec LoRa 32 V4",      "chip": "ESP32-S3",  "lora": "SX1262", "gps": "Opz.", "display": "OLED",       "price": "~40€",  "note": "27dBm, 2MB PSRAM, 16MB Flash, solare", "cat": "starter"},
    {"name": "Heltec Wireless Tracker", "chip": "ESP32-S3",  "lora": "SX1262", "gps": "UC6580","display": "OLED 0.96\"","price": "~35€", "note": "GPS integrato", "cat": "tracker"},
    {"name": "LilyGO T-Beam V1.1",     "chip": "ESP32",     "lora": "SX1276", "gps": "NEO-6M","display": "Opz.",      "price": "~45€",  "note": "Batteria 18650, il classico", "cat": "outdoor"},
    {"name": "LilyGO T-Beam Supreme S3","chip": "ESP32-S3", "lora": "SX1262", "gps": "L76K",  "display": "OLED 1.3\"","price": "~65€",  "note": "Sensori, RTC, IMU 6 assi", "cat": "outdoor"},
    {"name": "LilyGO T-Deck",          "chip": "ESP32-S3",  "lora": "SX1262", "gps": False,   "display": "IPS 2.8\"", "price": "~70€",  "note": "Tastiera QWERTY + trackball", "cat": "standalone"},
    {"name": "LilyGO T-Deck Plus",     "chip": "ESP32-S3",  "lora": "SX1262", "gps": "Sì",    "display": "IPS 2.8\"", "price": "~80€",  "note": "T-Deck con GPS integrato", "cat": "standalone"},
    {"name": "LilyGO T-Echo",          "chip": "nRF52840",  "lora": "SX1262", "gps": "Sì",    "display": "E-Ink 1.54\"","price": "~55€", "note": "Case incluso, E-Ink, NFC, ultra low power", "cat": "outdoor"},
    {"name": "LilyGO T-Watch S3",      "chip": "ESP32-S3",  "lora": "SX1262", "gps": False,   "display": "IPS 1.54\"","price": "~70€",  "note": "Smartwatch LoRa, touch screen", "cat": "wearable"},
    # nRF52840
    {"name": "RAK WisBlock 4631",       "chip": "nRF52840",  "lora": "SX1262", "gps": "Opz.",  "display": "Opz.",      "price": "~30€",  "note": "Modulare, gold standard solare", "cat": "modular"},
    {"name": "RAK WisMesh Pocket V2",   "chip": "nRF52840",  "lora": "SX1262", "gps": "Sì",    "display": "OLED 1.3\"","price": "~99€",  "note": "Handheld pronto all'uso, SOS", "cat": "handheld"},
    {"name": "RAK WisMesh Pocket Mini", "chip": "nRF52840",  "lora": "SX1262", "gps": "Sì",    "display": False,       "price": "~59€",  "note": "Ultra compatto, solo LED", "cat": "handheld"},
    {"name": "RAK WisMesh 1W Booster",  "chip": "nRF52840",  "lora": "SX1262", "gps": "Opz.",  "display": "Opz.",      "price": "~60€",  "note": "1W (30 dBm) con SKY66122 PA", "cat": "highpower"},
    {"name": "RAK WisMesh TAP V2",      "chip": "nRF52840",  "lora": "SX1262", "gps": "Sì",    "display": "Touch 3.5\"","price": "~120€","note": "Touchscreen outdoor, IP67", "cat": "standalone"},
    {"name": "SenseCAP Card T1000-E",   "chip": "nRF52840",  "lora": "LR1110", "gps": "Sì",    "display": False,       "price": "~40€",  "note": "Grande come carta credito, IP65", "cat": "tracker"},
    {"name": "SenseCAP Solar P1",       "chip": "nRF52840",  "lora": "SX1262", "gps": False,   "display": False,       "price": "~70$",  "note": "Solare, 48mA relay, IP67", "cat": "solar"},
    {"name": "SenseCAP Solar P1 Pro",   "chip": "nRF52840",  "lora": "SX1262", "gps": False,   "display": False,       "price": "~90$",  "note": "Solare pro, batteria maggiore", "cat": "solar"},
    {"name": "Seeed Wio Tracker L1",    "chip": "ESP32-S3",  "lora": "SX1262", "gps": "Sì",    "display": "Opz.",      "price": "~30€",  "note": "GPS, modulare, economico", "cat": "tracker"},
    {"name": "Seeed Wio Tracker L1 Pro","chip": "ESP32-S3",  "lora": "SX1262", "gps": "Sì",    "display": "E-Ink",     "price": "~43€",  "note": "E-Ink + solare, handheld", "cat": "outdoor"},
    {"name": "Nano G2 Ultra",           "chip": "nRF52840",  "lora": "SX1262", "gps": "ATGM336H","display": "OLED 1.3\"","price": "~85€","note": "3.5 giorni batteria, BLE 5.4", "cat": "handheld"},
    {"name": "Canary One",              "chip": "nRF52840",  "lora": "SX1262", "gps": "Sì",    "display": "LCD",       "price": "~120$", "note": "Rugged, ambienti estremi", "cat": "rugged"},
    {"name": "Station G2",              "chip": "ESP32-S3",  "lora": "SX1262", "gps": False,   "display": False,       "price": "~80€",  "note": "Alta potenza, per radioamatori", "cat": "highpower"},
    {"name": "ThinkNode M2",            "chip": "ESP32-S3",  "lora": "SX1262", "gps": "Sì",    "display": "OLED",      "price": "~50€",  "note": "Outdoor portatile", "cat": "outdoor"},
    {"name": "Muzi R1 Neo",             "chip": "nRF52840",  "lora": "SX1262", "gps": "Sì",    "display": "OLED",      "price": "~60€",  "note": "Custom design, GPS, buzzer", "cat": "handheld"},
    # RP2040
    {"name": "RAK11310 (RP2040)",       "chip": "RP2040",    "lora": "SX1262", "gps": "Opz.",  "display": "Opz.",      "price": "~25€",  "note": "DIY, UF2 bootloader", "cat": "diy"},
]

# ═══════════════════════════════════════════════════════════
# LINK UFFICIALI
# ═══════════════════════════════════════════════════════════

LINKS = {
    "meshtastic": {
        "web_flasher":    "https://flasher.meshtastic.org",
        "downloads":      "https://meshtastic.org/downloads/",
        "web_client":     "https://client.meshtastic.org",
        "docs":           "https://meshtastic.org/docs/introduction/",
        "cli_install":    "https://meshtastic.org/docs/software/python/cli/installation/",
        "cli_usage":      "https://meshtastic.org/docs/software/python/cli/usage/",
        "github_firmware":"https://github.com/meshtastic/firmware",
        "github_python":  "https://github.com/meshtastic/python",
        "app_android":    "https://play.google.com/store/apps/details?id=com.geeksville.mesh",
        "app_ios":        "https://apps.apple.com/us/app/meshtastic/id1586432531",
    },
    "community": {
        "sito":           "https://www.meshtasticitalia.it",
        "telegram":       "https://t.me/MeshtasticItalia",
        "telegram_latina":"https://t.me/meshtastic_latina",
        "facebook_group": "https://www.facebook.com/groups/1346187060851998/",
        "facebook_page":  "https://www.facebook.com/profile.php?id=61584782714060",
        "discord":        "https://discord.gg/Rbhwf54nB3",
        "instagram":      "https://www.instagram.com/meshtastic_italia",
        "youtube":        "https://www.youtube.com/@MeshtasticItalia",
        "x_twitter":      "https://x.com/MeshtasticITA",
        "tiktok":         "https://www.tiktok.com/@meshtasticitalia",
        "email":          "info@meshtasticitalia.it",
    },
    "maps": {
        "matrix_map":     "https://www.meshtasticitalia.it",
        "gnagni_map":     "https://meshtastic.gnagni.it/map",
        "gnagni_dash":    "https://meshtastic.gnagni.it",
        "niccomale":      "https://worldmap.niccomale.it/live-map",
        "loracity":       "https://maps.loracity.it/",
        "meshmap":        "https://meshmap.net/",
        "maps3d":         "https://maps3d.io/editor",
    },
    "tools": {
        "peakfinder":     "https://www.peakfinder.com/it",
        "heywhatsthat":   "https://www.heywhatsthat.com/",
        "uisp":           "https://ispdesign.ui.com/",
        "calcmaps":       "https://www.calcmaps.com/it/map-area/",
        "windy":          "https://www.windy.com/",
        "meshmonitor":    "https://meshmonitor.org/",
        "meshmonitor_gh": "https://github.com/Yeraze/meshmonitor",
    },
    "3d_printing": {
        "yeggi":          "https://www.yeggi.com/q/meshtastic+case/",
        "printables":     "https://www.printables.com/search/models?q=meshtastic",
    },
    "hardware": {
        "heltec_italia":  "https://www.heltec.it",
        "lilygo_europa":  "https://www.lilygo.eu",
    },
    "docs_pdf": {
        "guida_comparativa":  "https://raw.githubusercontent.com/RinoMazzella/meshtastic-docs/main/guida_comparativa_mesh_lora_italia_2026MARZO.pdf",
        "guida_meshtastic":   "https://raw.githubusercontent.com/RinoMazzella/meshtastic-docs/main/Meshtastic_Guida_Tecnica_Completa.pdf",
        "guida_lora_italia":  "https://raw.githubusercontent.com/RinoMazzella/meshtastic-docs/main/LoRaItalia_Guida_Tecnica_Completa.pdf",
        "guida_darkmesh":     "https://raw.githubusercontent.com/RinoMazzella/meshtastic-docs/main/DarkMesh_Guida_Tecnica_Completa.pdf",
        "guida_matrixmap":    "https://raw.githubusercontent.com/RinoMazzella/meshtastic-docs/main/MatrixMap_v2_Guida_Utente_Illustrata.pdf",
    },
    "python": {
        "download":       "https://www.python.org/downloads/",
        "pypi_meshtastic":"https://pypi.org/project/meshtastic/",
    },
}

# ═══════════════════════════════════════════════════════════
# FIRMWARE INFO
# ═══════════════════════════════════════════════════════════

FIRMWARE_INFO = {
    "latest_alpha": "v2.7.20.6658ec2",
    "latest_alpha_date": "11 marzo 2026",
    "recommended": "Stable dal Web Flasher",
    "platforms": ["ESP32", "ESP32-S3", "nRF52", "RP2040", "RP2350", "Linux"],
    "web_flasher": "https://flasher.meshtastic.org",
    "web_client": "https://client.meshtastic.org",
    "github_releases": "https://github.com/meshtastic/firmware/releases",
    "changelog_highlights_2_7": [
        "BaseUI: nuovo sistema interfaccia utente (sostituisce legacy UI)",
        "Web UI rimossa da ESP32 — usare client.meshtastic.org o self-host",
        "Multi-message storage per ridurre traffico rete",
        "APIPort configurabile da file config",
        "StatusMessage module e config overrides",
        "InkHUD navigazione joystick su Seeed Wio Tracker",
        "CLIENT_BASE ora si comporta come ROUTER_LATE per nodi preferiti",
        "Graduated scaling per NodeInfo send timeout",
        "Supporto RAK3112, Luckfox Lyra Hat, Heltec Tracker V2",
        "USB_MODE=1 per Station G2 (fix serial)",
        "PKC (Public Key Cryptography) — da firmware 2.5+",
    ],
    "mod_limitations": {
        "via_cli": [
            "Cambiare Node ID (--set-owner-hex)",
            "Cambiare HAM mode (--set-ham)",
            "Export/Import config YAML",
            "Factory Reset",
            "SET/GET qualsiasi parametro protobuf",
            "Frequency offset (--set lora.frequency_offset)",
            "Override duty cycle (--set lora.override_duty_cycle)",
            "Override TX power (con HAM mode)",
        ],
        "impossibile_senza_compilazione": [
            "Cambiare hardware name (variant.h in C++)",
            "Override reale TX Power EU senza HAM (macro REGION_EU_868 hardcoded)",
            "Aggiungere nuovo modello hardware (richiede fork firmware)",
            "Modificare BaseUI/InkHUD (C++ nel firmware)",
            "Disabilitare clamping EU (hardcoded in RadioInterface.cpp)",
        ],
        "solo_esptool_uf2": [
            "Flash firmware custom compilato",
            "Erase flash completa",
            "Backup/restore NVS",
            "Flash bootloader",
        ],
    },
}

# ═══════════════════════════════════════════════════════════
# BOOTLOADER PER DISPOSITIVO
# ═══════════════════════════════════════════════════════════

BOOTLOADER_METHODS = {
    "Heltec V3/V4":  "Tieni premuto BOOT (o PRG), premi e rilascia RST, poi rilascia BOOT",
    "T-Beam":        "Tieni premuto BOOT, collega il cavo USB, poi rilascia BOOT",
    "T-Beam Supreme":"Tieni premuto BOOT, collega il cavo USB, poi rilascia BOOT",
    "T-Deck":        "Spegni il T-Deck. Tieni premuta la trackball, accendi, poi rilascia la trackball",
    "T-Echo (nRF52)":"Doppio click sul tasto RESET per entrare in bootloader UF2. Copia il file .uf2 sul drive",
    "RAK WisBlock":  "Doppio click sul tasto RESET per entrare in bootloader UF2",
    "RAK WisMesh":   "Doppio click sul tasto RESET per bootloader UF2 (tutti i modelli nRF52)",
    "Station G2":    "Tieni premuto BOOT, collega USB. USB_MODE=1 risolve problemi seriale",
    "SenseCAP T1000-E": "Collega USB, il bootloader si attiva automaticamente",
    "Generico ESP32":"Tieni premuto BOOT/FLASH, premi RST, rilascia RST, rilascia BOOT",
    "Generico nRF52":"Doppio click RESET → drive UF2 → copia firmware .uf2",
    "Generico RP2040":"Tieni premuto BOOTSEL, collega USB → drive UF2 → copia firmware .uf2",
}
