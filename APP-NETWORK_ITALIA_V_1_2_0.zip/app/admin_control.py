# -*- coding: utf-8 -*-
"""
admin_control.py — Sprint H4.4 Admin Control Suite
════════════════════════════════════════════════════════════════════

Wrapper Python di alto livello per il protocollo AdminMessage
Meshtastic. Espone 30 comandi operativi contro un nodo collegato via
USB (o bridge MQTT), raggruppati in 7 famiglie:

  1. POWER        (3) reboot, shutdown, factory_reset
  2. OWNER        (2) set_owner, get_device_metadata
  3. CONFIG       (2) get_config, set_config   — 10 sotto-tipi
  4. MODULE_CFG   (2) get_module_config, set_module_config — 15 sotto-tipi
  5. CHANNEL      (3) get_channel, set_channel, delete_channel
  6. NODEDB       (6) nodedb_reset, remove_by_nodenum, set_favorite,
                      remove_favorite, set_ignored, toggle_muted
  7. POSITION     (3) set_fixed_position, remove_fixed_position, set_time
  8. CANNED/RING  (4) get_canned, set_canned, get_ringtone, set_ringtone
  9. ADVANCED     (5) begin_edit, commit_edit, enter_dfu,
                      exit_simulator, start_ota_reboot

Totale: 30 command wrapper (i sotto-tipi config non contano come comandi
distinti — passano tramite config_type parametro).

Ogni wrapper:
  - accetta `iface` (MeshInterface) o None (ritorna {ok: False,
    error: 'no_interface'})
  - richiede `confirm=True` per azioni distruttive (reboot, factory_reset,
    nodedb_reset, shutdown)
  - ritorna {ok: bool, action: str, ...details}
  - non lancia mai eccezioni verso il caller (try/except interno)

Sicurezza:
  - NO shell=True, NO subprocess
  - Solo API Python del pacchetto `meshtastic`
  - PRO gate applicato lato server.py prima di chiamare queste funzioni
  - Whitelist config_type e channel_index (0-7)

© 2026 MANGOLINK — tutti i diritti riservati.
"""

from __future__ import annotations

import time
import logging
from typing import Any, Dict, List, Optional, Tuple

_LOG = logging.getLogger("admin_control")

# ─── Import opzionali (la app deve comunque importarsi senza pacchetto) ──
try:
    from meshtastic.protobuf import (
        admin_pb2 as _admin_pb2,
        config_pb2 as _config_pb2,
        module_config_pb2 as _modcfg_pb2,
        channel_pb2 as _channel_pb2,
        mesh_pb2 as _mesh_pb2,
    )
    _PB_OK = True
except Exception as _e:
    _admin_pb2 = None
    _config_pb2 = None
    _modcfg_pb2 = None
    _channel_pb2 = None
    _mesh_pb2 = None
    _PB_OK = False
    _LOG.warning("meshtastic protobuf import failed: %s", _e)


# ════════════════════════════════════════════════════════════
# CATALOGHI (whitelist enum)
# ════════════════════════════════════════════════════════════

# Config types: 10 sotto-tipi di meshtastic.protobuf.config_pb2.Config
CONFIG_TYPES: Tuple[str, ...] = (
    "device", "position", "power", "network", "display",
    "lora", "bluetooth", "security", "sessionkey", "device_ui",
)

# ModuleConfig types: 15 sotto-tipi
MODULE_CONFIG_TYPES: Tuple[str, ...] = (
    "mqtt", "serial", "external_notification", "store_forward",
    "range_test", "telemetry", "canned_message", "audio",
    "remote_hardware", "neighbor_info", "ambient_lighting",
    "detection_sensor", "paxcounter", "statusmessage",
    "traffic_management",
)

# Mapping verso ConfigType enum numerico (AdminMessage.ConfigType)
_CONFIG_TYPE_ENUM = {
    "device": 0, "position": 1, "power": 2, "network": 3,
    "display": 4, "lora": 5, "bluetooth": 6, "security": 7,
    "sessionkey": 8, "device_ui": 9,
}
_MODULE_TYPE_ENUM = {
    "mqtt": 0, "serial": 1, "external_notification": 2,
    "store_forward": 3, "range_test": 4, "telemetry": 5,
    "canned_message": 6, "audio": 7, "remote_hardware": 8,
    "neighbor_info": 9, "ambient_lighting": 10,
    "detection_sensor": 11, "paxcounter": 12,
    "statusmessage": 13, "traffic_management": 14,
}

# Channel roles whitelist (Channel.Role enum values)
CHANNEL_ROLES: Tuple[str, ...] = ("DISABLED", "PRIMARY", "SECONDARY")


# ════════════════════════════════════════════════════════════
# HELPERS
# ════════════════════════════════════════════════════════════

def _need_iface(iface) -> Optional[Dict]:
    """Return error dict if iface is None/invalid, else None."""
    if iface is None:
        return {"ok": False, "error": "no_interface"}
    if not hasattr(iface, "localNode"):
        return {"ok": False, "error": "no_local_node"}
    return None


def _need_confirm(confirm: bool) -> Optional[Dict]:
    """Return error dict if destructive op not confirmed, else None."""
    if not confirm:
        return {"ok": False, "error": "confirm_required"}
    return None


def _ok(action: str, **details) -> Dict:
    d = {"ok": True, "action": action, "ts": time.time()}
    d.update(details)
    return d


def _fail(action: str, err: str, msg: str = "") -> Dict:
    d = {"ok": False, "action": action, "error": err}
    if msg:
        d["message"] = msg
    return d


def _node(iface):
    return getattr(iface, "localNode", None)


def _call_if(obj, name: str, *args, **kwargs):
    """Call obj.name(*args, **kwargs) if attr exists and is callable; else None."""
    fn = getattr(obj, name, None)
    if callable(fn):
        return fn(*args, **kwargs)
    return None


# ════════════════════════════════════════════════════════════
# 1. POWER (3 comandi)
# ════════════════════════════════════════════════════════════

def cmd_reboot(iface, seconds: int = 10, confirm: bool = False) -> Dict:
    """AdminMessage.reboot_seconds → localNode.reboot(seconds)."""
    _err = _need_confirm(confirm)
    if _err: return _err | {"action": "reboot"}
    _err = _need_iface(iface)
    if _err: return _err | {"action": "reboot"}
    try:
        n = _node(iface)
        try:
            n.reboot(int(seconds))
        except TypeError:
            n.reboot()
        return _ok("reboot", seconds=int(seconds))
    except Exception as e:
        return _fail("reboot", "reboot_fail", str(e))


def cmd_shutdown(iface, seconds: int = 10, confirm: bool = False) -> Dict:
    """AdminMessage.shutdown_seconds → localNode.shutdown(seconds)."""
    _err = _need_confirm(confirm)
    if _err: return _err | {"action": "shutdown"}
    _err = _need_iface(iface)
    if _err: return _err | {"action": "shutdown"}
    try:
        n = _node(iface)
        try:
            n.shutdown(int(seconds))
        except TypeError:
            n.shutdown()
        return _ok("shutdown", seconds=int(seconds))
    except Exception as e:
        return _fail("shutdown", "shutdown_fail", str(e))


def cmd_factory_reset(iface, full_device: bool = True,
                     confirm: bool = False) -> Dict:
    """AdminMessage.factory_reset_device/factory_reset_config.

    full_device=True  → factory_reset_device (wipe totale)
    full_device=False → factory_reset_config (solo config, mantiene NodeDB)
    """
    _err = _need_confirm(confirm)
    if _err: return _err | {"action": "factory_reset"}
    _err = _need_iface(iface)
    if _err: return _err | {"action": "factory_reset"}
    try:
        n = _node(iface)
        # meshtastic client ha factoryReset() (tutto)
        if full_device:
            _call_if(n, "factoryReset")
        else:
            # Alcune versioni hanno factoryResetConfig()
            if hasattr(n, "factoryResetConfig"):
                n.factoryResetConfig()
            else:
                # fallback: raw AdminMessage
                _send_admin(iface, "factory_reset_config", 1)
        return _ok("factory_reset", full_device=full_device)
    except Exception as e:
        return _fail("factory_reset", "reset_fail", str(e))


# ════════════════════════════════════════════════════════════
# 2. OWNER (2 comandi)
# ════════════════════════════════════════════════════════════

def cmd_set_owner(iface, long_name: str = "", short_name: str = "",
                  is_licensed: bool = False) -> Dict:
    """AdminMessage.set_owner → localNode.setOwner(long, short, is_lic)."""
    _err = _need_iface(iface)
    if _err: return _err | {"action": "set_owner"}
    # Validate
    long_name = (long_name or "").strip()[:40]
    short_name = (short_name or "").strip()[:4]
    if not long_name:
        return _fail("set_owner", "empty_long_name")
    try:
        n = _node(iface)
        try:
            n.setOwner(long_name, short_name, bool(is_licensed))
        except TypeError:
            # alcune versioni vogliono solo (long, short)
            n.setOwner(long_name, short_name)
        return _ok("set_owner", long_name=long_name, short_name=short_name,
                   is_licensed=bool(is_licensed))
    except Exception as e:
        return _fail("set_owner", "setowner_fail", str(e))


def cmd_get_device_metadata(iface) -> Dict:
    """AdminMessage.get_device_metadata_request → localNode.getMetadata()."""
    _err = _need_iface(iface)
    if _err: return _err | {"action": "get_device_metadata"}
    try:
        n = _node(iface)
        meta = _call_if(n, "getMetadata")
        return _ok("get_device_metadata", metadata=_proto_to_dict(meta))
    except Exception as e:
        return _fail("get_device_metadata", "getmeta_fail", str(e))


# ════════════════════════════════════════════════════════════
# 3. CONFIG (2 comandi × 10 sotto-tipi)
# ════════════════════════════════════════════════════════════

def cmd_get_config(iface, config_type: str) -> Dict:
    """AdminMessage.get_config_request → localNode.requestConfig(type_enum)."""
    _err = _need_iface(iface)
    if _err: return _err | {"action": "get_config"}
    if config_type not in _CONFIG_TYPE_ENUM:
        return _fail("get_config", "invalid_config_type",
                     f"allowed: {list(_CONFIG_TYPE_ENUM)}")
    try:
        n = _node(iface)
        enum_val = _CONFIG_TYPE_ENUM[config_type]
        _call_if(n, "requestConfig", enum_val)
        # La risposta arriva asincrona via onResponseRequestSettings
        # Qui ritorniamo conferma invio. UI dovrà fare polling /api/monitor/nodes.
        return _ok("get_config", config_type=config_type, sent=True)
    except Exception as e:
        return _fail("get_config", "getconfig_fail", str(e))


def cmd_set_config(iface, config_type: str, values: Dict) -> Dict:
    """AdminMessage.set_config → localNode.writeConfig(config_type, cfg)."""
    _err = _need_iface(iface)
    if _err: return _err | {"action": "set_config"}
    if config_type not in CONFIG_TYPES:
        return _fail("set_config", "invalid_config_type",
                     f"allowed: {CONFIG_TYPES}")
    if not isinstance(values, dict):
        return _fail("set_config", "values_not_dict")
    try:
        n = _node(iface)
        # Begin → write → commit transaction
        _call_if(n, "beginSettingsTransaction")
        # Costruisci il sotto-config protobuf richiesto
        if _PB_OK and _config_pb2:
            cfg_cls_map = {
                "device": _config_pb2.Config.DeviceConfig,
                "position": _config_pb2.Config.PositionConfig,
                "power": _config_pb2.Config.PowerConfig,
                "network": _config_pb2.Config.NetworkConfig,
                "display": _config_pb2.Config.DisplayConfig,
                "lora": _config_pb2.Config.LoRaConfig,
                "bluetooth": _config_pb2.Config.BluetoothConfig,
                "security": _config_pb2.Config.SecurityConfig,
            }
            cfg_cls = cfg_cls_map.get(config_type)
            if cfg_cls is None:
                # sessionkey / device_ui non applicabili via writeConfig standard
                return _fail("set_config", "unsupported_type",
                             f"{config_type} not writable via writeConfig")
            cfg_msg = cfg_cls()
            # popola campi
            for k, v in values.items():
                if hasattr(cfg_msg, k):
                    try:
                        setattr(cfg_msg, k, v)
                    except Exception as e:
                        _LOG.warning("set_config %s.%s=%r failed: %s",
                                     config_type, k, v, e)
            _call_if(n, "writeConfig", config_type, cfg_msg)
        _call_if(n, "commitSettingsTransaction")
        return _ok("set_config", config_type=config_type,
                   fields=list(values.keys()))
    except Exception as e:
        try:
            _call_if(_node(iface), "commitSettingsTransaction")
        except Exception:
            pass
        return _fail("set_config", "setconfig_fail", str(e))


# ════════════════════════════════════════════════════════════
# 4. MODULE_CONFIG (2 comandi × 15 sotto-tipi)
# ════════════════════════════════════════════════════════════

def cmd_get_module_config(iface, module_type: str) -> Dict:
    """AdminMessage.get_module_config_request."""
    _err = _need_iface(iface)
    if _err: return _err | {"action": "get_module_config"}
    if module_type not in _MODULE_TYPE_ENUM:
        return _fail("get_module_config", "invalid_module_type",
                     f"allowed: {list(_MODULE_TYPE_ENUM)}")
    try:
        n = _node(iface)
        # meshtastic python expone requestConfig per entrambi i tipi; alcuni
        # hanno requestModuleConfig separato
        fn = getattr(n, "requestModuleConfig", None) or \
             getattr(n, "requestConfig", None)
        if callable(fn):
            try:
                fn(_MODULE_TYPE_ENUM[module_type])
            except TypeError:
                fn()
        return _ok("get_module_config", module_type=module_type, sent=True)
    except Exception as e:
        return _fail("get_module_config", "getmodcfg_fail", str(e))


def cmd_set_module_config(iface, module_type: str, values: Dict) -> Dict:
    """AdminMessage.set_module_config."""
    _err = _need_iface(iface)
    if _err: return _err | {"action": "set_module_config"}
    if module_type not in MODULE_CONFIG_TYPES:
        return _fail("set_module_config", "invalid_module_type")
    if not isinstance(values, dict):
        return _fail("set_module_config", "values_not_dict")
    try:
        n = _node(iface)
        _call_if(n, "beginSettingsTransaction")
        # ModuleConfig ha sotto-tipi simili a Config
        if _PB_OK and _modcfg_pb2:
            mod_cls_map = {
                "mqtt": _modcfg_pb2.ModuleConfig.MQTTConfig,
                "serial": _modcfg_pb2.ModuleConfig.SerialConfig,
                "external_notification": _modcfg_pb2.ModuleConfig.ExternalNotificationConfig,
                "store_forward": _modcfg_pb2.ModuleConfig.StoreForwardConfig,
                "range_test": _modcfg_pb2.ModuleConfig.RangeTestConfig,
                "telemetry": _modcfg_pb2.ModuleConfig.TelemetryConfig,
                "canned_message": _modcfg_pb2.ModuleConfig.CannedMessageConfig,
                "audio": _modcfg_pb2.ModuleConfig.AudioConfig,
                "remote_hardware": _modcfg_pb2.ModuleConfig.RemoteHardwareConfig,
                "neighbor_info": _modcfg_pb2.ModuleConfig.NeighborInfoConfig,
                "ambient_lighting": _modcfg_pb2.ModuleConfig.AmbientLightingConfig,
                "detection_sensor": _modcfg_pb2.ModuleConfig.DetectionSensorConfig,
                "paxcounter": _modcfg_pb2.ModuleConfig.PaxcounterConfig,
            }
            mcls = mod_cls_map.get(module_type)
            if mcls:
                mmsg = mcls()
                for k, v in values.items():
                    if hasattr(mmsg, k):
                        try:
                            setattr(mmsg, k, v)
                        except Exception as e:
                            _LOG.warning("set_module_config %s.%s=%r failed: %s",
                                         module_type, k, v, e)
                # alcuni client hanno writeModuleConfig, altri usano
                # writeConfig con enum module
                _write_mod = getattr(n, "writeModuleConfig", None) or \
                            getattr(n, "writeConfig", None)
                if callable(_write_mod):
                    try:
                        _write_mod(module_type, mmsg)
                    except Exception:
                        pass
        _call_if(n, "commitSettingsTransaction")
        return _ok("set_module_config", module_type=module_type,
                   fields=list(values.keys()))
    except Exception as e:
        try:
            _call_if(_node(iface), "commitSettingsTransaction")
        except Exception:
            pass
        return _fail("set_module_config", "setmodcfg_fail", str(e))


# ════════════════════════════════════════════════════════════
# 5. CHANNEL (3 comandi)
# ════════════════════════════════════════════════════════════

def cmd_get_channel(iface, index: int = 0) -> Dict:
    """AdminMessage.get_channel_request → localNode.getChannelByChannelIndex."""
    _err = _need_iface(iface)
    if _err: return _err | {"action": "get_channel"}
    if not (0 <= int(index) <= 7):
        return _fail("get_channel", "invalid_index", "must be 0-7")
    try:
        n = _node(iface)
        ch = _call_if(n, "getChannelByChannelIndex", int(index))
        return _ok("get_channel", index=int(index),
                   channel=_proto_to_dict(ch))
    except Exception as e:
        return _fail("get_channel", "getch_fail", str(e))


def cmd_set_channel(iface, index: int, name: str = "",
                    role: str = "SECONDARY", psk_b64: str = "") -> Dict:
    """AdminMessage.set_channel → localNode.writeChannel."""
    _err = _need_iface(iface)
    if _err: return _err | {"action": "set_channel"}
    if not (0 <= int(index) <= 7):
        return _fail("set_channel", "invalid_index")
    if role not in CHANNEL_ROLES:
        return _fail("set_channel", "invalid_role")
    try:
        n = _node(iface)
        if not _PB_OK:
            return _fail("set_channel", "no_protobuf")
        ch = _channel_pb2.Channel()
        ch.index = int(index)
        ch.role = _channel_pb2.Channel.Role.Value(role)
        ch.settings.name = (name or "")[:12]
        if psk_b64:
            import base64
            try:
                ch.settings.psk = base64.b64decode(psk_b64)
            except Exception:
                return _fail("set_channel", "invalid_psk_b64")
        _call_if(n, "writeChannel", ch)
        return _ok("set_channel", index=int(index), name=name, role=role)
    except Exception as e:
        return _fail("set_channel", "setch_fail", str(e))


def cmd_delete_channel(iface, index: int, confirm: bool = False) -> Dict:
    """AdminMessage.set_channel (role=DISABLED) → localNode.deleteChannel."""
    _err = _need_confirm(confirm)
    if _err: return _err | {"action": "delete_channel"}
    _err = _need_iface(iface)
    if _err: return _err | {"action": "delete_channel"}
    if not (1 <= int(index) <= 7):
        return _fail("delete_channel", "invalid_index",
                     "cannot delete PRIMARY (index 0)")
    try:
        n = _node(iface)
        _call_if(n, "deleteChannel", int(index))
        return _ok("delete_channel", index=int(index))
    except Exception as e:
        return _fail("delete_channel", "delch_fail", str(e))


# ════════════════════════════════════════════════════════════
# 6. NODEDB (6 comandi)
# ════════════════════════════════════════════════════════════

def cmd_nodedb_reset(iface, confirm: bool = False) -> Dict:
    """AdminMessage.nodedb_reset → localNode.resetNodeDb()."""
    _err = _need_confirm(confirm)
    if _err: return _err | {"action": "nodedb_reset"}
    _err = _need_iface(iface)
    if _err: return _err | {"action": "nodedb_reset"}
    try:
        n = _node(iface)
        for m in ("resetNodeDb", "resetNodes"):
            if callable(getattr(n, m, None)):
                getattr(n, m)()
                return _ok("nodedb_reset", method=m)
        return _fail("nodedb_reset", "method_missing")
    except Exception as e:
        return _fail("nodedb_reset", "reset_fail", str(e))


def cmd_remove_by_nodenum(iface, node_num: int) -> Dict:
    """AdminMessage.remove_by_nodenum → localNode.removeNode(node_num)."""
    _err = _need_iface(iface)
    if _err: return _err | {"action": "remove_by_nodenum"}
    if int(node_num) <= 0:
        return _fail("remove_by_nodenum", "invalid_nodenum")
    try:
        n = _node(iface)
        _call_if(n, "removeNode", int(node_num))
        return _ok("remove_by_nodenum", node_num=int(node_num))
    except Exception as e:
        return _fail("remove_by_nodenum", "remove_fail", str(e))


def cmd_set_favorite(iface, node_num: int) -> Dict:
    """AdminMessage.set_favorite_node."""
    _err = _need_iface(iface)
    if _err: return _err | {"action": "set_favorite"}
    try:
        n = _node(iface)
        _call_if(n, "setFavorite", int(node_num))
        return _ok("set_favorite", node_num=int(node_num))
    except Exception as e:
        return _fail("set_favorite", "fav_fail", str(e))


def cmd_remove_favorite(iface, node_num: int) -> Dict:
    """AdminMessage.remove_favorite_node."""
    _err = _need_iface(iface)
    if _err: return _err | {"action": "remove_favorite"}
    try:
        n = _node(iface)
        _call_if(n, "removeFavorite", int(node_num))
        return _ok("remove_favorite", node_num=int(node_num))
    except Exception as e:
        return _fail("remove_favorite", "unfav_fail", str(e))


def cmd_set_ignored(iface, node_num: int, ignore: bool = True) -> Dict:
    """AdminMessage.set_ignored_node / remove_ignored_node."""
    _err = _need_iface(iface)
    if _err: return _err | {"action": "set_ignored"}
    try:
        n = _node(iface)
        if ignore:
            _call_if(n, "setIgnored", int(node_num))
        else:
            _call_if(n, "removeIgnored", int(node_num))
        return _ok("set_ignored", node_num=int(node_num), ignored=ignore)
    except Exception as e:
        return _fail("set_ignored", "ignore_fail", str(e))


def cmd_toggle_muted(iface, node_num: int) -> Dict:
    """AdminMessage.toggle_muted_node."""
    _err = _need_iface(iface)
    if _err: return _err | {"action": "toggle_muted"}
    try:
        # Nessun wrapper diretto → costruisci AdminMessage raw
        _send_admin(iface, "toggle_muted_node", int(node_num))
        return _ok("toggle_muted", node_num=int(node_num))
    except Exception as e:
        return _fail("toggle_muted", "mute_fail", str(e))


# ════════════════════════════════════════════════════════════
# 7. POSITION (3 comandi)
# ════════════════════════════════════════════════════════════

def cmd_set_fixed_position(iface, lat: float, lon: float,
                            altitude: int = 0) -> Dict:
    """AdminMessage.set_fixed_position → localNode.setFixedPosition."""
    # Validate input FIRST (non-stateful) → better UX vs. transient iface
    if not (-90 <= float(lat) <= 90):
        return _fail("set_fixed_position", "invalid_lat")
    if not (-180 <= float(lon) <= 180):
        return _fail("set_fixed_position", "invalid_lon")
    _err = _need_iface(iface)
    if _err: return _err | {"action": "set_fixed_position"}
    try:
        n = _node(iface)
        _call_if(n, "setFixedPosition", float(lat), float(lon),
                 int(altitude))
        return _ok("set_fixed_position", lat=float(lat), lon=float(lon),
                   altitude=int(altitude))
    except Exception as e:
        return _fail("set_fixed_position", "setpos_fail", str(e))


def cmd_remove_fixed_position(iface) -> Dict:
    """AdminMessage.remove_fixed_position."""
    _err = _need_iface(iface)
    if _err: return _err | {"action": "remove_fixed_position"}
    try:
        n = _node(iface)
        _call_if(n, "removeFixedPosition")
        return _ok("remove_fixed_position")
    except Exception as e:
        return _fail("remove_fixed_position", "rmpos_fail", str(e))


def cmd_set_time(iface, unix_ts: Optional[int] = None) -> Dict:
    """AdminMessage.set_time_only → localNode.setTime(unix_ts)."""
    _err = _need_iface(iface)
    if _err: return _err | {"action": "set_time"}
    ts = int(unix_ts if unix_ts is not None else time.time())
    try:
        n = _node(iface)
        try:
            n.setTime(ts)
        except TypeError:
            # alcune versioni non accettano argomento
            n.setTime()
        return _ok("set_time", unix_ts=ts)
    except Exception as e:
        return _fail("set_time", "settime_fail", str(e))


# ════════════════════════════════════════════════════════════
# 8. CANNED / RINGTONE (4 comandi)
# ════════════════════════════════════════════════════════════

def cmd_get_canned(iface) -> Dict:
    """AdminMessage.get_canned_message_module_messages_request."""
    _err = _need_iface(iface)
    if _err: return _err | {"action": "get_canned"}
    try:
        n = _node(iface)
        msg = _call_if(n, "get_canned_message")
        return _ok("get_canned", messages=msg)
    except Exception as e:
        return _fail("get_canned", "get_canned_fail", str(e))


def cmd_set_canned(iface, messages: str) -> Dict:
    """AdminMessage.set_canned_message_module_messages."""
    _err = _need_iface(iface)
    if _err: return _err | {"action": "set_canned"}
    if not isinstance(messages, str):
        return _fail("set_canned", "messages_not_str")
    # limite tipico 200 char
    if len(messages) > 200:
        return _fail("set_canned", "too_long",
                     f"{len(messages)} > 200 char")
    try:
        n = _node(iface)
        _call_if(n, "set_canned_message", messages)
        return _ok("set_canned", length=len(messages))
    except Exception as e:
        return _fail("set_canned", "set_canned_fail", str(e))


def cmd_get_ringtone(iface) -> Dict:
    """AdminMessage.get_ringtone_request."""
    _err = _need_iface(iface)
    if _err: return _err | {"action": "get_ringtone"}
    try:
        n = _node(iface)
        r = _call_if(n, "get_ringtone")
        return _ok("get_ringtone", ringtone=r)
    except Exception as e:
        return _fail("get_ringtone", "get_ring_fail", str(e))


def cmd_set_ringtone(iface, ringtone: str) -> Dict:
    """AdminMessage.set_ringtone_message."""
    _err = _need_iface(iface)
    if _err: return _err | {"action": "set_ringtone"}
    if not isinstance(ringtone, str):
        return _fail("set_ringtone", "ringtone_not_str")
    if len(ringtone) > 230:
        return _fail("set_ringtone", "too_long")
    try:
        n = _node(iface)
        _call_if(n, "set_ringtone", ringtone)
        return _ok("set_ringtone", length=len(ringtone))
    except Exception as e:
        return _fail("set_ringtone", "set_ring_fail", str(e))


# ════════════════════════════════════════════════════════════
# 9. ADVANCED (5 comandi)
# ════════════════════════════════════════════════════════════

def cmd_begin_edit(iface) -> Dict:
    """AdminMessage.begin_edit_settings — apri transazione."""
    _err = _need_iface(iface)
    if _err: return _err | {"action": "begin_edit"}
    try:
        _call_if(_node(iface), "beginSettingsTransaction")
        return _ok("begin_edit")
    except Exception as e:
        return _fail("begin_edit", "begin_fail", str(e))


def cmd_commit_edit(iface) -> Dict:
    """AdminMessage.commit_edit_settings — chiudi transazione."""
    _err = _need_iface(iface)
    if _err: return _err | {"action": "commit_edit"}
    try:
        _call_if(_node(iface), "commitSettingsTransaction")
        return _ok("commit_edit")
    except Exception as e:
        return _fail("commit_edit", "commit_fail", str(e))


def cmd_enter_dfu(iface, confirm: bool = False) -> Dict:
    """AdminMessage.enter_dfu_mode_request."""
    _err = _need_confirm(confirm)
    if _err: return _err | {"action": "enter_dfu"}
    _err = _need_iface(iface)
    if _err: return _err | {"action": "enter_dfu"}
    try:
        _call_if(_node(iface), "enterDFUMode")
        return _ok("enter_dfu")
    except Exception as e:
        return _fail("enter_dfu", "dfu_fail", str(e))


def cmd_exit_simulator(iface) -> Dict:
    """AdminMessage.exit_simulator."""
    _err = _need_iface(iface)
    if _err: return _err | {"action": "exit_simulator"}
    try:
        _call_if(_node(iface), "exitSimulator")
        return _ok("exit_simulator")
    except Exception as e:
        return _fail("exit_simulator", "exit_fail", str(e))


def cmd_reboot_ota(iface, seconds: int = 10, confirm: bool = False) -> Dict:
    """AdminMessage.reboot_ota_seconds."""
    _err = _need_confirm(confirm)
    if _err: return _err | {"action": "reboot_ota"}
    _err = _need_iface(iface)
    if _err: return _err | {"action": "reboot_ota"}
    try:
        n = _node(iface)
        try:
            n.rebootOTA(int(seconds))
        except TypeError:
            n.rebootOTA()
        return _ok("reboot_ota", seconds=int(seconds))
    except Exception as e:
        return _fail("reboot_ota", "rebootota_fail", str(e))


# ════════════════════════════════════════════════════════════
# HELPERS INTERNI (protobuf → dict, raw AdminMessage send)
# ════════════════════════════════════════════════════════════

def _proto_to_dict(pb) -> Dict:
    """Converte un messaggio protobuf in dict JSON-safe."""
    if pb is None:
        return {}
    try:
        from google.protobuf.json_format import MessageToDict
        try:
            return MessageToDict(pb, preserving_proto_field_name=False,
                                 use_integers_for_enums=True)
        except TypeError:
            return MessageToDict(pb)
    except Exception:
        return {"_repr": str(pb)[:200]}


def _send_admin(iface, field: str, value) -> None:
    """Invia AdminMessage raw costruito al volo."""
    if not _PB_OK or _admin_pb2 is None:
        raise RuntimeError("protobuf not available")
    n = _node(iface)
    if n is None:
        raise RuntimeError("no local node")
    am = _admin_pb2.AdminMessage()
    # proto fields with snake_case
    if hasattr(am, field):
        setattr(am, field, value)
    else:
        raise ValueError(f"AdminMessage has no field {field}")
    # Delivery: prefer n._sendAdmin (private API), else iface.sendData
    send_fn = getattr(n, "_sendAdmin", None)
    if callable(send_fn):
        send_fn(am)
        return
    # Fallback via sendData on interface with portnum ADMIN_APP=6
    iface.sendData(am.SerializeToString(), portNum=6, wantAck=True)


# ════════════════════════════════════════════════════════════
# CATALOGO COMMANDS (per /api/admin/tools/index)
# ════════════════════════════════════════════════════════════

COMMAND_CATALOG: List[Dict[str, Any]] = [
    # POWER
    {"family": "power",     "name": "reboot",               "destructive": True,  "desc": "Riavvia il nodo dopo N secondi"},
    {"family": "power",     "name": "shutdown",             "destructive": True,  "desc": "Spegne il nodo dopo N secondi"},
    {"family": "power",     "name": "factory_reset",        "destructive": True,  "desc": "Reset di fabbrica (device o solo config)"},
    # OWNER
    {"family": "owner",     "name": "set_owner",            "destructive": False, "desc": "Imposta long/short name + flag HAM licensed"},
    {"family": "owner",     "name": "get_device_metadata",  "destructive": False, "desc": "Legge firmware/hw_model/serial del nodo"},
    # CONFIG
    {"family": "config",    "name": "get_config",           "destructive": False, "desc": "Legge un sotto-config (10 tipi)"},
    {"family": "config",    "name": "set_config",           "destructive": False, "desc": "Scrive un sotto-config (8 tipi scrivibili)"},
    # MODULE_CONFIG
    {"family": "module",    "name": "get_module_config",    "destructive": False, "desc": "Legge un module config (15 tipi)"},
    {"family": "module",    "name": "set_module_config",    "destructive": False, "desc": "Scrive un module config (13 tipi scrivibili)"},
    # CHANNEL
    {"family": "channel",   "name": "get_channel",          "destructive": False, "desc": "Legge un canale per indice (0-7)"},
    {"family": "channel",   "name": "set_channel",          "destructive": False, "desc": "Scrive un canale con nome/ruolo/PSK"},
    {"family": "channel",   "name": "delete_channel",       "destructive": True,  "desc": "Disattiva un canale (non PRIMARY)"},
    # NODEDB
    {"family": "nodedb",    "name": "nodedb_reset",         "destructive": True,  "desc": "Svuota NodeDB (solo nodo locale)"},
    {"family": "nodedb",    "name": "remove_by_nodenum",    "destructive": False, "desc": "Rimuove un singolo nodo dal NodeDB"},
    {"family": "nodedb",    "name": "set_favorite",         "destructive": False, "desc": "Marca nodo come favorito"},
    {"family": "nodedb",    "name": "remove_favorite",      "destructive": False, "desc": "Rimuove flag favorito"},
    {"family": "nodedb",    "name": "set_ignored",          "destructive": False, "desc": "Ignora/rimuovi ignore di un nodo"},
    {"family": "nodedb",    "name": "toggle_muted",         "destructive": False, "desc": "Toggle mute di un nodo"},
    # POSITION
    {"family": "position",  "name": "set_fixed_position",   "destructive": False, "desc": "Imposta lat/lon/alt fissi"},
    {"family": "position",  "name": "remove_fixed_position","destructive": False, "desc": "Rimuove posizione fissa (torna GPS)"},
    {"family": "position",  "name": "set_time",             "destructive": False, "desc": "Sincronizza orologio del nodo"},
    # CANNED/RING
    {"family": "canned",    "name": "get_canned",           "destructive": False, "desc": "Legge messaggi canned"},
    {"family": "canned",    "name": "set_canned",           "destructive": False, "desc": "Scrive messaggi canned (max 200 char)"},
    {"family": "canned",    "name": "get_ringtone",         "destructive": False, "desc": "Legge ringtone RTTTL"},
    {"family": "canned",    "name": "set_ringtone",         "destructive": False, "desc": "Scrive ringtone RTTTL (max 230 char)"},
    # ADVANCED
    {"family": "advanced",  "name": "begin_edit",           "destructive": False, "desc": "Apre transazione settings"},
    {"family": "advanced",  "name": "commit_edit",          "destructive": False, "desc": "Chiude transazione settings"},
    {"family": "advanced",  "name": "enter_dfu",            "destructive": True,  "desc": "Entra in DFU mode (upload firmware)"},
    {"family": "advanced",  "name": "exit_simulator",       "destructive": False, "desc": "Exit dal simulatore (solo dev)"},
    {"family": "advanced",  "name": "reboot_ota",           "destructive": True,  "desc": "Reboot per OTA update"},
]

assert len(COMMAND_CATALOG) == 30, \
    f"COMMAND_CATALOG must have 30 entries, got {len(COMMAND_CATALOG)}"


# Dispatch table: maps command name → callable
COMMAND_DISPATCH = {
    "reboot":                cmd_reboot,
    "shutdown":              cmd_shutdown,
    "factory_reset":         cmd_factory_reset,
    "set_owner":             cmd_set_owner,
    "get_device_metadata":   cmd_get_device_metadata,
    "get_config":            cmd_get_config,
    "set_config":            cmd_set_config,
    "get_module_config":     cmd_get_module_config,
    "set_module_config":     cmd_set_module_config,
    "get_channel":           cmd_get_channel,
    "set_channel":           cmd_set_channel,
    "delete_channel":        cmd_delete_channel,
    "nodedb_reset":          cmd_nodedb_reset,
    "remove_by_nodenum":     cmd_remove_by_nodenum,
    "set_favorite":          cmd_set_favorite,
    "remove_favorite":       cmd_remove_favorite,
    "set_ignored":           cmd_set_ignored,
    "toggle_muted":          cmd_toggle_muted,
    "set_fixed_position":    cmd_set_fixed_position,
    "remove_fixed_position": cmd_remove_fixed_position,
    "set_time":              cmd_set_time,
    "get_canned":            cmd_get_canned,
    "set_canned":            cmd_set_canned,
    "get_ringtone":          cmd_get_ringtone,
    "set_ringtone":          cmd_set_ringtone,
    "begin_edit":            cmd_begin_edit,
    "commit_edit":           cmd_commit_edit,
    "enter_dfu":             cmd_enter_dfu,
    "exit_simulator":        cmd_exit_simulator,
    "reboot_ota":            cmd_reboot_ota,
}

assert len(COMMAND_DISPATCH) == 30, \
    f"COMMAND_DISPATCH must have 30 entries, got {len(COMMAND_DISPATCH)}"
