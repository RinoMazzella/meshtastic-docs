# -*- coding: utf-8 -*-
"""
monitor_analyst.py — Analyst Agent per Monitor LoRa
════════════════════════════════════════════════════════════════════

STEP E — Thread di analisi in background che, ogni ANALYST_INTERVAL_S
secondi, interroga il DB e produce insights sulla finestra temporale
ANALYST_WINDOW_S (default 1h). I risultati sono tenuti in cache RAM
e esposti via /api/monitor/analyst/insights.

Insights prodotti:
    - top_nodes       : top 3 nodi per pacchetti
    - spam_suspects   : nodi con rate anormale (>= SPAM_RATE_PKT_H)
    - stealth_suspects: nodi senza nodeinfo/position (flag DB stealth_suspect)
    - mqtt_gateways   : nodi che fanno gateway MQTT (source='mqtt')
    - hot_channels    : top 3 canali per attività
    - silent_channels : canali noti ma con 0 pacchetti recenti
    - rate_per_min    : pacchetti al minuto totali
    - enc_ratio       : frazione di pacchetti cifrati non decodificati
    - window_secs     : finestra di analisi

SICUREZZA:
    - Nessun shell=True. Nessuna modifica al DB.
    - Solo query SELECT sulla connessione monitor_db._connect().
    - Thread daemon, stop pulito con _STOP_EVT.

© 2026 MANGOLINK — tutti i diritti riservati.
"""

from __future__ import annotations
import time
import threading
import traceback

try:
    from app import monitor_db as _db
except Exception:  # pragma: no cover
    import monitor_db as _db

# ════════════════════════════════════════════════════════════════════
# CONFIG
# ════════════════════════════════════════════════════════════════════

ANALYST_INTERVAL_S = 60       # ricalcola ogni 60 secondi
ANALYST_WINDOW_S = 3600       # finestra 1 ora
SPAM_RATE_PKT_H = 60          # >=60 pacchetti/ora = sospetto spam
TOP_N = 3                     # quanti elementi nelle top-list

# ════════════════════════════════════════════════════════════════════
# STATO
# ════════════════════════════════════════════════════════════════════

_STATE = {
    "running": False,
    "thread": None,
    "last_run_ts": 0,
    "last_duration_ms": 0,
    "insights": {
        "top_nodes": [],
        "spam_suspects": [],
        "stealth_suspects": [],
        "mqtt_gateways": [],
        "hot_channels": [],
        "silent_channels": [],
        "rate_per_min": 0.0,
        "enc_ratio": 0.0,
        "window_secs": ANALYST_WINDOW_S,
        "generated_ts": 0,
        "total_packets": 0,
        "unique_nodes": 0,
    },
    "errors": [],
}

_STOP_EVT = threading.Event()
_LOCK = threading.Lock()


# ════════════════════════════════════════════════════════════════════
# HELPERS
# ════════════════════════════════════════════════════════════════════

def _now_ms() -> int:
    return int(time.time() * 1000)


def _node_hex(n):
    try:
        n = int(n)
        if n < 0:
            n = n & 0xFFFFFFFF
        return f"!{n:08x}"
    except Exception:
        return str(n)


# ════════════════════════════════════════════════════════════════════
# QUERY INSIGHTS
# ════════════════════════════════════════════════════════════════════

# FASE 6 (2026-05-05) — whitelist criteri ranking per top_nodes
_RANK_BY_OPTIONS = {
    "packets":   "c DESC",
    "rssi_avg":  "rssi_avg DESC NULLS LAST",
    "snr_avg":   "snr_avg DESC NULLS LAST",
    "hops":      "hops_away ASC NULLS LAST",     # piu' vicino = priorita'
    "recency":   "last_ts DESC",
}


def _compute_insights(window_s: int = ANALYST_WINDOW_S,
                      top_n: int = None,
                      rank_by: str = "packets") -> dict:
    """Esegue query SQL sulla finestra e ritorna dict di insights.

    Args:
        window_s: finestra temporale in secondi (default 1h)
        top_n: dimensione top-list (default TOP_N=3, range 1-50)
        rank_by: criterio ordinamento top_nodes (whitelist _RANK_BY_OPTIONS)

    Usa solo SELECT — nessuna scrittura.
    """
    # Validation
    if top_n is None or top_n < 1:
        top_n = TOP_N
    top_n = min(int(top_n), 50)
    if rank_by not in _RANK_BY_OPTIONS:
        rank_by = "packets"
    _order_by = _RANK_BY_OPTIONS[rank_by]
    out = {
        "top_nodes": [],
        "spam_suspects": [],
        "stealth_suspects": [],
        "mqtt_gateways": [],
        "hot_channels": [],
        "silent_channels": [],
        "rate_per_min": 0.0,
        "enc_ratio": 0.0,
        "window_secs": window_s,
        "top_n": top_n,            # FASE 6
        "rank_by": rank_by,        # FASE 6
        "generated_ts": _now_ms(),
        "total_packets": 0,
        "unique_nodes": 0,
    }

    now_ms = _now_ms()
    from_ms = now_ms - (window_s * 1000)

    conn = _db._connect()
    try:
        # Total + unique
        row = conn.execute(
            "SELECT COUNT(*) AS c, COUNT(DISTINCT from_node) AS n "
            "FROM packets WHERE ts >= ?", (from_ms,)
        ).fetchone()
        total = int(row["c"] or 0)
        uniq = int(row["n"] or 0)
        out["total_packets"] = total
        out["unique_nodes"] = uniq
        if window_s > 0:
            out["rate_per_min"] = round(total / (window_s / 60.0), 2)

        # Encrypted ratio (cifrati non decodificati)
        row = conn.execute(
            "SELECT SUM(CASE WHEN is_encrypted=1 AND psk_match IS NULL THEN 1 ELSE 0 END) AS e "
            "FROM packets WHERE ts >= ?", (from_ms,)
        ).fetchone()
        enc = int(row["e"] or 0)
        out["enc_ratio"] = round((enc / total) if total > 0 else 0.0, 3)

        # Top nodes — FASE 6 (2026-05-05): JOIN nodes arricchito + ranking selezionabile
        # Campi extra: short/long_name, region, role, hops_away, rssi_avg/snr_avg
        # (calcolati su finestra), hw_model, fw_type, network, modem_preset,
        # is_licensed, last_seen.
        # NULLS LAST richiede SQLite 3.30+; SQLite < 3.30 ignora NULLS LAST ma
        # ordinamento DESC mette NULL alla fine di default (basta).
        _order_clean = _order_by.replace("NULLS LAST", "")
        _sql_top = (
            "SELECT p.from_node AS nid, COUNT(*) AS c, "
            "  MAX(p.ts) AS last_ts, "
            "  AVG(p.rssi) AS rssi_avg, AVG(p.snr) AS snr_avg, "
            "  COUNT(DISTINCT p.channel_name) AS n_channels, "
            "  n.short_name AS sn, n.long_name AS ln, n.hw_model AS hw, "
            "  n.role AS role, n.region AS region, n.network AS network, "
            "  n.fw_type AS fw_type, n.modem_preset AS preset, "
            "  n.hops_away AS hops_away, n.is_licensed AS is_licensed, "
            "  n.last_seen AS last_seen, n.firmware_version AS fw_version "
            "FROM packets p LEFT JOIN nodes n ON n.node_id = p.from_node "
            "WHERE p.ts >= ? "
            "GROUP BY p.from_node ORDER BY " + _order_clean + " LIMIT ?"
        )
        rows = conn.execute(_sql_top, (from_ms, top_n)).fetchall()
        for r in rows:
            out["top_nodes"].append({
                "node_id": int(r["nid"]) if r["nid"] is not None else 0,
                "node_hex": _node_hex(r["nid"]),
                "packets": int(r["c"]),
                "last_ts": int(r["last_ts"]) if r["last_ts"] else 0,
                "rssi_avg": round(float(r["rssi_avg"]), 1) if r["rssi_avg"] is not None else None,
                "snr_avg": round(float(r["snr_avg"]), 1) if r["snr_avg"] is not None else None,
                "n_channels": int(r["n_channels"] or 0),
                "short_name": r["sn"],
                "long_name": r["ln"],
                "hw_model": r["hw"],
                "role": r["role"],
                "region": r["region"],
                "network": r["network"],
                "fw_type": r["fw_type"],
                "modem_preset": r["preset"],
                "hops_away": int(r["hops_away"]) if r["hops_away"] is not None else None,
                "is_licensed": (None if r["is_licensed"] is None else bool(r["is_licensed"])),
                "last_seen": int(r["last_seen"]) if r["last_seen"] else 0,
                "fw_version": r["fw_version"],
            })

        # Spam suspects: nodi con >= SPAM_RATE_PKT_H pacchetti nella finestra (proporzionato)
        spam_threshold = int(SPAM_RATE_PKT_H * (window_s / 3600.0))
        if spam_threshold < 5:
            spam_threshold = 5
        rows = conn.execute(
            "SELECT p.from_node AS nid, COUNT(*) AS c, "
            "  n.short_name AS sn, n.long_name AS ln "
            "FROM packets p LEFT JOIN nodes n ON n.node_id = p.from_node "
            "WHERE p.ts >= ? "
            "GROUP BY p.from_node HAVING c >= ? ORDER BY c DESC LIMIT 10",
            (from_ms, spam_threshold)
        ).fetchall()
        for r in rows:
            out["spam_suspects"].append({
                "node_id": int(r["nid"]) if r["nid"] is not None else 0,
                "node_hex": _node_hex(r["nid"]),
                "packets": int(r["c"]),
                "threshold": spam_threshold,
                "short_name": r["sn"],
                "long_name": r["ln"],
            })

        # Stealth suspects: flag DB stealth_suspect=1, visti nella finestra
        rows = conn.execute(
            "SELECT n.node_id AS nid, n.short_name AS sn, n.long_name AS ln, "
            "  n.last_seen AS ls, n.total_packets AS tp "
            "FROM nodes n "
            "WHERE n.stealth_suspect = 1 AND n.last_seen >= ? "
            "ORDER BY n.last_seen DESC LIMIT 10",
            (from_ms,)
        ).fetchall()
        for r in rows:
            out["stealth_suspects"].append({
                "node_id": int(r["nid"]) if r["nid"] is not None else 0,
                "node_hex": _node_hex(r["nid"]),
                "short_name": r["sn"],
                "long_name": r["ln"],
                "last_seen": int(r["ls"]) if r["ls"] else 0,
                "total_packets": int(r["tp"] or 0),
            })

        # MQTT gateways: nodi che emettono pacchetti con source='mqtt'
        rows = conn.execute(
            "SELECT p.from_node AS nid, COUNT(*) AS c, "
            "  n.short_name AS sn, n.long_name AS ln "
            "FROM packets p LEFT JOIN nodes n ON n.node_id = p.from_node "
            "WHERE p.ts >= ? AND p.source = 'mqtt' "
            "GROUP BY p.from_node ORDER BY c DESC LIMIT 5",
            (from_ms,)
        ).fetchall()
        for r in rows:
            out["mqtt_gateways"].append({
                "node_id": int(r["nid"]) if r["nid"] is not None else 0,
                "node_hex": _node_hex(r["nid"]),
                "mqtt_packets": int(r["c"]),
                "short_name": r["sn"],
                "long_name": r["ln"],
            })

        # Hot channels: top N per attivita' nella finestra
        # FASE 4 fix (2026-05-05): COALESCE(channel_name, psk_match) cattura
        # anche pacchetti decifrati con PSK ma con channel_name NULL (pre-fix
        # FASE 1) per coerenza retroattiva sui pacchetti vecchi.
        rows = conn.execute(
            "SELECT COALESCE(NULLIF(channel_name,''), psk_match) AS cn, COUNT(*) AS c "
            "FROM packets WHERE ts >= ? AND COALESCE(NULLIF(channel_name,''), psk_match) IS NOT NULL "
            "GROUP BY cn ORDER BY c DESC LIMIT ?",
            (from_ms, TOP_N)
        ).fetchall()
        for r in rows:
            out["hot_channels"].append({
                "channel": r["cn"] or "(sconosciuto)",
                "packets": int(r["c"]),
            })

        # Silent channels: canali noti (da psk_keys con channel_name + label) con 0 pacchetti
        # FASE 4+12 fix (2026-05-05): un canale e' "silente" SOLO se 0 pacchetti hanno
        # channel_name=label E 0 pacchetti hanno psk_match=label.
        # FASE 12: GROUP BY channel_name (con fallback su label) per deduplicare
        # canali Italia che hanno doppia entry (catalogo + sync nodo USB con label
        # diversa ma stesso channel_name).
        rows = conn.execute(
            "SELECT MIN(label) AS label, "
            "  COALESCE(NULLIF(channel_name,''), label) AS cn "
            "FROM psk_keys "
            "WHERE enabled = 1 AND (channel_name IS NOT NULL OR label IS NOT NULL) "
            "GROUP BY COALESCE(NULLIF(channel_name,''), label) "
            "ORDER BY cn"
        ).fetchall()
        for r in rows:
            cn = r["cn"]
            label = r["label"]
            if not cn:
                continue
            # Conta pacchetti che matchano via channel_name O psk_match (incluso anche
            # tutte le label varianti — uso LIKE per psk_match con prefisso "Nodo:")
            row = conn.execute(
                "SELECT COUNT(*) AS c FROM packets "
                "WHERE ts >= ? AND ("
                "  channel_name = ? OR channel_name = ? OR "
                "  psk_match = ? OR psk_match = ? OR "
                "  psk_match LIKE ? OR psk_match LIKE ?"
                ")",
                (from_ms, cn, label, cn, label, f'%{cn}%', f'%{label}%')
            ).fetchone()
            if int(row["c"] or 0) == 0:
                out["silent_channels"].append({"channel": cn, "packets": 0})

    finally:
        try:
            conn.close()
        except Exception:
            pass

    return out


# ════════════════════════════════════════════════════════════════════
# THREAD LOOP
# ════════════════════════════════════════════════════════════════════

def _loop():
    """Loop principale del thread analyst. Gira finché _STOP_EVT non è set."""
    while not _STOP_EVT.is_set():
        t0 = time.time()
        try:
            insights = _compute_insights(ANALYST_WINDOW_S)
            with _LOCK:
                _STATE["insights"] = insights
                _STATE["last_run_ts"] = _now_ms()
                _STATE["last_duration_ms"] = int((time.time() - t0) * 1000)
        except Exception as e:
            err = {"ts": _now_ms(), "error": str(e), "tb": traceback.format_exc()[:500]}
            with _LOCK:
                _STATE["errors"].append(err)
                # Conserva max 10 errori
                if len(_STATE["errors"]) > 10:
                    _STATE["errors"] = _STATE["errors"][-10:]
        # Sleep interrompibile
        _STOP_EVT.wait(ANALYST_INTERVAL_S)


def start():
    """Avvia il thread analyst. Idempotente."""
    with _LOCK:
        if _STATE["running"]:
            return {"ok": True, "already_running": True}
        _STOP_EVT.clear()
        th = threading.Thread(target=_loop, name="MonitorAnalyst", daemon=True)
        th.start()
        _STATE["running"] = True
        _STATE["thread"] = th
    return {"ok": True, "started": True}


def stop():
    """Ferma il thread analyst. Idempotente."""
    with _LOCK:
        if not _STATE["running"]:
            return {"ok": True, "already_stopped": True}
        _STOP_EVT.set()
        _STATE["running"] = False
    return {"ok": True, "stopped": True}


def is_running() -> bool:
    with _LOCK:
        return bool(_STATE["running"])


def get_insights() -> dict:
    """Ritorna copia dict degli insights correnti + metadati stato."""
    with _LOCK:
        ins = dict(_STATE["insights"])
        return {
            "running": _STATE["running"],
            "last_run_ts": _STATE["last_run_ts"],
            "last_duration_ms": _STATE["last_duration_ms"],
            "interval_s": ANALYST_INTERVAL_S,
            "insights": ins,
            "recent_errors": list(_STATE["errors"])[-3:],
        }


def force_refresh(window_s: int = None, top_n: int = None, rank_by: str = "packets"):
    """Forza un ricalcolo immediato (sincrono). Usato dall'endpoint on-demand.

    FASE 6 (2026-05-05): accetta parametri opzionali per personalizzare il
    ricalcolo. Se non forniti usa i default (1h, TOP_N=3, rank_by=packets).
    """
    if window_s is None or int(window_s) < 60:
        window_s = ANALYST_WINDOW_S
    window_s = int(window_s)
    t0 = time.time()
    try:
        insights = _compute_insights(window_s, top_n=top_n, rank_by=rank_by)
        with _LOCK:
            _STATE["insights"] = insights
            _STATE["last_run_ts"] = _now_ms()
            _STATE["last_duration_ms"] = int((time.time() - t0) * 1000)
        return {"ok": True, "insights": insights}
    except Exception as e:
        return {"ok": False, "error": str(e)}
