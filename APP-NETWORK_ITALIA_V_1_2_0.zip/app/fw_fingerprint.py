# -*- coding: utf-8 -*-
"""
🔍 Meshtastic Italia Network App v1.2.0 — Firmware Fingerprint
Classifica euristica del firmware di ogni nodo osservato.

Label NEUTRI esposti all'esterno (UI + i18n + DB):
    - stock     → firmware Meshtastic upstream standard
    - fork_a    → fork con traceroute rapido + ok_to_mqtt override
    - fork_b    → fork con compressione portnum 7 attiva
    - stealth   → pattern "solo TEXT_MESSAGE" sostenuto (invisibile su altri canali)
    - builder   → build custom non classificabile in fork_a/fork_b
    - unknown   → dati insufficienti per classificare

Flags aggiuntivi (JSON in DB nel campo fw_flags):
    - compressed_seen     : bool (ha trasmesso almeno un portnum 7)
    - fast_traceroute     : bool (traceroute <15s inter-arrivo)
    - nodeinfo_short      : bool (NodeInfo <1h)
    - text_only           : bool (>20 pacchetti solo TEXT_MESSAGE)
    - sample_size         : int  (quanti pacchetti ha contribuito)

© 2026 🌐🥭MANGOLINK🥭🌐 — Tutti i diritti riservati
"""

import time
import threading
from collections import defaultdict

# Soglie euristiche — tarate sulla documentazione raccolta
FAST_TRACEROUTE_S = 15      # upstream = 30s; <15s = fork
NODEINFO_SHORT_S = 3600     # upstream = 10800s; <3600s = fork
TEXT_ONLY_MIN_SAMPLES = 20  # servono almeno 20 pacchetti per concludere "text_only"
MIN_SAMPLES_FOR_STOCK = 10  # almeno 10 pacchetti prima di dire "stock" con fiducia

_LOCK = threading.RLock()

# Stato per-nodo: tracciamo ultimi eventi rilevanti per l'euristica
_NODE_STATE = defaultdict(lambda: {
    "first_seen": 0,
    "last_seen": 0,
    "sample_size": 0,
    "portnum_counts": defaultdict(int),     # portnum_int → count
    "last_traceroute_ts": 0,
    "min_traceroute_delta_s": None,
    "last_nodeinfo_ts": 0,
    "min_nodeinfo_delta_s": None,
    "compressed_seen": False,               # portnum 7 visto
    "text_count": 0,
    "non_text_count": 0,
    "last_fingerprint": "unknown",
    "last_flags": {},
})


def _now():
    return time.time()


def observe(from_node, portnum_int, ts=None):
    """Registra un pacchetto del nodo e ricalcola fingerprint.
    Ritorna (fw_type_str, flags_dict)."""
    if from_node is None or portnum_int is None:
        return "unknown", {}
    try:
        node_key = int(from_node)
    except Exception:
        return "unknown", {}
    now = ts if ts is not None else _now()

    with _LOCK:
        st = _NODE_STATE[node_key]
        if st["first_seen"] == 0:
            st["first_seen"] = now
        st["last_seen"] = now
        st["sample_size"] += 1
        st["portnum_counts"][portnum_int] += 1

        # Portnum 7 = compressione (indicatore fork_b)
        if portnum_int == 7:
            st["compressed_seen"] = True

        # Traceroute = 70
        if portnum_int == 70:
            if st["last_traceroute_ts"]:
                delta = now - st["last_traceroute_ts"]
                if delta > 0:
                    cur = st["min_traceroute_delta_s"]
                    st["min_traceroute_delta_s"] = min(cur, delta) if cur is not None else delta
            st["last_traceroute_ts"] = now

        # NodeInfo = 4
        if portnum_int == 4:
            if st["last_nodeinfo_ts"]:
                delta = now - st["last_nodeinfo_ts"]
                if delta > 0:
                    cur = st["min_nodeinfo_delta_s"]
                    st["min_nodeinfo_delta_s"] = min(cur, delta) if cur is not None else delta
            st["last_nodeinfo_ts"] = now

        # TEXT_MESSAGE = 1
        if portnum_int == 1:
            st["text_count"] += 1
        else:
            st["non_text_count"] += 1

        fw, flags = _classify(st)
        st["last_fingerprint"] = fw
        st["last_flags"] = flags
        return fw, flags


def _classify(st):
    """Applica le regole di classificazione sullo stato corrente del nodo.
    Ordine di priorità decrescente:
      1. stealth (text_only dominante + sample size alto)
      2. fork_b  (compressed_seen = True)
      3. fork_a  (fast traceroute OR nodeinfo_short)
      4. stock   (sample size >= MIN e nessun indicatore)
      5. builder (anomalie non classificabili, es. solo portnum esotici)
      6. unknown (default)"""
    flags = {
        "compressed_seen": bool(st["compressed_seen"]),
        "fast_traceroute": False,
        "nodeinfo_short": False,
        "text_only": False,
        "sample_size": int(st["sample_size"]),
    }
    if st["min_traceroute_delta_s"] is not None and st["min_traceroute_delta_s"] < FAST_TRACEROUTE_S:
        flags["fast_traceroute"] = True
    if st["min_nodeinfo_delta_s"] is not None and st["min_nodeinfo_delta_s"] < NODEINFO_SHORT_S:
        flags["nodeinfo_short"] = True
    if st["sample_size"] >= TEXT_ONLY_MIN_SAMPLES:
        if st["text_count"] >= 0.9 * st["sample_size"]:
            flags["text_only"] = True

    # Classificazione
    if flags["text_only"]:
        return "stealth", flags
    if flags["compressed_seen"]:
        return "fork_b", flags
    if flags["fast_traceroute"] or flags["nodeinfo_short"]:
        return "fork_a", flags
    # PortNum "builder-only" indicators (RemoteHardware abilitato)
    if st["portnum_counts"].get(2, 0) > 0:  # REMOTE_HARDWARE_APP
        return "builder", flags
    if flags["sample_size"] >= MIN_SAMPLES_FOR_STOCK:
        return "stock", flags
    return "unknown", flags


def get_node_state(from_node):
    """Snapshot (read-only) per debug/UI."""
    try:
        node_key = int(from_node)
    except Exception:
        return None
    with _LOCK:
        st = _NODE_STATE.get(node_key)
        if not st:
            return None
        return {
            "sample_size": st["sample_size"],
            "text_count": st["text_count"],
            "non_text_count": st["non_text_count"],
            "compressed_seen": st["compressed_seen"],
            "min_traceroute_delta_s": st["min_traceroute_delta_s"],
            "min_nodeinfo_delta_s": st["min_nodeinfo_delta_s"],
            "fingerprint": st["last_fingerprint"],
            "flags": dict(st["last_flags"]),
        }


def reset():
    """Reset completo stato (chiamato da monitor.start())."""
    with _LOCK:
        _NODE_STATE.clear()


def all_labels():
    """Ritorna i 6 label esposti all'UI. Utile per i18n check."""
    return ["stock", "fork_a", "fork_b", "stealth", "builder", "unknown"]
