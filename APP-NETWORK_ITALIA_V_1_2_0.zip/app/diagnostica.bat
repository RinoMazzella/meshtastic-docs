@echo off
chcp 65001 >nul 2>&1
title Diagnostica - Meshtastic Italia Network App
cd /d "%~dp0"
echo.
echo  ============================================================
echo    DIAGNOSTICA APP - Meshtastic Italia Network
echo    Verifica licenza + codice macchina + report dettagliato
echo  ============================================================
echo.
set "PYEXE="
where python  >nul 2>&1 && set "PYEXE=python"
if not defined PYEXE ( where py      >nul 2>&1 && set "PYEXE=py" )
if not defined PYEXE ( where python3 >nul 2>&1 && set "PYEXE=python3" )
if not defined PYEXE (
    echo  [ERRORE] Python non trovato. Installa da https://www.python.org/downloads/
    echo  e spunta "Add Python to PATH".
    echo.
    pause
    exit /b 1
)
"%PYEXE%" "diagnostica_app.py"
