/* ═══════════════════════════════════════════════════════════
   📡 MESHTASTIC ITALIA NETWORK APP v1.1.0 — JavaScript v5
   Sistema Licenze + USB + Terminali + QR + Assistente + MOD Firmware
   © 2026 🌐🥭MANGOLINK🥭🌐 — Tutti i diritti riservati
   ═══════════════════════════════════════════════════════════ */

const APP = { currentSection:'guida', systemInfo:null, configMode:null, paramsInfo:{}, selectedPort:null, license:null };

// ══════════════════════════════════════════════════════════════
// 🔐 LICENSE MANAGEMENT
// ══════════════════════════════════════════════════════════════

async function checkLicense(){
    try{
        const d=await apiFetch('license/status');
        if(!d){
            // Retry once after 2s if server is slow at startup
            setTimeout(async()=>{
                const _retry=await apiFetch('license/status');
                if(_retry){APP.license=_retry;applyLicenseUI(_retry);}
            },2000);
            return;
        }
        APP.license=d;
        applyLicenseUI(d);
    }catch(e){console.log('License check failed',e);}
}

// ══════════════════════════════════════════════════════════════
// 🔐 REVOCATION POLLING — Check periodico ogni 5 minuti + check immediato
// ══════════════════════════════════════════════════════════════

let _revocationInterval = null;
const _REVOKE_POLL_MS = 5 * 60 * 1000; // 5 minuti (era 30 — troppo lento per revoca)
const _REVOKE_FIRST_CHECK_MS = 15 * 1000; // Primo check dopo 15 secondi dall'avvio

async function _doRevocationCheck(){
    try{
        // ★ FIX: Usa force-revoke-check che cancella cache e forza verifica online
        const _lic = await apiFetch('license/force-revoke-check',{method:'POST',body:'{}'});
        if(!_lic) return;
        // Se lo status è cambiato a revoked o invalid durante la sessione
        if(_lic.status==='revoked'){
            APP.license = _lic;
            applyLicenseUI(_lic);
            showRevokedOverlay();
            // Stop polling — non serve più, la licenza è revocata
            if(_revocationInterval){ clearInterval(_revocationInterval); _revocationInterval=null; }
        }else if(_lic.status==='invalid' && APP.license && APP.license.status!=='free'){
            APP.license = _lic;
            applyLicenseUI(_lic);
            showToast(t('⚠️ Licenza non valida — verifica la connessione internet'));
        }else{
            // Aggiorna silenziosamente lo stato cache/grace
            APP.license = _lic;
        }
    }catch(_e){/* Polling silenzioso — non mostrare errori */}
}

function startRevocationPolling(){
    if(_revocationInterval) clearInterval(_revocationInterval);
    // ★ FIX: Check immediato dopo 15s dall'avvio (dà tempo al server di partire)
    setTimeout(_doRevocationCheck, _REVOKE_FIRST_CHECK_MS);
    // ★ FIX: Intervallo ridotto a 5 minuti (era 30 — revoca era troppo lenta)
    _revocationInterval = setInterval(_doRevocationCheck, _REVOKE_POLL_MS);
}

function showRevokedOverlay(){
    // Se l'overlay esiste già, non crearlo di nuovo
    if(document.getElementById('revoked-overlay')) return;
    const _ov = document.createElement('div');
    _ov.id = 'revoked-overlay';
    _ov.style.cssText = 'position:fixed;top:0;left:0;width:100vw;height:100vh;background:rgba(0,0,0,0.92);z-index:99999;display:flex;align-items:center;justify-content:center;flex-direction:column;';
    _ov.innerHTML = '<div style="text-align:center;max-width:500px;padding:2rem;">'
        +'<div style="font-size:4rem;margin-bottom:1rem;">🚫</div>'
        +'<h2 style="color:var(--danger,#ff4444);font-size:1.5rem;margin-bottom:1rem;">'+t('Licenza Revocata')+'</h2>'
        +'<p style="color:#ccc;font-size:1rem;margin-bottom:1.5rem;">'+t('La tua licenza è stata revocata dall\'amministratore.')+'<br>'
        +t('Contatta la community per assistenza.')+'</p>'
        +'<p style="color:var(--text-muted,#888);font-size:0.8rem;">'+t('L\'app verrà riavviata al prossimo avvio con licenza FREE.')+'</p>'
        +'</div>';
    document.body.appendChild(_ov);
    // Disabilita TUTTA la navigazione
    document.querySelectorAll('.nav-tab').forEach(_tab=>{
        _tab.classList.add('nav-locked');
        _tab.style.pointerEvents='none';
    });
}

async function resetLicenseCache(){
    if(!confirm(t('Vuoi resettare la cache licenza?')+'\n\n'+t('Questo cancella i file di cache anti-tampering e revoca.')+'\n'+t('La licenza NON viene cancellata.')+'\n\n'+t('Dopo il reset, clicca "Verifica Licenza".'))){return;}
    showToast(t('🗑️ Reset cache in corso...'));
    const d=await apiFetch('license/reset-cache',{method:'POST',body:'{}'});
    if(!d){showToast(t('❌ Errore connessione al server'));return;}
    const _vr=document.getElementById('verify-result');
    if(_vr){
        _vr.style.display='block';
        _vr.style.background='rgba(0,255,136,0.08)';
        _vr.style.border='1px solid var(--accent)';
        _vr.style.color='var(--accent)';
        let _detail='✅ '+t('Cache resettata')+'\n';
        if(d.results){
            for(const _r of d.results){
                _detail+=(_r.deleted?'  ✅ ':'  ⬜ ')+_r.file+(_r.reason?' ('+t(_r.reason)+')':'')+'\n';
            }
        }
        _detail+='\n'+t('Clicca "🔄 Verifica Licenza" per riprovare.');
        _vr.innerHTML='<pre style="margin:0;font-family:var(--font-display);font-size:0.75rem;text-align:left;">'+_detail+'</pre>';
    }
    showToast(t('Cache resettata')+'. '+t('Clicca "🔄 Verifica Licenza" per riprovare.'));
}

function applyLicenseUI(lic){
    if(!lic)return;
    const badge=document.getElementById('license-badge');
    const detail=document.getElementById('license-detail');
    
    // ── Badge + Detail text ──
    if(badge){
        if(lic.status==='pro_mod'){
            badge.className='license-badge pro';
            badge.innerHTML=t('🔧 PRO+MOD');
        }else if(lic.status==='pro'){
            badge.className='license-badge pro';
            badge.innerHTML=t('⭐ PRO ATTIVATA');
        }else if(lic.status==='base'){
            badge.className='license-badge base';
            badge.innerHTML=t('🟢 BASE');
        }else if(lic.status==='expired'){
            badge.className='license-badge expired';
            badge.innerHTML=t('⚠️ SCADUTA');
        }else if(lic.status==='revoked'){
            badge.className='license-badge revoked';
            badge.innerHTML=t('🚫 REVOCATA');
        }else{
            badge.className='license-badge free';
            badge.innerHTML=t('🔒 FREE');
        }
    }
    if(detail){
        if(lic.status==='pro'||lic.status==='base'||lic.status==='pro_mod'){
            if(lic.days_left===-1){
                detail.innerHTML='<span style="color:var(--accent);">'+t('♾️ Illimitata')+'</span>';
            }else if(lic.days_left>30){
                detail.innerHTML='<span style="color:var(--accent);">📅 '+lic.days_left+' '+t('giorni')+'</span>';
            }else if(lic.days_left>7){
                detail.innerHTML='<span style="color:var(--warning);">📅 '+lic.days_left+' '+t('giorni')+'</span>';
            }else if(lic.days_left>0){
                detail.innerHTML='<span style="color:var(--danger);">⚠️ '+lic.days_left+' '+t('giorni')+'!</span>';
            }else{
                detail.innerHTML='<span style="color:var(--danger);">'+t('⚠️ Scade oggi!')+'</span>';
            }
        }else if(lic.status==='expired'){
            detail.innerHTML='<span style="color:var(--danger);">'+t('Rinnova la licenza')+'</span>';
        }else if(lic.status==='revoked'){
            detail.innerHTML='<span style="color:var(--danger);">'+t('Contatta la community')+'</span>';
        }else{
            detail.textContent='';
        }
    }
    
    // ── Offline counter bar ──
    const offBar=document.getElementById('offline-bar');
    if(offBar){
        const _grace=lic.grace_days_left;
        const _graceTotal=10;
        const _showOffline=(!lic.online_verified && lic.status!=='free' && _grace!==undefined && _grace<_graceTotal);
        const _hasWarning=lic.offline_warning;
        if(_hasWarning||_showOffline){
            offBar.style.display='block';
            const _remaining=_grace!==undefined?_grace:0;
            const _offText=document.getElementById('offline-text');
            if(_offText) _offText.textContent=t('⚠️ Offline — verifica licenza tra')+' '+_remaining+' '+t('giorni')+'. '+t('Connetti a internet.');
            // Grace period progress bar
            const _graceBar=document.getElementById('grace-bar');
            const _graceFill=document.getElementById('grace-fill');
            if(_graceBar&&_graceFill&&_remaining<_graceTotal){
                _graceBar.style.display='block';
                const _pct=Math.round((_remaining/_graceTotal)*100);
                _graceFill.style.width=_pct+'%';
                _graceFill.style.background=_pct>50?'#000':(_pct>20?'#663300':'#cc0000');
            }
        }else{offBar.style.display='none';}
    }
    
    // ── Lock nav tabs ──
    const secs=lic.sections||{};
    const _navIsPro=(lic.status==='pro'||lic.status==='pro_mod');
    document.querySelectorAll('.nav-tab').forEach(tab=>{
        const s=tab.dataset.section;
        let ok=true;
        let _tip=t('🔒 Richiede licenza');
        if(s==='cli'||s==='nodo'||s==='dev'){ ok=secs.cli||false; }
        else if(s==='config'){ ok=secs.config_auto||false; }
        else if(s==='monitor'){ ok=_navIsPro; _tip=t('🔒 Richiede licenza PRO'); }
        tab.classList.toggle('nav-locked',!ok);
        tab.title=ok?'':_tip;
    });
    
    // ── Activation panel ──
    const ap=document.getElementById('activation-panel');
    if(ap) ap.style.display=['free','invalid','expired','revoked'].includes(lic.status)?'block':'none';
    
    // ── Fingerprint ──
    const fp=document.getElementById('fp-display');
    if(fp&&lic.fingerprint) fp.textContent=lic.fingerprint;
    
    // ── Config PRO lock ──
    const pl=document.getElementById('pro-lock-overlay');
    if(pl) pl.style.display=(lic.status==='pro'||lic.status==='pro_mod')?'none':'flex';

    // ── Monitor PRO gate (sezione intera) ──
    const _mLock=document.getElementById('monitor-pro-lock');
    const _mCont=document.getElementById('monitor-content');
    const _isPro=(lic.status==='pro'||lic.status==='pro_mod');
    if(_mLock) _mLock.style.display=_isPro?'none':'block';
    if(_mCont) _mCont.style.display=_isPro?'block':'none';
    
    // ── Config MOD lock ──
    const ml=document.getElementById('mod-lock-overlay');
    if(ml) ml.style.display=lic.status==='pro_mod'?'none':'flex';
    const modToggle=document.getElementById('toggle-mod');
    if(modToggle&&lic.status!=='pro_mod') modToggle.disabled=true;
}

function navigateWithLicense(id){
    if(!APP.license)return navigateTo(id);
    const s=APP.license.sections||{};
    const _navProOk=(APP.license.status==='pro'||APP.license.status==='pro_mod');
    let ok=true;
    let _proOnly=false;
    if(id==='cli'||id==='nodo'||id==='dev'){ ok=s.cli||false; }
    else if(id==='config'){ ok=s.config_auto||false; }
    else if(id==='monitor'){ ok=_navProOk; _proOnly=true; }
    if(!ok){showToast(_proOnly?t('🔒 Richiede licenza PRO'):t('🔒 Richiede licenza BASE o PRO'));return;}
    navigateTo(id);
}

async function reloadLicense(){
    showToast(t('🔄 Verifica licenza...'));
    const _vr=document.getElementById('verify-result');
    if(_vr){_vr.style.display='block';_vr.style.background='var(--bg-input)';_vr.style.border='1px solid var(--border)';_vr.style.color='var(--text-muted)';_vr.textContent=t('🔄 Verifica licenza...');}
    const d=await apiFetch('license/reload',{method:'POST',body:'{}'});
    if(!d){
        showToast(t('❌ Errore connessione al server'));
        if(_vr){_vr.style.border='1px solid var(--danger)';_vr.style.color='var(--danger)';_vr.textContent=t('❌ Errore connessione al server');}
        return;
    }
    APP.license=d;
    applyLicenseUI(d);
    // Build translated message from status
    const _lvlLabels={'BASE':t('🟢 Licenza BASE attivata'),'PRO':t('⭐ Licenza PRO attivata'),'PRO_MOD':t('🔧 Licenza PRO+MOD attivata')};
    let _msg='';
    let _isOk=false;
    if(d.status==='pro'||d.status==='base'||d.status==='pro_mod'){
        _msg=_lvlLabels[d.level]||_lvlLabels['BASE'];
        if(d.security_version==='v2-ed25519') _msg+=' '+t('— Firma digitale verificata ✓');
        _isOk=true;
    }else if(d.status==='free'){
        _msg=t('Nessuna licenza trovata. Modalità FREE.');
    }else if(d.status==='expired'){
        _msg=t('⚠️ SCADUTA')+' — '+t('Rinnova la licenza');
    }else if(d.status==='revoked'){
        _msg=t('🚫 REVOCATA')+' — '+t('Contatta la community');
    }else if(d.status==='tampered'){
        _msg=t("⚠️ Integrità del codice compromessa. Reinstalla l'app.");
    }else if(d.status==='invalid'){
        _msg=t(d.message||'Firma digitale non valida. File licenza corrotto o contraffatto.');
    }else{
        _msg=t(d.message||'Verificato');
    }
    showToast(_msg);
    // Visual feedback in panel
    if(_vr){
        if(_isOk){
            _vr.style.background='rgba(0,255,136,0.08)';_vr.style.border='1px solid var(--accent)';_vr.style.color='var(--accent)';
            _vr.innerHTML='✅ '+_msg;
        }else{
            _vr.style.background='rgba(255,68,68,0.08)';_vr.style.border='1px solid var(--danger)';_vr.style.color='var(--danger)';
            _vr.innerHTML='❌ '+_msg+'<br><span style="font-size:0.72rem;color:var(--text-muted);">'+t('Usa "🔧 Diagnostica Licenza" per dettagli')+'</span>';
        }
    }
}

async function openAppFolder(){
    await apiFetch('license/open-folder',{method:'POST',body:'{}'});
    showToast(t('📂 Cartella aperta'));
}

async function runDiagnostics(){
    const _out=document.getElementById('diag-output');
    const _btn=document.getElementById('diag-btn');
    if(!_out||!_btn)return;
    _btn.disabled=true;
    _btn.textContent=t('⏳ Diagnostica in corso...');
    _out.style.display='block';
    _out.innerHTML='<span style="color:var(--accent);">'+t('🔍 Avvio diagnostica licenza...')+'</span>\n';

    try{
        const d=await apiFetch('license/diagnose');
        if(!d||!d.steps){
            _out.innerHTML+='<span style="color:var(--danger);">'+t('❌ Errore: nessuna risposta dal server')+'</span>';
            return;
        }
        _out.innerHTML='';

        // Header
        _out.innerHTML+='<span style="color:var(--accent);font-weight:700;">'+t('🔐 DIAGNOSTICA LICENZA')+'</span>\n';
        _out.innerHTML+='<span style="color:var(--text-muted);">'+t('Fingerprint')+': <span style="color:var(--accent);">'+d.fingerprint+'</span></span>\n';
        _out.innerHTML+='<span style="color:var(--border);">────────────────────────────────────</span>\n';

        // Steps
        for(const _step of d.steps){
            const icon=_step.ok?'<span style="color:var(--accent);">✅</span>':'<span style="color:var(--danger);">❌</span>';
            const labelColor=_step.ok?'var(--text-primary)':'var(--danger)';
            _out.innerHTML+=icon+' <span style="color:'+labelColor+';">'+t(_step.label)+'</span>\n';
            _out.innerHTML+='   <span style="color:var(--text-muted);font-size:0.72rem;">→ '+t(_step.detail)+'</span>\n';
        }

        // Summary
        _out.innerHTML+='<span style="color:var(--border);">────────────────────────────────────</span>\n';
        const allOk=d.steps.every(function(_s){return _s.ok;});
        if(allOk){
            const lvl=d.level||'BASE';
            const lvlLabels={'BASE':'🟢 BASE','PRO':'⭐ PRO','PRO_MOD':'🔧 PRO+MOD'};
            _out.innerHTML+='<span style="color:var(--accent);font-weight:700;">✅ '+t('Licenza valida')+' — '+(lvlLabels[lvl]||lvl)+'</span>\n';
            if(d.expires&&d.expires!=='unlimited'){
                _out.innerHTML+='<span style="color:var(--text-muted);">📅 '+t('Scadenza')+': '+d.expires.split('T')[0]+' ('+d.days_left+' '+t('giorni')+')</span>\n';
            }else if(d.expires==='unlimited'){
                _out.innerHTML+='<span style="color:var(--text-muted);">♾️ '+t('Licenza illimitata')+'</span>\n';
            }
            if(d.user){
                _out.innerHTML+='<span style="color:var(--text-muted);">👤 '+d.user+'</span>\n';
            }
            _out.innerHTML+='<span style="color:var(--text-muted);">🔐 '+d.crypto_version+'</span>\n';
        }else{
            const failedSteps=d.steps.filter(function(_s){return !_s.ok;});
            _out.innerHTML+='<span style="color:var(--danger);font-weight:700;">❌ '+t('Attivazione fallita')+'</span>\n';
            _out.innerHTML+='<span style="color:var(--warning);">'+t('Primo errore')+': '+t(failedSteps[0].label)+'</span>\n';
            _out.innerHTML+='<span style="color:var(--text-muted);">💡 '+t(failedSteps[0].detail)+'</span>\n';
        }

        // Dopo diagnostica, aggiorna anche la UI licenza
        if(allOk){
            const ld=await apiFetch('license/reload',{method:'POST',body:'{}'});
            if(ld){APP.license=ld;applyLicenseUI(ld);}
        }
    }catch(e){
        _out.innerHTML+='<span style="color:var(--danger);">'+t('❌ Errore connessione al server')+': '+e.message+'</span>';
    }finally{
        _btn.disabled=false;
        _btn.textContent=t('🔧 Diagnostica Licenza');
    }
}

// ══════════════════════════════════════════════════════════════
// 🔌 USB PORT MANAGEMENT — Globale per tutta l'app
// ══════════════════════════════════════════════════════════════

function toggleUsbPanel(){
    const panel=document.getElementById('usb-panel');
    if(!panel)return;
    if(panel.style.display==='none'){
        panel.style.display='block';
        scanUsbPorts();
        showUsbOsHint();
        // Chiudi cliccando fuori
        setTimeout(()=>document.addEventListener('click',_closeUsbPanelOutside),100);
    }else{
        panel.style.display='none';
        document.removeEventListener('click',_closeUsbPanelOutside);
    }
}
function _closeUsbPanelOutside(e){
    const panel=document.getElementById('usb-panel');
    const sel=document.getElementById('usb-selector');
    if(panel&&sel&&!sel.contains(e.target)){
        panel.style.display='none';
        document.removeEventListener('click',_closeUsbPanelOutside);
    }
}

function showUsbOsHint(){
    const el=document.getElementById('usb-os-hint');
    if(!el)return;
    const ua=navigator.userAgent.toLowerCase();
    if(ua.includes('win')){
        el.innerHTML=t('🪟 <b>Windows</b>: le porte appaiono come <b>COM3</b>, <b>COM4</b>...<br>Se non vedi porte → installa driver <b>CP210x</b> o <b>CH340</b>');
    }else if(ua.includes('mac')){
        el.innerHTML=t('🍎 <b>macOS</b>: le porte appaiono come <b>/dev/cu.usbserial-XXX</b><br>Se non vedi porte → installa driver da Silicon Labs + Riavvia');
    }else{
        el.innerHTML=t('🐧 <b>Linux</b>: le porte appaiono come <b>/dev/ttyUSB0</b> o <b>/dev/ttyACM0</b><br>Se non vedi porte →') + ' <code>sudo usermod -a -G dialout $USER</code> ' + t('e rilogga');
    }
}

// ═══ USB Auto-Refresh ═══
let _usbPollTimer=null;
function startUsbPolling(){
    if(_usbPollTimer)return;
    _usbPollTimer=setInterval(async()=>{
        const d=await apiFetch('system/ports');
        const ports=(d&&d.ports)?d.ports:[];
        const dot=document.getElementById('usb-dot');
        if(APP.selectedPort){
            const stillThere=ports.some(p=>p.port===APP.selectedPort);
            if(!stillThere){
                APP.selectedPort=null;
                updateUsbIndicator();
                showToast(t('⚠️ Dispositivo USB disconnesso'));
            }
        }else if(ports.length>0&&!APP.selectedPort){
            if(dot)dot.className='usb-dot available';
        }
    },5000);
}
function stopUsbPolling(){if(_usbPollTimer){clearInterval(_usbPollTimer);_usbPollTimer=null;}}

async function scanUsbPorts(){
    const list=document.getElementById('usb-ports-list');
    const dot=document.getElementById('usb-dot');
    if(!list)return;
    if(dot)dot.className='usb-dot scanning';
    list.innerHTML='<div style="color:var(--text-muted);font-size:0.75rem;text-align:center;padding:0.5rem;">🔍 Scansione porte USB...</div>';
    
    const d=await apiFetch('system/ports');
    const ports=(d&&d.ports)?d.ports:[];
    
    if(ports.length===0){
        list.innerHTML='<div style="color:var(--warning);font-size:0.75rem;padding:0.5rem;">⚠️ Nessuna porta trovata.<br><br>Verifica:<br>• Cavo USB <b>dati</b> (non solo ricarica)<br>• Driver <b>CP210x</b> o <b>CH340</b> installati<br>• Dispositivo <b>acceso</b></div>';
        if(dot)dot.className='usb-dot disconnected';
        return;
    }
    
    list.innerHTML='';
    ports.forEach(p=>{
        const item=document.createElement('div');
        item.className='usb-port-item'+(APP.selectedPort===p.port?' selected':'');
        item.innerHTML=`<span class="port-name">🔌 ${p.port}</span><span class="port-desc">${p.description||''}${p.manufacturer?' — '+p.manufacturer:''}</span>`;
        item.onclick=()=>selectUsbPort(p.port, p.description);
        list.appendChild(item);
    });
    
    // Se non c'è una porta selezionata e ce n'è solo una, selezionala automaticamente
    if(!APP.selectedPort&&ports.length===1){
        selectUsbPort(ports[0].port, ports[0].description);
    }
    
    updateUsbIndicator();
}

function selectUsbPort(port, desc){
    APP.selectedPort=port;
    
    // Aggiorna UI lista
    document.querySelectorAll('.usb-port-item').forEach(el=>{
        el.classList.toggle('selected', el.querySelector('.port-name').textContent.includes(port));
    });
    
    // Aggiorna info
    const info=document.getElementById('usb-selected-info');
    if(info) info.innerHTML=`✅ <b>${port}</b> selezionata — tutti i comandi useranno questa porta`;
    
    updateUsbIndicator();
    showToast(t('🔌 Porta') + ` ${port} ` + t('selezionata'));
    
    // Chiudi pannello
    setTimeout(()=>{
        const panel=document.getElementById('usb-panel');
        if(panel)panel.style.display='none';
    },800);
}

function deselectUsbPort(){
    APP.selectedPort=null;
    updateUsbIndicator();
    document.querySelectorAll('.usb-port-item').forEach(el=>el.classList.remove('selected'));
    const info=document.getElementById('usb-selected-info');
    if(info) info.innerHTML='';
}

function updateUsbIndicator(){
    const dot=document.getElementById('usb-dot');
    const label=document.getElementById('usb-label');
    if(APP.selectedPort){
        if(dot)dot.className='usb-dot connected';
        if(label)label.textContent=APP.selectedPort;
    }else{
        if(dot)dot.className='usb-dot disconnected';
        if(label)label.textContent=t('Nessuna porta');
    }
}

// Ritorna l'argomento --port da aggiungere ai comandi CLI
function getPortArg(){
    return APP.selectedPort ? `--port ${APP.selectedPort} ` : '';
}

// ── CARICA DATABASE INFO PARAMETRI ─────────────────────────
async function loadParamsInfo(){
    try{
        const r=await fetch('/api/data/params_info');
        APP.paramsInfo=await r.json();
    }catch(e){ console.log('params_info non caricato, uso fallback'); }
}

// ── NAVIGAZIONE SPA ────────────────────────────────────────
function navigateTo(id){
    document.querySelectorAll('.section').forEach(s=>s.classList.remove('active'));
    document.querySelectorAll('.nav-tab').forEach(_tab=>_tab.classList.remove('active'));
    const sec=document.getElementById('section-'+id);
    const tab=document.querySelector(`[data-section="${id}"]`);
    if(sec)sec.classList.add('active');
    if(tab)tab.classList.add('active');
    APP.currentSection=id;
    window.scrollTo({top:0,behavior:'smooth'});
    // Auto-azioni per sezioni specifiche
    if(id==='nodo'||id==='cli')setTimeout(checkCLI,300);
    if(id==='dev')setTimeout(()=>{detectPorts();initCopyButtons();initOsPlayButtons();},300);
    if(id==='monitor')setTimeout(()=>{if(typeof initMonitor==='function')initMonitor();},100);
    setTimeout(()=>{initTooltips();initCopyButtons();},200);
}

// ── INIT ───────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded',()=>{
    document.querySelectorAll('.nav-tab').forEach(_tab=>{
        _tab.addEventListener('click',()=>navigateWithLicense(_tab.dataset.section));
    });
    loadSystemInfo();
    loadParamsInfo();
    navigateTo('guida');
    initCopyButtons();
    initTooltips();
    // 🔐 Check licenza all'avvio
    checkLicense();
    // 🔐 Check periodico revoca in background (ogni 30 min)
    startRevocationPolling();
    // 🌐 Init multilingua
    if(typeof initI18n==='function') initI18n();
    // 🩺 Auto-diagnosi all'avvio (dopo 2s per non rallentare il caricamento)
    setTimeout(()=>runDiagnosisStartup(), 2000);
    // 📦 Check dipendenze all'avvio (dopo 4s — fallback se diagnosi non trova problemi)
    setTimeout(()=>checkDepsStartup(), 4000);
    // Auto-scan porte USB all'avvio (silenzioso)
    setTimeout(async ()=>{
        const d=await apiFetch('system/ports');
        if(d&&d.ports&&d.ports.length===1){
            selectUsbPort(d.ports[0].port, d.ports[0].description);
        }else if(d&&d.ports&&d.ports.length>1){
            updateUsbIndicator();
        }
        // Avvia USB auto-refresh polling (5s)
        startUsbPolling();
    }, 1000);
    // ⌨️ Terminal history: arrow keys per navigare comandi
    setTimeout(()=>{
        const termInput=document.getElementById('term-input');
        if(termInput)termInput.addEventListener('keydown',_termKeyHandler);
        const cliInput=document.getElementById('cli-term-input');
        if(cliInput)cliInput.addEventListener('keydown',function(e){
            if(e.key==='ArrowUp'){
                e.preventDefault();
                if(_cmdHistoryIdx>0){_cmdHistoryIdx--;cliInput.value=_cmdHistory[_cmdHistoryIdx];}
            }else if(e.key==='ArrowDown'){
                e.preventDefault();
                if(_cmdHistoryIdx<_cmdHistory.length-1){_cmdHistoryIdx++;cliInput.value=_cmdHistory[_cmdHistoryIdx];}
                else{_cmdHistoryIdx=_cmdHistory.length;cliInput.value='';}
            }else if(e.key==='Enter'){cliTermRunInput();}
        });
    },500);
});

// ── API ────────────────────────────────────────────────────
async function apiFetch(ep,opt={}){
    try{const r=await fetch('/api/'+ep,{headers:{'Content-Type':'application/json'},...opt});return await r.json();}
    catch(e){console.error('API:',e);return null;}
}

async function loadSystemInfo(){
    APP.systemInfo=await apiFetch('system/info');
    if(APP.systemInfo){
        const i=APP.systemInfo;
        const el=document.getElementById('sys-os');
        if(el&&i.os){const em={windows:'🪟',macos:'🍎',linux:'🐧'};el.textContent=`${em[i.os.os]||'💻'} ${i.os.os_name} ${i.os.os_release}`;}
        const py=document.getElementById('sys-python');
        if(py&&i.python)py.textContent=i.python.python_installed?`✅ Python ${i.python.python_version}`:'❌ Python non trovato';
    }
}

// ── TOOLTIP ℹ️ DINAMICO DAL JSON ───────────────────────────
function initTooltips(){
    document.querySelectorAll('.info-btn[data-param]').forEach(btn=>{
        if(btn.dataset.tooltipInit)return; // Skip se già inizializzato
        btn.dataset.tooltipInit='1';
        const param=btn.dataset.param;
        btn.addEventListener('mouseenter',(e)=>showTooltipHover(e,param));
        btn.addEventListener('mouseleave',hideTooltipHover);
    });
}

function showTooltipHover(e,paramId){
    hideTooltipHover();
    const info=APP.paramsInfo[paramId];
    if(!info)return;
    const tip=document.createElement('div');
    tip.id='hover-tooltip';
    // 🌐 Traduci i testi del tooltip tramite t()
    const _name = t(info.name||'');
    const _desc = t(info.desc||'');
    const _rec = t(info.recommended||'');
    const _recLabel = t('Consigliato');
    tip.innerHTML=`<strong style="color:var(--accent)">${_name}</strong><br><span style="font-size:0.8rem">${_desc}</span><br><span style="font-size:0.75rem;color:var(--text-muted)">⚙️ ${_recLabel}: ${_rec}</span>`;
    tip.style.cssText=`position:fixed;z-index:300;background:var(--bg-card);border:1px solid var(--accent);padding:0.8rem;border-radius:8px;max-width:320px;font-size:0.85rem;color:var(--text-primary);box-shadow:var(--glow-strong);pointer-events:none;`;
    document.body.appendChild(tip);
    const rect=e.target.getBoundingClientRect();
    tip.style.left=Math.min(rect.right+8,window.innerWidth-340)+'px';
    tip.style.top=Math.max(rect.top-20,8)+'px';
}

function hideTooltipHover(){
    const _tip=document.getElementById('hover-tooltip');
    if(_tip)_tip.remove();
}

function showInfo(paramId){
    const info=APP.paramsInfo[paramId];
    if(!info){
        // Fallback per parametri non nel JSON
        const fallbacks={
            region:{name:'Regione LoRa',desc:'Banda 868 MHz per Italia. OBBLIGATORIO EU_868.',recommended:'EU_868',warning:'Regione sbagliata = ILLEGALE!',tip:'Imposta subito dopo flash.',example:'meshtastic --set lora.region EU_868'},
        };
        const fb=fallbacks[paramId];
        if(fb)return showInfoModal(fb);  // showInfoModal ora traduce con t()
        return;
    }
    showInfoModal(info);  // showInfoModal ora traduce con t()
}

function showInfoModal(info){
    const o=document.getElementById('modal-overlay');if(!o)return;
    // 🌐 Traduci TUTTI i campi info tramite t() prima di inserirli nel DOM
    document.getElementById('modal-title').textContent='ℹ️ '+t(info.name||'');
    document.getElementById('modal-desc').textContent=t(info.desc||'');
    document.getElementById('modal-recommended').textContent=t(info.recommended||'—');
    document.getElementById('modal-warning').textContent=t(info.warning||'Nessun warning.');
    document.getElementById('modal-tip').textContent=t(info.tip||'—');
    const exEl=document.getElementById('modal-example');
    if(exEl)exEl.textContent=info.example||'';  // Esempi CLI: non tradurre
    o.classList.add('active');
}

function closeModal(){document.getElementById('modal-overlay')?.classList.remove('active');}
function closeInfoModal(){closeModal();}
function checkNode(){if(APP.selectedPort)cliRun('--info');else showToast(t('⚠️ Seleziona prima una porta USB'));}

// ── COPIA-INCOLLA ──────────────────────────────────────────
function initCopyButtons(){
    document.querySelectorAll('.cli-block').forEach(block=>{
        if(block.querySelector('.copy-btn'))return;
        const btn=document.createElement('button');
        btn.className='copy-btn';btn.textContent='📋 COPIA';
        btn.onclick=()=>copyCommand(block,btn);
        block.appendChild(btn);
    });
}

async function copyCommand(block,btn){
    const code=block.querySelector('code')?.textContent||block.textContent.replace('📋 COPIA','').trim();
    try{await navigator.clipboard.writeText(code);}
    catch(e){const ta=document.createElement('textarea');ta.value=code;document.body.appendChild(ta);ta.select();document.execCommand('copy');document.body.removeChild(ta);}
    btn.textContent='✅ Copiato!';btn.classList.add('copied');
    setTimeout(()=>{btn.textContent='📋 COPIA';btn.classList.remove('copied');},2000);
}

function copyText(text){
    navigator.clipboard.writeText(text).then(()=>showToast(t('📋 Copiato negli appunti!'))).catch(()=>{
        const ta=document.createElement('textarea');ta.value=text;document.body.appendChild(ta);ta.select();document.execCommand('copy');document.body.removeChild(ta);showToast(t('📋 Copiato!'));
    });
}

function showToast(msg,dur=2500){
    let _toast=document.getElementById('toast');
    if(!_toast){_toast=document.createElement('div');_toast.id='toast';_toast.style.cssText=`position:fixed;bottom:2rem;left:50%;transform:translateX(-50%);background:var(--accent);color:#000;padding:0.6rem 1.5rem;border-radius:8px;font-family:var(--font-display);font-size:0.85rem;font-weight:600;z-index:999;box-shadow:var(--glow-strong);transition:opacity 0.3s;opacity:0;`;document.body.appendChild(_toast);}
    _toast.textContent=msg;_toast.style.opacity='1';
    setTimeout(()=>_toast.style.opacity='0',dur);
}

// ── EXECUTION LOCK (previene doppio click) ─────────────────
let _execLock = false;

// ── RILEVA PORTE ───────────────────────────────────────────
// ── OS TAB SWITCH ──
function showOsTab(os){
    ['win','mac','linux'].forEach(id=>{
        const el=document.getElementById('os-'+id);
        const tab=document.getElementById('os-tab-'+id);
        if(el)el.style.display=id===os?'block':'none';
        if(tab){tab.className=id===os?'btn btn-primary':'btn btn-secondary';}
    });
}

// ── DEV TERMINAL: esegue comando di sistema nel terminale dev ──
async function devExec(cmd){
    if(_execLock)return;
    _execLock=true;
    try{
    const _term=document.getElementById('dev-terminal');
    if(!_term)return;
    _term.scrollIntoView({behavior:'smooth',block:'center'});
    
    // Comandi che richiedono admin (più precisi)
    const needsAdmin=cmd.match(/^(sudo |chkdsk|sfc |DISM |powercfg|netsh |Start-Mp|Update-Mp|Optimize-Volume|cleanmgr|diskutil|fsck|fstrim|systemctl mask|systemctl unmask|modprobe|udevadm|ufw |update-grub)/i)
        || cmd.match(/Remove-Item.*Windows\\Temp/i)
        || cmd.match(/Remove-Item.*C:\\Windows/i)
        || cmd.match(/netsh advfirewall/i);
    
    if(needsAdmin){
        termAppendTo('dev-terminal', `\n⚠️ RICHIEDE PRIVILEGI AMMINISTRATORE`, 'error');
        termAppendTo('dev-terminal', `$ ${cmd}`, 'prompt');
        if(!confirm(t('⚠️ Questo comando richiede i diritti di AMMINISTRATORE:')+`\n\n${cmd}\n\n`+t('🪟 Windows: Apri PowerShell come Admin')+`\n`+t('🍎 Mac: Il comando usa sudo (inserisci password)')+`\n`+t('🐧 Linux: Il comando usa sudo')+`\n\n`+t('Vuoi eseguirlo?'))){
            termAppendTo('dev-terminal', '❌ Annullato dall\'utente', 'info');
            return;
        }
    }else{
        termAppendTo('dev-terminal', `\n$ ${cmd}`, 'prompt');
    }
    
    termAppendTo('dev-terminal', '⏳ Esecuzione...', 'info');
    
    const d=await apiFetch('system/exec',{method:'POST',body:JSON.stringify({command:cmd})});
    // 🔧 FIX: usare _term (elemento terminale), NON t (funzione traduzione!)
    if(_term){const lines=_term.querySelectorAll('span');const last=lines[lines.length-1];if(last&&last.textContent.includes('⏳'))last.remove();}
    
    if(d){
        if(d.success){
            if(d.partial){
                termAppendTo('dev-terminal', d.stdout||t('⚠️ Completato parzialmente'), 'info');
            }else{
                termAppendTo('dev-terminal', d.stdout||t('✅ Eseguito'), 'output');
            }
            if(d.stderr&&d.stderr.length>0) termAppendTo('dev-terminal', d.stderr, 'error');
        }else if(d.error){
            termAppendTo('dev-terminal', '❌ '+t(d.error), 'error');
            if(d.stdout) termAppendTo('dev-terminal', d.stdout, 'output');
            if(d.needs_admin) termAppendTo('dev-terminal', t('💡 Esegui il terminale come Amministratore e riprova'), 'info');
        }
    }else{
        navigator.clipboard.writeText(cmd).catch(()=>{});
        termAppendTo('dev-terminal', '📋 Copiato negli appunti! Incolla nel tuo terminale.', 'info');
    }
    if(_term) _term.scrollTop=_term.scrollHeight;
    }finally{_execLock=false;}
}

// Wrappa ogni cli-block nelle sezioni OS in una riga con ▶ ESTERNO
function initOsPlayButtons(){
    ['os-win','os-mac','os-linux'].forEach(osId=>{
        const container=document.getElementById(osId);
        if(!container)return;
        container.querySelectorAll('.cli-block').forEach(block=>{
            if(block.parentElement.classList.contains('os-cmd-row'))return; // già wrappato
            const code=block.querySelector('code');
            if(!code)return;
            const cmd=code.textContent.trim();
            
            // Crea wrapper row
            const row=document.createElement('div');
            row.className='os-cmd-row';
            block.parentNode.insertBefore(row, block);
            row.appendChild(block); // sposta il block dentro la row
            
            // Crea ▶ button FUORI dal block
            const btn=document.createElement('button');
            btn.className='os-play';
            btn.textContent='▶';
            btn.title=t('Esegui comando');
            btn.onclick=()=>devExec(cmd);
            row.appendChild(btn);
        });
    });
}

async function detectPorts(){
    // Scrivi in tutte le sezioni che mostrano le porte
    const containers=[document.getElementById('ports-list'),document.getElementById('dev-ports-list')].filter(Boolean);
    containers.forEach(c=>c.innerHTML='<p style="color:var(--text-muted)">⏳ Rilevamento...</p>');
    const d=await apiFetch('system/ports');
    const html=d&&d.ports&&d.ports.length>0
        ? d.ports.map(p=>`<div class="card" style="padding:0.8rem;margin-bottom:0.5rem;"><span style="color:var(--accent);font-family:var(--font-display)">${p.port}</span> <span style="color:var(--text-secondary);font-size:0.8rem">${p.description}</span>${p.manufacturer?`<br><span style="color:var(--text-muted);font-size:0.75rem">${p.manufacturer}</span>`:''}</div>`).join('')
        : `<div class="alert alert-warning">${t("⚠️ Nessuna porta trovata.")} ${t("Verifica:")}<br>• ${t("Cavo USB")} <strong>${t("dati")}</strong> (${t("non solo ricarica")})<br>• ${t("Driver CP210x o CH340 installati")}<br>• ${t("Dispositivo acceso")}</div>`;
    containers.forEach(c=>c.innerHTML=html);
}

// ── SELEZIONA MODALITÀ CONFIG ──────────────────────────────
function selectConfigMode(mode){
    APP.configMode=mode;
    document.querySelectorAll('.mode-card').forEach(c=>c.classList.remove('active'));
    document.querySelector(`[data-mode="${mode}"]`)?.classList.add('active');
    ['auto','manual','pro'].forEach(m=>{
        const el=document.getElementById('config-'+m);
        if(el){el.style.display=m===mode?'block':'none';}
    });
    if(mode==='auto')generateConfig('auto');
    // Reinizializza tooltip e copy buttons sugli elementi appena resi visibili
    setTimeout(()=>{initTooltips();initCopyButtons();},100);
}

// ── GENERA CONFIGURAZIONE ──────────────────────────────────
// Canali standard Italia
const ITALIA_CHANNELS = [
    {name:'MediumFast', psk:'AQ=='},
    {name:'Ita-Nord', psk:'hJ7/x9L+qJ5kL2nF8dG7hJ1vK4xM3nB5vC6xZ1aS2dQ='},
    {name:'Ita-Centro', psk:'hJ7/x9L+qJ5kL2nF8dG7hJ1vK4xM3nB5vC6xZ1aS2dQ='},
    {name:'Ita-Sud', psk:'hJ7/x9L+qJ5kL2nF8dG7hJ1vK4xM3nB5vC6xZ1aS2dQ='},
    {name:'Ita-Help', psk:'hJ7/x9L+qJ5kL2nF8dG7hJ1vK4xM3nB5vC6xZ1aS2dQ='},
    {name:'Ita-Test', psk:'hJ7/x9L+qJ5kL2nF8dG7hJ1vK4xM3nB5vC6xZ1aS2dQ='},
    {name:'Ita-Shop', psk:'hJ7/x9L+qJ5kL2nF8dG7hJ1vK4xM3nB5vC6xZ1aS2dQ='},
    {name:'Italia', psk:'mQ=='}
];

function fillDefaultChannels(prefix){
    ITALIA_CHANNELS.forEach((ch,i)=>{
        const nameEl=document.getElementById(`${prefix}-ch${i}-name`);
        const pskEl=document.getElementById(`${prefix}-ch${i}-psk`);
        const upEl=document.getElementById(`${prefix}-ch${i}-up`);
        const dnEl=document.getElementById(`${prefix}-ch${i}-dn`);
        if(nameEl) nameEl.value=ch.name;
        if(pskEl) pskEl.value=ch.psk;
        if(upEl) upEl.checked=true;
        if(dnEl) dnEl.checked=true;
    });
    showToast(t('🔄 Canali standard Italia inseriti'));
}

function collectChannels(prefix){
    const channels=[];
    let truncated=false;
    for(let i=0;i<8;i++){
        let name=(document.getElementById(`${prefix}-ch${i}-name`)?.value||'').trim();
        const psk=(document.getElementById(`${prefix}-ch${i}-psk`)?.value||'').trim();
        const up=document.getElementById(`${prefix}-ch${i}-up`)?.checked??true;
        const dn=document.getElementById(`${prefix}-ch${i}-dn`)?.checked??true;
        // Meshtastic limita i nomi canale a 11 caratteri
        if(name.length>11){
            name=name.substring(0,11);
            const _nameEl=document.getElementById(`${prefix}-ch${i}-name`);
            if(_nameEl) _nameEl.value=name;
            truncated=true;
        }
        if(name||psk){
            channels.push({index:i, name, psk, uplink:up, downlink:dn});
        }
    }
    if(truncated) showToast(t('⚠️ Nomi canale troncati a 11 caratteri (limite Meshtastic)'));
    return channels;
}

async function generateConfig(mode){
    const p={region:"EU_868",modem_preset:"MEDIUM_FAST"};
    if(mode==='auto'){
        p.use_autoconfig=true;p.mqtt_enabled=true;p.role="CLIENT";
    }else if(mode==='manual'){
        p.long_name=document.getElementById('cfg-longname-man')?.value||'';
        p.short_name=document.getElementById('cfg-shortname-man')?.value||'';
        p.role=document.getElementById('cfg-role')?.value||'CLIENT';
        p.mqtt_enabled=document.getElementById('cfg-mqtt')?.checked??true;
        // Canali personalizzati manuale
        if(document.getElementById('cfg-man-use-custom-ch')?.checked){
            p.use_autoconfig=false;
            p.custom_channels=collectChannels('man');
        }else{
            p.use_autoconfig=true;
        }
    }else if(mode==='pro'){
        p.long_name=document.getElementById('cfg-longname')?.value||'';
        p.short_name=document.getElementById('cfg-shortname')?.value||'';
        p.role=document.getElementById('cfg-role-pro')?.value||'CLIENT';
        p.mqtt_enabled=document.getElementById('cfg-mqtt-pro')?.checked??true;
        p.hop_limit=parseInt(document.getElementById('cfg-hoplimit')?.value)||3;
        p.tx_power=parseInt(document.getElementById('cfg-txpower')?.value)||27;
        p.rebroadcast_mode=document.getElementById('cfg-rebroadcast')?.value||'ALL';
        // GPS
        p.gps_enabled=document.getElementById('cfg-gps')?.value||'true';
        p.smart_position=document.getElementById('cfg-smartpos')?.value||'true';
        p.position_broadcast_secs=document.getElementById('cfg-posbcast')?.value||'900';
        p.gps_update_interval=document.getElementById('cfg-gpsinterval')?.value||'120';
        // Fixed position
        const lat=document.getElementById('cfg-lat')?.value;
        const lon=document.getElementById('cfg-lon')?.value;
        if(lat&&lon){p.latitude=lat;p.longitude=lon;p.altitude=document.getElementById('cfg-alt')?.value||'';}
        // MQTT
        p.mqtt_encryption=document.getElementById('cfg-mqtt-enc')?.checked??true;
        // Connettività
        p.bluetooth_enabled=document.getElementById('cfg-ble')?.value||'true';
        p.wifi_enabled=document.getElementById('cfg-wifi')?.value||'false';
        p.screen_on_secs=document.getElementById('cfg-screen')?.value||'60';
        // Telemetria
        p.telemetry_device_interval=document.getElementById('cfg-telem-dev')?.value||'900';
        p.telemetry_environment=document.getElementById('cfg-telem-env')?.value||'false';
        // Energia
        p.power_saving=document.getElementById('cfg-powersave')?.value||'false';
        p.led_disabled=document.getElementById('cfg-led')?.value||'false';
        // Moduli
        p.neighbor_info=document.getElementById('cfg-neighbor')?.checked||false;
        p.store_forward=document.getElementById('cfg-storefw')?.checked||false;
        p.range_test=document.getElementById('cfg-rangetest')?.checked||false;
        // Canali personalizzati pro
        if(document.getElementById('cfg-pro-use-custom-ch')?.checked){
            p.use_autoconfig=false;
            p.custom_channels=collectChannels('pro');
        }else{
            p.use_autoconfig=true;
        }
    }
    const d=await apiFetch('config/commands',{method:'POST',body:JSON.stringify(p)});
    if(d)displayCommands(d);
}

function displayCommands(d){
    const c=document.getElementById('config-output');if(!c)return;
    let h='';
    if(d.validation){
        if(d.validation.errors.length)h+=d.validation.errors.map(e=>`<div class="alert alert-danger">${e}</div>`).join('');
        if(d.validation.warnings.length)h+=d.validation.warnings.map(w=>`<div class="alert alert-warning">${w}</div>`).join('');
    }
    if(d.commands){
        h+='<div class="card config-highlight"><div class="card-title">💻 Comandi CLI generati ✅</div>';
        d.commands.forEach(cmd=>{
            const cmdArg=cmd.command.replace('meshtastic ','').replace(/"/g,'&quot;').replace(/'/g,"\\'");
            h+=`<div class="cli-run-row">
                <span class="cli-desc">${cmd.description}</span>
                <div class="cli-block" style="margin:0;flex:1"><code>${cmd.command}</code></div>
                <button class="btn btn-sm btn-primary cli-exec" onclick="navigateTo('cli');setTimeout(()=>cliRun('${cmdArg}'),400)">▶</button>
            </div>`;
        });
        h+='</div>';
    }
    if(d.script){
        h+=`<div class="card config-highlight" style="margin-top:1rem"><div class="card-title">📋 Script completo (copia tutto)</div><div class="cli-block"><code>${d.script.replace(/\n/g,'<br>')}</code></div></div>`;
    }
    c.innerHTML=h;
    initCopyButtons();
    setTimeout(()=>c.scrollIntoView({behavior:'smooth',block:'start'}),200);
}

// ── QR CODE (cerca tutti i container) ───────────────────────
const AUTOCONFIG_URL="https://meshtastic.org/e/#CgsSAQEoATABOgIIIAo0EiCEnv_H0v6onmQvacXx0buEnW8rjEzecHm8LrFnVpLZ1BoISXRhLU5vcmQoATABOgIIIAo2EiCEnv_H0v6onmQvacXx0buEnW8rjEzecHm8LrFnVpLZ1BoKSXRhLUNlbnRybygBMAE6AgggCjMSIISe_8fS_qieZC9pxfHRu4SdbyuMTN5webwusWdWktnUGgdJdGEtU3VkKAEwAToCCCAKNBIghJ7_x9L-qJ5kL2nF8dG7hJ1vK4xM3nB5vC6xZ1aS2dQaCEl0YS1IZWxwKAEwAToCCCAKNBIghJ7_x9L-qJ5kL2nF8dG7hJ1vK4xM3nB5vC6xZ1aS2dQaCEl0YS1UZXN0KAEwAToCCCAKNBIghJ7_x9L-qJ5kL2nF8dG7hJ1vK4xM3nB5vC6xZ1aS2dQaCEl0YS1TaG9wKAEwAToCCCAKExIBmRoGSXRhbGlhKAEwAToCCCASGAgBEAQY-gEgCygFOANABEgBUBtoAcgGAQ";

async function generateQR(targetId){
    const containers=[targetId,'qr-container','qr-container-pro','qr-wizard'].map(id=>document.getElementById(id)).filter(Boolean);
    const c=containers[0];
    if(!c)return;
    c.innerHTML='<p style="color:var(--text-muted)">⏳ Generazione QR...</p>';

    // Raccogli configurazione canali: se l'utente ha canali custom, inviali
    const payload={region:"EU_868",modem_preset:"MEDIUM_FAST"};

    // Determina se siamo in Pro o Manual mode
    const proCustom=document.getElementById('cfg-pro-use-custom-ch')?.checked;
    const manCustom=document.getElementById('cfg-man-use-custom-ch')?.checked;

    if(proCustom){
        payload.custom_channels=collectChannels('pro');
        payload.hop_limit=parseInt(document.getElementById('cfg-hoplimit')?.value)||3;
        payload.tx_power=parseInt(document.getElementById('cfg-txpower')?.value)||27;
    }else if(manCustom){
        payload.custom_channels=collectChannels('man');
    }

    // Prova via server Python (genera URL protobuf dinamico)
    let useExternal=true;
    let qrUrl=AUTOCONFIG_URL;
    try{
        const d=await apiFetch('config/qrcode',{method:'POST',body:JSON.stringify(payload)});
        if(d&&d.url) qrUrl=d.url;
        if(d&&d.qr_code){
            c.innerHTML=_buildQrHtml(null, d.qr_code, qrUrl);
            useExternal=false;
        }
    }catch(e){}

    // Fallback: API esterna per generare QR
    if(useExternal){
        const encUrl=encodeURIComponent(qrUrl);
        c.innerHTML=_buildQrHtml(encUrl, null, qrUrl);
    }
}

function _buildQrHtml(encUrl, b64img, fullUrl){
    const imgTag=b64img
        ? `<img src="data:image/png;base64,${b64img}" alt="QR" style="max-width:200px;border:2px solid var(--accent);border-radius:8px;">`
        : `<img src="https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=${encUrl}&bgcolor=0a0e14&color=00ff88" alt="QR Code Meshtastic" style="max-width:200px;border:2px solid var(--accent);border-radius:8px;" onerror="this.style.display='none'">`;
    return `${imgTag}
        <p style="font-size:0.75rem;color:var(--text-muted);margin-top:0.5rem">${t('Scansiona con app Meshtastic per configurare')}</p>
        <div style="margin-top:0.8rem;display:flex;gap:0.4rem;justify-content:center;flex-wrap:wrap;">
            <a href="${fullUrl}" target="_blank" class="btn btn-sm btn-primary" style="font-size:0.72rem;">📱 ${t('Apri con App Meshtastic')}</a>
            <button class="btn btn-sm btn-secondary" onclick="copyText('${fullUrl.replace(/'/g,"\\'")}');" style="font-size:0.72rem;">📋 ${t('Copia Link')}</button>
        </div>
        <div style="margin-top:0.5rem;background:var(--bg-input);border:1px solid var(--border);border-radius:6px;padding:0.4rem 0.6rem;max-width:400px;margin-left:auto;margin-right:auto;">
            <code style="font-size:0.6rem;word-break:break-all;color:var(--accent);">${fullUrl.length>120?fullUrl.substring(0,120)+'...':fullUrl}</code>
        </div>`;
}

// ── CALCOLATORI ────────────────────────────────────────────
function calcBattery(){
    const mah=parseFloat(document.getElementById('calc-mah')?.value)||0;
    const ma=parseFloat(document.getElementById('calc-ma')?.value)||0;
    const r=document.getElementById('calc-battery-result');
    if(r&&mah>0&&ma>0){const h=(mah/ma).toFixed(1);r.innerHTML=`<strong style="color:var(--accent)">${h} ore</strong> (${(h/24).toFixed(1)} giorni)`;}
}
function calcRF(){
    const dbm=document.getElementById('calc-dbm'),mw=document.getElementById('calc-mw');
    if(!dbm||!mw)return;
    if(document.activeElement===dbm){const v=parseFloat(dbm.value);if(!isNaN(v))mw.value=Math.pow(10,v/10).toFixed(2);}
    else{const v=parseFloat(mw.value);if(!isNaN(v)&&v>0)dbm.value=(10*Math.log10(v)).toFixed(1);}
}
function calcAntenna(){
    const freq=parseFloat(document.getElementById('calc-freq')?.value)||868;
    const r=document.getElementById('calc-antenna-result');
    if(r){const q=((300/freq)*100/4).toFixed(1);const h=((300/freq)*100/2).toFixed(1);r.innerHTML=`λ/4 = <strong style="color:var(--accent)">${q} cm</strong> | λ/2 = <strong style="color:var(--accent)">${h} cm</strong>`;}
}

// ── ASSISTENTE IA ──────────────────────────────────────────
function getWizardQuestions(){return[
    {id:'location',q:t('Dove vuoi mettere il nodo?'),opts:[
        {val:'outdoor_high',label:t('🏔️ Montagna/torre/traliccio'),tip:t('Posizione elevata con vista a 360°')},
        {val:'rooftop',label:t('🏠 Tetto/mansarda di casa'),tip:t('Posizione fissa elevata in area urbana')},
        {val:'indoor',label:t('🏢 Dentro casa/ufficio'),tip:t('Posizione interna, segnale limitato')},
        {val:'mobile',label:t('🚶 Portatile (zaino/tasca)'),tip:t('In movimento, batteria importante')},
        {val:'vehicle',label:t('🚗 Veicolo (auto/bici/moto)'),tip:t('Tracking GPS in movimento')},
    ]},
    {id:'has_gps',q:t('Il tuo dispositivo ha il GPS integrato?'),opts:[
        {val:'yes',label:t('✅ Sì, ha il GPS')},
        {val:'no',label:t('❌ No, senza GPS')},
        {val:'unknown',label:t('🤷 Non lo so')},
    ]},
    {id:'power',q:t('Come viene alimentato?'),opts:[
        {val:'battery',label:t('🔋 Solo batteria')},
        {val:'solar',label:t('☀️ Solare + batteria')},
        {val:'usb',label:t('🔌 USB/rete elettrica 24/7')},
        {val:'battery_usb',label:t('🔋🔌 Batteria + ricarica USB')},
    ]},
    {id:'purpose',q:t('Qual è lo scopo principale?'),opts:[
        {val:'chat',label:t('💬 Chattare con altri')},
        {val:'relay',label:t('📡 Estendere la copertura')},
        {val:'track',label:t('📍 Tracciare posizione')},
        {val:'sensor',label:t('🌡️ Monitorare sensori')},
        {val:'emergency',label:t('🆘 Comunicazione emergenza')},
    ]},
    {id:'multi_node',q:t('Hai altri nodi Meshtastic?'),opts:[
        {val:'only_one',label:t('1️⃣ Questo è il mio unico nodo')},
        {val:'two_three',label:t('2️⃣ Ho 2-3 nodi')},
        {val:'many',label:t('🔢 Ho 4+ nodi')},
    ]},
];}

let wizardStep=0, wizardAnswers={};

function startWizard(){
    wizardStep=0;wizardAnswers={};
    renderWizardStep();
}

function renderWizardStep(){
    const c=document.getElementById('wizard-content');if(!c)return;
    const _wq=getWizardQuestions();
    if(wizardStep>=_wq.length){
        renderWizardResult();return;
    }
    const q=_wq[wizardStep];
    let h=`<div class="card" style="border-color:var(--accent)">`;
    h+=`<div class="card-title">${t('Domanda')} ${wizardStep+1}/${_wq.length}</div>`;
    h+=`<h3 style="color:var(--text-primary);margin-bottom:1rem">${q.q}</h3>`;
    h+=`<div class="grid-2">`;
    q.opts.forEach(o=>{
        h+=`<div class="role-card" onclick="wizardAnswer('${q.id}','${o.val}')" style="cursor:pointer">
            <div class="role-name">${o.label}</div>
            <div class="role-desc">${o.tip||''}</div>
        </div>`;
    });
    h+=`</div></div>`;
    c.innerHTML=h;
}

function wizardAnswer(id,val){
    wizardAnswers[id]=val;
    wizardStep++;
    renderWizardStep();
}

function renderWizardResult(){
    const a=wizardAnswers;
    const c=document.getElementById('wizard-content');if(!c)return;
    
    // Logica di raccomandazione
    let role='CLIENT', tips=[], warnings=[];
    
    // Ruolo basato su posizione e scopo
    if(a.location==='outdoor_high'&&a.purpose==='relay'&&a.power!=='battery'){
        role='ROUTER';
        tips.push(t('Posizione eccezionale + relay + alimentazione fissa = ROUTER è appropriato.'));
        warnings.push(t('Assicurati di avere vista a 360° libera. Se non è una vera cima, usa ROUTER_LATE.'));
    }else if(a.location==='rooftop'&&a.purpose==='relay'){
        role='ROUTER_LATE';
        tips.push(t('Tetto in città = ROUTER_LATE. Copre zone morte senza disturbare la rete.'));
    }else if(a.location==='rooftop'&&a.multi_node!=='only_one'){
        role='CLIENT_BASE';
        tips.push(t('Nodo sul tetto con altri nodi tuoi = CLIENT_BASE. Metti i tuoi nodi nei Preferiti.'));
    }else if(a.purpose==='track'||a.location==='vehicle'){
        role='TRACKER';
        tips.push(t('Tracking GPS = TRACKER. Si sveglia, invia posizione, dorme. Batteria lunga.'));
    }else if(a.purpose==='sensor'){
        role='SENSOR';
        tips.push(t('Monitoraggio sensori = SENSOR. Si sveglia, legge, invia, dorme.'));
    }else if(a.location==='outdoor_high'&&a.power==='solar'){
        role='REPEATER';
        tips.push(t('Solare su montagna = REPEATER. Invisibile, zero manutenzione, puro relay.'));
    }else{
        role='CLIENT';
        tips.push(t('CLIENT è il ruolo giusto per la maggior parte degli utenti.'));
    }

    // Consigli GPS
    let gpsAdvice='';
    if(a.has_gps==='yes'){
        gpsAdvice=t('✅ GPS: Abilita GPS e Smart Position.');
        tips.push(t('Con GPS attivo, abilita Smart Position per risparmiare airtime.'));
    }else if(a.has_gps==='no'){
        gpsAdvice=t('📍 GPS: Imposta posizione fissa con coordinate manuali.');
        tips.push(t('Senza GPS, imposta lat/lon/alt manualmente per apparire sulla mappa.'));
    }

    // Consigli energia
    let powerAdvice='';
    if(a.power==='battery'){
        powerAdvice=t('🔋 Abilita risparmio energetico. Riduci TX a 17-20 dBm.');
        tips.push(t('Con batteria: power.is_power_saving = true, tx_power = 17-20 dBm.'));
    }else if(a.power==='solar'){
        powerAdvice=t('☀️ Nodo solare: display off, BLE off, risparmio energetico attivo.');
    }else{
        powerAdvice=t('🔌 Alimentazione fissa: puoi usare TX max (27 dBm) e display sempre acceso.');
    }

    // Multi-nodo
    if(a.multi_node==='two_three'||a.multi_node==='many'){
        tips.push(t('Con più nodi: metti 1 su CLIENT/CLIENT_BASE, gli altri su CLIENT_MUTE.'));
    }
    
    // Rendering risultato
    let h=`<div class="card" style="border-color:var(--accent)">
        <div class="card-title">🎯 ${t('Configurazione Consigliata')}</div>
        <div style="text-align:center;padding:1rem">
            <div style="font-size:3rem;margin-bottom:0.5rem">${{CLIENT:'🟢',CLIENT_MUTE:'🟢',CLIENT_BASE:'🟡',TRACKER:'🔵',SENSOR:'🔵',ROUTER:'🔴',ROUTER_LATE:'🟡',REPEATER:'🔴'}[role]||'🟢'}</div>
            <div style="font-family:var(--font-display);font-size:1.5rem;color:var(--accent)">${role}</div>
        </div>
        <div style="margin:1rem 0">
            <div class="alert alert-success">📡 <strong>${t('Regione')}:</strong> EU_868 | <strong>Preset:</strong> MediumFast</div>
            <div class="alert alert-info">${gpsAdvice}</div>
            <div class="alert alert-info">${powerAdvice}</div>
        </div>`;

    tips.forEach(_tip=>{h+=`<p style="margin:0.5rem 0;font-size:0.9rem">💡 ${_tip}</p>`;});
    warnings.forEach(_wrn=>{h+=`<div class="alert alert-warning">⚠️ ${_wrn}</div>`;});

    h+=`<div style="margin-top:1.5rem;display:flex;gap:0.5rem;flex-wrap:wrap">
        <button class="btn btn-primary" onclick="applyWizardConfig('${role}')">⚙️ ${t('Genera comandi per')} ${role}</button>
        <button class="btn btn-secondary" onclick="startWizard()">🔄 ${t('Ricomincia')}</button>
    </div></div>`;
    
    c.innerHTML=h;
}

async function applyWizardConfig(role){
    const a=wizardAnswers;
    const c=document.getElementById('wizard-content');
    if(!c)return;
    
    // Aggiungi un container per i comandi sotto il risultato
    let outputDiv=document.getElementById('wizard-output');
    if(!outputDiv){
        outputDiv=document.createElement('div');
        outputDiv.id='wizard-output';
        c.appendChild(outputDiv);
    }
    outputDiv.innerHTML='<p style="color:var(--text-muted);margin:1rem 0">'+t('⏳ Generazione comandi in corso...')+'</p>';
    
    // Prepara parametri basati sulle risposte del wizard
    const params={
        region:'EU_868',
        modem_preset:'MEDIUM_FAST',
        role: role,
        use_autoconfig: true,
        mqtt_enabled: true,
        long_name: '',
        short_name: '',
    };
    
    // GPS
    if(a.has_gps==='no'){
        // suggerisci posizione fissa
    }
    
    // Potenza
    if(a.power==='battery'){
        params.tx_power=20;
    }
    
    // Genera comandi via API
    const d=await apiFetch('config/commands',{method:'POST',body:JSON.stringify(params)});
    
    if(!d){
        outputDiv.innerHTML='<div class="alert alert-danger">'+t('Errore nella generazione comandi')+'</div>';
        return;
    }
    
    let h='';
    
    // Titolo
    h+=`<div class="card config-highlight" style="border-color:var(--accent);margin-top:1.5rem;">
        <div class="card-title">💻 ${t('Comandi CLI per')} ${role} — ${t('Copia e Incolla nel Terminale')}</div>
        <p style="font-size:0.85rem;color:var(--text-secondary);margin-bottom:1rem;">${t('Collega il dispositivo via USB e esegui questi comandi uno alla volta nel terminale.')}</p>`;
    
    // Validazione
    if(d.validation){
        if(d.validation.errors.length)h+=d.validation.errors.map(e=>`<div class="alert alert-danger">${e}</div>`).join('');
        if(d.validation.warnings.length)h+=d.validation.warnings.map(w=>`<div class="alert alert-warning">${w}</div>`).join('');
    }
    
    // Comandi singoli con spiegazione
    if(d.commands){
        d.commands.forEach((cmd,i)=>{
            h+=`<div style="margin-top:1rem;">
                <p style="color:var(--text-secondary);font-size:0.82rem;"><strong>Step ${i+1}:</strong> ${cmd.description}</p>
                <div class="cli-block"><code>${cmd.command}</code></div>
            </div>`;
        });
    }
    h+=`</div>`;
    
    // Script completo copia tutto
    if(d.script){
        h+=`<div class="card config-highlight" style="margin-top:1rem;">
            <div class="card-title">📋 ${t('Script Completo — Copia Tutto in Un Colpo')}</div>
            <p style="font-size:0.8rem;color:var(--text-secondary);margin-bottom:0.5rem;">${t('Copia e incolla TUTTO nel terminale (ogni riga viene eseguita in sequenza):')}</p>
            <div class="cli-block"><code>${d.script.replace(/\n/g,'<br>')}</code></div>
        </div>`;
    }
    
    // Link autoconfigurazione + QR Code
    h+=`<div class="card" style="margin-top:1rem;">
        <div class="card-title">📱 ${t('Configurazione Rapida via App')}</div>
        <p style="font-size:0.85rem;color:var(--text-secondary);margin-bottom:1rem;">${t('In alternativa al CLI, puoi configurare i canali direttamente dall\'app Meshtastic sul telefono:')}</p>
        <div style="display:flex;gap:0.5rem;flex-wrap:wrap;margin-bottom:1rem;">
            <a href="${AUTOCONFIG_URL}" target="_blank" class="btn btn-primary">📱 ${t('Apri con App Meshtastic')}</a>
            <button class="btn btn-secondary" onclick="copyText(AUTOCONFIG_URL)">📋 ${t('Copia Link')}</button>
        </div>
        <div id="qr-wizard" style="text-align:center;"></div>
    </div>`;
    
    // Consigli aggiuntivi basati sulle risposte
    h+=`<div class="card" style="margin-top:1rem;">
        <div class="card-title">💡 ${t('Consigli per il Tuo Setup')}</div>`;

    // GPS advice
    if(a.has_gps==='yes'){
        h+=`<div class="alert alert-success">📍 <strong>GPS:</strong> ${t('Abilita GPS e Smart Position per aggiornare la posizione solo quando ti muovi.')}</div>
        <div class="cli-block"><code>meshtastic --set position.gps_enabled true</code></div>
        <div class="cli-block"><code>meshtastic --set position.position_broadcast_smart_enabled true</code></div>`;
    }else if(a.has_gps==='no'){
        h+=`<div class="alert alert-info">📍 <strong>${t('Senza GPS')}:</strong> ${t('Imposta una posizione fissa per apparire sulla mappa. Trova le coordinate su Google Maps (click destro → coordinate).')}</div>
        <div class="cli-block"><code>meshtastic --setlat TUA_LATITUDINE --setlon TUA_LONGITUDINE --setalt TUA_ALTITUDINE</code></div>`;
    }

    // Power advice
    if(a.power==='battery'){
        h+=`<div class="alert alert-info">🔋 <strong>${t('Batteria')}:</strong> ${t('Attiva risparmio energetico e riduci potenza TX.')}</div>
        <div class="cli-block"><code>meshtastic --set power.is_power_saving true</code></div>
        <div class="cli-block"><code>meshtastic --set lora.tx_power 20</code></div>`;
    }else if(a.power==='solar'){
        h+=`<div class="alert alert-info">☀️ <strong>${t('Solare')}:</strong> ${t('Disabilita display e BLE per massimo risparmio.')}</div>
        <div class="cli-block"><code>meshtastic --set power.is_power_saving true</code></div>
        <div class="cli-block"><code>meshtastic --set display.screen_on_secs 0</code></div>`;
    }

    // Multi-nodo advice
    if(a.multi_node==='two_three'||a.multi_node==='many'){
        h+=`<div class="alert alert-info">📡 <strong>Multi-nodo:</strong> ${t('Imposta gli altri nodi come CLIENT_MUTE per non congestionare la rete.')}</div>
        <div class="cli-block"><code>meshtastic --set device.role CLIENT_MUTE</code></div>`;
    }

    // Verifica finale
    h+=`<div style="margin-top:1rem;"><p style="color:var(--text-secondary);font-size:0.85rem;"><strong>${t('Ultimo step')}:</strong> ${t('Verifica che tutto sia configurato correttamente:')}</p>
        <div class="cli-block"><code>meshtastic --info</code></div>
    </div>`;
    
    h+=`</div>`;
    
    // Pulsanti azione finali
    h+=`<div style="margin-top:1.5rem;display:flex;gap:0.5rem;flex-wrap:wrap;">
        <button class="btn btn-secondary" onclick="startWizard()">🔄 ${t('Ricomincia Questionario')}</button>
        <button class="btn btn-secondary" onclick="navigateTo('nodo')">🔍 ${t('Testa con Terminale')}</button>
        <button class="btn btn-secondary" onclick="navigateTo('config')">⚙️ ${t('Vai alla Config Pro')}</button>
    </div>`;
    
    outputDiv.innerHTML=h;
    
    // Genera QR Code nel container dedicato
    setTimeout(()=>generateQR('qr-wizard'),500);
    
    // Inizializza copy buttons
    setTimeout(()=>{initCopyButtons();initTooltips();},300);
    
    // Scroll verso output
    setTimeout(()=>outputDiv.scrollIntoView({behavior:'smooth',block:'start'}),400);
}

// ── TERMINALE SEZIONE CLI (condivide logica con sezione Nodo) ────
function termAppendTo(termId, text, cls='output'){
    const _el=document.getElementById(termId);if(!_el)return;
    const line=document.createElement('span');
    line.className=cls;
    line.textContent=text+'\n';
    _el.appendChild(line);
    _el.scrollTop=_el.scrollHeight;
}

// Funzione UNIVERSALE — trova il terminale visibile e esegue lì
async function execCmd(cmd){
    if(_execLock)return;
    _execLock=true;
    try{
    // Comandi che modificano → chiedi conferma
    const modifyCmds=['--set ','--set-owner','--ch-set','--factory-reset','--reboot','--reset-nodedb','--remove-position','--setlat','--setlon','--configure'];
    const needsConfirm=modifyCmds.some(mc=>cmd.startsWith(mc));
    if(needsConfirm){
        const portInfo=APP.selectedPort?`\n🔌 Porta: ${APP.selectedPort}`:'';
        if(!confirm(t('⚠️ Vuoi eseguire questo comando?')+`\n\nmeshtastic ${cmd}${portInfo}\n\n`+t('⚡ Questo MODIFICHERÀ la configurazione del nodo.'))){_execLock=false;return;}
    }
    
    // Trova il terminale visibile
    let termId='cli-terminal';
    const nodoTerm=document.getElementById('terminal');
    const cliTerm=document.getElementById('cli-terminal');
    if(nodoTerm&&nodoTerm.offsetParent!==null) termId='terminal';
    else if(cliTerm&&cliTerm.offsetParent!==null) termId='cli-terminal';
    else{
        navigateTo('cli');
        await new Promise(r=>setTimeout(r,400));
        termId='cli-terminal';
    }
    
    const _el=document.getElementById(termId);
    if(_el)_el.scrollIntoView({behavior:'smooth',block:'center'});
    
    // Mostra comando con porta se selezionata
    const portDisplay=APP.selectedPort?` [${APP.selectedPort}]`:'';
    termAppendTo(termId, `\n$ meshtastic ${getPortArg()}${cmd}`, 'prompt');
    if(!APP.selectedPort) termAppendTo(termId, t('⚠️ Nessuna porta selezionata — verrà usata la porta auto-detect'), 'info');
    
    const check=await apiFetch('cli/check');
    if(check&&!check.installed){
        termAppendTo(termId, t('❌ Meshtastic CLI non installato!'),'error');
        termAppendTo(termId, t('   Installa: pip install --upgrade meshtastic'),'info');
        // Bottone installazione automatica nel terminale
        const _btn=document.createElement('span');
        _btn.className='output';
        _btn.innerHTML=`<button onclick="installCLI()" style="background:var(--accent);color:#000;border:none;padding:0.3rem 0.8rem;border-radius:4px;cursor:pointer;font-weight:bold;font-size:0.8rem;margin:0.3rem 0">📦 ${t('Installa automaticamente')}</button>`;
        const _termEl=document.getElementById(termId);
        if(_termEl)_termEl.appendChild(_btn);
        return;
    }
    termAppendTo(termId, '⏳ Esecuzione in corso...', 'info');
    // Invia comando + porta selezionata al server
    const payload={command:cmd};
    if(APP.selectedPort) payload.port=APP.selectedPort;
    const d=await apiFetch('cli/execute',{method:'POST',body:JSON.stringify(payload)});
    // 🔧 FIX: usare _el (elemento terminale), NON t (funzione traduzione!)
    if(_el){const lines=_el.querySelectorAll('span');const last=lines[lines.length-1];if(last&&last.textContent.includes('⏳'))last.remove();}

    if(d){
        if(d.success){termAppendTo(termId, d.stdout||t('✅ Comando eseguito'),'output');}
        else if(d.error){
            termAppendTo(termId, '❌ '+t(d.error),'error');
            if(d.install_command)termAppendTo(termId, '💡 '+d.install_command,'info');
            // 🩺 Smart error parsing — analizza e proponi fix
            const _errText = (d.error||'') + '\n' + (d.stderr||'') + '\n' + (d.stdout||'');
            await parseTerminalError(_errText, termId);
        }
        else{
            if(d.stdout)termAppendTo(termId, d.stdout,'output');
            if(d.stderr){
                termAppendTo(termId, d.stderr,'error');
                // 🩺 Smart error parsing per stderr
                await parseTerminalError(d.stderr, termId);
            }
        }
    }else{termAppendTo(termId, t('❌ Errore comunicazione'),'error');}
    if(_el)_el.scrollTop=_el.scrollHeight;
    }finally{_execLock=false;}
}

// cliRun = alias per compatibilità (pagina CLI)
async function cliRun(cmd){ return execCmd(cmd); }

function cliTermRunInput(){
    const input=document.getElementById('cli-term-input');
    if(!input||!input.value.trim())return;
    let cmd=input.value.trim();
    if(cmd && (_cmdHistory.length===0 || _cmdHistory[_cmdHistory.length-1]!==cmd)){
        _cmdHistory.push(cmd);
    }
    _cmdHistoryIdx=_cmdHistory.length;
    if(cmd.startsWith('meshtastic '))cmd=cmd.replace('meshtastic ','');
    cliRun(cmd);
    input.value='';input.focus();
}

// ── TERMINALE SEZIONE NODO ─────────────────────────────────
let terminalHistory = [];
let _cmdHistory = [];
let _cmdHistoryIdx = -1;

function termAppend(text, cls='output'){
    termAppendTo('terminal', text, cls);
}

async function checkCLI(){
    const s=document.getElementById('cli-status');
    if(!s)return;
    s.innerHTML='<span style="color:var(--text-muted)">⏳ Verifico installazione CLI...</span>';
    const d=await apiFetch('cli/check');
    if(d&&d.installed){
        s.innerHTML=`<span style="color:var(--accent)">✅ Meshtastic CLI installato — ${d.version||'trovato'} — Pronto per comunicare con il nodo!</span>`;
    }else{
        s.innerHTML=`<div class="alert alert-danger" style="margin:0.5rem 0">
            ❌ <strong>${t('Meshtastic CLI non installato!')}</strong><br>
            <span style="font-size:0.85rem">${t('Il terminale ha bisogno del CLI per comunicare con il nodo.')}</span>
        </div>
        <button onclick="installCLI()" style="background:var(--accent);color:#000;border:none;padding:0.5rem 1.2rem;border-radius:6px;cursor:pointer;font-weight:bold;font-size:0.9rem;margin:0.5rem 0">
            📦 ${t('Installa automaticamente')}
        </button>
        <p style="font-size:0.85rem;color:var(--text-secondary);margin:0.5rem 0">${t('Oppure installa manualmente con questo comando:')}</p>
        <div class="cli-block"><code>pip install --upgrade meshtastic</code></div>
        <p style="font-size:0.8rem;color:var(--text-muted);margin-top:0.5rem">${t('Dopo l\'installazione, clicca "🔄 Verifica CLI" per controllare.')}</p>`;
        initCopyButtons();
    }
}

async function installCLI(){
    const s=document.getElementById('cli-status');
    if(s) s.innerHTML=`<span style="color:var(--warning)">⏳ ${t('Installazione Meshtastic CLI in corso... attendere')}</span>`;
    // Mostra anche nel terminale visibile se presente
    const _term=document.getElementById('terminal');
    const _cliTerm=document.getElementById('cli-terminal');
    const _activeTerm=(_cliTerm&&_cliTerm.offsetParent!==null)?_cliTerm:_term;
    if(_activeTerm){
        termAppendTo(_activeTerm.id, `\n$ pip install --upgrade meshtastic`, 'prompt');
        termAppendTo(_activeTerm.id, t('⏳ Installazione in corso... può richiedere 1-2 minuti'), 'info');
    }
    const d=await apiFetch('cli/install',{method:'POST'});
    if(d&&d.success&&d.installed_now){
        if(s) s.innerHTML=`<span style="color:var(--accent)">✅ ${t('Meshtastic CLI installato con successo!')}</span>`;
        if(_activeTerm){
            termAppendTo(_activeTerm.id, t('✅ Installazione completata!'),'output');
            if(d.stdout){
                const _lastLine=(d.stdout.split('\n').pop()||'').trim();
                if(_lastLine) termAppendTo(_activeTerm.id, _lastLine,'output');
            }
        }
        // Re-verifica per mostrare la versione
        setTimeout(()=>checkCLI(), 1000);
    }else{
        const _errMsg=d?(d.error||d.stderr||t('Errore sconosciuto')):t('Errore comunicazione server');
        if(s) s.innerHTML=`<div class="alert alert-danger" style="margin:0.5rem 0">
            ❌ <strong>${t('Installazione fallita')}</strong><br>
            <span style="font-size:0.85rem">${_errMsg}</span><br>
            <span style="font-size:0.8rem;color:var(--text-muted)">${t('Prova manualmente: apri un terminale e scrivi')} <code>pip install --upgrade meshtastic</code></span>
        </div>`;
        if(_activeTerm){
            termAppendTo(_activeTerm.id, '❌ '+t('Installazione fallita')+': '+_errMsg,'error');
            termAppendTo(_activeTerm.id, t('💡 Prova manualmente: pip install --upgrade meshtastic'),'info');
        }
    }
}

// ═══════════════════════════════════════════════════════════
// 🩺 AUTO-DIAGNOSI RECOVERY — analisi errori smart + fix
// ═══════════════════════════════════════════════════════════

/**
 * Analizza output errore del terminale e mostra pulsanti fix se riconosciuto
 * @param {string} errorText - Testo stderr/stdout con errore
 * @param {string} termId - ID del terminale dove mostrare i fix
 * @returns {boolean} true se errore riconosciuto e fix proposto
 */
async function parseTerminalError(errorText, termId){
    if(!errorText || errorText.length < 20) return false;
    // Controlla se contiene un Traceback o pattern errore noto
    const _hasTraceback = /Traceback|Error:|Exception:|ModuleNotFoundError|ImportError|serial\.serialutil|TimeoutError|PermissionError/i.test(errorText);
    if(!_hasTraceback) return false;

    // Chiedi al server di analizzare l'errore
    const _diag = await apiFetch('error/analyze', {method:'POST', body:JSON.stringify({error: errorText})});
    if(!_diag || !_diag.found || !_diag.diagnoses || _diag.diagnoses.length === 0) return false;

    for(const _d of _diag.diagnoses){
        // Mostra diagnosi nel terminale
        termAppendTo(termId, '', 'output');
        termAppendTo(termId, '🩺 '+t('DIAGNOSI AUTOMATICA'), 'prompt');
        termAppendTo(termId, '   '+t('Problema')+': '+t(_d.title_it), 'error');

        if(_d.fix_action === 'serial_troubleshoot' || _d.fix_action === 'device_troubleshoot' || _d.fix_action === 'os_troubleshoot'){
            // Mostra step suggeriti (senza bottone auto-fix)
            if(_d.fix_steps){
                for(const _step of _d.fix_steps){
                    termAppendTo(termId, '   💡 '+t(_step), 'info');
                }
            }
        } else if(_d.fix_action === 'python_version_warning'){
            termAppendTo(termId, '   ⚠️ Python '+(_d.python_version||'')+' '+t('potrebbe non essere compatibile'), 'info');
            termAppendTo(termId, '   💡 '+t('Raccomandata: Python 3.11 o 3.12'), 'info');
            termAppendTo(termId, '   🔗 https://www.python.org/downloads/', 'info');
        } else if(_d.fix_package){
            // Mostra bottone fix con conferma si/no
            const _pkg = _d.fix_package;
            const _action = _d.fix_action || 'install';
            const _actionLabel = _action === 'reinstall' ? t('Reinstallare') :
                                 _action === 'upgrade' ? t('Aggiornare') : t('Installare');

            const _fixEl = document.createElement('div');
            _fixEl.style.cssText = 'margin:0.5rem 0;padding:0.5rem;background:rgba(0,255,136,0.08);border:1px solid var(--accent);border-radius:6px;';
            _fixEl.innerHTML = `
                <span style="color:var(--accent);font-weight:bold">🔧 ${t('Soluzione disponibile')}</span><br>
                <span style="font-size:0.85rem;color:var(--text-secondary)">${_actionLabel} <code>${_pkg}</code>?</span>
                <div style="margin-top:0.4rem;display:flex;gap:0.5rem">
                    <button onclick="fixPackage('${_pkg}','${_action}',this,'${termId}')" style="background:var(--accent);color:#000;border:none;padding:0.3rem 1rem;border-radius:4px;cursor:pointer;font-weight:bold;font-size:0.8rem">
                        ✅ ${t('Sì, correggi')}
                    </button>
                    <button onclick="this.parentElement.parentElement.remove()" style="background:transparent;color:var(--text-muted);border:1px solid #444;padding:0.3rem 0.8rem;border-radius:4px;cursor:pointer;font-size:0.8rem">
                        ❌ ${t('No')}
                    </button>
                </div>`;
            const _termEl = document.getElementById(termId);
            if(_termEl) _termEl.appendChild(_fixEl);
        }
    }
    return true;
}

/**
 * Esegue fix mirato su un pacchetto — chiamato dai bottoni nel terminale
 */
async function fixPackage(pkg, action, btnEl, termId){
    if(btnEl){
        const _parent = btnEl.parentElement.parentElement;
        _parent.innerHTML = `<span style="color:var(--warning)">⏳ ${t('Correzione in corso...')} ${pkg}</span>`;
    }
    termAppendTo(termId, `\n🔧 ${t('Fix in corso')}: ${action} ${pkg}...`, 'prompt');

    const _result = await apiFetch('deps/fix', {
        method: 'POST',
        body: JSON.stringify({action: action, package: pkg})
    });

    if(_result && _result.success){
        termAppendTo(termId, `✅ ${t('Fix completato con successo!')} ${pkg}`, 'output');
        if(_result.steps){
            for(const _s of _result.steps){
                if(_s.output) termAppendTo(termId, '   '+_s.output.split('\n').pop(), 'info');
            }
        }
        // Suggerisci di riprovare il comando
        termAppendTo(termId, `💡 ${t('Riprova il comando precedente.')}`, 'info');
        // Aggiorna stato CLI se era meshtastic
        if(pkg === 'meshtastic' && typeof checkCLI === 'function'){
            setTimeout(()=>checkCLI(), 1500);
        }
    } else {
        const _err = _result ? (_result.error || t('Errore sconosciuto')) : t('Errore comunicazione server');
        termAppendTo(termId, `❌ ${t('Fix fallito')}: ${_err}`, 'error');
        termAppendTo(termId, `💡 ${t('Prova manualmente')}: pip install --force-reinstall ${pkg}`, 'info');
    }
}

/**
 * Diagnosi completa — chiamata all'avvio o dal bottone Diagnosi
 */
async function runDiagnosisStartup(){
    const _diag = await apiFetch('deps/diagnose');
    if(!_diag) return;
    if(_diag.status === 'ok' && (!_diag.issues || _diag.issues.length === 0)){
        // Tutto OK — nessun modal
        localStorage.removeItem('diag_dismissed');
        return;
    }

    // ── Cache dismissal: se utente ha già gestito e non ci sono critical, skip 24h ──
    try {
        const _dismissed = JSON.parse(localStorage.getItem('diag_dismissed') || 'null');
        if(_dismissed){
            const _elapsed = Date.now() - (_dismissed.ts || 0);
            const _hasCritical = (_diag.issues || []).some(_i => _i.severity === 'critical');
            // Rimostra SOLO se: passate 24h, oppure ci sono nuovi problemi critical
            if(_elapsed < 86400000 && !_hasCritical){
                console.log('[Diag] Diagnosi già gestita, skip modal (rimostra tra ' + Math.round((86400000 - _elapsed)/3600000) + 'h)');
                return;
            }
        }
    } catch(_e){ /* localStorage non disponibile — mostra comunque */ }

    // Ci sono problemi — mostra modal diagnosi
    const _borderColor = _diag.status==='critical'?'var(--danger,#ff4444)':'var(--warning,#ffaa00)';
    let _html = `
    <div id="diag-modal-overlay" style="position:fixed;inset:0;background:rgba(0,0,0,0.88);z-index:99999;display:flex;align-items:center;justify-content:center;font-family:monospace">
    <div style="background:var(--bg-card,#1a1a2e);border:2px solid ${_borderColor};border-radius:12px;padding:2rem;max-width:720px;width:92%;max-height:88vh;overflow-y:auto;color:var(--text-primary,#e0e0e0)">
        <h2 style="color:${_borderColor};margin:0 0 0.5rem 0">
            🩺 ${t('Auto-Diagnosi Sistema')}
        </h2>
        <p style="font-size:0.85rem;color:var(--text-secondary,#aaa);margin:0 0 0.8rem 0">
            ${t('Score')}: <strong style="color:${_diag.score>=80?'var(--accent)':(_diag.score>=50?'var(--warning)':'var(--danger)')}">${_diag.score}/100</strong>
            &nbsp;—&nbsp; Python ${_diag.python_version || '?'} &nbsp;|&nbsp; CLI ${_diag.cli_version || t('non trovato')} &nbsp;|&nbsp; ${_diag.ports_count || 0} ${t('porte USB')}
        </p>`;

    // ── SEZIONE 1: INFO SISTEMA ──────────────────────────────
    _html += `<div style="margin-bottom:0.8rem;font-size:0.8rem;padding:0.5rem;background:rgba(255,255,255,0.03);border-radius:6px">`;
    for(const _i of (_diag.info || [])){
        const _icon = _i.ok ? '✅' : '❌';
        _html += `<div style="margin:0.2rem 0">${_icon} <strong>${_i.label}:</strong> ${_i.value}${_i.path ? ' <span style="color:var(--text-muted,#666)">'+_i.path+'</span>' : ''}${_i.error ? ' <span style="color:var(--danger,#f44)">— '+_i.error.substring(0,80)+'</span>' : ''}</div>`;
    }
    _html += `</div>`;

    // ── SEZIONE 2: PROBLEMI CRITICI (auto-fix) ───────────────
    if(_diag.issues && _diag.issues.length > 0){
        _html += `<h3 style="color:var(--danger,#ff4444);font-size:0.95rem;margin:0.8rem 0 0.4rem 0">❌ ${t('Problemi trovati')}</h3>`;
        for(const _issue of _diag.issues){
            const _sevColor = _issue.severity === 'critical' ? 'var(--danger,#ff4444)' : 'var(--warning,#ffaa00)';
            _html += `<div style="margin:0.4rem 0;padding:0.5rem;border-left:3px solid ${_sevColor};background:rgba(255,68,68,0.05);border-radius:0 6px 6px 0">
                <div style="color:${_sevColor};font-weight:bold;font-size:0.85rem">${_issue.title}</div>
                <div style="font-size:0.8rem;color:var(--text-muted,#888);margin:0.2rem 0">${_issue.detail || ''}</div>`;
            if(_issue.fix_package && _issue.fix_action !== 'upgrade_python' && _issue.fix_action !== 'downgrade_python'){
                _html += `<button onclick="diagFixPackage('${_issue.fix_package}','${_issue.fix_action || 'install'}',this)"
                    style="margin-top:0.3rem;background:var(--accent,#00ff88);color:#000;border:none;padding:0.25rem 0.8rem;border-radius:4px;cursor:pointer;font-weight:bold;font-size:0.78rem">
                    🔧 ${t('Correggi automaticamente')}
                </button>`;
            } else if(_issue.fix_url){
                _html += `<a href="${_issue.fix_url}" target="_blank" style="display:inline-block;margin-top:0.3rem;color:var(--accent);font-size:0.8rem;text-decoration:underline">
                    🔗 ${t('Scarica versione corretta')}
                </a>`;
            }
            _html += `</div>`;
        }
    }

    // ── SEZIONE 3: AVVISI ────────────────────────────────────
    if(_diag.warnings && _diag.warnings.length > 0){
        _html += `<h3 style="color:var(--warning,#ffaa00);font-size:0.95rem;margin:0.8rem 0 0.4rem 0">⚠️ ${t('Avvisi')}</h3>`;
        for(const _w of _diag.warnings){
            _html += `<div style="margin:0.3rem 0;padding:0.4rem;font-size:0.8rem;color:var(--text-secondary)">
                ⚠️ ${_w.title}${_w.detail ? ' — '+_w.detail : ''}
            </div>`;
        }
    }

    // ── BOTTONI FIX AUTOMATICO ────────────────────────────────
    _html += `
        <div style="display:flex;gap:0.8rem;flex-wrap:wrap;margin-top:1rem">
            <button id="diag-fix-all-btn" onclick="diagFixAll()" style="background:var(--accent,#00ff88);color:#000;border:none;padding:0.5rem 1.2rem;border-radius:6px;cursor:pointer;font-weight:bold;font-size:0.9rem;flex:1">
                🔧 ${t('Correggi tutto automaticamente')}
            </button>
            <button onclick="try{localStorage.setItem('diag_dismissed',JSON.stringify({ts:Date.now(),action:'ignore'}))}catch(_e){}document.getElementById('diag-modal-overlay').remove()" style="background:transparent;color:var(--text-muted,#888);border:1px solid #444;padding:0.5rem 1rem;border-radius:6px;cursor:pointer;font-size:0.85rem">
                ${t('Ignora')}
            </button>
        </div>
        <p id="diag-status" style="font-size:0.8rem;color:var(--text-muted,#888);margin:0.8rem 0 0 0;min-height:1.2rem"></p>`;

    // ══════════════════════════════════════════════════════════
    // SEZIONE MANUALE — per utenti tecnici
    // ══════════════════════════════════════════════════════════
    _html += `
        <details style="margin-top:1.2rem;border-top:1px solid #333;padding-top:1rem">
            <summary style="cursor:pointer;color:var(--accent,#00ff88);font-weight:bold;font-size:0.9rem;user-select:none">
                🛠️ ${t('Sezione Manuale (utenti tecnici)')}
            </summary>
            <div style="margin-top:0.8rem">

            <!-- PYTHON VERSIONS -->
            <h4 style="color:var(--accent,#00ff88);font-size:0.88rem;margin:0.8rem 0 0.4rem 0">🐍 ${t('Versioni Python — Download')}</h4>
            <p style="font-size:0.78rem;color:var(--text-muted,#888);margin:0 0 0.5rem 0">
                ${t('Scegli la versione più adatta al tuo sistema. Le versioni raccomandate sono testate con meshtastic CLI.')}
            </p>
            <table style="width:100%;border-collapse:collapse;font-size:0.78rem;margin-bottom:0.8rem">
                <tr style="border-bottom:1px solid #333;color:var(--accent)">
                    <th style="text-align:left;padding:0.3rem">${t('Versione')}</th>
                    <th style="text-align:center;padding:0.3rem">${t('Stato')}</th>
                    <th style="text-align:left;padding:0.3rem">${t('Note')}</th>
                    <th style="text-align:center;padding:0.3rem">Link</th>
                </tr>
                <tr style="border-bottom:1px solid #222">
                    <td style="padding:0.3rem;color:var(--accent)"><strong>Python 3.12</strong></td>
                    <td style="text-align:center">⭐ ${t('Raccomandata')}</td>
                    <td style="padding:0.3rem;color:var(--text-secondary)">${t('Stabile, testata, compatibile con tutto')}</td>
                    <td style="text-align:center"><a href="https://www.python.org/downloads/release/python-3129/" target="_blank" style="color:var(--accent)">📥</a></td>
                </tr>
                <tr style="border-bottom:1px solid #222">
                    <td style="padding:0.3rem;color:var(--accent)"><strong>Python 3.11</strong></td>
                    <td style="text-align:center">✅ ${t('Ottima')}</td>
                    <td style="padding:0.3rem;color:var(--text-secondary)">${t('Veloce, molto stabile, supporto LTS')}</td>
                    <td style="text-align:center"><a href="https://www.python.org/downloads/release/python-31111/" target="_blank" style="color:var(--accent)">📥</a></td>
                </tr>
                <tr style="border-bottom:1px solid #222">
                    <td style="padding:0.3rem"><strong>Python 3.13</strong></td>
                    <td style="text-align:center">✅ ${t('Supportata')}</td>
                    <td style="padding:0.3rem;color:var(--text-secondary)">${t('Recente, compatibile con meshtastic')}</td>
                    <td style="text-align:center"><a href="https://www.python.org/downloads/release/python-3132/" target="_blank" style="color:var(--accent)">📥</a></td>
                </tr>
                <tr style="border-bottom:1px solid #222">
                    <td style="padding:0.3rem"><strong>Python 3.10</strong></td>
                    <td style="text-align:center">✅ ${t('Supportata')}</td>
                    <td style="padding:0.3rem;color:var(--text-secondary)">${t('Stabile ma più datata, funziona bene')}</td>
                    <td style="text-align:center"><a href="https://www.python.org/downloads/release/python-31016/" target="_blank" style="color:var(--accent)">📥</a></td>
                </tr>
                <tr style="border-bottom:1px solid #222">
                    <td style="padding:0.3rem"><strong>Python 3.9</strong></td>
                    <td style="text-align:center">⚠️ ${t('Minima')}</td>
                    <td style="padding:0.3rem;color:var(--text-muted)">${t('Versione minima supportata, fine vita 2025')}</td>
                    <td style="text-align:center"><a href="https://www.python.org/downloads/release/python-3922/" target="_blank" style="color:var(--accent)">📥</a></td>
                </tr>
                <tr style="border-bottom:1px solid #222;background:rgba(255,68,68,0.05)">
                    <td style="padding:0.3rem;color:var(--danger)"><strong>Python 3.14+</strong></td>
                    <td style="text-align:center">❌ ${t('Non testata')}</td>
                    <td style="padding:0.3rem;color:var(--danger)">${t('Troppo nuova — meshtastic potrebbe crashare')}</td>
                    <td style="text-align:center">—</td>
                </tr>
            </table>
            <p style="font-size:0.75rem;color:var(--text-muted,#666);margin:0 0 0.8rem 0">
                💡 ${t('Consiglio')}: ${t('Su Windows puoi avere più versioni Python installate. Usa il Python Launcher')} <code>py -3.12</code> ${t('per scegliere quale usare.')}
            </p>

            <!-- LIBRERIE PRINCIPALI -->
            <h4 style="color:var(--accent,#00ff88);font-size:0.88rem;margin:0.8rem 0 0.4rem 0">📦 ${t('Librerie Principali (richieste)')}</h4>
            <table style="width:100%;border-collapse:collapse;font-size:0.78rem;margin-bottom:0.8rem">
                <tr style="border-bottom:1px solid #333;color:var(--accent)">
                    <th style="text-align:left;padding:0.3rem">${t('Pacchetto')}</th>
                    <th style="text-align:left;padding:0.3rem">${t('Comando pip')}</th>
                    <th style="text-align:left;padding:0.3rem">${t('A cosa serve')}</th>
                </tr>
                <tr style="border-bottom:1px solid #222"><td style="padding:0.3rem"><strong>meshtastic</strong></td><td><code>pip install meshtastic</code></td><td style="color:var(--text-secondary)">${t('CLI + API per dispositivi LoRa')}</td></tr>
                <tr style="border-bottom:1px solid #222"><td style="padding:0.3rem"><strong>flask</strong></td><td><code>pip install flask</code></td><td style="color:var(--text-secondary)">${t('Web server locale dell\'app')}</td></tr>
                <tr style="border-bottom:1px solid #222"><td style="padding:0.3rem"><strong>flask-cors</strong></td><td><code>pip install flask-cors</code></td><td style="color:var(--text-secondary)">${t('Permessi cross-origin per API')}</td></tr>
                <tr style="border-bottom:1px solid #222"><td style="padding:0.3rem"><strong>pyserial</strong></td><td><code>pip install pyserial</code></td><td style="color:var(--text-secondary)">${t('Comunicazione USB seriale')}</td></tr>
                <tr style="border-bottom:1px solid #222"><td style="padding:0.3rem"><strong>cryptography</strong></td><td><code>pip install cryptography</code></td><td style="color:var(--text-secondary)">${t('Crittografia licenze Ed25519')}</td></tr>
                <tr style="border-bottom:1px solid #222"><td style="padding:0.3rem"><strong>qrcode + Pillow</strong></td><td><code>pip install qrcode[pil]</code></td><td style="color:var(--text-secondary)">${t('Generazione QR code canali')}</td></tr>
                <tr style="border-bottom:1px solid #222"><td style="padding:0.3rem"><strong>protobuf</strong></td><td><code>pip install protobuf</code></td><td style="color:var(--text-secondary)">${t('Serializzazione dati Meshtastic')}</td></tr>
            </table>

            <!-- LIBRERIE AGGIUNTIVE / OPZIONALI -->
            <h4 style="color:var(--accent,#00ff88);font-size:0.88rem;margin:0.8rem 0 0.4rem 0">🔌 ${t('Librerie Aggiuntive (opzionali)')}</h4>
            <table style="width:100%;border-collapse:collapse;font-size:0.78rem;margin-bottom:0.8rem">
                <tr style="border-bottom:1px solid #333;color:var(--accent)">
                    <th style="text-align:left;padding:0.3rem">${t('Pacchetto')}</th>
                    <th style="text-align:left;padding:0.3rem">${t('Comando pip')}</th>
                    <th style="text-align:left;padding:0.3rem">${t('A cosa serve')}</th>
                </tr>
                <tr style="border-bottom:1px solid #222"><td style="padding:0.3rem"><strong>esptool</strong></td><td><code>pip install esptool</code></td><td style="color:var(--text-secondary)">${t('Flash firmware ESP32 (sezione Flash)')}</td></tr>
                <tr style="border-bottom:1px solid #222"><td style="padding:0.3rem"><strong>bleak</strong></td><td><code>pip install bleak</code></td><td style="color:var(--text-secondary)">${t('Connessione Bluetooth BLE ai nodi')}</td></tr>
                <tr style="border-bottom:1px solid #222"><td style="padding:0.3rem"><strong>pyyaml</strong></td><td><code>pip install pyyaml</code></td><td style="color:var(--text-secondary)">${t('Export/import configurazioni YAML')}</td></tr>
                <tr style="border-bottom:1px solid #222"><td style="padding:0.3rem"><strong>tabulate</strong></td><td><code>pip install tabulate</code></td><td style="color:var(--text-secondary)">${t('Formattazione tabelle nel terminale')}</td></tr>
                <tr style="border-bottom:1px solid #222"><td style="padding:0.3rem"><strong>requests</strong></td><td><code>pip install requests</code></td><td style="color:var(--text-secondary)">${t('HTTP client per update e API remote')}</td></tr>
            </table>

            <!-- DRIVER USB -->
            <h4 style="color:var(--accent,#00ff88);font-size:0.88rem;margin:0.8rem 0 0.4rem 0">🔌 ${t('Driver USB (necessari per la comunicazione)')}</h4>
            <table style="width:100%;border-collapse:collapse;font-size:0.78rem;margin-bottom:0.8rem">
                <tr style="border-bottom:1px solid #333;color:var(--accent)">
                    <th style="text-align:left;padding:0.3rem">${t('Driver')}</th>
                    <th style="text-align:left;padding:0.3rem">${t('Dispositivi')}</th>
                    <th style="text-align:center;padding:0.3rem">Download</th>
                </tr>
                <tr style="border-bottom:1px solid #222">
                    <td style="padding:0.3rem"><strong>CP210x</strong> (Silicon Labs)</td>
                    <td style="color:var(--text-secondary)">${t('T-Beam, T-Lora, Heltec, LilyGO — la maggior parte dei dispositivi')}</td>
                    <td style="text-align:center"><a href="https://www.silabs.com/developers/usb-to-uart-bridge-vcp-drivers" target="_blank" style="color:var(--accent)">📥 ${t('Scarica')}</a></td>
                </tr>
                <tr style="border-bottom:1px solid #222">
                    <td style="padding:0.3rem"><strong>CH340/CH341</strong> (WCH)</td>
                    <td style="color:var(--text-secondary)">${t('Cloni economici, alcune schede WisBlock, NodeMCU')}</td>
                    <td style="text-align:center"><a href="https://www.wch-ic.com/downloads/CH341SER_EXE.html" target="_blank" style="color:var(--accent)">📥 ${t('Scarica')}</a></td>
                </tr>
            </table>
            <p style="font-size:0.75rem;color:var(--text-muted,#666);margin:0 0 0.5rem 0">
                💡 ${t('Dopo aver installato un driver, riavvia il PC e ricollega il dispositivo USB.')}
            </p>

            <!-- COMANDI UTILI -->
            <h4 style="color:var(--accent,#00ff88);font-size:0.88rem;margin:0.8rem 0 0.4rem 0">💻 ${t('Comandi Utili (terminale di sistema)')}</h4>
            <div style="font-size:0.78rem;background:rgba(0,0,0,0.3);border:1px solid #333;border-radius:6px;padding:0.6rem;margin-bottom:0.5rem">
                <div style="margin:0.2rem 0"><code style="color:var(--accent)">python --version</code> <span style="color:var(--text-muted)">— ${t('Verifica versione Python')}</span></div>
                <div style="margin:0.2rem 0"><code style="color:var(--accent)">pip --version</code> <span style="color:var(--text-muted)">— ${t('Verifica pip installato')}</span></div>
                <div style="margin:0.2rem 0"><code style="color:var(--accent)">meshtastic --version</code> <span style="color:var(--text-muted)">— ${t('Verifica meshtastic CLI')}</span></div>
                <div style="margin:0.2rem 0"><code style="color:var(--accent)">pip install --upgrade meshtastic</code> <span style="color:var(--text-muted)">— ${t('Aggiorna meshtastic all\'ultima versione')}</span></div>
                <div style="margin:0.2rem 0"><code style="color:var(--accent)">pip install --force-reinstall meshtastic</code> <span style="color:var(--text-muted)">— ${t('Reinstalla da zero (risolve molti problemi)')}</span></div>
                <div style="margin:0.2rem 0"><code style="color:var(--accent)">pip list</code> <span style="color:var(--text-muted)">— ${t('Mostra tutte le librerie installate')}</span></div>
                <div style="margin:0.2rem 0"><code style="color:var(--accent)">pip install --user meshtastic</code> <span style="color:var(--text-muted)">— ${t('Installa senza permessi admin')}</span></div>
            </div>
            <p style="font-size:0.75rem;color:var(--text-muted,#666);margin:0 0 0.5rem 0">
                🐧 <strong>Linux</strong>: ${t('Se le porte USB non compaiono')}: <code>sudo usermod -a -G dialout $USER</code> ${t('poi ri-login')}<br>
                🍎 <strong>macOS</strong>: ${t('Dopo l\'installazione driver, riavvia il Mac')}<br>
                🪟 <strong>Windows</strong>: ${t('Se pip non funziona, prova')}: <code>py -m pip install meshtastic</code>
            </p>

            <!-- BOTTONE INSTALLA SINGOLO -->
            <h4 style="color:var(--accent,#00ff88);font-size:0.88rem;margin:0.8rem 0 0.4rem 0">🔧 ${t('Installa Pacchetto Singolo')}</h4>
            <div style="display:flex;gap:0.5rem;align-items:center;margin-bottom:0.5rem">
                <select id="diag-manual-pkg" style="background:#111;color:var(--text-primary);border:1px solid #444;padding:0.3rem 0.6rem;border-radius:4px;font-size:0.8rem;font-family:monospace;flex:1">
                    <option value="meshtastic">meshtastic</option>
                    <option value="flask">flask</option>
                    <option value="flask-cors">flask-cors</option>
                    <option value="pyserial">pyserial</option>
                    <option value="cryptography">cryptography</option>
                    <option value="qrcode[pil]">qrcode[pil]</option>
                    <option value="Pillow">Pillow</option>
                    <option value="protobuf">protobuf</option>
                    <option value="esptool">esptool</option>
                    <option value="bleak">bleak</option>
                    <option value="pyyaml">pyyaml</option>
                    <option value="tabulate">tabulate</option>
                    <option value="requests">requests</option>
                </select>
                <select id="diag-manual-action" style="background:#111;color:var(--text-primary);border:1px solid #444;padding:0.3rem 0.5rem;border-radius:4px;font-size:0.8rem;font-family:monospace">
                    <option value="install">${t('Installa/Aggiorna')}</option>
                    <option value="reinstall">${t('Reinstalla da zero')}</option>
                </select>
                <button id="diag-manual-btn" onclick="diagManualInstall()" style="background:var(--accent,#00ff88);color:#000;border:none;padding:0.35rem 0.8rem;border-radius:4px;cursor:pointer;font-weight:bold;font-size:0.8rem;white-space:nowrap">
                    📦 ${t('Esegui')}
                </button>
            </div>
            <p id="diag-manual-status" style="font-size:0.78rem;color:var(--text-muted,#888);margin:0;min-height:1rem"></p>

            </div>
        </details>
    </div></div>`;

    document.body.insertAdjacentHTML('beforeend', _html);
}

/**
 * Installazione manuale singolo pacchetto dal dropdown nel modal diagnosi
 */
async function diagManualInstall(){
    const _pkg = document.getElementById('diag-manual-pkg');
    const _act = document.getElementById('diag-manual-action');
    const _btn = document.getElementById('diag-manual-btn');
    const _status = document.getElementById('diag-manual-status');
    if(!_pkg || !_act) return;

    const _pkgVal = _pkg.value;
    const _actVal = _act.value;

    if(_btn){_btn.disabled=true; _btn.innerHTML=`⏳ ...`; _btn.style.opacity='0.6';}
    if(_status) _status.innerHTML = `<span style="color:var(--warning)">⏳ ${t('Installazione')} ${_pkgVal}...</span>`;

    const _r = await apiFetch('deps/fix', {
        method:'POST',
        body:JSON.stringify({action: _actVal, package: _pkgVal})
    });

    if(_r && _r.success){
        if(_status) _status.innerHTML = `<span style="color:var(--accent)">✅ ${_pkgVal} ${t('installato con successo!')}</span>`;
    } else {
        const _err = _r ? (_r.error || t('Errore sconosciuto')) : t('Errore comunicazione server');
        if(_status) _status.innerHTML = `<span style="color:var(--danger)">❌ ${t('Fallito')}: ${_err.substring(0,120)}</span>`;
    }
    if(_btn){_btn.disabled=false; _btn.innerHTML=`📦 ${t('Esegui')}`; _btn.style.opacity='1';}
}

/**
 * Fix singolo pacchetto dal modal diagnosi
 */
async function diagFixPackage(pkg, action, btnEl){
    if(btnEl){
        btnEl.disabled = true;
        btnEl.innerHTML = `⏳ ${t('Correzione in corso...')}`;
        btnEl.style.opacity = '0.6';
    }
    const _result = await apiFetch('deps/fix', {
        method:'POST',
        body:JSON.stringify({action: action, package: pkg})
    });
    if(_result && _result.success){
        if(btnEl){
            btnEl.innerHTML = `✅ ${t('Corretto!')}`;
            btnEl.style.background = 'var(--accent)';
        }
    } else {
        if(btnEl){
            btnEl.innerHTML = `❌ ${t('Fallito')}`;
            btnEl.style.background = 'var(--danger)';
            btnEl.disabled = false;
            btnEl.style.opacity = '1';
        }
    }
}

/**
 * Fix tutti i problemi trovati dalla diagnosi
 */
async function diagFixAll(){
    const _btn = document.getElementById('diag-fix-all-btn');
    const _status = document.getElementById('diag-status');
    if(_btn){_btn.disabled=true; _btn.innerHTML=`⏳ ${t('Correzione in corso...')}`; _btn.style.opacity='0.6';}
    if(_status) _status.textContent = t('⏳ Analisi e correzione in corso... può richiedere 2-3 minuti');

    // Prima ottieni la diagnosi corrente
    const _diag = await apiFetch('deps/diagnose');
    if(!_diag || !_diag.issues || _diag.issues.length === 0){
        if(_status) _status.innerHTML = `<span style="color:var(--accent)">✅ ${t('Nessun problema da correggere!')}</span>`;
        if(_btn){_btn.innerHTML=`✅ ${t('Tutto OK!')}`;}
        return;
    }

    let _fixed = 0;
    let _failed = 0;
    // Fix ogni problema che ha un fix_package
    for(const _issue of _diag.issues){
        if(_issue.fix_package){
            if(_status) _status.textContent = `⏳ ${t('Correzione')}: ${_issue.fix_package}...`;
            const _r = await apiFetch('deps/fix', {
                method:'POST',
                body:JSON.stringify({action: _issue.fix_action || 'install', package: _issue.fix_package})
            });
            if(_r && _r.success) _fixed++;
            else _failed++;
        }
    }

    if(_status){
        if(_failed === 0){
            _status.innerHTML = `<span style="color:var(--accent)">✅ ${t('Tutti i problemi corretti!')} (${_fixed} fix)</span>`;
        } else {
            _status.innerHTML = `<span style="color:var(--warning)">⚠️ ${_fixed} ${t('corretti')}, ${_failed} ${t('falliti')}</span>`;
        }
    }
    if(_btn){
        _btn.innerHTML = _failed === 0 ? `✅ ${t('Completato!')}` : `⚠️ ${_fixed}/${_fixed+_failed} ${t('corretti')}`;
    }

    // Rimuovi modal dopo 3s se tutto OK + salva dismissal cache
    if(_failed === 0){
        try{localStorage.setItem('diag_dismissed',JSON.stringify({ts:Date.now(),action:'fixed',count:_fixed}))}catch(_e){}
        setTimeout(()=>{
            const _overlay = document.getElementById('diag-modal-overlay');
            if(_overlay) _overlay.remove();
            if(typeof checkCLI === 'function') checkCLI();
        }, 3000);
    }
}

// ═══════════════════════════════════════════════════════════
// CHECK DIPENDENZE ALL'AVVIO — verifica + auto-install
// ═══════════════════════════════════════════════════════════
async function checkDepsStartup(){
    const d=await apiFetch('deps/check');
    if(!d) return; // server non risponde — probabilmente deps OK (Flask gira)
    if(d.all_ok) return; // Tutto installato — nessun modal

    // Ci sono dipendenze mancanti — mostra modal
    const _missing=d.deps.filter(_dep=>_dep.required&&!_dep.installed);
    const _optional=d.deps.filter(_dep=>!_dep.required&&!_dep.installed);

    let _html=`
    <div id="deps-modal-overlay" style="position:fixed;inset:0;background:rgba(0,0,0,0.85);z-index:99999;display:flex;align-items:center;justify-content:center;font-family:monospace">
    <div style="background:var(--bg-card,#1a1a2e);border:2px solid var(--accent,#00ff88);border-radius:12px;padding:2rem;max-width:600px;width:90%;max-height:80vh;overflow-y:auto;color:var(--text-primary,#e0e0e0)">
        <h2 style="color:var(--accent,#00ff88);margin:0 0 0.5rem 0">📦 ${t('Dipendenze mancanti')}</h2>
        <p style="font-size:0.9rem;color:var(--text-secondary,#aaa);margin:0 0 1rem 0">
            ${t('Alcune librerie Python necessarie non sono installate.')}
        </p>
        <div style="margin-bottom:1rem">
            <p style="font-size:0.85rem;margin:0.3rem 0"><strong>Python:</strong> ${d.python_version} ${d.pip_available?'✅ pip '+d.pip_version:'❌ pip '+t('non trovato')}</p>
        </div>
        <table style="width:100%;border-collapse:collapse;font-size:0.85rem;margin-bottom:1rem">
        <tr style="border-bottom:1px solid #333;color:var(--accent,#00ff88)">
            <th style="text-align:left;padding:0.4rem">${t('Pacchetto')}</th>
            <th style="text-align:center;padding:0.4rem">${t('Stato')}</th>
            <th style="text-align:left;padding:0.4rem">${t('Versione')}</th>
        </tr>`;

    for(const _dep of d.deps){
        const _icon=_dep.installed?'✅':'❌';
        const _color=_dep.installed?'var(--accent,#00ff88)':'var(--danger,#ff4444)';
        const _ver=_dep.installed?(_dep.version||'?'):(_dep.required?t('MANCANTE'):t('opzionale'));
        _html+=`<tr style="border-bottom:1px solid #222">
            <td style="padding:0.4rem;color:${_color}">${_dep.label}</td>
            <td style="text-align:center;padding:0.4rem">${_icon}</td>
            <td style="padding:0.4rem;font-size:0.8rem;color:var(--text-muted,#888)">${_ver}</td>
        </tr>`;
    }

    _html+=`</table>
        <div style="display:flex;gap:0.8rem;flex-wrap:wrap">
            <button id="deps-install-btn" onclick="installAllDeps()" style="background:var(--accent,#00ff88);color:#000;border:none;padding:0.6rem 1.5rem;border-radius:6px;cursor:pointer;font-weight:bold;font-size:0.95rem;flex:1">
                📦 ${t('Installa tutto automaticamente')}
            </button>
            <button onclick="document.getElementById('deps-modal-overlay').remove()" style="background:transparent;color:var(--text-muted,#888);border:1px solid #444;padding:0.6rem 1rem;border-radius:6px;cursor:pointer;font-size:0.85rem">
                ${t('Ignora')}
            </button>
        </div>
        <p id="deps-status" style="font-size:0.8rem;color:var(--text-muted,#888);margin:0.8rem 0 0 0;min-height:1.2rem"></p>
    </div></div>`;

    document.body.insertAdjacentHTML('beforeend', _html);
}

async function installAllDeps(){
    const _btn=document.getElementById('deps-install-btn');
    const _status=document.getElementById('deps-status');
    if(_btn){
        _btn.disabled=true;
        _btn.innerHTML=`⏳ ${t('Installazione in corso...')}`;
        _btn.style.opacity='0.6';
    }
    if(_status) _status.textContent=t('⏳ Installazione in corso... può richiedere 1-2 minuti');

    const d=await apiFetch('deps/install',{method:'POST',body:JSON.stringify({})});
    if(d&&d.success){
        if(_status) _status.innerHTML=`<span style="color:var(--accent)">✅ ${t('Tutte le dipendenze installate!')}</span>`;
        if(_btn){
            _btn.innerHTML=`✅ ${t('Completato!')}`;
            _btn.style.background='var(--accent)';
        }
        // Rimuovi modal dopo 2s e aggiorna pagina
        setTimeout(()=>{
            const _overlay=document.getElementById('deps-modal-overlay');
            if(_overlay) _overlay.remove();
            // Aggiorna lo stato CLI se siamo nella pagina CLI
            if(typeof checkCLI==='function') checkCLI();
        }, 2000);
    }else{
        const _errMsg=d?(d.error||t('Errore sconosciuto')):t('Errore comunicazione server');
        if(_status) _status.innerHTML=`<span style="color:var(--danger)">❌ ${_errMsg}</span><br><span style="font-size:0.75rem">${t('Prova manualmente: apri un terminale e scrivi')} <code>pip install -r requirements.txt</code></span>`;
        if(_btn){
            _btn.disabled=false;
            _btn.innerHTML=`🔄 ${t('Riprova')}`;
            _btn.style.opacity='1';
        }
    }
}

async function termRun(cmd){
    if(_execLock)return;
    _execLock=true;
    try{
    const _term=document.getElementById('terminal');if(!_term)return;
    // Conferma per comandi che modificano
    const modifyCmds=['--set ','--set-owner','--ch-set','--factory-reset','--reboot','--reset-nodedb','--remove-position','--setlat','--setlon'];
    if(modifyCmds.some(mc=>cmd.startsWith(mc))){
        if(!confirm(t('⚠️ Vuoi eseguire questo comando?')+`\n\nmeshtastic ${cmd}\n\n`+t('⚡ Questo MODIFICHERÀ la configurazione del nodo.')))return;
    }
    _term.scrollIntoView({behavior:'smooth',block:'center'});
    termAppend(`\n$ meshtastic ${getPortArg()}${cmd}`, 'prompt');
    if(!APP.selectedPort) termAppend(t('⚠️ Nessuna porta selezionata — auto-detect'), 'info');
    
    // Prima controlla se CLI è installato
    const check=await apiFetch('cli/check');
    if(check&&!check.installed){
        termAppend(t('❌ Meshtastic CLI non è installato sul tuo PC!'),'error');
        termAppend('','output');
        termAppend(t('Per installarlo, apri un terminale e scrivi:'),'info');
        termAppend('  pip install --upgrade meshtastic','prompt');
        termAppend('','output');
        // Bottone installazione automatica
        const _btn=document.createElement('span');
        _btn.className='output';
        _btn.innerHTML=`<button onclick="installCLI()" style="background:var(--accent);color:#000;border:none;padding:0.3rem 0.8rem;border-radius:4px;cursor:pointer;font-weight:bold;font-size:0.8rem;margin:0.3rem 0">📦 ${t('Installa automaticamente')}</button> <span style="color:var(--text-muted);font-size:0.8rem">${t('oppure installa manualmente e riavvia')}</span>`;
        const _termNode=document.getElementById('terminal');
        if(_termNode)_termNode.appendChild(_btn);
        return;
    }
    
    termAppend('⏳ Esecuzione in corso...', 'info');
    
    const payload={command:cmd};
    if(APP.selectedPort) payload.port=APP.selectedPort;
    const d=await apiFetch('cli/execute',{method:'POST',body:JSON.stringify(payload)});
    
    // Rimuovi il messaggio "in corso"
    const lines=_term.querySelectorAll('span');
    const last=lines[lines.length-1];
    if(last&&last.textContent.includes('⏳'))last.remove();
    
    if(d){
        if(d.success){
            termAppend(d.stdout||t('(nessun output)'),'output');
            terminalHistory.push({cmd:cmd, output:d.stdout});
        }else if(d.error){
            termAppend('❌ '+t(d.error),'error');
            if(d.install_command){
                termAppend(t('💡 Installa con: ')+d.install_command,'info');
            }
            // 🩺 Smart error parsing
            const _errText = (d.error||'') + '\n' + (d.stderr||'') + '\n' + (d.stdout||'');
            await parseTerminalError(_errText, 'terminal');
        }else{
            if(d.stdout)termAppend(d.stdout,'output');
            if(d.stderr){
                termAppend(d.stderr,'error');
                await parseTerminalError(d.stderr, 'terminal');
            }
        }
    }else{
        termAppend(t('❌ Errore di comunicazione con il server'),'error');
    }
    }finally{_execLock=false;}
}

function termRunInput(){
    const input=document.getElementById('term-input');
    if(!input||!input.value.trim())return;
    let cmd=input.value.trim();
    // Salva nella cronologia
    if(cmd && (_cmdHistory.length===0 || _cmdHistory[_cmdHistory.length-1]!==cmd)){
        _cmdHistory.push(cmd);
    }
    _cmdHistoryIdx=_cmdHistory.length;
    // Rimuovi "meshtastic " se l'utente lo ha scritto
    if(cmd.startsWith('meshtastic '))cmd=cmd.replace('meshtastic ','');
    termRun(cmd);
    input.value='';
    input.focus();
}

// ── Arrow key history navigation per terminali ──
function _termKeyHandler(e){
    const input=e.target;
    if(e.key==='ArrowUp'){
        e.preventDefault();
        if(_cmdHistoryIdx>0){_cmdHistoryIdx--;input.value=_cmdHistory[_cmdHistoryIdx];}
    }else if(e.key==='ArrowDown'){
        e.preventDefault();
        if(_cmdHistoryIdx<_cmdHistory.length-1){_cmdHistoryIdx++;input.value=_cmdHistory[_cmdHistoryIdx];}
        else{_cmdHistoryIdx=_cmdHistory.length;input.value='';}
    }else if(e.key==='Enter'){
        termRunInput();
    }
}

function analyzeTerminalOutput(){
    const c=document.getElementById('node-analysis');if(!c)return;
    const _term=document.getElementById('terminal');
    const text=_term?_term.textContent:'';
    const tl=text.toLowerCase();
    
    if(text.length<200){
        c.innerHTML='<div class="alert alert-warning">'+t('⚠️ Esegui prima <strong>--info</strong> nel terminale per avere dati da analizzare.')+'</div>';
        return;
    }
    
    let s=[];
    
    // ═══ VERIFICA DATI RICEVUTI (punto 3: controlla che siano tutti usciti) ═══
    const dataChecks=[
        {key:'"firmwareVersion"',label:'Firmware',found:false},
        {key:'"hwModel"',label:'Hardware Model',found:false},
        {key:'"role"',label:'Ruolo dispositivo',found:false},
        {key:'"region"',label:'Regione LoRa',found:false},
        {key:'"modemPreset"',label:'Preset Modem',found:false},
        {key:'"hopLimit"',label:'Hop Limit',found:false},
        {key:'"txPower"',label:'TX Power',found:false},
        {key:'"batteryLevel"',label:'Livello Batteria',found:false},
        {key:'"channelUtilization"',label:'Channel Utilization',found:false},
        {key:'"airUtilTx"',label:'Airtime TX',found:false},
        {key:'gpsEnabled',label:'Stato GPS',found:false},
        {key:'gpsMode',label:'Modalità GPS',found:false},
        {key:'"wifiEnabled"',label:'Stato WiFi',found:false},
        {key:'"fixedPin"',label:'PIN Bluetooth',found:false},
        {key:'"positionBroadcastSmartEnabled"',label:'Smart Position',found:false},
        {key:'"mqtt"',label:'Configurazione MQTT',found:false},
        {key:'"neighborInfo"',label:'Neighbor Info',found:false},
        {key:'"telemetry"',label:'Telemetria',found:false},
        {key:'"storeForward"',label:'Store & Forward',found:false},
        {key:'Channels:',label:'Canali configurati',found:false},
        {key:'downlinkEnabled',label:'Downlink canali',found:false},
        {key:'uplinkEnabled',label:'Uplink canali',found:false},
        {key:'Complete URL',label:'URL configurazione completo',found:false},
    ];
    
    let foundCount=0;
    dataChecks.forEach(dc=>{
        if(text.includes(dc.key)){dc.found=true;foundCount++;}
    });
    
    s.push({t:foundCount>=20?'success':foundCount>=15?'warning':'danger',
        m:`📊 <strong>Dati ricevuti: ${foundCount}/${dataChecks.length}</strong> — ${foundCount>=20?'Output completo!':foundCount>=15?'Parziale, esegui anche --get all':'Incompleto, ripeti --info'}`});
    
    // Lista dati mancanti
    const missing=dataChecks.filter(dc=>!dc.found);
    if(missing.length>0&&missing.length<10){
        s.push({t:'info',m:'📋 <strong>Dati mancanti:</strong> '+missing.map(m=>m.label).join(', ')});
    }
    
    // ═══ ESTRAI E MOSTRA TUTTI I VALORI TROVATI ═══
    const fwMatch=text.match(/"firmwareVersion":\s*"([^"]+)"/);
    const hwMatch=text.match(/"hwModel":\s*"([^"]+)"/);
    const roleMatch=text.match(/"role":\s*"([^"]+)"/);
    const hopMatch=text.match(/"hopLimit":\s*(\d+)/);
    const txMatch=text.match(/"txPower":\s*(\d+)/);
    const batMatch=text.match(/"batteryLevel":\s*(\d+)/);
    const chUtil=text.match(/"channelUtilization":\s*([\d.]+)/);
    const airTx=text.match(/"airUtilTx":\s*([\d.]+)/);
    const nodeCount=(text.match(/"user":/g)||[]).length;
    const regionMatch=text.match(/"region":\s*"([^"]+)"/);
    const presetMatch=text.match(/"modemPreset":\s*"([^"]+)"/);
    
    if(fwMatch) s.push({t:'info',m:`📦 <strong>Firmware:</strong> ${fwMatch[1]}`});
    if(hwMatch) s.push({t:'info',m:`🔧 <strong>Hardware:</strong> ${hwMatch[1]}`});
    if(roleMatch) s.push({t:'info',m:`👤 <strong>Ruolo:</strong> ${roleMatch[1]}`});
    if(regionMatch) s.push({t:regionMatch[1]==='EU_868'?'success':'danger',m:`📡 <strong>Regione:</strong> ${regionMatch[1]}${regionMatch[1]!=='EU_868'?' — '+t('⚠️ NON è EU_868!')+'':''}`,fix:regionMatch[1]!=='EU_868'?'meshtastic --set lora.region EU_868':null});
    if(presetMatch) s.push({t:presetMatch[1]==='MEDIUM_FAST'?'success':'warning',m:`📻 <strong>Preset:</strong> ${presetMatch[1]}${presetMatch[1]!=='MEDIUM_FAST'?' — Non è lo standard Italia':''}`,fix:presetMatch[1]!=='MEDIUM_FAST'?'meshtastic --set lora.modem_preset MEDIUM_FAST':null});
    if(hopMatch){const h=parseInt(hopMatch[1]);s.push({t:h>5?'danger':h>3?'warning':'success',m:`🔄 <strong>Hop Limit:</strong> ${h}${h>5?' — TROPPO ALTO! Causa congestione':''}`,fix:h>3?'meshtastic --set lora.hop_limit 3':null});}
    if(txMatch){const tx=parseInt(txMatch[1]);s.push({t:tx>27?'danger':'success',m:`📡 <strong>TX Power:</strong> ${tx} dBm${tx>27?' — Supera limite legale EU!':''}`,fix:tx>27?'meshtastic --set lora.tx_power 27':null});}
    if(batMatch){const b=parseInt(batMatch[1]);s.push({t:b<=20?'danger':b<=50?'warning':'success',m:`🔋 <strong>Batteria:</strong> ${b}%`});}
    if(chUtil) s.push({t:parseFloat(chUtil[1])>30?'danger':parseFloat(chUtil[1])>15?'warning':'success',m:`📊 <strong>Channel Util:</strong> ${parseFloat(chUtil[1]).toFixed(1)}%`});
    if(airTx) s.push({t:parseFloat(airTx[1])>5?'danger':parseFloat(airTx[1])>2?'warning':'success',m:`📡 <strong>Airtime TX:</strong> ${parseFloat(airTx[1]).toFixed(2)}%`});
    if(nodeCount>0) s.push({t:'info',m:`👥 <strong>Nodi visibili:</strong> ${nodeCount}`});
    
    // ═══ PROBLEMI DA CORREGGERE ═══
    if(tl.includes('"gpsenabled": false')&&tl.includes('"gpsmode": "enabled"'))
        s.push({t:'warning',m:'⚠️ <strong>GPS contraddittorio</strong> — gpsEnabled=false ma gpsMode=ENABLED',fix:'meshtastic --set position.gps_enabled true'});
    if(tl.includes('"positionbroadcastsmartenabled": false'))
        s.push({t:'warning',m:'⚠️ <strong>Smart Position OFF</strong> — Abilita per risparmiare airtime',fix:'meshtastic --set position.position_broadcast_smart_enabled true'});
    if(tl.includes('"wifienabled": true')){
        s.push({t:'warning',m:'⚠️ <strong>WiFi abilitato</strong> — Consuma batteria',fix:'meshtastic --set network.wifi_enabled false'});
        const ssid=text.match(/"wifiSsid":\s*"([^"]+)"/);
        const psk=text.match(/"wifiPsk":\s*"([^"]+)"/);
        if(ssid&&psk) s.push({t:'danger',m:`🔐 <strong>SICUREZZA!</strong> Credenziali WiFi visibili: SSID="${ssid[1]}"`});
    }
    if(tl.includes('"fixedpin": 123456'))
        s.push({t:'warning',m:'⚠️ <strong>PIN BT default 123456</strong>',fix:'meshtastic --set bluetooth.fixed_pin 847291'});
    const dlOff=(text.match(/"downlinkEnabled": false/g)||[]).length;
    if(dlOff>4) s.push({t:'warning',m:`⚠️ <strong>Downlink OFF su ${dlOff} canali</strong>`,fix:'meshtastic --ch-set downlink_enabled true --ch-index 0'});
    if(tl.includes('"deviceupdateinterval": 0'))
        s.push({t:'warning',m:'⚠️ <strong>Telemetria device: intervallo 0</strong>',fix:'meshtastic --set telemetry.device_update_interval 900'});
    if(tl.includes('"environmentupdateinterval": 0')&&tl.includes('"environmentmeasurementenabled": true'))
        s.push({t:'warning',m:'⚠️ <strong>Telemetria env: intervallo 0</strong>',fix:'meshtastic --set telemetry.environment_update_interval 900'});
    const nameMatch=text.match(/"longName":\s*"Meshtastic \w+"/);
    if(nameMatch) s.push({t:'info',m:'ℹ️ <strong>Nome di default</strong> — Personalizza!',fix:'meshtastic --set-owner "TuoNome-Citta"'});
    
    // ═══ ESTRAI URL per QR (punto 5) ═══
    const urlMatch=text.match(/Complete URL[^:]*:\s*(https:\/\/meshtastic\.org\/e\/[^\s]+)/);
    if(urlMatch){
        s.push({t:'success',m:`🔗 <strong>URL Configurazione estratto</strong>`});
    }
    
    // Rendering
    let h='<div class="card config-highlight" style="border-color:var(--accent)"><div class="card-title">🔍 Analisi Completa — '+s.length+' elementi</div>';
    const order={danger:0,warning:1,info:2,success:3};
    s.sort((a,b)=>(order[a.t]||99)-(order[b.t]||99));
    s.forEach(item=>{
        h+=`<div class="alert alert-${item.t}" style="margin-bottom:0.5rem">${item.m}`;
        if(item.fix){
            h+=`<div class="cli-run-row" style="margin-top:0.3rem"><div class="cli-block" style="margin:0;flex:1"><code>${item.fix}</code></div><button class="btn btn-sm btn-primary cli-exec" onclick="execCmd('${item.fix.replace('meshtastic ','').replace(/'/g,"\\'")}')">▶</button></div>`;
        }
        h+=`</div>`;
    });
    
    // QR Code dal link estratto
    if(urlMatch){
        h+=`<div style="margin-top:1rem;display:flex;gap:0.5rem;flex-wrap:wrap;align-items:center">
            <a href="${urlMatch[1]}" target="_blank" class="btn btn-primary">📱 Apri Config nell'App</a>
            <button class="btn btn-secondary" onclick="copyText('${urlMatch[1]}')">📋 Copia Link</button>
            <button class="btn btn-secondary" onclick="generateQR('node-qr-result')">📱 Genera QR</button>
        </div><div id="node-qr-result" style="margin-top:0.5rem;text-align:center"></div>`;
    }
    
    h+='</div>';
    c.innerHTML=h;
    initCopyButtons();
    c.scrollIntoView({behavior:'smooth',block:'start'});
}

// ══════════════════════════════════════════════════════════════
// 🔐 GENERATORE PSK — Chiavi crittografiche per canali
// ══════════════════════════════════════════════════════════════

function generatePSK(){
    const type=document.getElementById('psk-type')?.value||'256';
    const target=document.getElementById('psk-target-ch')?.value||'none';
    const result=document.getElementById('psk-result');
    const output=document.getElementById('psk-output');
    const info=document.getElementById('psk-info');
    const cliDiv=document.getElementById('psk-cli');
    if(!result||!output)return;

    let bytes, pskB64, label, entropy;
    
    if(type==='1'){
        // Chiave pubblica (1 byte)
        pskB64='AQ==';
        label='🔓 Chiave Pubblica (1 byte) — Canale aperto, nessuna crittografia';
        entropy='0 bit (pubblica)';
    }else{
        // Genera chiave crittografica forte
        const len=type==='256'?32:16;
        const arr=new Uint8Array(len);
        crypto.getRandomValues(arr); // CSPRNG del browser
        // Base64 encode
        let binary='';
        arr.forEach(b=>binary+=String.fromCharCode(b));
        pskB64=btoa(binary);
        label=type==='256'
            ?'🔒 AES-256 (32 byte) — Massima sicurezza, chiave militare'
            :'🔑 AES-128 (16 byte) — Buona sicurezza, compatibilità massima';
        entropy=`${len*8} bit di entropia (CSPRNG)`;
    }
    
    output.textContent=pskB64;
    info.innerHTML=`${label}<br><span style="color:var(--accent);">Entropia: ${entropy}</span>`;
    result.style.display='block';
    
    // Applica a canale se selezionato
    if(target!=='none'){
        if(target==='all_secondary'){
            for(let i=1;i<=7;i++){
                const el=document.getElementById(`pro-ch${i}-psk`);
                if(el)el.value=pskB64;
            }
            showToast(t('🔐 PSK applicata a Ch1-Ch7'));
        }else{
            const el=document.getElementById(`pro-ch${target}-psk`);
            if(el)el.value=pskB64;
            showToast(t('🔐 PSK applicata a Ch') + target);
        }
    }
    
    // Mostra comando CLI
    if(target!=='none'&&target!=='all_secondary'){
        cliDiv.innerHTML=`<div class="cli-block" style="margin:0;font-size:0.72rem;"><code>meshtastic --ch-set psk "base64:${pskB64}" --ch-index ${target}</code></div>`;
        initCopyButtons();
    }else if(target==='all_secondary'){
        let cmds='';
        for(let i=1;i<=7;i++){
            cmds+=`meshtastic --ch-set psk "base64:${pskB64}" --ch-index ${i}\n`;
        }
        cliDiv.innerHTML=`<div class="cli-block" style="margin:0;font-size:0.72rem;"><code>${cmds.trim().replace(/\n/g,'<br>')}</code></div>`;
        initCopyButtons();
    }else{
        cliDiv.innerHTML='';
    }
}

// ══════════════════════════════════════════════════════════════
// 🔧 MOD FIRMWARE — Operazioni avanzate sul dispositivo
// ══════════════════════════════════════════════════════════════

function termAppendMod(msg,type){
    termAppendTo('mod-terminal',msg,type||'output');
}

async function modExec(args,termId){
    if(_execLock)return;
    _execLock=true;
    try{
    const _term=document.getElementById('mod-terminal');
    if(_term)_term.scrollIntoView({behavior:'smooth',block:'center'});
    
    const fullCmd=`meshtastic ${getPortArg()}${args}`;
    termAppendMod(`\n$ ${fullCmd}`,'prompt');
    termAppendMod(t('⏳ Esecuzione...'),'info');
    
    const timeout=args.includes('--export-config')||args.includes('--nodes')?120:60;
    const d=await apiFetch('cli/exec',{method:'POST',body:JSON.stringify({args:args,timeout:timeout,port:APP.selectedPort||''})});

    // 🔧 FIX: usare _term (elemento terminale), NON t (funzione traduzione!)
    if(_term){const lines=_term.querySelectorAll('span');const last=lines[lines.length-1];if(last&&last.textContent.includes('⏳'))last.remove();}

    if(d){
        if(d.not_found){
            termAppendMod(t('❌ meshtastic CLI non trovato — installa con: pip install meshtastic'),'error');
        }else{
            if(d.stdout)termAppendMod(d.stdout,'output');
            if(d.stderr){
                termAppendMod(d.stderr,'error');
                // 🩺 Smart error parsing per MOD terminal
                await parseTerminalError(d.stderr, 'mod-terminal');
            }
            if(!d.stdout&&!d.stderr)termAppendMod(t('✅ Eseguito (nessun output)'),'info');
            // Se returncode != 0 e c'è stdout con errore
            if(d.returncode && d.returncode !== 0 && d.stdout){
                await parseTerminalError(d.stdout, 'mod-terminal');
            }
        }
    }else{
        termAppendMod(t('❌ Errore comunicazione server'),'error');
    }
    if(_term)_term.scrollTop=_term.scrollHeight;
    }finally{_execLock=false;}
}

function modSetNodeId(){
    const id=(document.getElementById('mod-nodeid')?.value||'').trim();
    if(!id){showToast(t('⚠️ Inserisci un Node ID'));return;}
    // Validate hex format
    const clean=id.replace(/^!/,'');
    if(!/^[0-9a-fA-F]{8}$/.test(clean)){
        showToast(t('⚠️ Node ID deve essere 8 cifre hex (es. a1b2c3d4)'));
        return;
    }
    if(confirm(t('⚠️ CAMBIO NODE ID')+`\n\n`+t('Nuovo ID')+`: !${clean}\n\n`+t('ATTENZIONE:')+`\n• `+t('Il nodo apparirà come un NUOVO dispositivo nella rete mesh')+`\n• `+t('Gli altri nodi perderanno la connessione al vecchio ID')+`\n• `+t('Non c\u0027è modo di tornare indietro automaticamente')+`\n\n`+t('Confermi?'))){
        // meshtastic --set device.node_id 0xHEX + reboot
        modExec(`--set device.node_id 0x${clean}`,'mod');
        setTimeout(()=>{
            termAppendMod(t('⏳ Riavvio nodo per applicare nuovo ID...'),'info');
            modExec('--reboot','mod');
        },2000);
    }
}

function modSetHam(){
    const call=(document.getElementById('mod-hamcall')?.value||'').trim().toUpperCase();
    if(!call){showToast(t('⚠️ Inserisci un call sign'));return;}
    if(!/^[A-Z0-9]{3,8}$/.test(call)){
        showToast(t('⚠️ Call sign non valido (3-8 caratteri alfanumerici)'));
        return;
    }
    if(confirm(t('⚠️ SET HAM MODE')+`\n\nCall Sign: ${call}\n\n`+t('Questo comando:')+`\n• `+t('Imposta il call sign come nome lungo')+`\n• `+t('Abilita is_licensed = true')+`\n• `+t('La crittografia E2E viene disabilitata (obbligo HAM)')+`\n• `+t('PSK canale primario → AQ== (pubblico)')+`\n\n`+t('Confermi?'))){
        modExec(`--set-ham "${call}"`,'mod');
    }
}

function modGenerateRandomId(){
    const arr=new Uint8Array(4);
    crypto.getRandomValues(arr);
    const hex=Array.from(arr).map(b=>b.toString(16).padStart(2,'0')).join('');
    document.getElementById('mod-nodeid').value='!'+hex;
    showToast(t('🎲 ID generato: !') + hex);
}

async function modExportConfig(){
    termAppendMod('\n'+t('📤 Export configurazione YAML...'),'prompt');
    const d=await apiFetch('cli/exec',{method:'POST',body:JSON.stringify({args:'--export-config',timeout:120,port:APP.selectedPort||''})});
    if(d&&d.stdout){
        termAppendMod(t('✅ Config esportata (')+d.stdout.length+t(' caratteri)'),'info');
        // Download come file
        const blob=new Blob([d.stdout],{type:'text/yaml'});
        const url=URL.createObjectURL(blob);
        const a=document.createElement('a');
        a.href=url;
        a.download='meshtastic_config_backup.yaml';
        a.click();
        URL.revokeObjectURL(url);
        termAppendMod(t('💾 File meshtastic_config_backup.yaml scaricato'),'output');
    }else{
        termAppendMod(t('❌ Errore export config'),'error');
        if(d&&d.stderr)termAppendMod(d.stderr,'error');
    }
}

async function modImportConfig(){
    const fileInput=document.getElementById('mod-import-file');
    if(!fileInput||!fileInput.files||fileInput.files.length===0){
        showToast(t('⚠️ Seleziona un file YAML'));return;
    }
    const file=fileInput.files[0];
    if(!confirm(t('⚠️ IMPORT CONFIGURAZIONE')+`\n\nFile: ${file.name} (${(file.size/1024).toFixed(1)} KB)\n\n`+t('Questo SOVRASCRIVE TUTTA la configurazione attuale del nodo!')+`\n\n`+t('Confermi?'))){return;}
    
    termAppendMod(`\n📥 Import config da ${file.name}...`,'prompt');
    
    const text=await file.text();
    // Salva il file sul server per poi usare --configure
    const d=await apiFetch('mod/import-config',{method:'POST',body:JSON.stringify({yaml_content:text,filename:file.name})});
    if(d&&d.success){
        termAppendMod('✅ '+t(d.message),'output');
    }else{
        termAppendMod('❌ '+(d?.error||t('Errore import')),'error');
    }
}

async function modRawSet(){
    const path=(document.getElementById('mod-raw-path')?.value||'').trim();
    const value=(document.getElementById('mod-raw-value')?.value||'').trim();
    if(!path){showToast(t('⚠️ Inserisci il path del parametro'));return;}
    if(!value){showToast(t('⚠️ Inserisci il valore'));return;}
    await modSetAndVerify(path, value);
}

// ══════════════════════════════════════════════════════════════
// 🔧 SET + VERIFY + REBOOT — Il metodo forte
// ══════════════════════════════════════════════════════════════

async function modSetAndVerify(path, value, skipReboot) {
    // 1. SET
    termAppendMod(`\n⚡ SET: ${path} = ${value}`, 'prompt');
    await modExec(`--set ${path} ${value}`, 'mod');
    
    // 2. Pausa per lasciar scrivere il firmware
    await new Promise(r => setTimeout(r, 2000));
    
    // 3. VERIFY — leggi il valore appena scritto
    termAppendMod(t('🔍 Verifica...'), 'info');
    const d = await apiFetch('cli/exec', {
        method: 'POST',
        body: JSON.stringify({args: `--get ${path}`, timeout: 30, port: APP.selectedPort || ''})
    });
    
    if (d && d.stdout) {
        termAppendMod(d.stdout, 'output');
        
        // Controlla se il valore è stato applicato
        const output = d.stdout.toLowerCase();
        const setValue = value.toString().toLowerCase();
        
        if (output.includes(setValue) || output.includes(path.split('.').pop())) {
            // Check for clamping: value was set but firmware changed it
            const match = output.match(new RegExp(path.split('.').pop() + ':\\s*(.+)', 'i'));
            if (match) {
                const actualVal = match[1].trim();
                if (actualVal !== value && actualVal !== setValue) {
                    termAppendMod(t('⚠️ ATTENZIONE: hai impostato')+` ${value} `+t('ma il firmware ha applicato')+` ${actualVal}`, 'error');
                    termAppendMod(t('ℹ️ Il firmware ha dei limiti per la tua regione (EU_868: max 27 dBm, duty cycle 10%)'), 'info');
                    termAppendMod(t('ℹ️ Questo valore')+` (${actualVal}) `+t('è il massimo consentito dal firmware per la tua regione.'), 'info');
                    return false; // Clamped
                }
            }
        }
    }
    
    // 4. REBOOT se richiesto
    if (!skipReboot) {
        termAppendMod(t('🔄 Riavvio nodo per applicare le modifiche...'), 'info');
        await new Promise(r => setTimeout(r, 1000));
        await modExec('--reboot', 'mod');
        termAppendMod(t('✅ Nodo riavviato — la modifica è attiva.'), 'info');
    }
    return true;
}

function modRawGet(){
    const path=(document.getElementById('mod-raw-path')?.value||'').trim();
    if(!path){showToast(t('⚠️ Inserisci il path del parametro'));return;}
    modExec(`--get ${path}`,'mod');
}

async function modBatchExec(){
    const text=(document.getElementById('mod-raw-batch')?.value||'').trim();
    if(!text){showToast(t('⚠️ Inserisci almeno un comando'));return;}
    const lines=text.split('\n').map(l=>l.trim()).filter(l=>l&&!l.startsWith('#'));
    if(lines.length===0)return;
    
    const _preview=lines.slice(0,5).join('\n');
    const _moreText=lines.length>5?'\n... (+'+(lines.length-5)+' '+t('altri')+')':'';
    if(!confirm(t('⚠️ BATCH EXEC')+'\n\n'+t('Eseguirai')+' '+lines.length+' '+t('comandi in sequenza')+'.\n'+t('Alla fine il nodo verrà riavviato automaticamente per applicare TUTTE le modifiche.')+'\n\n'+_preview+_moreText+'\n\n'+t('Confermi?')))return;
    
    termAppendMod(`\n🔧 Batch: ${lines.length} comandi in sequenza`,'prompt');
    
    let setCount = 0;
    for(let i=0;i<lines.length;i++){
        let cmd=lines[i];
        if(cmd.startsWith('meshtastic '))cmd=cmd.replace('meshtastic ','');
        termAppendMod(`\n[${i+1}/${lines.length}] ${cmd}`,'prompt');
        
        const d=await apiFetch('cli/exec',{method:'POST',body:JSON.stringify({args:cmd,timeout:30,port:APP.selectedPort||''})});
        if(d){
            if(d.stdout)termAppendMod(d.stdout,'output');
            if(d.stderr)termAppendMod(d.stderr,'error');
            if(!d.stdout&&!d.stderr)termAppendMod(t('✅ OK'),'info');
        }else{
            termAppendMod(t('❌ Errore'),'error');
        }
        
        if(cmd.includes('--set'))setCount++;
        if(i<lines.length-1)await new Promise(r=>setTimeout(r,1500));
    }
    
    // Reboot automatico alla fine se ci sono stati dei --set
    if(setCount > 0){
        termAppendMod(`\n🔄 Riavvio nodo per applicare ${setCount} modifiche...`,'info');
        await new Promise(r=>setTimeout(r,1000));
        await modExec('--reboot','mod');
        termAppendMod('✅ Nodo riavviato — tutte le modifiche sono attive.','info');
        
        // Verifica dopo reboot
        termAppendMod(t('\n🔍 Verifica post-reboot (attendo avvio nodo 5s)...'),'info');
        await new Promise(r=>setTimeout(r,5000));
        await modExec('--get all','mod');
    }else{
        termAppendMod(`\n🏁 Batch completato: ${lines.length} comandi eseguiti`,'info');
    }
}

async function modEsptool(action){
    const port=APP.selectedPort;
    if(!port){showToast(t('⚠️ Seleziona una porta USB prima'));return;}
    
    let cmd='';
    let warn='';
    switch(action){
        case 'chip_id':
            cmd=`esptool.py --port ${port} chip_id`;
            break;
        case 'flash_id':
            cmd=`esptool.py --port ${port} flash_id`;
            break;
        case 'read_nvs':
            cmd=`esptool.py --port ${port} read_flash 0x9000 0x5000 nvs_backup.bin`;
            warn='Backup NVS (20KB) nella cartella dell\'app';
            break;
        case 'erase_flash':
            cmd=`esptool.py --port ${port} erase_flash`;
            warn=t('TUTTA la memoria flash verrà cancellata!');
            break;
    }
    
    if(warn){
        termAppendMod(`⚠️ ${warn}`,'error');
    }
    
    termAppendMod(`\n$ ${cmd}`,'prompt');
    termAppendMod('⏳ Esecuzione esptool...','info');
    
    const d=await apiFetch('system/exec',{method:'POST',body:JSON.stringify({command:cmd})});
    const _term=document.getElementById('mod-terminal');
    if(_term){const lines=_term.querySelectorAll('span');const last=lines[lines.length-1];if(last&&last.textContent.includes('⏳'))last.remove();}
    
    if(d){
        if(d.success){
            if(d.stdout)termAppendMod(d.stdout,'output');
        }else{
            termAppendMod(t(d.error||'❌ Errore esptool'),'error');
            if(d.stdout)termAppendMod(d.stdout,'output');
            if(!d.error||d.error.includes('not found')){
                termAppendMod(t('💡 Installa esptool: pip install esptool'),'info');
            }
        }
    }
    if(_term)_term.scrollTop=_term.scrollHeight;
}

async function modEsptoolCustom(){
    const args=(document.getElementById('mod-esptool-cmd')?.value||'').trim();
    if(!args){showToast(t('⚠️ Inserisci gli argomenti esptool'));return;}
    const cmd=`esptool.py ${args}`;
    termAppendMod(`\n$ ${cmd}`,'prompt');
    const d=await apiFetch('system/exec',{method:'POST',body:JSON.stringify({command:cmd})});
    if(d){
        if(d.stdout)termAppendMod(d.stdout,'output');
        if(d.stderr)termAppendMod(d.stderr,'error');
        if(!d.stdout&&!d.stderr&&d.error)termAppendMod(d.error,'error');
    }
}

// ══════════════════════════════════════════════════════════════
// 🧙 MOD WIZARD
// ══════════════════════════════════════════════════════════════

function wizToggle(id, show) {
    const el = document.getElementById(id);
    if (el) el.style.display = show ? 'block' : 'none';
}

function wizBuildCommands() {
    const cmds = [];
    const logoSteps = [];
    
    // Nome
    if (document.getElementById('wiz-name')?.checked) {
        const ln = document.getElementById('wiz-longname')?.value?.trim();
        const sn = document.getElementById('wiz-shortname')?.value?.trim();
        if (ln) cmds.push(`--set-owner "${ln}"`);
        if (sn) cmds.push(`--set-owner-short "${sn}"`);
    }
    
    // Node ID
    if (document.getElementById('wiz-id')?.checked) {
        const nid = document.getElementById('wiz-nodeid')?.value?.trim();
        if (nid) {
            const hex = nid.replace('!','');
            cmds.push(`--set device.node_id 0x${hex}`);
        }
    }
    
    // Ruolo
    if (document.getElementById('wiz-role')?.checked) {
        const role = document.getElementById('wiz-role-sel')?.value;
        if (role) cmds.push(`--set device.role ${role}`);
    }
    
    // TX Power
    if (document.getElementById('wiz-power')?.checked) {
        const pw = document.getElementById('wiz-power-sel')?.value;
        if (pw) cmds.push(`--set lora.tx_power ${pw}`);
    }
    
    // Regione
    if (document.getElementById('wiz-region')?.checked) {
        const reg = document.getElementById('wiz-region-sel')?.value;
        if (reg) cmds.push(`--set lora.region ${reg}`);
    }
    
    // ── Legacy / Firmware 2.7 fixes ──
    if (document.getElementById('wiz-telem')?.checked) {
        cmds.push('--set telemetry.device_update_interval 900');
        cmds.push('--set telemetry.environment_update_interval 900');
    }
    if (document.getElementById('wiz-mapReport')?.checked) {
        cmds.push('--set mqtt.map_report_enabled true');
    }
    if (document.getElementById('wiz-neighborInfo')?.checked) {
        cmds.push('--set neighbor_info.enabled true');
        cmds.push('--set neighbor_info.update_interval 900');
    }
    if (document.getElementById('wiz-timezone')?.checked) {
        cmds.push('--set device.tzdef CET-1CEST,M3.5.0,M10.5.0/3');
    }
    
    // Logo (genera istruzioni, non comandi CLI)
    if (document.getElementById('wiz-logo')?.checked) {
        const bt = document.getElementById('wiz-boottext')?.value?.trim() || '';
        const dev = document.getElementById('wiz-device')?.value || 'heltec-v3';
        logoSteps.push('# ══ LOGO PERSONALIZZATO (esegui nel tuo terminale) ══');
        logoSteps.push('pip install platformio');
        logoSteps.push('git clone https://github.com/meshtastic/firmware.git');
        logoSteps.push('cd firmware');
        logoSteps.push('# 1. Converti il tuo PNG (128x64, B/N) in XBM:');
        logoSteps.push('#    https://windows87.github.io/xbm-viewer-converter/');
        logoSteps.push('# 2. Copia il file XBM convertito:');
        logoSteps.push('#    cp tuo_logo.xbm src/graphics/img/icon.xbm');
        if (bt) {
            logoSteps.push(`# 3. In src/graphics/Screen.cpp cerca:`);
            logoSteps.push(`#    const char *title = "meshtastic.org";`);
            logoSteps.push(`#    Sostituisci con: const char *title = "${bt}";`);
        }
        logoSteps.push(`# Compila e flasha:`);
        logoSteps.push(`pio run -e ${dev}`);
        logoSteps.push(`pio run -e ${dev} --target upload`);
    }
    
    return { cmds, logoSteps };
}

function wizPreview() {
    const { cmds, logoSteps } = wizBuildCommands();
    const summary = document.getElementById('wiz-summary');
    const pre = document.getElementById('wiz-commands');
    
    if (cmds.length === 0 && logoSteps.length === 0) {
        pre.textContent = t('⚠️ Seleziona almeno una opzione e compila i campi!');
        summary.style.display = 'block';
        return;
    }
    
    let text = '';
    if (cmds.length > 0) {
        text += '# ══ COMANDI CLI (eseguiti automaticamente) ══\n';
        cmds.forEach(c => text += `meshtastic ${c}\n`);
    }
    if (logoSteps.length > 0) {
        if (text) text += '\n';
        text += logoSteps.join('\n') + '\n';
    }
    
    pre.textContent = text;
    summary.style.display = 'block';
}

async function wizExecute() {
    const { cmds, logoSteps } = wizBuildCommands();
    
    if (cmds.length === 0 && logoSteps.length === 0) {
        alert(t('Seleziona almeno una opzione e compila i campi!'));
        return;
    }
    
    if (!confirm(t('Verranno eseguiti')+` ${cmds.length} `+t('comandi CLI')+`.\n`+t('Dopo i comandi il nodo verrà riavviato automaticamente.')+`\n${logoSteps.length > 0 ? t('Le istruzioni per il logo verranno mostrate nel terminale.')+'\n' : ''}`+t('Continuare?'))) return;
    
    const _term = document.getElementById('mod-terminal');
    if (!_term) return;
    
    // Show logo instructions in terminal
    if (logoSteps.length > 0) {
        logoSteps.forEach(step => {
            const span = document.createElement('span');
            span.className = step.startsWith('#') ? 'info' : 'prompt';
            span.textContent = step;
            _term.appendChild(span);
        });
    }
    
    // Execute CLI commands sequentially (WITHOUT reboot after each - reboot at end)
    let setCount = 0;
    for (let i = 0; i < cmds.length; i++) {
        const cmd = cmds[i];
        const span = document.createElement('span');
        span.className = 'prompt';
        span.textContent = `[${i+1}/${cmds.length}] meshtastic ${cmd}`;
        _term.appendChild(span);
        _term.scrollTop = _term.scrollHeight;
        
        await modExec(cmd, 'mod');
        if (cmd.includes('--set')) setCount++;
        
        if (i < cmds.length - 1) {
            await new Promise(r => setTimeout(r, 2000));
        }
    }
    
    // Single reboot at the end to apply ALL changes
    if (setCount > 0) {
        const rSpan = document.createElement('span');
        rSpan.className = 'info';
        rSpan.textContent = t('🔄 Riavvio nodo per applicare') + ` ${setCount} ` + t('modifiche...');
        _term.appendChild(rSpan);
        
        await new Promise(r => setTimeout(r, 1000));
        await modExec('--reboot', 'mod');
        
        // Wait for node to come back
        const waitSpan = document.createElement('span');
        waitSpan.className = 'info';
        waitSpan.textContent = t('⏳ Attendo riavvio nodo (5 secondi)...');
        _term.appendChild(waitSpan);
        await new Promise(r => setTimeout(r, 5000));
        
        // Verify all changes
        const vSpan = document.createElement('span');
        vSpan.className = 'info';
        vSpan.textContent = t('🔍 Verifica configurazione post-reboot...');
        _term.appendChild(vSpan);
        await modExec('--get all', 'mod');
    }
    
    const done = document.createElement('span');
    done.className = 'info';
    done.textContent = t('✅ Wizard completato!') + ` ${cmds.length} ` + t('comandi eseguiti + reboot + verifica.');
    _term.appendChild(done);
    _term.scrollTop = _term.scrollHeight;
}

// ══════════════════════════════════════════════════════════════
// 🔓 SBLOCCA LIMITI FIRMWARE — Sequenze corrette con reboot
// ══════════════════════════════════════════════════════════════

async function unlockTxPower() {
    const power = document.getElementById('unlock-txpower')?.value || '30';
    
    if (!confirm(
        t('⚠️ SBLOCCO TX POWER A')+` ${power} dBm\n\n` +
        t('Questa operazione:')+`\n` +
        t('1. Attiva modalità HAM (is_licensed=true)')+`\n` +
        t('2. DISABILITA la crittografia E2E!')+`\n` +
        t('3. Riavvia il nodo')+`\n` +
        `4. `+t('Imposta TX power a')+` ${power} dBm\n` +
        t('5. Riavvia di nuovo per applicare')+`\n` +
        t('6. Verifica il valore effettivo')+`\n\n` +
        t('⚠️ I tuoi messaggi saranno in CHIARO!')+`\n` +
        t('⚠️ Oltre 27 dBm è ILLEGALE in EU senza licenza HAM!')+`\n\n` +
        t('Confermi?')
    )) return;
    
    termAppendMod('\n'+t('🔓 ═══ SBLOCCO TX POWER ═══'), 'prompt');
    
    // Step 1: Attiva is_licensed
    termAppendMod(t('\n[1/6] Attivazione modalità HAM (is_licensed=true)...'), 'info');
    await modExec('--set device.is_licensed true', 'mod');
    await new Promise(r => setTimeout(r, 2000));
    
    // Step 2: Primo reboot (il firmware deve leggere is_licensed al boot)
    termAppendMod('\n[2/6] Primo reboot (necessario per attivare HAM)...', 'info');
    await modExec('--reboot', 'mod');
    
    // Step 3: Attendi che il nodo torni online
    termAppendMod('\n[3/6] Attendo riavvio nodo (8 secondi)...', 'info');
    await new Promise(r => setTimeout(r, 8000));
    
    // Step 4: Ora imposta TX power (il firmware non clamperà perché is_licensed è attivo)
    termAppendMod(`\n[4/6] Impostazione TX power a ${power} dBm...`, 'info');
    await modExec(`--set lora.tx_power ${power}`, 'mod');
    await new Promise(r => setTimeout(r, 2000));
    
    // Step 5: Secondo reboot per applicare
    termAppendMod('\n[5/6] Secondo reboot per applicare TX power...', 'info');
    await modExec('--reboot', 'mod');
    await new Promise(r => setTimeout(r, 8000));
    
    // Step 6: Verifica
    termAppendMod(t('\n[6/6] Verifica valori effettivi...'), 'info');
    await modExec('--get lora.tx_power', 'mod');
    await new Promise(r => setTimeout(r, 1500));
    await modExec('--get device.is_licensed', 'mod');
    
    termAppendMod('\n🔓 ═══ SBLOCCO TX POWER COMPLETATO ═══', 'prompt');
    termAppendMod(t('⚠️ Ricorda: la crittografia E2E è ORA DISABILITATA'), 'error');
    termAppendMod(t('Per ripristinare: usa il pulsante "Ripristina limiti"'), 'info');
}

async function relockTxPower() {
    if (!confirm(
        t('Ripristino limiti:')+`\n\n` +
        t('1. Disattiva modalità HAM')+`\n` +
        t('2. Riporta TX power a 27 dBm')+`\n` +
        t('3. Riattiva la crittografia E2E')+`\n\n` +
        t('Confermi?')
    )) return;
    
    termAppendMod('\n'+t('🔒 ═══ RIPRISTINO LIMITI ═══'), 'prompt');
    
    await modExec('--set device.is_licensed false', 'mod');
    await new Promise(r => setTimeout(r, 1500));
    await modExec('--set lora.tx_power 27', 'mod');
    await new Promise(r => setTimeout(r, 1500));
    
    termAppendMod('\n🔄 Reboot per applicare...', 'info');
    await modExec('--reboot', 'mod');
    await new Promise(r => setTimeout(r, 8000));
    
    termAppendMod(t('\n🔍 Verifica...'), 'info');
    await modExec('--get lora.tx_power', 'mod');
    await new Promise(r => setTimeout(r, 1500));
    await modExec('--get device.is_licensed', 'mod');
    
    termAppendMod('\n🔒 ═══ LIMITI RIPRISTINATI ═══', 'prompt');
    termAppendMod('✅ Crittografia E2E riattivata', 'info');
}

async function unlockDutyCycle(enable) {
    const val = enable ? 'true' : 'false';
    const msg = enable
        ? t('⚠️ SBLOCCO DUTY CYCLE')+'\n\n'+t('Il nodo potrà trasmettere senza il limite del 10%.')+'\n'+t('Questo viola la normativa ETSI EN 300 220.')+'\n\n'+t('Confermi?')
        : t('Ripristina il duty cycle al 10% standard.')+'\n\n'+t('Confermi?');
    
    if (!confirm(msg)) return;
    
    termAppendMod(`\n${enable?'🔓':'🔒'} ${enable?'Sblocco':'Ripristino'} duty cycle...`, 'prompt');
    await modExec(`--set lora.override_duty_cycle ${val}`, 'mod');
    await new Promise(r => setTimeout(r, 2000));
    
    termAppendMod(t('🔄 Reboot per applicare...'), 'info');
    await modExec('--reboot', 'mod');
    await new Promise(r => setTimeout(r, 8000));
    
    termAppendMod('🔍 Verifica...', 'info');
    await modExec('--get lora.override_duty_cycle', 'mod');
    
    termAppendMod(`\n✅ Duty cycle ${enable?'SBLOCCATO — trasmissione continua':'RIPRISTINATO — limite 10%'}`, 'info');
}

async function unlockManualRadio(enable) {
    if (enable) {
        const bw = document.getElementById('unlock-bw')?.value || '250';
        const sf = document.getElementById('unlock-sf')?.value || '11';
        const cr = document.getElementById('unlock-cr')?.value || '5';
        
        if (!confirm(
            t('⚠️ RADIO MANUALE')+`\n\n` +
            t('Parametri')+`: BW=${bw}kHz, SF${sf}, CR=4/${cr}\n\n` +
            t('Il nodo NON comunicherà più con chi usa preset standard!')+`\n` +
            t('Tutti i nodi della rete devono avere gli stessi parametri.')+`\n\n` +
            t('Confermi?')
        )) return;
        
        termAppendMod('\n'+t('🔓 ═══ RADIO MANUALE ═══'), 'prompt');
        
        await modExec('--set lora.use_preset false', 'mod');
        await new Promise(r => setTimeout(r, 1500));
        await modExec(`--set lora.bandwidth ${bw}`, 'mod');
        await new Promise(r => setTimeout(r, 1500));
        await modExec(`--set lora.spread_factor ${sf}`, 'mod');
        await new Promise(r => setTimeout(r, 1500));
        await modExec(`--set lora.coding_rate ${cr}`, 'mod');
        await new Promise(r => setTimeout(r, 1500));
        
        termAppendMod('🔄 Reboot per applicare...', 'info');
        await modExec('--reboot', 'mod');
        await new Promise(r => setTimeout(r, 8000));
        
        termAppendMod('🔍 Verifica...', 'info');
        await modExec('--get lora', 'mod');
        
        termAppendMod(`\n✅ Radio manuale: BW=${bw}, SF${sf}, CR=4/${cr}`, 'info');
        termAppendMod('⚠️ Incompatibile con preset standard della mesh!', 'error');
    } else {
        if (!confirm(t('Torna al preset MediumFast standard?')+'\n\n'+t('Confermi?'))) return;
        
        termAppendMod('\n🔒 Ripristino preset MediumFast...', 'prompt');
        await modExec('--set lora.use_preset true', 'mod');
        await new Promise(r => setTimeout(r, 1500));
        await modExec('--set lora.modem_preset MEDIUM_FAST', 'mod');
        await new Promise(r => setTimeout(r, 1500));
        
        termAppendMod('🔄 Reboot per applicare...', 'info');
        await modExec('--reboot', 'mod');
        await new Promise(r => setTimeout(r, 8000));
        
        await modExec('--get lora', 'mod');
        termAppendMod('\n✅ Preset MediumFast ripristinato', 'info');
    }
}

async function unlockFrequency() {
    const freq = parseFloat(document.getElementById('unlock-freq')?.value || '0');
    if (!freq || freq < 100) {
        showToast(t('⚠️ Inserisci una frequenza valida (es. 869.525)'));
        return;
    }
    
    if (!confirm(
        t('⚠️ OVERRIDE FREQUENZA:')+` ${freq} MHz\n\n` +
        t('Il nodo trasmetterà su')+` ${freq} MHz `+t('indipendentemente dalla regione.')+`\n` +
        t('Trasmettere fuori dalla banda 868 MHz in EU è un REATO PENALE.')+`\n` +
        t('Il chip deve supportare fisicamente questa frequenza.')+`\n\n` +
        t('Confermi?')
    )) return;
    
    termAppendMod(`\n🔓 Override frequenza a ${freq} MHz...`, 'prompt');
    await modExec(`--set lora.override_frequency ${freq}`, 'mod');
    await new Promise(r => setTimeout(r, 2000));
    
    termAppendMod('🔄 Reboot per applicare...', 'info');
    await modExec('--reboot', 'mod');
    await new Promise(r => setTimeout(r, 8000));
    
    termAppendMod('🔍 Verifica...', 'info');
    await modExec('--get lora.override_frequency', 'mod');
    
    termAppendMod(`\n✅ Frequenza override: ${freq} MHz`, 'info');
}

// ══════════════════════════════════════════════════════════════
// 🔨 FIRMWARE CUSTOM BUILDER — Genera script PlatformIO
// ══════════════════════════════════════════════════════════════

function generateFirmwareScript() {
    const device = document.getElementById('fw-device')?.value || 'heltec-v3';
    const power = document.getElementById('fw-power')?.value || '30';
    const boottext = document.getElementById('fw-boottext')?.value?.trim() || '';
    const dutyOverride = document.getElementById('fw-duty')?.value === 'yes';
    
    const isWin = navigator.platform.indexOf('Win') > -1;
    const comment = isWin ? 'REM' : '#';
    const nl = '\n';
    
    let script = '';
    
    script += `${comment} ════════════════════════════════════════════════════════${nl}`;
    script += `${comment}  MESHTASTIC CUSTOM FIRMWARE BUILDER${nl}`;
    script += `${comment}  Generato da Meshtastic Italia Network App v1.1.0${nl}`;
    script += `${comment}  Dispositivo: ${device} | TX Power: ${power} dBm${nl}`;
    script += `${comment}  © 2026 MANGOLINK${nl}`;
    script += `${comment} ════════════════════════════════════════════════════════${nl}${nl}`;
    
    script += `${comment} STEP 1: Installa prerequisiti${nl}`;
    script += `pip install platformio${nl}`;
    script += `${nl}`;
    
    script += `${comment} STEP 2: Clona il firmware ufficiale Meshtastic${nl}`;
    script += `git clone https://github.com/meshtastic/firmware.git${nl}`;
    script += `cd firmware${nl}`;
    script += `git submodule update --init --recursive${nl}`;
    script += `${nl}`;
    
    script += `${comment} STEP 3: PATCH — Modifica power_limit EU868 da 27 a ${power}${nl}`;
    script += `${comment} File: src/mesh/RadioInterface.cpp${nl}`;
    script += `${comment} Cerca la riga: RDEF(EU868, 869.4f, 869.65f, 10, 0, 27, false, false, false)${nl}`;
    script += `${comment} Sostituisci 27 con ${power}${nl}`;
    
    if (isWin) {
        script += `powershell -Command "(Get-Content src\\mesh\\RadioInterface.cpp) -replace 'RDEF\\(EU868, 869.4f, 869.65f, 10, 0, 27,', 'RDEF(EU868, 869.4f, 869.65f, 10, 0, ${power},' | Set-Content src\\mesh\\RadioInterface.cpp"${nl}`;
    } else {
        script += `sed -i 's/RDEF(EU868, 869.4f, 869.65f, 10, 0, 27,/RDEF(EU868, 869.4f, 869.65f, 10, 0, ${power},/g' src/mesh/RadioInterface.cpp${nl}`;
    }
    script += `${nl}`;
    
    if (dutyOverride) {
        script += `${comment} STEP 3b: PATCH — Rimuovi duty cycle limit${nl}`;
        script += `${comment} Nella stessa riga RDEF, il primo numero dopo la frequenza (10) è il duty cycle %${nl}`;
        script += `${comment} Cambiarlo a 100 = nessun limite${nl}`;
        if (isWin) {
            script += `powershell -Command "(Get-Content src\\mesh\\RadioInterface.cpp) -replace 'RDEF\\(EU868, 869.4f, 869.65f, 10, 0, ${power},', 'RDEF(EU868, 869.4f, 869.65f, 100, 0, ${power},' | Set-Content src\\mesh\\RadioInterface.cpp"${nl}`;
        } else {
            script += `sed -i 's/RDEF(EU868, 869.4f, 869.65f, 10, 0, ${power},/RDEF(EU868, 869.4f, 869.65f, 100, 0, ${power},/g' src/mesh/RadioInterface.cpp${nl}`;
        }
        script += `${nl}`;
    }
    
    if (boottext) {
        script += `${comment} STEP 3c: PATCH — Cambia testo boot${nl}`;
        if (isWin) {
            script += `powershell -Command "(Get-Content src\\graphics\\Screen.cpp) -replace 'const char \\*title = \\x22meshtastic.org\\x22', 'const char *title = \\x22${boottext}\\x22' | Set-Content src\\graphics\\Screen.cpp"${nl}`;
        } else {
            script += `sed -i 's/const char \\*title = "meshtastic.org"/const char *title = "${boottext}"/g' src/graphics/Screen.cpp${nl}`;
        }
        script += `${nl}`;
    }
    
    script += `${comment} STEP 4: VERIFICA — Controlla che la patch sia applicata${nl}`;
    if (isWin) {
        script += `findstr "RDEF(EU868" src\\mesh\\RadioInterface.cpp${nl}`;
    } else {
        script += `grep "RDEF(EU868" src/mesh/RadioInterface.cpp${nl}`;
    }
    script += `${comment} Dovresti vedere: RDEF(EU868, 869.4f, 869.65f, ${dutyOverride?'100':'10'}, 0, ${power}, ...)${nl}`;
    script += `${nl}`;
    
    script += `${comment} STEP 5: COMPILA per ${device}${nl}`;
    script += `${comment} Questo scarica il toolchain (la prima volta richiede ~5 min)${nl}`;
    script += `pio run -e ${device}${nl}`;
    script += `${nl}`;
    
    script += `${comment} STEP 6: FLASHA sul dispositivo (collega USB prima!)${nl}`;
    script += `pio run -e ${device} --target upload${nl}`;
    script += `${nl}`;
    
    script += `${comment} STEP 7: VERIFICA — Dopo il flash, apri un terminale e controlla:${nl}`;
    script += `${comment} meshtastic --get lora.tx_power${nl}`;
    script += `${comment} Imposta il nuovo valore:${nl}`;
    script += `${comment} meshtastic --set lora.tx_power ${power}${nl}`;
    script += `${comment} meshtastic --reboot${nl}`;
    script += `${comment} meshtastic --get lora.tx_power${nl}`;
    script += `${comment} Se vedi ${power} = FUNZIONA!${nl}`;
    script += `${nl}`;
    
    script += `${comment} ════════════════════════════════════════════════════════${nl}`;
    script += `${comment} ATTENZIONE LEGALE:${nl}`;
    script += `${comment} TX power oltre 27 dBm in EU senza licenza HAM = ILLEGALE${nl}`;
    script += `${comment} D.Lgs 259/2003, sanzioni da 15.000 euro${nl}`;
    script += `${comment} L'utente è l'unico responsabile dell'uso${nl}`;
    script += `${comment} ════════════════════════════════════════════════════════${nl}`;
    
    // Show output
    const output = document.getElementById('fw-script-output');
    const pre = document.getElementById('fw-script-text');
    if (output && pre) {
        pre.textContent = script;
        output.style.display = 'block';
    }
    
    // Also show in MOD terminal
    termAppendMod('\n🔨 ═══ FIRMWARE CUSTOM SCRIPT GENERATO ═══', 'prompt');
    termAppendMod(`Dispositivo: ${device} | Power: ${power} dBm | Duty: ${dutyOverride?'OVERRIDE':'10%'}${boottext?' | Boot: '+boottext:''}`, 'info');
    termAppendMod(t('Lo script è visibile sopra. Copialo e incollalo nel tuo terminale.'), 'info');
    termAppendMod('⚠️ Devi avere Git e PlatformIO installati!', 'error');
    
    return script;
}

function copyFirmwareScript() {
    const pre = document.getElementById('fw-script-text');
    if (!pre || !pre.textContent) {
        showToast(t('⚠️ Prima genera lo script!'));
        return;
    }
    navigator.clipboard.writeText(pre.textContent).then(() => {
        showToast(t('✅ Script copiato negli appunti!'));
    }).catch(() => {
        // Fallback
        const ta = document.createElement('textarea');
        ta.value = pre.textContent;
        document.body.appendChild(ta);
        ta.select();
        document.execCommand('copy');
        document.body.removeChild(ta);
        showToast(t('✅ Script copiato!'));
    });
}

// ══════════════════════════════════════════════════════════════
// 🔍 AUTO-DETECT DISPOSITIVO — Legge --info e mappa hwModel
// ══════════════════════════════════════════════════════════════

const HW_MODEL_MAP = {
    // hwModel string → { pio: PlatformIO env, chip: radio chip, maxHwPower: max fisico dBm, pa: ha PA esterno }
    'HELTEC_V3':           { pio: 'heltec-v3',             chip: 'SX1262', maxHw: 22, pa: false },
    'HELTEC_V4':           { pio: 'heltec-v4',             chip: 'SX1262', maxHw: 30, pa: true, paNote: 'GC1109 PA' },
    'HELTEC_WIRELESS_TRACKER': { pio: 'heltec-wireless-tracker', chip: 'SX1262', maxHw: 22, pa: false },
    'HELTEC_WIRELESS_TRACKER_V2': { pio: 'heltec-wireless-tracker-V2', chip: 'SX1262', maxHw: 30, pa: true },
    'TBEAM':               { pio: 'tbeam',                 chip: 'SX1276', maxHw: 20, pa: false },
    'T_BEAM_S3_CORE':      { pio: 'tbeam-s3-core',         chip: 'SX1262', maxHw: 22, pa: false },
    'TLORA_V2_1_1_6':      { pio: 'tlora-v2-1-1_6',        chip: 'SX1262', maxHw: 22, pa: false },
    'T_DECK':              { pio: 't-deck',                 chip: 'SX1262', maxHw: 22, pa: false },
    'T_DECK_PLUS':         { pio: 't-deck-plus',            chip: 'SX1262', maxHw: 22, pa: false },
    'T_WATCH_S3':          { pio: 't-watch-s3',             chip: 'SX1262', maxHw: 22, pa: false },
    'STATION_G2':          { pio: 'station-g2',             chip: 'SX1262', maxHw: 33, pa: true, paNote: 'PA integrato 5W' },
    'RAK4631':             { pio: 'rak4631',                chip: 'SX1262', maxHw: 22, pa: false },
    'RAK11310':            { pio: 'rak11310',               chip: 'SX1262', maxHw: 22, pa: false },
    'WISMESH_TAP':         { pio: 'wismesh-tap',            chip: 'SX1262', maxHw: 22, pa: false },
    'NANO_G2_ULTRA':       { pio: 'nano-g2-ultra',          chip: 'SX1262', maxHw: 22, pa: false },
    'T_ECHO':              { pio: 't-echo',                 chip: 'SX1262', maxHw: 22, pa: false },
    'SENSECAP_INDICATOR':  { pio: 'seeed-sensecap-indicator',chip: 'SX1262', maxHw: 22, pa: false },
    'WIPHONE':             { pio: 'wiphone',                chip: 'SX1276', maxHw: 20, pa: false },
    'THINKNODE_M1':        { pio: 'thinknode-m1',           chip: 'SX1262', maxHw: 22, pa: false },
    'THINKNODE_M2':        { pio: 'thinknode-m2',           chip: 'SX1262', maxHw: 22, pa: false },
    'MUZI_R1_NEO':         { pio: 'muzi-r1-neo',            chip: 'SX1262', maxHw: 22, pa: false },
    'CANARY_ONE':          { pio: 'canary-one',             chip: 'SX1262', maxHw: 22, pa: false },
};

// Parametri bloccati dal firmware C++ (non modificabili via CLI)
const FW_CLAMPED_PARAMS = {
    'lora.tx_power': {
        clampedBy: 'RDEF power_limit in RadioInterface.cpp',
        euLimit: 27,
        bypass: 'Firmware custom con PlatformIO (modifica RDEF)',
        cliBypass: false
    },
    'lora.bandwidth': {
        clampedBy: 'bootstrapLoRaConfigFromPreset in NodeDB.cpp (se use_preset=true)',
        bypass: '--set lora.use_preset false prima di modificare',
        cliBypass: true
    },
    'lora.spread_factor': {
        clampedBy: 'bootstrapLoRaConfigFromPreset in NodeDB.cpp (se use_preset=true)',
        bypass: '--set lora.use_preset false prima di modificare',
        cliBypass: true
    },
    'lora.coding_rate': {
        clampedBy: 'bootstrapLoRaConfigFromPreset in NodeDB.cpp (se use_preset=true)',
        bypass: '--set lora.use_preset false prima di modificare',
        cliBypass: true
    },
};

async function autoDetectDevice() {
    termAppendMod('\n🔍 ═══ AUTO-DETECT DISPOSITIVO ═══', 'prompt');
    termAppendMod('Lettura info dal nodo...', 'info');
    
    const d = await apiFetch('cli/exec', {
        method: 'POST',
        body: JSON.stringify({args: '--info', timeout: 30, port: APP.selectedPort || ''})
    });
    
    if (!d || !d.stdout) {
        termAppendMod('❌ Impossibile leggere info dal nodo. Collega il dispositivo e seleziona la porta.', 'error');
        return null;
    }
    
    const output = d.stdout;
    termAppendMod(output, 'output');
    
    // Parse hwModel
    const hwMatch = output.match(/Hardware Model:\s*(\S+)/i) || output.match(/hwModel[=:\s]+(\S+)/i);
    const fwMatch = output.match(/Firmware Version:\s*([\d.]+)/i) || output.match(/firmware_version[=:\s]+([\d.]+)/i);
    const regionMatch = output.match(/lora\.region[=:\s]+(\S+)/i) || output.match(/Region:\s*(\S+)/i);
    const nodeMatch = output.match(/Num:\s*(0x[0-9a-fA-F]+)/i) || output.match(/my_node_num[=:\s]+(\d+)/i);
    const nameMatch = output.match(/Owner:\s*(.+)/i) || output.match(/long_name[=:\s]+(.+)/i);
    
    const hwModel = hwMatch ? hwMatch[1].toUpperCase().replace(/-/g, '_') : 'UNKNOWN';
    const fwVersion = fwMatch ? fwMatch[1] : 'unknown';
    const region = regionMatch ? regionMatch[1] : 'EU_868';
    const nodeName = nameMatch ? nameMatch[1].trim() : '';
    
    // Lookup in map
    const hwInfo = HW_MODEL_MAP[hwModel] || null;
    
    termAppendMod('\n📋 ═══ RISULTATO RILEVAMENTO ═══', 'prompt');
    termAppendMod(`📟 Modello: ${hwModel}`, 'info');
    termAppendMod(`📦 Firmware: ${fwVersion}`, 'info');
    termAppendMod(`🌍 Regione: ${region}`, 'info');
    if (nodeName) termAppendMod(`👤 Nome: ${nodeName}`, 'info');
    
    if (hwInfo) {
        termAppendMod(`🔧 PlatformIO env: ${hwInfo.pio}`, 'info');
        termAppendMod(`📡 Chip radio: ${hwInfo.chip}`, 'info');
        termAppendMod(`⚡ Max potenza hardware: ${hwInfo.maxHw} dBm${hwInfo.pa ? ' (con '+hwInfo.paNote+')' : ' (senza PA)'}`, 'info');
        
        // Auto-select in firmware builder dropdown
        const fwDevSelect = document.getElementById('fw-device');
        if (fwDevSelect) {
            for (let opt of fwDevSelect.options) {
                if (opt.value === hwInfo.pio) {
                    fwDevSelect.value = hwInfo.pio;
                    termAppendMod(`✅ Dispositivo auto-selezionato nel Firmware Builder: ${hwInfo.pio}`, 'info');
                    break;
                }
            }
        }
        
        // Warning about real power limits
        if (!hwInfo.pa && region.includes('EU')) {
            termAppendMod(`\n⚠️ ATTENZIONE: ${hwModel} con ${hwInfo.chip} ha un massimo FISICO di ${hwInfo.maxHw} dBm.`, 'error');
            termAppendMod(`Anche con firmware custom, il chip non può emettere più di ${hwInfo.maxHw} dBm.`, 'error');
            termAppendMod(`Per superare ${hwInfo.maxHw} dBm serve un dispositivo con PA esterno (RAK 1W, Station G2).`, 'info');
        }
    } else {
        termAppendMod(`⚠️ Modello ${hwModel} non nella mappa. Seleziona manualmente nel Firmware Builder.`, 'error');
    }
    
    // Check clamped params
    termAppendMod('\n📋 ═══ PARAMETRI BLOCCATI DAL FIRMWARE ═══', 'prompt');
    for (const [param, info] of Object.entries(FW_CLAMPED_PARAMS)) {
        const icon = info.cliBypass ? '🟡' : '🔴';
        termAppendMod(`${icon} ${param}: ${info.clampedBy}`, info.cliBypass ? 'info' : 'error');
        termAppendMod(`   Bypass: ${info.bypass}`, 'info');
    }
    
    return { hwModel, hwInfo, fwVersion, region, nodeName };
}

// ══════════════════════════════════════════════════════════════════════════════
// 🛰️ MONITOR — Scanner real-time pacchetti mesh (PRO)
// ══════════════════════════════════════════════════════════════════════════════
// ⚠️ NO SHADOWING: NON usare 'const t =' — usa _el, _row, _line, _mon_*
// Tutte le stringhe JS passano da t() traduttore globale.
// ══════════════════════════════════════════════════════════════════════════════

const MON = {
    evtSource: null,
    statusTimer: null,
    statsTimer: null,
    initialized: false,
    rfCount: 0,
    mqttCount: 0,
    textCount: 0,
    rawCount: 0,
    maxLinesPerTerm: 250,   // cap lines per terminal for performance
    autoscroll: true,
    // H5 — performance: batch SSE packets via rAF (1 flush/frame max)
    renderQueue: [],
    _flushScheduled: false,
    maxBurst: 500,          // se coda > maxBurst, droppa i più vecchi
    // VERBOSE MODE — 3 feature sinergiche (super_scanner-style)
    verbose: false,          // toggle verbose: espande OGNI pacchetto con dump nested
    autoExpand: true,        // toggle auto-espandi portnum ad alta densità info
    rawEnabled: false,       // toggle terminale RAW dedicato
    // Portnum con payload "denso" che beneficiano di auto-expand
    autoExpandPorts: ['NODEINFO_APP','TELEMETRY_APP','POSITION_APP','ROUTING_APP','TRACEROUTE_APP','NEIGHBORINFO_APP','MAP_REPORT_APP','ADMIN_APP','WAYPOINT_APP','STORE_FORWARD_APP','STORE_FORWARD_PLUSPLUS_APP'],
    // STEP 7 — Duplicate detector LRU (90s sliding window per packet_id+sender)
    dupEnabled: true,            // toggle UI: evidenzia ritrasmessi come '↻ dup'
    dupWindowMs: 90000,          // finestra 90 secondi
    dupMaxSize: 512,             // cap LRU (evita bloat memoria in sessioni lunghe)
    dupSeen: new Map(),          // key = pid||sender → {ts, count, first_via}
    dupCount: 0,                 // contatore duplicati totali (UI stat)
};

function initMonitor(){
    // Ottieni licenza corrente
    const _lic=APP.license||{};
    const _isPro=(_lic.status==='pro'||_lic.status==='pro_mod');
    const _mLock=document.getElementById('monitor-pro-lock');
    const _mCont=document.getElementById('monitor-content');
    if(_mLock) _mLock.style.display=_isPro?'none':'block';
    if(_mCont) _mCont.style.display=_isPro?'block':'none';

    if(!_isPro) return;
    if(MON.initialized) {
        monitorRefreshStatus();
        return;
    }
    MON.initialized=true;

    // Scansione porte iniziale
    monitorScanPorts();

    // Se già attivo lato server, aggancia lo stream
    monitorRefreshStatus().then(_st=>{
        if(_st && _st.active){
            monitorConnectStream();
        }
    });
}

async function monitorScanPorts(){
    const _sel=document.getElementById('monitor-port-select');
    if(!_sel) return;
    _sel.innerHTML='<option value="">'+t('🔍 Scansione in corso...')+'</option>';
    const d=await apiFetch('monitor/ports');
    const _ports=(d&&d.ports)?d.ports:[];
    if(_ports.length===0){
        _sel.innerHTML='<option value="">'+t('⚠️ Nessuna porta trovata')+'</option>';
        return;
    }
    _sel.innerHTML='';
    // Se c'è una porta selezionata a livello globale, usala come default
    const _preferred=APP.selectedPort||'';
    _ports.forEach(p=>{
        const _opt=document.createElement('option');
        _opt.value=p.port;
        _opt.textContent='🔌 '+p.port+(p.description?' — '+p.description:'');
        if(p.port===_preferred) _opt.selected=true;
        _sel.appendChild(_opt);
    });
}

async function monitorStart(){
    const _sel=document.getElementById('monitor-port-select');
    const _port=_sel?_sel.value:'';
    if(!_port){
        showToast(t('⚠️ Seleziona prima una porta USB'));
        return;
    }
    const _btnStart=document.getElementById('monitor-btn-start');
    if(_btnStart){_btnStart.disabled=true;_btnStart.textContent=t('⏳ Connessione...');}

    const d=await apiFetch('monitor/start',{method:'POST',body:JSON.stringify({port:_port})});
    if(!d||!d.success){
        const _msg=(d&&d.error==='requires_pro')?t('🔒 Richiede licenza PRO')
                 :(d&&d.error)?t('❌ Errore')+': '+d.error
                 :t('❌ Impossibile avviare il Monitor');
        monitorShowError(_msg);
        if(_btnStart){_btnStart.disabled=false;_btnStart.textContent=t('▶️ Avvia Monitor');}
        return;
    }
    monitorHideError();
    monitorUpdateUI(true);
    monitorConnectStream();
    monitorRefreshStatus();
    showToast(t('✅ Monitor avviato'));
}

async function monitorStop(){
    const _btnStop=document.getElementById('monitor-btn-stop');
    if(_btnStop){_btnStop.disabled=true;_btnStop.textContent=t('⏳ Fermata...');}
    const d=await apiFetch('monitor/stop',{method:'POST',body:'{}'});
    monitorDisconnectStream();
    monitorUpdateUI(false);
    if(_btnStop){_btnStop.disabled=false;_btnStop.textContent=t('⏹️ Ferma Monitor');}
    if(d&&d.success) showToast(t('⏹️ Monitor fermato'));
    else showToast(t('❌ Errore durante lo stop'));
}

function monitorUpdateUI(active){
    const _dot=document.getElementById('monitor-dot');
    const _txt=document.getElementById('monitor-status-text');
    const _btnStart=document.getElementById('monitor-btn-start');
    const _btnStop=document.getElementById('monitor-btn-stop');
    const _counters=document.getElementById('monitor-counters');
    const _warn=document.getElementById('monitor-exclusive-warn');
    if(_dot) _dot.className=active?'active':'';
    if(_txt) _txt.textContent=active?t('🟢 Monitor attivo — USB esclusivo'):t('⏸️ Inattivo');
    if(_btnStart){_btnStart.style.display=active?'none':'inline-block';_btnStart.disabled=false;_btnStart.textContent=t('▶️ Avvia Monitor');}
    if(_btnStop){_btnStop.style.display=active?'inline-block':'none';}
    if(_counters) _counters.style.display=active?'grid':'none';
    if(_warn) _warn.style.display=active?'block':'none';
}

async function monitorRefreshStatus(){
    const d=await apiFetch('monitor/status');
    if(!d) return null;
    monitorUpdateUI(!!d.active);
    monitorApplyStatus(d);
    return d;
}

function monitorApplyStatus(s){
    if(!s) return;
    const _set=(id,v)=>{const _el=document.getElementById(id); if(_el) _el.textContent=v;};
    _set('mstat-total', s.packets_total||0);
    _set('mstat-rf', s.packets_rf||0);
    _set('mstat-mqtt', s.packets_mqtt||0);
    _set('mstat-text', s.packets_text||0);
    _set('mstat-enc', s.packets_encrypted||0);
    _set('mstat-nodes', s.unique_nodes||0);
    _set('mstat-uptime', monitorFormatUptime(s.uptime_s||0));
    // My node
    const _myBox=document.getElementById('monitor-my-node');
    const _myName=document.getElementById('monitor-my-name');
    if(s.my_node_name){
        if(_myBox) _myBox.style.display='block';
        if(_myName) _myName.textContent=s.my_node_name+' ('+(s.my_node_num||'')+')';
    } else {
        if(_myBox) _myBox.style.display='none';
    }
    // Error
    if(s.last_error) monitorShowError(t('❌ Errore')+': '+s.last_error);
}

function monitorFormatUptime(sec){
    sec=sec|0;
    if(sec<=0) return '—';
    const h=(sec/3600)|0;
    const m=((sec%3600)/60)|0;
    const s=sec%60;
    if(h>0) return h+'h '+m+'m '+s+'s';
    if(m>0) return m+'m '+s+'s';
    return s+'s';
}

function monitorShowError(msg){
    const _e=document.getElementById('monitor-error');
    if(!_e) return;
    _e.style.display='block';
    _e.textContent=msg;
}
function monitorHideError(){
    const _e=document.getElementById('monitor-error');
    if(_e) _e.style.display='none';
}

function monitorConnectStream(){
    monitorDisconnectStream();
    try {
        const _es=new EventSource('/api/monitor/stream');
        MON.evtSource=_es;
        _es.addEventListener('packet', ev => monitorOnPacket(ev));
        _es.addEventListener('status', ev => monitorOnStatus(ev));
        _es.addEventListener('packet_decoded', ev => monitorOnPacketDecoded(ev));
        _es.addEventListener('error', () => {
            // Il browser riconnette da solo; logghiamo solo un warning visibile
        });
    } catch(e){
        monitorShowError(t('❌ SSE non supportato dal browser'));
    }
}

function monitorDisconnectStream(){
    if(MON.evtSource){
        try{MON.evtSource.close();}catch(e){}
        MON.evtSource=null;
    }
}

// H5 — batch flush dei pacchetti bufferizzati (max 1 ciclo/frame)
function monitorFlushRenderQueue(){
    MON._flushScheduled = false;
    const _q = MON.renderQueue;
    if(!_q.length) return;
    MON.renderQueue = [];
    // Backlog protection: se arriva un burst gigante (es. tab era nascosto),
    // renderizziamo solo gli ultimi maxBurst (gli altri sono comunque in DB).
    const _items = _q.length > MON.maxBurst ? _q.slice(-MON.maxBurst) : _q;
    for (let _i = 0; _i < _items.length; _i++) {
        try { monitorRenderPacket(_items[_i]); } catch(_e){}
    }
}

// H5 — enqueue + schedule di un flush al prossimo frame (throttle nativo a 60fps)
function monitorEnqueuePacket(p){
    MON.renderQueue.push(p);
    if (!MON._flushScheduled) {
        MON._flushScheduled = true;
        if (typeof requestAnimationFrame === 'function') {
            requestAnimationFrame(monitorFlushRenderQueue);
        } else {
            setTimeout(monitorFlushRenderQueue, 16);
        }
    }
}

function monitorOnPacket(ev){
    let _data;
    try { _data=JSON.parse(ev.data); } catch(e){ return; }
    // H5 — non render sincrono: bufferizza e lascia che rAF accorpi il frame
    monitorEnqueuePacket(_data);
}

function monitorOnPacketDecoded(ev){
    // STEP B — evento emesso dopo rematch riuscito (Crypto Hunter, auto-seed PSK, PSK agent).
    // FIX 2026-04-20 (STEP 11): il DOM target era 'mon-terminal-msgs' (legacy, refactor H-batch) →
    // ora 'term-text' (id reale della card "Messaggi Canali" in index.html:1986).
    // Bug: tutti gli eventi packet_decoded venivano silenziosamente scartati → utente
    // vedeva solo le righe ENC originali senza mai vedere il contenuto decriptato.
    let _data;
    try { _data=JSON.parse(ev.data); } catch(e){ return; }
    try {
        const _tt=document.getElementById('term-text');
        if(!_tt) return;
        const _txt=(_data.payload && _data.payload.text) ? String(_data.payload.text) : '';
        const _lbl=_data.psk_match_label || _data.pki_match_label || t('PSK sconosciuta');
        const _pid=_data.packet_id || 0;
        const _pidHex='0x'+(Number(_pid)||0).toString(16).padStart(8,'0');
        const _src=_data.sender_id || '????';
        const _port=_data.portnum || 'UNKNOWN_APP';
        const _ts=_data.ts || Math.floor(Date.now()/1000);
        let _hms='[??:??:??]';
        try { const _d=new Date(_ts*1000); _hms='['+_d.toTimeString().substring(0,8)+']'; } catch(_e){}
        const _esc=monitorEscape(_txt);
        const _line='<div class="mon-line mon-line-decoded" style="color:var(--success,#00ff9f);">'+
            '<span class="mon-ts" style="color:var(--text-muted,#888);">'+_hms+'</span> '+
            '🔓 <strong>'+t('Decifrato')+'</strong> ['+monitorEscape(_lbl)+'] '+
            '<code>'+_pidHex+'</code> '+monitorEscape(_src)+' '+
            '<span style="color:var(--accent,#f1b84a);">'+monitorEscape(_port)+'</span>'+
            (_txt ? ' — '+_esc : '')+
            '</div>';
        monitorAppendLine(_tt, _line);
        MON.textCount = (MON.textCount||0) + 1;
        const _c=document.getElementById('text-count');
        if(_c) _c.textContent=MON.textCount;
    } catch(_e){}
}

function monitorOnStatus(ev){
    let _data;
    try { _data=JSON.parse(ev.data); } catch(e){ return; }
    monitorApplyStatus(_data);
    if(_data.active===false){
        monitorUpdateUI(false);
        monitorDisconnectStream();
    }
}

// Render singolo pacchetto nei 3 terminali
// ─────────────────────────────────────────────────────────────
// VERBOSE MODE — toggle handlers + recursive dump (super_scanner-style)
// ─────────────────────────────────────────────────────────────

window.monitorToggleVerbose = function(_el){
    MON.verbose = !!(_el && _el.checked);
};

window.monitorToggleAutoExpand = function(_el){
    MON.autoExpand = !!(_el && _el.checked);
};

window.monitorToggleRaw = function(_el){
    MON.rawEnabled = !!(_el && _el.checked);
    const _card = document.getElementById('mon-term-raw-card');
    if(_card) _card.style.display = MON.rawEnabled ? '' : 'none';
};

// STEP 7 — Toggle duplicate detector
window.monitorToggleDup = function(_el){
    MON.dupEnabled = !!(_el && _el.checked);
    if(!MON.dupEnabled){
        MON.dupSeen.clear();
        MON.dupCount = 0;
        const _c = document.getElementById('dup-count'); if(_c) _c.textContent = 0;
    }
};

// Flatten recursivo di un dict/list in HTML (stile super_scanner.recursive_print)
function monitorRecursiveFormat(data, depth){
    depth = depth || 0;
    if(depth > 6) return '<span style="opacity:0.5;">…</span>';     // cap profondità
    const _pad = '&nbsp;'.repeat(depth*3);
    if(data === null || data === undefined){
        return _pad + '<span style="color:#666;">null</span>';
    }
    if(Array.isArray(data)){
        if(!data.length) return _pad + '<span style="opacity:0.55;">[]</span>';
        const _parts = [];
        for(let _i=0; _i<data.length; _i++){
            _parts.push(_pad+'<span style="color:#9b7fff;">['+_i+']</span>');
            _parts.push(monitorRecursiveFormat(data[_i], depth+1));
        }
        return _parts.join('<br>');
    }
    if(typeof data === 'object'){
        const _keys = Object.keys(data);
        if(!_keys.length) return _pad + '<span style="opacity:0.55;">{}</span>';
        const _parts = [];
        for(let _j=0; _j<_keys.length; _j++){
            const _k = _keys[_j];
            const _v = data[_k];
            const _isNested = (_v !== null && typeof _v === 'object');
            if(_isNested){
                _parts.push(_pad + '<span style="color:#60a5fa;">'+monitorEscape(_k)+':</span>');
                _parts.push(monitorRecursiveFormat(_v, depth+1));
            } else {
                let _vs = String(_v);
                if(_vs.length > 400) _vs = _vs.slice(0,400) + '…';
                _parts.push(_pad + '<span style="opacity:0.75;">'+monitorEscape(_k)+':</span> <span style="color:#ffcc00;">'+monitorEscape(_vs)+'</span>');
            }
        }
        return _parts.join('<br>');
    }
    // Primitivo
    let _s = String(data);
    if(_s.length > 400) _s = _s.slice(0,400) + '…';
    return _pad + '<span style="color:#ffcc00;">'+monitorEscape(_s)+'</span>';
}

// Costruisce il blocco espanso (usato in verbose E auto-expand)
function monitorBuildVerboseBlock(p){
    // Mostra SOLO il payload decoded + raw hex + encrypted hex (header già in forensic row)
    const _title = '<div style="color:#10b981;font-weight:700;margin-top:0.25rem;">▸ '+t('Dettaglio completo')+' ['+monitorEscape(p.portnum||'?')+']</div>';
    const _body = [];
    if(p.payload && Object.keys(p.payload).length){
        _body.push('<div style="opacity:0.8;">payload:</div>');
        _body.push(monitorRecursiveFormat(p.payload, 1));
    }
    if(p.decoded_meta && Object.keys(p.decoded_meta).length){
        _body.push('<div style="opacity:0.8;margin-top:0.2rem;">decoded_meta:</div>');
        _body.push(monitorRecursiveFormat(p.decoded_meta, 1));
    }
    if(p.raw_payload_hex){
        _body.push('<div style="opacity:0.8;margin-top:0.2rem;">raw_payload ['+p.raw_payload_len+'B]:</div>');
        _body.push('<div style="word-break:break-all;color:#ff8800;opacity:0.85;">&nbsp;&nbsp;&nbsp;'+monitorEscape(p.raw_payload_hex)+'</div>');
    }
    if(!_body.length){
        _body.push('<div style="opacity:0.5;font-style:italic;">'+t('Nessun payload decodificato')+'</div>');
    }
    return '<div class="verbose-block" style="margin:0.25rem 0 0.5rem 1rem;padding:0.35rem 0.55rem;border-left:2px solid #10b981;background:rgba(16,185,129,0.04);font-size:0.69rem;line-height:1.5;">'
        + _title + _body.join('<br>') + '</div>';
}

// Linea COMPLETA per il terminale RAW (identica vocazione super_scanner)
function monitorBuildRawDump(p){
    const _ts = monitorEscape(p.ts_hms||'--:--:--');
    const _src = p.source === 'mqtt' ? '☁️ MQTT' : ('📡 RF '+(p.rssi||0)+'dBm SNR:'+Number(p.snr||0).toFixed(2));
    const _name = monitorEscape(p.long_name||p.sender_id||'Unknown');
    const _to = monitorEscape(p.to_id||'Broadcast');
    const _port = monitorEscape(p.portnum||'UNKNOWN');
    const _pid = monitorEscape(p.packet_id||'0');
    const _hop = (p.hop_start!=null?p.hop_start:'?')+'→'+(p.hop_limit!=null?p.hop_limit:'?');
    // STEP 3 — etichetta canale risolta (hash → nome)
    const _chLblRaw = (typeof window.monitorChannelLabel==='function')?window.monitorChannelLabel(p):null;
    const _chLine = (p.channel_hash!=null)
        ? ('<div><span style="font-weight:700;">CH:</span> <span style="color:#ffcc00;">0x'
            + Number(p.channel_hash).toString(16) + ' (' + Number(p.channel_hash) + ')'
            + (_chLblRaw?(' '+monitorEscape(_chLblRaw)):'') + '</span></div>')
        : '';
    const _bar = '═'.repeat(80);
    const _dash = '─'.repeat(80);
    // STEP 6 — TYPE row: badge portnum (emoji+label) + nome testuale
    const _typeBadge = (typeof monitorPortTag === 'function') ? monitorPortTag(p.portnum) : '';
    // STEP 6 — FLAGS row: via_mqtt/want_ack/pki/licensed/stealth/...
    const _flagsArr = (typeof window.monitorFlagBadges === 'function') ? window.monitorFlagBadges(p) : [];
    const _flagsLine = _flagsArr.length
        ? '<div><span style="font-weight:700;">FLAGS:</span> ' + _flagsArr.join(' ') + '</div>'
        : '';
    // STEP 6 — TX row: priority/delayed/tx_after/next_hop/relay_node
    const _txBits = [];
    if (p.priority && p.priority !== 'UNSET') _txBits.push('Prio:' + p.priority);
    if (p.priority_num != null) _txBits.push('P#' + p.priority_num);
    if (p.delayed) _txBits.push('delayed:' + p.delayed);
    if (p.tx_after) _txBits.push('txAfter:' + p.tx_after);
    if (p.next_hop) _txBits.push('next:0x' + Number(p.next_hop).toString(16));
    if (p.relay_node) _txBits.push('relay:0x' + Number(p.relay_node).toString(16));
    const _txLine = _txBits.length
        ? '<div><span style="font-weight:700;">TX:</span> <span style="color:#fbbf24;">' + monitorEscape(_txBits.join(' · ')) + '</span></div>'
        : '';
    const _head = '<div style="color:#666;">'+_bar+'</div>'+
                  '<div>['+_ts+'] <span style="color:'+(p.source==='mqtt'?'#9b7fff':'#10b981')+';">'+_name+'</span> ➔ <span style="color:#60a5fa;">'+_to+'</span> | '+_src+' | ID:'+_pid+' Hop:'+_hop+'</div>'+
                  '<div style="color:#666;">'+_dash+'</div>'+
                  '<div><span style="font-weight:700;">TYPE:</span> '+_typeBadge+' <span style="color:#ffcc00;">'+_port+'</span></div>'+
                  _chLine + _flagsLine + _txLine;
    let _body = '';
    // Dump completo di TUTTI i campi del packet event (esclusi quelli troppo grandi o raw_packet_b64 per non intasare)
    const _exclude = {'raw_packet_b64':1,'ts_hms':1,'seq':1,'type':1};
    const _clean = {};
    for(const _k in p){
        if(!_exclude[_k] && p[_k] !== null && p[_k] !== undefined) _clean[_k] = p[_k];
    }
    _body += monitorRecursiveFormat(_clean, 0);
    // GPS link se POSITION_APP
    if(p.portnum === 'POSITION_APP' && p.payload && p.payload.latitude){
        const _lat = p.payload.latitude;
        const _lon = p.payload.longitude;
        if(_lat && _lat !== 0){
            _body += '<br><span style="color:#10b981;">🔗 MAPPA: </span><a href="https://www.google.com/maps/search/?api=1&query='+encodeURIComponent(_lat+','+_lon)+'" target="_blank" style="color:#60a5fa;">'+_lat+', '+_lon+'</a>';
        }
    }
    // Hex dump se raw payload o encrypted
    const _rawHex = p.encrypted_hex || p.raw_payload_hex || '';
    if(_rawHex){
        const _len = p.encrypted_len || p.raw_payload_len || (_rawHex.length/2);
        _body += '<br><span style="color:#ef4444;">RAW ('+_len+'B):</span> <span style="word-break:break-all;opacity:0.85;">'+monitorEscape(_rawHex)+'</span>';
    }
    return '<div class="raw-dump" style="margin-bottom:0.5rem;font-size:0.69rem;line-height:1.5;">'+_head+'<div style="padding:0.25rem 0.4rem;">'+_body+'</div></div>';
}

// STEP 7 — Duplicate detector LRU
// Ritorna {isDup:bool, count:int, first_via:str} oppure null se toggle off / no pid
function monitorDupDetect(p){
    if(!MON.dupEnabled) return null;
    if(!p || !p.packet_id) return null;
    const _key = String(p.packet_id) + '||' + String(p.sender_id||p.from_node||'?');
    const _now = Date.now();
    const _rec = MON.dupSeen.get(_key);
    // Scaduto? tratta come nuovo
    if(_rec && (_now - _rec.ts) > MON.dupWindowMs){
        MON.dupSeen.delete(_key);
    }
    const _existing = MON.dupSeen.get(_key);
    if(_existing){
        _existing.count = (_existing.count||1) + 1;
        _existing.ts = _now;
        MON.dupCount++;
        const _c = document.getElementById('dup-count'); if(_c) _c.textContent = MON.dupCount;
        // LRU refresh: re-inserisci in fondo
        MON.dupSeen.delete(_key);
        MON.dupSeen.set(_key, _existing);
        return {isDup:true, count:_existing.count, first_via:_existing.first_via};
    }
    // Nuovo: inserisci + purge LRU
    MON.dupSeen.set(_key, {ts:_now, count:1, first_via: p.source||'rf'});
    if(MON.dupSeen.size > MON.dupMaxSize){
        const _oldest = MON.dupSeen.keys().next().value;
        if(_oldest) MON.dupSeen.delete(_oldest);
    }
    return {isDup:false, count:1, first_via:p.source||'rf'};
}

// STEP 7 — Render compatto per duplicati (linea grigia, NO expand block, NO text/raw)
function monitorBuildDupLine(p, dupInfo, kind){
    const _pid = monitorEscape(String(p.packet_id||'?'));
    const _sender = monitorEscape(String(p.sender_id||p.from_node||'?'));
    const _via = monitorEscape(kind==='mqtt'?'mqtt':'rf');
    const _firstVia = monitorEscape(dupInfo.first_via||'?');
    const _count = Number(dupInfo.count||2);
    const _hops = (p.hop_start != null && p.hop_limit != null) ? (p.hop_start - p.hop_limit) : null;
    const _hopsStr = _hops != null ? (' · hop:'+_hops) : '';
    const _rssi = (p.rssi != null) ? (' · RSSI:'+p.rssi) : '';
    return '<div class="mon-line mon-line-dup" style="color:var(--text-muted,#6b7280);opacity:0.7;font-size:0.78rem;">'+
           '↻ <span title="duplicate packet">dup</span> '+
           '<code>#'+_pid+'</code> '+_sender+' '+
           '<span style="color:#9ca3af;">[×'+_count+' · '+_firstVia+'→'+_via+_hopsStr+_rssi+']</span>'+
           '</div>';
}

function monitorRenderPacket(p){
    if(!p||p.type!=='packet') return;
    const _isMqtt=p.source==='mqtt';
    // STEP 7 — Dup detector: se duplicato, render compatto e stop (evita spam terminali)
    const _dup = monitorDupDetect(p);
    if(_dup && _dup.isDup){
        const _targetId = _isMqtt ? 'term-mqtt' : 'term-rf';
        const _target = document.getElementById(_targetId);
        if(_target){
            monitorAppendLine(_target, monitorBuildDupLine(p, _dup, _isMqtt?'mqtt':'rf'));
        }
        return;
    }
    // 1) Terminal RF o MQTT
    const _targetId=_isMqtt?'term-mqtt':'term-rf';
    const _target=document.getElementById(_targetId);
    if(_target){
        const _line=monitorBuildLine(p, _isMqtt?'mqtt':'rf');
        // VERBOSE / AUTO-EXPAND: aggiungi blocco espanso dopo la riga compatta
        let _expandBlock = '';
        const _autoTrigger = MON.autoExpand && p.portnum && MON.autoExpandPorts.indexOf(p.portnum) !== -1;
        if(MON.verbose || _autoTrigger){
            try { _expandBlock = monitorBuildVerboseBlock(p); } catch(_e){ _expandBlock=''; }
        }
        monitorAppendLine(_target, _line + _expandBlock);
        if(_isMqtt){MON.mqttCount++;const _c=document.getElementById('mqtt-count'); if(_c)_c.textContent=MON.mqttCount;}
        else {MON.rfCount++;const _c=document.getElementById('rf-count'); if(_c)_c.textContent=MON.rfCount;}
    }
    // 2) Terminal TEXT — mostra TUTTI i messaggi testuali:
    //    - TEXT_MESSAGE_APP (plain) + TEXT_MESSAGE_COMPRESSED_APP (unishox)
    //    - Pacchetti decifrati via PSK (psk_match_label presente)
    //    - Pacchetti ENC senza match → riga dimmed
    const _isText=(p.portnum==='TEXT_MESSAGE_APP'||p.portnum==='TEXT_MESSAGE_COMPRESSED_APP');
    const _hasText=p.payload&&p.payload.text;
    const _isEnc=p.is_encrypted&&p.encrypted_hex;
    if(_isText||_hasText||_isEnc){
        const _tt=document.getElementById('term-text');
        if(_tt){
            const _line=monitorBuildTextLine(p);
            monitorAppendLine(_tt, _line);
            MON.textCount++;
            const _c=document.getElementById('text-count'); if(_c)_c.textContent=MON.textCount;
        }
    }
    // 3) Terminal RAW — dump completo stile super_scanner (solo se toggle ON)
    if(MON.rawEnabled){
        const _tr=document.getElementById('term-raw');
        if(_tr){
            try {
                const _rawLine = monitorBuildRawDump(p);
                monitorAppendLine(_tr, _rawLine);
                MON.rawCount++;
                const _cr = document.getElementById('raw-count'); if(_cr) _cr.textContent = MON.rawCount;
            } catch(_e){}
        }
    }
}

function monitorEscape(s){
    if(s===null||s===undefined) return '';
    return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

// ─────────────────────────────────────────────────────────────
// MONITOR: PORTNUM TAGS & PAYLOAD RENDERERS (100% metadati)
// Ogni portnum ha un emoji + stile + renderer dedicato.
// ─────────────────────────────────────────────────────────────
const MON_PORT_TAGS={
    TEXT_MESSAGE_APP:{emoji:'💬',cls:'port-txt',lbl:'TXT'},
    TEXT_MESSAGE_COMPRESSED_APP:{emoji:'📦',cls:'port-txt',lbl:'TXTZ'},
    POSITION_APP:{emoji:'📍',cls:'port-pos',lbl:'POS'},
    NODEINFO_APP:{emoji:'ℹ️',cls:'port-inf',lbl:'INFO'},
    ROUTING_APP:{emoji:'🔄',cls:'port-rt',lbl:'RT'},
    ADMIN_APP:{emoji:'⚙️',cls:'port-adm',lbl:'ADM'},
    WAYPOINT_APP:{emoji:'🎯',cls:'port-pos',lbl:'WPT'},
    AUDIO_APP:{emoji:'🔊',cls:'port-adm',lbl:'AUD'},
    DETECTION_SENSOR_APP:{emoji:'👁️',cls:'port-sen',lbl:'DET'},
    ALERT_APP:{emoji:'🚨',cls:'port-alr',lbl:'ALR'},
    KEY_VERIFICATION_APP:{emoji:'🔐',cls:'port-adm',lbl:'KEY'},
    REMOTE_HARDWARE_APP:{emoji:'🔌',cls:'port-adm',lbl:'HW'},
    REPLY_APP:{emoji:'↩️',cls:'port-rt',lbl:'RPY'},
    IP_TUNNEL_APP:{emoji:'🌐',cls:'port-adm',lbl:'IP'},
    PAXCOUNTER_APP:{emoji:'👣',cls:'port-sen',lbl:'PAX'},
    SERIAL_APP:{emoji:'📟',cls:'port-adm',lbl:'SER'},
    STORE_FORWARD_APP:{emoji:'📥',cls:'port-rt',lbl:'S&F'},
    STORE_FORWARD_PLUSPLUS_APP:{emoji:'📥',cls:'port-rt',lbl:'S&F+'},
    RANGE_TEST_APP:{emoji:'📏',cls:'port-tst',lbl:'RNG'},
    TELEMETRY_APP:{emoji:'📊',cls:'port-tlm',lbl:'TLM'},
    TRACEROUTE_APP:{emoji:'🗺️',cls:'port-rt',lbl:'TRACE'},
    NEIGHBORINFO_APP:{emoji:'👥',cls:'port-rt',lbl:'NBR'},
    ATAK_PLUGIN:{emoji:'🎖️',cls:'port-atk',lbl:'ATAK'},
    ATAK_PLUGIN_V2:{emoji:'🎖️',cls:'port-atk',lbl:'ATAK2'},
    ATAK_FORWARDER:{emoji:'🎖️',cls:'port-atk',lbl:'ATAKF'},
    MAP_REPORT_APP:{emoji:'🗺️',cls:'port-pos',lbl:'MAP'},
    POWERSTRESS_APP:{emoji:'⚡',cls:'port-tst',lbl:'PWR'},
    PRIVATE_APP:{emoji:'🔒',cls:'port-adm',lbl:'PRIV'},
    LORAWAN_BRIDGE:{emoji:'📡',cls:'port-adm',lbl:'LoRaWAN'},
    RETICULUM_TUNNEL_APP:{emoji:'🌐',cls:'port-adm',lbl:'RETIC'},
    CAYENNE_APP:{emoji:'🌡️',cls:'port-tlm',lbl:'CAY'},
    SIMULATOR_APP:{emoji:'🎮',cls:'port-tst',lbl:'SIM'},
};

function monitorPortTag(portnum){
    const _cfg=MON_PORT_TAGS[portnum]||{emoji:'❓',cls:'',lbl:portnum||'?'};
    return '<span class="port-tag '+_cfg.cls+'">'+_cfg.emoji+' '+monitorEscape(_cfg.lbl)+'</span>';
}

function monitorFmtNum(v, digits){
    if(v===null||v===undefined) return '';
    if(typeof v!=='number') return String(v);
    return v.toFixed(digits!=null?digits:2);
}

// Rendering esaustivo del payload per ogni portnum
function monitorPayloadHtml(p){
    const pl=p.payload||{};
    const pn=p.portnum||'';
    const esc=monitorEscape;

    if(pn==='TEXT_MESSAGE_APP'||pn==='TEXT_MESSAGE_COMPRESSED_APP'){
        return ' <span style="color:#fff;">"'+esc(pl.text||'')+'"</span>';
    }
    if(pn==='POSITION_APP'){
        const _bits=[];
        if(pl.latitude!=null&&pl.longitude!=null){
            _bits.push('Lat:'+monitorFmtNum(pl.latitude,5)+' Lon:'+monitorFmtNum(pl.longitude,5));
            if(pl.altitude!=null) _bits.push('Alt:'+pl.altitude+'m');
            if(pl.altitude_hae!=null) _bits.push('HAE:'+pl.altitude_hae+'m');
            if(pl.altitude_geoidal_separation!=null) _bits.push('Geo:'+pl.altitude_geoidal_separation+'m');
            if(pl.sats_in_view!=null) _bits.push('🛰️'+pl.sats_in_view);
            if(pl.fix_type&&pl.fix_type!=='NONE') _bits.push('Fix:'+esc(pl.fix_type));
            if(pl.fix_quality!=null) _bits.push('Q:'+pl.fix_quality);
            if(pl.pdop!=null&&pl.pdop>0) _bits.push('PDOP:'+monitorFmtNum(pl.pdop/100,2));
            if(pl.hdop!=null&&pl.hdop>0) _bits.push('HDOP:'+monitorFmtNum(pl.hdop/100,2));
            if(pl.vdop!=null&&pl.vdop>0) _bits.push('VDOP:'+monitorFmtNum(pl.vdop/100,2));
            if(pl.gps_accuracy!=null) _bits.push('Acc:'+pl.gps_accuracy+'mm');
            if(pl.ground_speed!=null&&pl.ground_speed>0) _bits.push('Spd:'+pl.ground_speed+'cm/s');
            if(pl.ground_track!=null) _bits.push('Dir:'+pl.ground_track+'°');
            if(pl.precision_bits!=null) _bits.push('Prec:'+pl.precision_bits+'b');
            if(pl.location_source&&pl.location_source!=='LOC_UNSET') _bits.push('Src:'+esc(pl.location_source));
            if(pl.altitude_source&&pl.altitude_source!=='ALT_UNSET') _bits.push('AltSrc:'+esc(pl.altitude_source));
            if(pl.seq_number!=null) _bits.push('seq#'+pl.seq_number);
            if(pl.timestamp!=null) _bits.push('tsGPS:'+pl.timestamp);
        } else {
            _bits.push(t('No GPS fix'));
        }
        return ' '+esc(_bits.join(' '));
    }
    if(pn==='TELEMETRY_APP'){
        const _parts=[];
        const _push=(v,lbl,d)=>{ if(v!=null) _parts.push(lbl+monitorFmtNum(v,d==null?1:d)); };
        // Device
        if(pl.device){
            const d=pl.device;
            if(d.battery_level!=null) _parts.push('🔋'+d.battery_level+'%');
            if(d.voltage!=null) _parts.push('⚡'+monitorFmtNum(d.voltage,2)+'V');
            if(d.channel_utilization!=null) _parts.push('ChU:'+monitorFmtNum(d.channel_utilization,1)+'%');
            if(d.air_util_tx!=null) _parts.push('Air:'+monitorFmtNum(d.air_util_tx,1)+'%');
            if(d.uptime_seconds!=null) _parts.push('Up:'+Math.floor(d.uptime_seconds/3600)+'h');
        }
        // Environment
        if(pl.environment){
            const e=pl.environment;
            _push(e.temperature,'🌡️',1); _push(e.relative_humidity,'💧',0);
            _push(e.barometric_pressure,'📈',0); _push(e.iaq,'IAQ:',0);
            _push(e.lux,'☀️',0); _push(e.uv_lux,'UV:',0);
            _push(e.wind_speed,'💨',1);
            if(e.wind_direction!=null) _parts.push(e.wind_direction+'°');
            _push(e.weight,'⚖️',2); _push(e.rainfall_1h,'🌧️',1);
            _push(e.soil_moisture,'🌱',0); _push(e.radiation,'☢️',1);
            _push(e.distance,'📏',2);
        }
        // Air quality
        if(pl.air_quality){
            const a=pl.air_quality;
            if(a.pm25_standard!=null) _parts.push('PM2.5:'+a.pm25_standard);
            if(a.pm10_standard!=null) _parts.push('PM10:'+a.pm10_standard);
            if(a.co2!=null) _parts.push('CO₂:'+a.co2);
        }
        // Power
        if(pl.power){
            for(let i=1;i<=8;i++){
                const v=pl.power['ch'+i+'_voltage'], c=pl.power['ch'+i+'_current'];
                if(v!=null||c!=null) _parts.push('Ch'+i+':'+(v!=null?monitorFmtNum(v,2)+'V':'')+(c!=null?'/'+monitorFmtNum(c,0)+'mA':''));
            }
        }
        // Local stats
        if(pl.local_stats){
            const ls=pl.local_stats;
            if(ls.num_online_nodes!=null) _parts.push('📡'+ls.num_online_nodes+'/'+(ls.num_total_nodes||'?'));
            if(ls.num_packets_rx_bad!=null&&ls.num_packets_rx_bad>0) _parts.push('BadRx:'+ls.num_packets_rx_bad);
        }
        // Health
        if(pl.health){
            const h=pl.health;
            _push(h.heart_bpm,'❤️',0); _push(h.spO2,'SpO₂:',0);
        }
        return ' '+esc(_parts.join(' '));
    }
    if(pn==='NODEINFO_APP'){
        let s=' '+esc(pl.long_name||'???')+' ('+esc(pl.short_name||'???')+') HW:'+esc(pl.hw_model||'');
        if(pl.role) s+=' Role:'+esc(pl.role);
        if(pl.is_licensed) s+=' 📻HAM';
        if(pl.is_stealth) s+=' 👤stealth';
        if(pl.is_unmessagable) s+=' 🔕no-msg';
        if(pl.macaddr) s+=' MAC:'+esc(pl.macaddr);
        if(pl.has_public_key) s+=' 🔑';
        if(pl.public_key_hex) s+=' pk:'+esc(pl.public_key_hex);
        return s;
    }
    if(pn==='ROUTING_APP'){
        let s='';
        if(pl.error_reason&&pl.error_reason!=='NONE') s+=' ❌'+esc(pl.error_reason);
        else s+=' ✓ACK';
        return s;
    }
    if(pn==='TRACEROUTE_APP'){
        // Forward path con SNR inline
        const _rFwd=(pl.route||[]);
        const _snrFwd=(pl.snr_towards_db||[]);
        const _fwdParts=_rFwd.map((nid,i)=>{
            const _s=(i<_snrFwd.length&&_snrFwd[i]!=null)?(' ('+monitorFmtNum(_snrFwd[i],1)+'dB)'):'';
            return esc(nid||'?')+_s;
        });
        let s=_fwdParts.length?(' →: '+_fwdParts.join(' → ')):'';
        // Back path (se presente)
        const _rBack=(pl.route_back||[]);
        const _snrBack=(pl.snr_back_db||[]);
        if(_rBack.length){
            const _backParts=_rBack.map((nid,i)=>{
                const _s=(i<_snrBack.length&&_snrBack[i]!=null)?(' ('+monitorFmtNum(_snrBack[i],1)+'dB)'):'';
                return esc(nid||'?')+_s;
            });
            s+=' ←: '+_backParts.join(' ← ');
        }
        const hc=pl.hops_count||0;
        if(hc) s+=' ('+hc+' hops)';
        return s;
    }
    if(pn==='NEIGHBORINFO_APP'){
        const n=pl.neighbors||[];
        let s=' '+n.length+' '+t('vicini');
        if(pl.node_broadcast_interval_secs) s+=' (bcast:'+pl.node_broadcast_interval_secs+'s)';
        if(n.length>0){
            // mostra fino a 8 vicini inline, resto in tooltip
            const _top=n.slice(0,8).map(x=>{
                let _bit=esc(x.node_id||'?');
                if(x.snr_db!=null) _bit+=' SNR:'+monitorFmtNum(x.snr_db,1)+'dB';
                if(x.last_rx_time) _bit+=' (rx'+Math.floor((Date.now()/1000-x.last_rx_time)/60)+'m)';
                return _bit;
            }).join(' | ');
            s+=' ['+_top+(n.length>8?(' … +'+(n.length-8)+' '+t('altri')):'')+']';
        }
        return s;
    }
    if(pn==='WAYPOINT_APP'){
        let s=' 🗺️'+esc(pl.name||'');
        if(pl.id!=null) s+=' #'+pl.id;
        if(pl.icon!=null) s+=' icon:'+pl.icon;
        if(pl.description) s+=' — '+esc(pl.description);
        if(pl.latitude!=null) s+=' Lat:'+monitorFmtNum(pl.latitude,5);
        if(pl.longitude!=null) s+=' Lon:'+monitorFmtNum(pl.longitude,5);
        if(pl.expire){
            const _dt=new Date(pl.expire*1000).toISOString().substring(0,16).replace('T',' ');
            s+=' exp:'+_dt;
        }
        if(pl.locked_to) s+=' 🔒'+esc(pl.locked_to);
        return s;
    }
    if(pn==='MAP_REPORT_APP'){
        let s=' '+esc(pl.long_name||'???')+' ('+esc(pl.short_name||'')+')';
        if(pl.role) s+=' Role:'+esc(pl.role);
        if(pl.hw_model) s+=' HW:'+esc(pl.hw_model);
        if(pl.firmware_version) s+=' FW:'+esc(pl.firmware_version);
        if(pl.modem_preset) s+=' '+esc(pl.modem_preset);
        if(pl.region) s+=' '+esc(pl.region);
        if(pl.latitude!=null&&pl.longitude!=null) s+=' 📍'+monitorFmtNum(pl.latitude,3)+','+monitorFmtNum(pl.longitude,3);
        if(pl.altitude!=null) s+=' Alt:'+pl.altitude+'m';
        if(pl.num_online_local_nodes!=null) s+=' 📡'+pl.num_online_local_nodes+' '+t('vicini');
        if(pl.position_precision!=null) s+=' Prec:'+pl.position_precision+'b';
        if(pl.has_default_channel) s+=' 📻def';
        if(pl.has_opted_report_location===false) s+=' 🚫no-pos';
        return s;
    }
    if(pn==='PAXCOUNTER_APP'){
        return ' WiFi:'+(pl.wifi||0)+' BLE:'+(pl.ble||0)+' Up:'+(pl.uptime||0)+'s';
    }
    if(pn==='DETECTION_SENSOR_APP'){
        return ' '+esc(pl.name||'')+' = '+esc(pl.state||'?')+(pl.text?' "'+esc(pl.text)+'"':'');
    }
    if(pn==='RANGE_TEST_APP'){
        let s='';
        if(pl.seq!=null) s+=' seq#'+pl.seq;
        if(pl.text) s+=' "'+esc(pl.text)+'"';
        return s;
    }
    if(pn==='STORE_FORWARD_APP'||pn==='STORE_FORWARD_PLUSPLUS_APP'){
        let s=' '+esc(pl.rr||'?')+(pl.text?' "'+esc(pl.text)+'"':'');
        const _st=pl.stats||pl.statistics;
        if(_st&&typeof _st==='object'){
            const _sb=[];
            if(_st.messages_total!=null||_st.messagesTotal!=null) _sb.push('tot:'+(_st.messages_total??_st.messagesTotal));
            if(_st.messages_saved!=null||_st.messagesSaved!=null) _sb.push('saved:'+(_st.messages_saved??_st.messagesSaved));
            if(_st.messages_max!=null||_st.messagesMax!=null) _sb.push('max:'+(_st.messages_max??_st.messagesMax));
            if(_st.up_time!=null||_st.upTime!=null){
                const _u=(_st.up_time??_st.upTime);
                _sb.push('up:'+Math.floor(_u/3600)+'h');
            }
            if(_st.requests!=null) _sb.push('req:'+_st.requests);
            if(_st.requests_history!=null||_st.requestsHistory!=null) _sb.push('reqH:'+(_st.requests_history??_st.requestsHistory));
            if(_st.heartbeat) _sb.push('❤️');
            if(_st.return_max!=null||_st.returnMax!=null) _sb.push('rmax:'+(_st.return_max??_st.returnMax));
            if(_st.return_window!=null||_st.returnWindow!=null) _sb.push('rwin:'+(_st.return_window??_st.returnWindow)+'s');
            if(_sb.length) s+=' ['+_sb.join(' ')+']';
        }
        if(pl.history_messages!=null) s+=' h:'+pl.history_messages;
        if(pl.last_request!=null) s+=' lr:'+pl.last_request;
        return s;
    }
    if(pn==='ADMIN_APP'){
        let s=' variant:'+esc(pl.variant||'?');
        if(pl.session_passkey_hex) s+=' 🔑pk';
        return s;
    }
    if(pn==='REMOTE_HARDWARE_APP'){
        return ' '+esc(pl.type||'?')+(pl.gpio_mask!=null?' mask=0x'+(pl.gpio_mask>>>0).toString(16):'')+(pl.gpio_value!=null?' val=0x'+(pl.gpio_value>>>0).toString(16):'');
    }
    if(pn==='AUDIO_APP'){
        return ' Codec2 '+(pl.codec2_magic?'✓':'?')+(pl.bitrate_marker!=null?' br:'+pl.bitrate_marker:'')+' ('+(pl.size||0)+'B)';
    }
    if(pn==='IP_TUNNEL_APP'){
        if(pl.ip_src&&pl.ip_dst) return ' '+esc(pl.ip_src)+' → '+esc(pl.ip_dst)+' proto:'+pl.ip_protocol;
        return ' ('+(pl.size||0)+'B)';
    }
    if(pn==='ALERT_APP'){
        return ' 🚨 '+esc(pl.text||'')+(pl.severity?' ['+esc(pl.severity)+']':'');
    }
    if(pn==='SERIAL_APP'){
        return ' ('+(pl.size||0)+'B serial)';
    }
    if(pn==='PRIVATE_APP'||pn==='KEY_VERIFICATION_APP'||pn==='POWERSTRESS_APP'||pn==='SIMULATOR_APP'||pn==='REPLY_APP'){
        return ' ('+(pl.size||0)+'B)';
    }
    if(pn&&pn.indexOf('ATAK')>=0){
        return ' CoT ('+(pl.size||0)+'B)';
    }
    if(pl.raw_hex){
        return ' <span class="encrypted-hex" style="display:inline;word-break:break-all;">'+monitorEscape(pl.raw_hex)+'</span>'+
               ' <button class="btn-crypto-agent" onclick=\'window.cryptoAgentDecrypt('+JSON.stringify({encrypted_hex:pl.raw_hex,packet_id:pl.packet_id,from_node:pl.from_node,to_node:pl.to_node,portnum_hint:pl.portnum})+')\' style="background:#7c3aed;color:white;border:none;padding:1px 6px;border-radius:3px;cursor:pointer;font-size:0.7rem;margin-left:0.3rem;" title="Tenta decrypt con Crypto Agent">🔓</button>';
    }
    return '';
}

function monitorBuildLine(p, kind){
    const _ts=monitorEscape(p.ts_hms||'--:--:--');
    const _name=monitorEscape(p.long_name||p.sender_id||'Unknown');
    const _short=monitorEscape(p.short_name||'');
    const _mac=monitorEscape(p.sender_mac||'');
    const _pid=monitorEscape(p.packet_id||'');
    const _hopLim=(p.hop_limit!=null)?p.hop_limit:'?';
    const _hopSt=(p.hop_start!=null)?p.hop_start:'?';
    const _hopsU=(p.hops_used!=null)?p.hops_used:'?';
    const _ch=(p.channel!=null)?p.channel:0;
    const _to=monitorEscape(p.to_id||'');
    const _prio=monitorEscape(p.priority||'');

    // Signal source
    let _srcHtml='';
    if(kind==='mqtt'){
        _srcHtml='<span class="src-mqtt">☁️ MQTT</span>';
    } else {
        const _rssi=p.rssi||0, _snr=p.snr||0;
        const _snrCls=_snr>5?'sig-good':(_snr>0?'sig-mid':'sig-bad');
        _srcHtml='<span class="src-rf">📡 RF</span> <span class="'+_snrCls+'">RSSI:'+_rssi+'dBm SNR:'+Number(_snr).toFixed(1)+'dB</span>';
    }

    const _portHtml=monitorPortTag(p.portnum);
    const _payloadHtml=monitorPayloadHtml(p);

    // Encrypted payload (FULL hex dump, no truncation) + Crypto Agent button
    let _encHtml='';
    if(p.encrypted_hex){
        const _agentArg={encrypted_hex:p.encrypted_hex,packet_id:p.packet_id,from_node:p.sender_id,to_node:p.to_id,portnum_hint:p.portnum,channel_idx:p.channel_idx,channel_hash:p.channel_hash,public_key_hex:p.public_key_hex};
        // STEP 8 — badge feedback brute-force PSK
        // STEP 13 — visibility anche quando decrypt_attempts=0 (catalog vuoto, DB giu', ecc.)
        let _bruteBadge='';
        if(p.is_encrypted&&p.decrypt_attempts){
            const _tl=Array.isArray(p.decrypt_tried_labels)?p.decrypt_tried_labels.join(', '):'';
            const _reasons=p.decrypt_reasons||{};
            const _rParts=[];
            for(const _k in _reasons){ _rParts.push(_k+':'+_reasons[_k]); }
            const _tip=t('Provate %n chiavi PSK senza match').replace('%n',String(p.decrypt_attempts))+
                       (_rParts.length?(' · '+_rParts.join(' ')):'')+
                       (_tl?('\n'+t('Chiavi provate')+': '+_tl):'');
            _bruteBadge=' <span class="brute-badge" style="color:#fbbf24;opacity:0.85;font-size:0.72rem;margin-left:0.3rem;" title="'+monitorEscape(_tip)+'">🔍 '+p.decrypt_attempts+'</span>';
        } else if(p.is_encrypted&&p.decrypt_skipped_reason){
            // STEP 13 — nessuna brute tentata: mostra warning con motivo
            const _reasonMap={
                'no_psk_in_db': t('Nessuna PSK nel catalogo'),
                'db_unavailable': t('DB non disponibile'),
                'crypto_module_unavailable': t('Modulo crypto non caricato')
            };
            const _rmsg=_reasonMap[p.decrypt_skipped_reason]||p.decrypt_skipped_reason;
            const _tip=t('Brute-force saltata')+': '+_rmsg+
                       (p.decrypt_skipped_reason==='no_psk_in_db' ? ('\n'+t('Clicca "Carica 36 canali Italia" per riseedare')):'');
            _bruteBadge=' <span class="brute-badge" style="color:#ef4444;opacity:0.9;font-size:0.72rem;margin-left:0.3rem;cursor:help;" title="'+monitorEscape(_tip)+'">⚠️ '+monitorEscape(_rmsg)+'</span>';
        }
        _encHtml='<div class="encrypted-hex" style="word-break:break-all;white-space:pre-wrap;">🔐 ENC '+monitorEscape(p.encrypted_hex)+' <span style="opacity:0.7">('+p.encrypted_len+'B)</span>'+_bruteBadge+
                 ' <button class="btn-crypto-agent" onclick=\'window.cryptoAgentDecrypt('+JSON.stringify(_agentArg).replace(/'/g,"&#39;")+')\' style="background:#7c3aed;color:white;border:none;padding:2px 6px;border-radius:3px;cursor:pointer;font-size:0.7rem;margin-left:0.4rem;" title="Crypto Agent: tenta decrypt con tutte le chiavi">🔓 Crypto Agent</button>'+
                 '</div>';
    }

    // Spam alert
    let _spamHtml='';
    if(p.spam_alert){
        _spamHtml=' <span class="spam-tag">⚠️ SPAM Δ'+p.spam_alert.delta_s+'s</span>';
    }

    // Forensic row esteso: TUTTI i campi MeshPacket
    // STEP C — channel_hash vs channel_idx distinti
    const _forBits=[];
    const _chHash=(p.channel_hash!=null)?p.channel_hash:_ch;
    const _chIdx=(p.channel_idx!=null)?p.channel_idx:null;
    // STEP 3 — etichetta canale risolta (backend OR cache hash→name)
    const _chLbl=(typeof window.monitorChannelLabel==='function')?window.monitorChannelLabel(p):null;
    if(_chIdx!=null){
        _forBits.push('Ch:'+_chIdx+' (hash:'+_chHash+')'+(_chLbl?' "'+monitorEscape(_chLbl)+'"':''));
    } else {
        _forBits.push('Hash:'+_chHash+' (0x'+Number(_chHash).toString(16)+')'+(_chLbl?' "'+monitorEscape(_chLbl)+'"':''));
    }
    _forBits.push('Hop:'+_hopSt+'→'+_hopLim+' ('+_hopsU+' usati)');
    if(_to) _forBits.push('To:'+_to+(p.is_broadcast?' 📢':''));
    _forBits.push('PktID:'+_pid);
    if(_prio&&_prio!=='UNSET') _forBits.push('Prio:'+_prio);
    if(p.priority_num!=null) _forBits.push('P#'+p.priority_num);
    if(p.want_ack) _forBits.push('ACK?');
    if(p.via_mqtt===true) _forBits.push('viaMQTT');
    if(p.pki_encrypted) _forBits.push('🔑PKI');
    if(p.public_key_hex) _forBits.push('pk:'+monitorEscape(p.public_key_hex));
    if(p.next_hop) _forBits.push('nextHop:0x'+Number(p.next_hop).toString(16));
    if(p.relay_node) _forBits.push('relay:0x'+Number(p.relay_node).toString(16));
    if(p.role) _forBits.push('Role:'+monitorEscape(p.role));
    // H3 — Sticky node identity (propagati da NODEINFO/MAP_REPORT passati)
    if(p.hw_model&&p.hw_model!=='UNKNOWN') _forBits.push('HW:'+monitorEscape(p.hw_model));
    if(p.firmware_version) _forBits.push('FW:'+monitorEscape(p.firmware_version));
    if(p.region) _forBits.push('Rgn:'+monitorEscape(p.region));
    if(p.modem_preset) _forBits.push('Prs:'+monitorEscape(p.modem_preset));
    if(p.is_licensed===true) _forBits.push('📻HAM');
    if(p.is_stealth===true) _forBits.push('👤stealth');
    if(p.hops_away!=null&&p.hops_away!==p.hop_limit) _forBits.push('hopsAway:'+p.hops_away);
    if(p.fw_type&&p.fw_type!=='unknown') _forBits.push('fw:'+monitorEscape(p.fw_type));
    if(p.delayed) _forBits.push('delayed:'+p.delayed);
    if(p.tx_after) _forBits.push('txAfter:'+p.tx_after);
    if(p.macaddr_full) _forBits.push('MACfull:'+monitorEscape(p.macaddr_full));
    _forBits.push('MAC:'+_mac);
    // decoded_meta completo (requestId/replyId/emoji/bitfield/source/dest)
    const _dm=p.decoded_meta||{};
    if(_dm.request_id) _forBits.push('req:0x'+Number(_dm.request_id).toString(16));
    if(_dm.reply_id) _forBits.push('rpl:0x'+Number(_dm.reply_id).toString(16));
    if(_dm.emoji) _forBits.push('emj:'+_dm.emoji);
    if(_dm.want_response) _forBits.push('wantResp');
    if(_dm.bitfield!=null) _forBits.push('bf:0x'+Number(_dm.bitfield).toString(16));
    if(_dm.source) _forBits.push('src:0x'+Number(_dm.source).toString(16));
    if(_dm.dest) _forBits.push('dst:0x'+Number(_dm.dest).toString(16));
    // STEP C — Icona 🔍 per JSON completo
    const _pktJson=JSON.stringify(p).replace(/"/g,'&quot;').replace(/</g,'&lt;');
    const _detailBtn='<span class="pkt-detail-btn" onclick="monitorShowPacketDetail(this)" data-pkt="'+_pktJson+'" style="cursor:pointer;margin-left:0.4rem;opacity:0.75;" title="'+t('Dettagli completi')+'">🔍</span>';
    const _forensic='<div class="forensic-row">└─ '+monitorEscape(_forBits.join(' · '))+_detailBtn+'</div>';

    // Payload size row (quando raw_payload presente E decoded OK) — FULL hex (no truncation)
    let _rawRow='';
    if(p.raw_payload_hex&&!p.encrypted_hex){
        _rawRow='<div class="forensic-row" style="opacity:0.7;word-break:break-all;white-space:pre-wrap;">   📦 raw['+p.raw_payload_len+'B]: '+monitorEscape(p.raw_payload_hex)+'</div>';
    }

    const _extraCls=(p.encrypted_hex?' encrypted':'')+(p.spam_alert?' spam':'');
    return '<div class="term-line '+kind+_extraCls+'">'+
           '<span class="ts">['+_ts+']</span> '+_srcHtml+' '+_portHtml+
           ' <span class="node-name">'+_name+'</span>'+(_short?' <span style="color:var(--text-muted);">['+_short+']</span>':'')+
           _spamHtml+_payloadHtml+
           _forensic+_rawRow+_encHtml+
           '</div>';
}

function monitorBuildTextLine(p){
    const _ts=monitorEscape(p.ts_hms||'--:--:--');
    const _name=monitorEscape(p.long_name||p.sender_id||'Unknown');
    const _short=monitorEscape(p.short_name||'');
    const _ch=(p.channel!=null)?p.channel:0;
    // STEP 3 — preferisci backend channel_name, fallback su cache hash→name
    const _chLblRaw=(typeof window.monitorChannelLabel==='function')?window.monitorChannelLabel(p):null;
    const _chName=monitorEscape(_chLblRaw||p.channel_name||'');
    const _text=(p.payload&&p.payload.text)?monitorEscape(p.payload.text):'';
    const _srcTag=p.source==='mqtt'?'<span class="src-mqtt">☁️</span>':'<span class="src-rf">📡</span>';
    const _network=p.network_bucket||p.network||'';
    const _netBadge=_network?' <span class="net-badge net-'+monitorEscape(_network)+'">'+monitorEscape(_network)+'</span>':'';
    // PSK match badge
    let _pskBadge='';
    if(p.psk_match_label){
        const _kind=p.psk_match_kind||'public';
        _pskBadge=' <span class="psk-match-badge '+monitorEscape(_kind)+'" title="'+monitorEscape(p.psk_match_label)+'">🔓 '+monitorEscape(_kind==='private'?t('priv'):t('pub'))+'</span>';
    }
    // Compressed indicator
    let _zipBadge='';
    if(p.portnum==='TEXT_MESSAGE_COMPRESSED_APP'){
        _zipBadge=' <span class="zip-badge" title="'+monitorEscape(t('Unishox2 compressed'))+'">📦</span>';
    }
    // Encrypted (no match) → riga dimmed
    let _extraCls='';
    let _body='';
    if(_text){
        _body='<span style="color:#fff;">'+_text+'</span>';
    } else if(p.is_encrypted&&p.encrypted_hex){
        _extraCls=' encrypted-dim';
        // H4.2 — FULL encrypted hex + Crypto Agent button
        const _agentArg={encrypted_hex:p.encrypted_hex,packet_id:p.packet_id,from_node:p.from_node||p.sender_num,to_node:p.to_node,portnum_hint:p.portnum,channel_idx:p.channel,channel_hash:p.channel_hash,public_key_hex:p.public_key_hex};
        const _agentJson=JSON.stringify(_agentArg).replace(/"/g,'&quot;').replace(/'/g,'&#39;');
        // STEP 8 — badge feedback brute-force PSK
        // STEP 13 — visibility anche su decrypt_attempts=0 + skip reason
        let _bruteBadgeTxt='';
        if(p.decrypt_attempts){
            const _tl=Array.isArray(p.decrypt_tried_labels)?p.decrypt_tried_labels.join(', '):'';
            const _reasons=p.decrypt_reasons||{};
            const _rParts=[];
            for(const _k in _reasons){ _rParts.push(_k+':'+_reasons[_k]); }
            const _tip=t('Provate %n chiavi PSK senza match').replace('%n',String(p.decrypt_attempts))+
                       (_rParts.length?(' · '+_rParts.join(' ')):'')+
                       (_tl?('\n'+t('Chiavi provate')+': '+_tl):'');
            _bruteBadgeTxt=' <span class="brute-badge" style="color:#fbbf24;opacity:0.85;font-size:0.72rem;" title="'+monitorEscape(_tip)+'">🔍 '+p.decrypt_attempts+'</span>';
        } else if(p.decrypt_skipped_reason){
            const _reasonMap={
                'no_psk_in_db': t('Nessuna PSK nel catalogo'),
                'db_unavailable': t('DB non disponibile'),
                'crypto_module_unavailable': t('Modulo crypto non caricato')
            };
            const _rmsg=_reasonMap[p.decrypt_skipped_reason]||p.decrypt_skipped_reason;
            const _tip=t('Brute-force saltata')+': '+_rmsg+
                       (p.decrypt_skipped_reason==='no_psk_in_db' ? ('\n'+t('Clicca "Carica 36 canali Italia" per riseedare')):'');
            _bruteBadgeTxt=' <span class="brute-badge" style="color:#ef4444;opacity:0.9;font-size:0.72rem;cursor:help;" title="'+monitorEscape(_tip)+'">⚠️ '+monitorEscape(_rmsg)+'</span>';
        }
        _body='<span style="color:#7a7a7a;word-break:break-all;white-space:pre-wrap;">🔐 '+t('Messaggio cifrato')+' ['+p.encrypted_len+'B]'+_bruteBadgeTxt+' '+monitorEscape(p.encrypted_hex)+' <button onclick="window.cryptoAgentDecrypt('+JSON.stringify(_agentArg).replace(/"/g,'&quot;')+')" title="'+t('Decripta con tutte le chiavi')+'" style="background:linear-gradient(90deg,#a78bfa,#8b5cf6);border:0;color:#fff;cursor:pointer;padding:2px 6px;border-radius:3px;font-size:0.7rem;margin-left:4px;">🔓 Crypto Agent</button></span>';
    } else {
        _body='<span style="color:#aaa;">'+t('(payload vuoto)')+'</span>';
    }
    const _chDisplay=_chName?(_chName+' #'+_ch):('Ch'+_ch);
    const _nodeLink='<a href="#" class="node-link" data-node-id="'+monitorEscape(p.sender_id||'')+'">'+_name+'</a>';

    // H4 — Riga metadati COMPLETA: TUTTI i campi Meshtastic disponibili
    const _metaBits=[];
    // ───── Segnale (solo RF) ─────
    if(p.source!=='mqtt' && (p.rssi!=null || p.snr!=null)){
        const _rssi=(p.rssi!=null)?p.rssi+'dBm':'—';
        const _snr=(p.snr!=null)?Number(p.snr).toFixed(1)+'dB':'—';
        const _snrV=Number(p.snr||0);
        const _cls=_snrV>5?'sig-good':(_snrV>0?'sig-mid':'sig-bad');
        _metaBits.push('<span class="'+_cls+'">📶'+_rssi+' 📊'+_snr+'</span>');
    }
    // ───── Hop topology ─────
    if(p.hops_used!=null || p.hop_limit!=null){
        const _hu=(p.hops_used!=null)?p.hops_used:'?';
        const _hs=(p.hop_start!=null)?p.hop_start:'?';
        const _hl=(p.hop_limit!=null)?p.hop_limit:'?';
        _metaBits.push('<span title="hop_start→hop_limit (usati)">📏'+_hs+'→'+_hl+' ('+_hu+')</span>');
    }
    if(p.hops_away!=null){
        _metaBits.push('<span title="hops_away (distanza logica)">↔'+p.hops_away+'</span>');
    }
    if(p.next_hop){
        _metaBits.push('<span title="next_hop">→0x'+Number(p.next_hop).toString(16)+'</span>');
    }
    if(p.relay_node){
        _metaBits.push('<span title="relay_node">↻0x'+Number(p.relay_node).toString(16)+'</span>');
    }
    // ───── Identificatori ─────
    if(p.packet_id){
        _metaBits.push('<span style="font-family:monospace;" title="packet_id">#'+monitorEscape(String(p.packet_id))+'</span>');
    }
    if(p.sender_mac){
        _metaBits.push('<span style="font-family:monospace;" title="MAC address mittente">MAC:'+monitorEscape(p.sender_mac)+'</span>');
    }
    if(p.macaddr_full){
        _metaBits.push('<span style="font-family:monospace;" title="MAC full">MACf:'+monitorEscape(p.macaddr_full)+'</span>');
    }
    if(p.long_name && p.short_name){
        _metaBits.push('<span title="long · short">🏷️'+monitorEscape(p.long_name)+' ('+monitorEscape(p.short_name)+')</span>');
    }
    if(p.to_id){
        _metaBits.push('<span title="to_id">→'+monitorEscape(p.to_id)+(p.is_broadcast?' 📢':'')+'</span>');
    }
    // ───── Ruolo / firmware / hardware ─────
    if(p.role){
        _metaBits.push('<span title="role">🎭'+monitorEscape(p.role)+'</span>');
    }
    if(p.firmware_version){
        _metaBits.push('<span title="firmware_version">🧬'+monitorEscape(p.firmware_version)+'</span>');
    } else if(p.fw_type && p.fw_type!=='unknown'){
        _metaBits.push('<span title="fw_type">🧬'+monitorEscape(p.fw_type)+'</span>');
    }
    if(p.hw_model && p.hw_model!=='UNKNOWN'){
        _metaBits.push('<span title="hw_model">💻'+monitorEscape(p.hw_model)+'</span>');
    }
    if(p.region){
        _metaBits.push('<span title="region">🌍'+monitorEscape(p.region)+'</span>');
    }
    if(p.modem_preset){
        _metaBits.push('<span title="modem_preset">📡'+monitorEscape(p.modem_preset)+'</span>');
    }
    // ───── Flag nodo ─────
    if(p.is_licensed===true){
        _metaBits.push('<span style="color:#f59e0b;" title="HAM licensed">📻HAM</span>');
    }
    if(p.is_stealth===true){
        _metaBits.push('<span style="color:#8b5cf6;" title="Stealth mode">👤stealth</span>');
    }
    if(p.is_unmessagable===true){
        _metaBits.push('<span style="color:#ef4444;" title="Unmessagable">🔕no-msg</span>');
    }
    // ───── Canale / PSK ─────
    if(p.channel_hash!=null){
        // STEP 3 — arricchisci con nome canale se risolto
        const _chMetaLbl=(typeof window.monitorChannelLabel==='function')?window.monitorChannelLabel(p):null;
        const _chSfx=_chMetaLbl?' ('+monitorEscape(_chMetaLbl)+')':'';
        _metaBits.push('<span title="channel_hash">#ch:0x'+Number(p.channel_hash).toString(16)+_chSfx+'</span>');
    }
    if(p.psk_match_label){
        const _kind=p.psk_match_kind||'public';
        _metaBits.push('<span style="color:#10b981;" title="PSK match ('+monitorEscape(_kind)+')">🔓'+monitorEscape(p.psk_match_label)+'</span>');
    }
    // ───── Cripto / PKI ─────
    if(p.pki_encrypted===true){
        _metaBits.push('<span style="color:#a78bfa;" title="PKI encrypted">🔑PKI</span>');
    }
    if(p.public_key_hex){
        _metaBits.push('<span style="font-family:monospace;word-break:break-all;" title="public_key (X25519)">pk:'+monitorEscape(p.public_key_hex)+'</span>');
    }
    if(p.encrypted_len){
        _metaBits.push('<span title="encrypted size">🔐'+p.encrypted_len+'B</span>');
    }
    // ───── Transport flags ─────
    if(p.via_mqtt===true){
        _metaBits.push('<span style="color:#06b6d4;" title="via MQTT">☁️MQTT</span>');
    }
    if(p.want_ack){
        _metaBits.push('<span title="want_ack">ACK?</span>');
    }
    if(p.priority && p.priority!=='UNSET'){
        _metaBits.push('<span title="priority">⚡'+monitorEscape(p.priority)+'</span>');
    }
    // ───── Position quality / GPS (solo se il pacchetto è POSITION) ─────
    const _pq=p.position_quality||{};
    const _hasPos=(p.portnum==='POSITION_APP')||(p.payload&&p.payload.latitude!=null);
    if(_hasPos){
        const _sats=_pq.sats_in_view!=null?_pq.sats_in_view:(p.payload&&p.payload.sats_in_view);
        const _locSrc=_pq.location_source||(p.payload&&p.payload.location_source);
        const _hdop=_pq.HDOP!=null?_pq.HDOP:(p.payload&&p.payload.HDOP);
        const _pdop=_pq.PDOP!=null?_pq.PDOP:(p.payload&&p.payload.PDOP);
        const _gSp=_pq.ground_speed!=null?_pq.ground_speed:(p.payload&&p.payload.ground_speed);
        const _prec=_pq.precision_bits!=null?_pq.precision_bits:(p.payload&&p.payload.precision_bits);
        if(_sats!=null) _metaBits.push('<span title="satellites in view">🛰️'+_sats+'</span>');
        if(_locSrc){
            // "veri" (INTERNAL_GPS) vs "posizione fissa" (MANUAL)
            const _fixIco=(_locSrc==='LOC_INTERNAL'||_locSrc==='INTERNAL')?'🎯':(
                          (_locSrc==='LOC_MANUAL'||_locSrc==='MANUAL')?'📌':'📍');
            _metaBits.push('<span title="location_source">'+_fixIco+monitorEscape(_locSrc)+'</span>');
        }
        if(_hdop!=null) _metaBits.push('<span title="HDOP">H'+Number(_hdop).toFixed(1)+'</span>');
        if(_pdop!=null) _metaBits.push('<span title="PDOP">P'+Number(_pdop).toFixed(1)+'</span>');
        if(_gSp!=null) _metaBits.push('<span title="ground_speed (m/s)">💨'+Number(_gSp).toFixed(1)+'</span>');
        if(_prec!=null) _metaBits.push('<span title="precision_bits">Δ'+_prec+'b</span>');
    }
    // ───── decoded_meta extras (request/reply/emoji/bitfield) ─────
    const _dm=p.decoded_meta||{};
    if(_dm.request_id) _metaBits.push('<span title="request_id">req:0x'+Number(_dm.request_id).toString(16)+'</span>');
    if(_dm.reply_id) _metaBits.push('<span title="reply_id">rpl:0x'+Number(_dm.reply_id).toString(16)+'</span>');
    if(_dm.emoji) _metaBits.push('<span title="emoji">emj:'+_dm.emoji+'</span>');
    if(_dm.want_response) _metaBits.push('<span title="want_response">wantResp</span>');
    if(_dm.bitfield!=null) _metaBits.push('<span title="bitfield">bf:0x'+Number(_dm.bitfield).toString(16)+'</span>');
    // ───── Azioni rapide (bottoni) ─────
    // FIX BUG (2026-04-20): prima il bottone 🔑psk cercava .pkt-detail-btn nel parent che non esiste
    // in monitorBuildTextLine → modal si apriva vuoto. Ora data-pkt è embedded direttamente sul bottone.
    const _sid=monitorEscape(p.sender_id||'');
    const _pktJsonSafe=JSON.stringify(p).replace(/"/g,'&quot;').replace(/</g,'&lt;');
    const _actionBtns=_sid?
        ' <span class="text-meta-actions" style="margin-left:0.4rem;">'+
        '<button class="btn-meta-tr" onclick="hubOpenNodeDetail(\''+_sid+'\');setTimeout(()=>hubScrollToPanel(\'tr\'),150)" title="'+t('Apri traceroutes nodo')+'" style="background:transparent;border:1px solid var(--border);color:var(--text-muted);cursor:pointer;padding:1px 4px;border-radius:3px;font-size:0.7rem;margin-right:2px;">🛰️tr</button>'+
        '<button class="btn-meta-wp" onclick="hubOpenNodeDetail(\''+_sid+'\');setTimeout(()=>hubScrollToPanel(\'wp\'),150)" title="'+t('Apri waypoints nodo')+'" style="background:transparent;border:1px solid var(--border);color:var(--text-muted);cursor:pointer;padding:1px 4px;border-radius:3px;font-size:0.7rem;margin-right:2px;">📍wp</button>'+
        '<button class="btn-meta-psk" onclick="monitorShowPacketDetail(this)" data-pkt="'+_pktJsonSafe+'" title="'+t('Dettagli pacchetto (PSK, JSON)')+'" style="background:transparent;border:1px solid var(--border);color:var(--text-muted);cursor:pointer;padding:1px 4px;border-radius:3px;font-size:0.7rem;">🔑psk</button>'+
        '</span>':'';
    const _metaRow=_metaBits.length
        ? '<div class="text-meta-row" style="font-size:0.7rem;color:var(--text-muted);padding-left:1.2rem;margin-top:0.1rem;opacity:0.82;">└─ '+_metaBits.join(' · ')+_actionBtns+'</div>'
        : (_sid?'<div class="text-meta-row" style="font-size:0.7rem;padding-left:1.2rem;margin-top:0.1rem;">└─ '+_actionBtns+'</div>':'');

    return '<div class="term-line text'+_extraCls+'">'+
           '<span class="ts">['+_ts+']</span> '+_srcTag+_netBadge+
           ' <span style="color:var(--text-muted);">'+monitorEscape(_chDisplay)+'</span>'+
           _pskBadge+_zipBadge+
           ' '+_nodeLink+(_short?' <span style="color:var(--text-muted);">['+_short+']</span>':'')+': '+
           _body+
           _metaRow+
           '</div>';
}

function monitorAppendLine(_target, _lineHtml){
    const _tmp=document.createElement('div');
    _tmp.innerHTML=_lineHtml;
    const _newNode=_tmp.firstChild;
    if(!_newNode) return;
    _target.appendChild(_newNode);
    // Cap al massimo numero linee
    while(_target.childElementCount>MON.maxLinesPerTerm){
        _target.removeChild(_target.firstChild);
    }
    if(MON.autoscroll){
        _target.scrollTop=_target.scrollHeight;
    }
}

function monitorClearTerm(which){
    let _id;
    if(which==='mqtt') _id='term-mqtt';
    else if(which==='text') _id='term-text';
    else if(which==='raw') _id='term-raw';
    else _id='term-rf';
    const _el=document.getElementById(_id);
    if(_el) _el.innerHTML='';
    if(which==='mqtt'){MON.mqttCount=0;const _c=document.getElementById('mqtt-count'); if(_c)_c.textContent=0;}
    else if(which==='text'){MON.textCount=0;const _c=document.getElementById('text-count'); if(_c)_c.textContent=0;}
    else if(which==='raw'){MON.rawCount=0;const _c=document.getElementById('raw-count'); if(_c)_c.textContent=0;}
    else {MON.rfCount=0;const _c=document.getElementById('rf-count'); if(_c)_c.textContent=0;}
}


// ═══════════════════════════════════════════════════════════════════
// 📊 MONITOR STATS 7 GIORNI — Leaderboard, heatmap, settings
// ═══════════════════════════════════════════════════════════════════

const MSTATS = {
    lastWindow: '7d',
    lastNet: 'all',
    lastFw: 'all',
    refreshing: false,
    // Quali leaderboard rendere (corrispondono a DOM id mlb-<kind>)
    kinds: ['top_nodes','top_channels','top_portnums','by_network','by_firmware',
            'best_signal','new_nodes','silent_nodes','compressed_nodes']
};

function monitorStatsGetFilters(){
    const _w=document.getElementById('mstats-window');
    const _n=document.getElementById('mstats-network');
    const _f=document.getElementById('mstats-fw');
    return {
        window: _w?_w.value:'7d',
        network: _n?_n.value:'all',
        fw: _f?_f.value:'all',
    };
}

function monitorStatsQS(extra){
    const f=monitorStatsGetFilters();
    const qs=new URLSearchParams();
    qs.set('window', f.window);
    if(f.network && f.network!=='all') qs.set('network', f.network);
    if(f.fw && f.fw!=='all') qs.set('fw', f.fw);
    if(extra){
        for(const k of Object.keys(extra)){
            if(extra[k]!==undefined && extra[k]!==null) qs.set(k, String(extra[k]));
        }
    }
    return qs.toString();
}

async function monitorStatsRefresh(){
    if(MSTATS.refreshing) return;
    MSTATS.refreshing=true;
    try{
        // Una fetch per ogni leaderboard + una per la timeline
        const jobs=MSTATS.kinds.map(k=>monitorStatsLoadLeaderboard(k));
        jobs.push(monitorStatsLoadHeatmap());
        jobs.push(monitorStatsLoadDbInfo());
        await Promise.all(jobs);
    }catch(e){
        console.error('stats refresh error:', e);
    }finally{
        MSTATS.refreshing=false;
    }
}

async function monitorStatsLoadLeaderboard(kind){
    const _body=document.getElementById('mlb-'+kind);
    if(!_body) return;
    try{
        const r=await fetch('/api/monitor/stats/leaderboard?type='+kind+'&'+monitorStatsQS({limit:10}));
        const j=await r.json();
        if(!j.success || !Array.isArray(j.rows) || j.rows.length===0){
            _body.innerHTML='<div class="monitor-lb-empty" data-i18n="monitor.lb_empty">'+(window.t?t('monitor.lb_empty'):'Nessun dato')+'</div>';
            return;
        }
        _body.innerHTML=monitorStatsRenderRows(kind, j.rows);
    }catch(e){
        _body.innerHTML='<div class="monitor-lb-empty" style="color:var(--danger);">'+(window.t?t('monitor.lb_error'):'Errore')+'</div>';
    }
}

function monitorStatsRenderRows(kind, rows){
    // Trova max per le barre proporzionali
    const maxCount=Math.max(1, ...rows.map(r=>r.packets||0));
    const html=[];
    for(const r of rows){
        const label=monitorStatsLabel(kind, r);
        const count=Number(r.packets||0);
        const pct=Math.max(2, Math.round((count/maxCount)*100));
        const extra=monitorStatsExtra(kind, r);
        html.push(
            '<div class="monitor-lb-row">'+
                '<div class="monitor-lb-label">'+monitorEscape(label)+'</div>'+
                '<div class="monitor-lb-bar-wrap"><div class="monitor-lb-bar" style="width:'+pct+'%;"></div></div>'+
                '<div class="monitor-lb-count">'+count+'</div>'+
                (extra?'<div class="monitor-lb-extra">'+monitorEscape(extra)+'</div>':'')+
            '</div>'
        );
    }
    return html.join('');
}

function monitorStatsLabel(kind, row){
    if(kind==='top_nodes' || kind==='best_signal' || kind==='new_nodes' ||
       kind==='silent_nodes' || kind==='compressed_nodes'){
        const n=row.short_name||row.long_name;
        if(n) return n+' ('+monitorStatsNodeHex(row.node_id)+')';
        return monitorStatsNodeHex(row.node_id);
    }
    if(kind==='top_channels') return row.channel||'—';
    if(kind==='top_portnums') return (row.port_name||('#'+row.portnum))||'—';
    if(kind==='by_network'){
        const k='network.'+(row.network||'unknown');
        return window.t?t(k):(row.network||'—');
    }
    if(kind==='by_firmware'){
        const k='fw.'+(row.fw_type||'unknown');
        return window.t?t(k):(row.fw_type||'—');
    }
    return '—';
}

function monitorStatsExtra(kind, row){
    if(kind==='best_signal'){
        const rssi=row.avg_rssi!=null?Math.round(row.avg_rssi)+'dBm':'';
        const snr=row.avg_snr!=null?Number(row.avg_snr).toFixed(1)+'dB':'';
        return [rssi, snr].filter(Boolean).join(' · ');
    }
    if(kind==='top_nodes' || kind==='new_nodes'){
        if(row.network){
            const k='network.'+row.network;
            return window.t?t(k):row.network;
        }
    }
    return '';
}

function monitorStatsNodeHex(id){
    if(id==null) return '—';
    try{
        const n=Number(id);
        if(!Number.isFinite(n)) return String(id);
        return '!'+n.toString(16).padStart(8,'0');
    }catch(_e){ return String(id); }
}

async function monitorStatsLoadHeatmap(){
    const _canvas=document.getElementById('monitor-heatmap-canvas');
    if(!_canvas) return;
    try{
        const r=await fetch('/api/monitor/stats/timeline?'+monitorStatsQS({bucket:'1h'}));
        const j=await r.json();
        if(!j.success || !Array.isArray(j.series)){
            monitorHeatmapDrawEmpty(_canvas);
            return;
        }
        monitorHeatmapDraw(_canvas, j.series);
    }catch(e){
        monitorHeatmapDrawEmpty(_canvas);
    }
}

function monitorHeatmapDraw(_canvas, series){
    // series: [{bucket, packets, enc, compr}, ...]
    const ctx=_canvas.getContext('2d');
    const w=_canvas.width, h=_canvas.height;
    ctx.clearRect(0,0,w,h);
    if(!series || series.length===0){
        monitorHeatmapDrawEmpty(_canvas);
        return;
    }
    // Costruisce matrice 7 giorni × 24 ore (UTC), aggrega se ci sono più bucket per cella
    const matrix=[]; for(let d=0; d<7; d++){ const row=[]; for(let h2=0; h2<24; h2++) row.push(0); matrix.push(row); }
    const nowMs=Date.now();
    const dayMs=86400000;
    for(const b of series){
        const t2=Number(b.bucket);
        if(!Number.isFinite(t2)) continue;
        const ageDays=Math.floor((nowMs-t2)/dayMs);
        if(ageDays<0 || ageDays>=7) continue;
        const dIdx=6-ageDays; // riga 0 = 7 giorni fa, riga 6 = oggi
        const hr=new Date(t2).getUTCHours();
        matrix[dIdx][hr]+=Number(b.packets||0);
    }
    // Normalizza
    let maxC=1; for(const row of matrix) for(const c of row) if(c>maxC) maxC=c;
    // Draw
    const marginL=28, marginT=18, marginR=8, marginB=18;
    const cellW=(w-marginL-marginR)/24;
    const cellH=(h-marginT-marginB)/7;
    ctx.font='10px monospace';
    ctx.fillStyle='#888';
    ctx.textAlign='center';
    for(let hr=0; hr<24; hr+=2){
        ctx.fillText(String(hr).padStart(2,'0'), marginL+hr*cellW+cellW/2, marginT-4);
    }
    ctx.textAlign='right';
    const labelDays=['-6d','-5d','-4d','-3d','-2d','-1d','0d'];
    for(let d=0; d<7; d++){
        ctx.fillText(labelDays[d], marginL-3, marginT+d*cellH+cellH/2+3);
    }
    for(let d=0; d<7; d++){
        for(let hr=0; hr<24; hr++){
            const c=matrix[d][hr];
            const intensity=c/maxC;
            // gradient verde: basso=scuro, alto=accent
            const r=Math.round(10+intensity*0);
            const g=Math.round(30+intensity*225);
            const b=Math.round(20+intensity*100);
            ctx.fillStyle='rgb('+r+','+g+','+b+')';
            ctx.fillRect(marginL+hr*cellW+1, marginT+d*cellH+1, cellW-2, cellH-2);
        }
    }
}

function monitorHeatmapDrawEmpty(_canvas){
    const ctx=_canvas.getContext('2d');
    const w=_canvas.width, h=_canvas.height;
    ctx.clearRect(0,0,w,h);
    ctx.fillStyle='#666';
    ctx.font='14px monospace';
    ctx.textAlign='center';
    const msg=window.t?t('monitor.lb_empty'):'Nessun dato';
    ctx.fillText(msg, w/2, h/2);
}

function monitorStatsExport(kind){
    const qs=monitorStatsQS({type:kind, format:'csv', limit:100});
    window.open('/api/monitor/stats/export?'+qs, '_blank');
}

async function monitorStatsLoadDbInfo(){
    const _el=document.getElementById('monitor-db-info');
    if(!_el) return;
    try{
        const r=await fetch('/api/monitor/db/info');
        const j=await r.json();
        if(!j.success || !j.info){
            _el.innerHTML='<span style="color:var(--danger);">'+(window.t?t('monitor.db_info_error'):'Errore DB')+'</span>';
            return;
        }
        const i=j.info;
        const sizeKb=Math.round((i.size_bytes||0)/1024);
        const oldest=i.oldest_ts?new Date(i.oldest_ts).toLocaleString():'—';
        const newest=i.newest_ts?new Date(i.newest_ts).toLocaleString():'—';
        const rtn=i.retention_days||7;
        const rows=i.total_packets||0;
        const nodes=i.total_nodes||0;
        const parts=[
            '<strong>'+(window.t?t('monitor.db_label'):'DB')+':</strong> '+sizeKb+' KB · '+rows+' pkt · '+nodes+' '+(window.t?t('monitor.db_nodes'):'nodi'),
            '<strong>'+(window.t?t('monitor.db_retention'):'Retention')+':</strong> '+rtn+'g',
            '<strong>'+(window.t?t('monitor.db_oldest'):'Primo')+':</strong> '+oldest,
            '<strong>'+(window.t?t('monitor.db_newest'):'Ultimo')+':</strong> '+newest,
        ];
        _el.innerHTML=parts.join(' · ');
    }catch(e){
        _el.innerHTML='<span style="color:var(--danger);">'+(window.t?t('monitor.db_info_error'):'Errore DB')+'</span>';
    }
}

async function monitorSettingsReload(){
    try{
        const r=await fetch('/api/monitor/settings');
        const j=await r.json();
        if(!j.success || !j.settings) return;
        const s=j.settings;
        const _rt=document.getElementById('mset-retention'); if(_rt) _rt.value=s.retention_days||7;
        const _st=document.getElementById('mset-save-text'); if(_st) _st.checked=!!s.save_text;
        const _sp=document.getElementById('mset-save-payload'); if(_sp) _sp.checked=!!s.save_payload;
        const _en=document.getElementById('mset-enrich'); if(_en) _en.checked=!!s.enrich_online;
    }catch(e){}
}

async function monitorSettingsSave(){
    const body={};
    const _rt=document.getElementById('mset-retention'); if(_rt) body.retention_days=parseInt(_rt.value,10)||7;
    const _st=document.getElementById('mset-save-text'); if(_st) body.save_text=!!_st.checked;
    const _sp=document.getElementById('mset-save-payload'); if(_sp) body.save_payload=!!_sp.checked;
    const _en=document.getElementById('mset-enrich'); if(_en) body.enrich_online=!!_en.checked;
    try{
        const r=await fetch('/api/monitor/settings', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(body)});
        const j=await r.json();
        if(j.success){
            if(typeof showToast==='function') showToast(window.t?t('monitor.settings_saved'):'Impostazioni salvate', 'success');
        }else{
            if(typeof showToast==='function') showToast(window.t?t('monitor.settings_err'):'Errore salvataggio', 'error');
        }
    }catch(e){
        if(typeof showToast==='function') showToast(window.t?t('monitor.settings_err'):'Errore salvataggio', 'error');
    }
}

async function monitorPurgeOld(){
    if(!confirm(window.t?t('monitor.confirm_purge_old'):"Pulire i dati più vecchi della retention?")) return;
    try{
        const r=await fetch('/api/monitor/db/purge', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({confirm:true, scope:'older_than_retention'})});
        const j=await r.json();
        if(j.success){
            if(typeof showToast==='function') showToast(window.t?t('monitor.purge_ok'):'Pulizia completata', 'success');
            monitorStatsLoadDbInfo();
        }
    }catch(e){}
}

async function monitorPurgeAll(){
    if(!confirm(window.t?t('monitor.confirm_purge_all'):"⚠️ Cancellare TUTTI i dati del DB? L'operazione è irreversibile.")) return;
    if(!confirm(window.t?t('monitor.confirm_purge_all_2'):"Conferma definitivamente: cancellare tutto?")) return;
    try{
        const r=await fetch('/api/monitor/db/purge', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({confirm:true, scope:'all'})});
        const j=await r.json();
        if(j.success){
            if(typeof showToast==='function') showToast(window.t?t('monitor.purge_all_ok'):'DB svuotato', 'success');
            monitorStatsRefresh();
        }
    }catch(e){}
}

// Auto-load settings + refresh quando la sezione Monitor viene aperta
(function _monitorStatsAutoBoot(){
    function _hookFilters(){
        for(const id of ['mstats-window','mstats-network','mstats-fw']){
            const _el=document.getElementById(id);
            if(_el && !_el._mstatsHooked){
                _el._mstatsHooked=true;
                _el.addEventListener('change', ()=>{ monitorStatsRefresh(); });
            }
        }
    }
    // Delegato al global nav listener: quando si attiva section-monitor, refresh una volta
    document.addEventListener('DOMContentLoaded', ()=>{
        _hookFilters();
        // Se la sezione Monitor è già attiva al boot, carica subito
        const _mc=document.getElementById('monitor-content');
        if(_mc && _mc.offsetParent!==null){
            try{
                monitorSettingsReload();
                monitorStatsRefresh();
                if(typeof monitorNetInfoRefresh==='function'){ monitorNetInfoRefresh(); }
                if(typeof monitorModeScheduleLoad==='function'){ monitorModeScheduleLoad(); }
                if(typeof monitorGpsRefresh==='function'){ monitorGpsRefresh(); }
                if(typeof monitorGpsStartAuto==='function'){ monitorGpsStartAuto(); }
            }catch(_e){}
        }
    });
    // Patch navigateTo: quando apre "monitor", fai refresh una volta sola
    const _prevNav=window.navigateTo;
    if(typeof _prevNav==='function' && !_prevNav._mstatsPatched){
        window.navigateTo=function(_id){
            const _r=_prevNav.apply(this, arguments);
            // Toggle body class per full-width del Monitor
            if(_id==='monitor'){
                document.body.classList.add('monitor-fullwidth');
                _hookFilters();
                setTimeout(()=>{
                    try{
                        monitorSettingsReload();
                        monitorStatsRefresh();
                        monitorLoadHistory();    // Backfill ultimi 500 pacchetti
                        monitorPskReload();      // Carica elenco PSK
                        if(typeof monitorChannelMapReload==='function'){ monitorChannelMapReload(); } // STEP 2: mappa canali da DB
                        if(typeof monitorPubkeyRefresh==='function'){ monitorPubkeyRefresh(); } // STEP 5: pubkey harvester
                        if(typeof monitorAnalystRefresh==='function'){
                            monitorAnalystRefresh();
                            monitorAnalystStartAuto();
                        }
                        // STEP F2/F3/F4 — Network info, Monitor Mode schedule, GPS nodes
                        if(typeof monitorNetInfoRefresh==='function'){ monitorNetInfoRefresh(); }
                        if(typeof monitorModeScheduleLoad==='function'){ monitorModeScheduleLoad(); }
                        if(typeof monitorGpsRefresh==='function'){ monitorGpsRefresh(); }
                        if(typeof monitorGpsStartAuto==='function'){ monitorGpsStartAuto(); }
                    }catch(_e){}
                }, 250);
            } else {
                document.body.classList.remove('monitor-fullwidth');
                if(typeof monitorAnalystStopAuto==='function'){ monitorAnalystStopAuto(); }
                if(typeof monitorGpsStopAuto==='function'){ monitorGpsStopAuto(); }
            }
            return _r;
        };
        window.navigateTo._mstatsPatched=true;
    }
})();


// ═══════════════════════════════════════════════════════════════════
// 📚 MONITOR HISTORY — backfill pacchetti dal DB 7gg
// ═══════════════════════════════════════════════════════════════════

async function monitorLoadHistory(window_){
    const _win=window_||'7d';
    const _rf=document.getElementById('term-rf');
    const _mqtt=document.getElementById('term-mqtt');
    const _txt=document.getElementById('term-text');
    try{
        const _res=await fetch('/api/monitor/history?limit=500&window='+encodeURIComponent(_win), {credentials:'same-origin'});
        if(!_res.ok) return;
        const _data=await _res.json();
        if(!_data.success||!Array.isArray(_data.packets)) return;
        // Pacchetti in DESC (più recenti prima) → renderizza da vecchio a nuovo
        const _pkts=_data.packets.slice().reverse();
        // Reset terminali prima del backfill
        if(_rf){_rf.innerHTML='';}
        if(_mqtt){_mqtt.innerHTML='';}
        if(_txt){_txt.innerHTML='';}
        MON.rfCount=0; MON.mqttCount=0; MON.textCount=0;
        for(const _row of _pkts){
            // Map riga DB → formato packet atteso da renderer
            const _p=monitorMapHistoryRow(_row);
            monitorRenderPacket(_p);
        }
        const _histInfo=document.getElementById('mon-history-info');
        if(_histInfo){
            _histInfo.textContent=t('📚 Cronologia')+': '+_data.count+' '+t('pacchetti ultimi')+' '+_win;
        }
    }catch(_e){/* silent */}
}

function monitorMapHistoryRow(r){
    // Converte riga packets+nodes in oggetto "packet" atteso dal renderer
    const _ts=r.ts?Math.floor(r.ts/1000):0;
    const _hms=_ts?(new Date(_ts*1000)).toLocaleTimeString('it-IT'):'--:--:--';
    return {
        type:'packet',
        ts:_ts, ts_hms:_hms,
        source:r.source||'rf',
        sender_id:r.from_node?('!'+Number(r.from_node).toString(16).padStart(8,'0')):'',
        to_id:r.to_node?('!'+Number(r.to_node).toString(16).padStart(8,'0')):'',
        long_name:r.long_name||'', short_name:r.short_name||'',
        channel:r.channel_idx||0, channel_name:r.channel_name||'',
        psk_match_label:r.psk_match||null,
        network_bucket:r.network||'', network:r.network||'',
        portnum:r.port_name||'', portnum_num:r.portnum||null,
        payload:r.payload_text?{text:r.payload_text}:{},
        payload_len:r.payload_len||0,
        rssi:r.rssi, snr:r.snr,
        hop_start:r.hop_start, hop_limit:r.hop_limit,
        packet_id:r.packet_id,
        is_encrypted:!!r.is_encrypted,
        is_compressed:!!r.is_compressed,
        fw_type:r.fw_type||'unknown',
        fw_flags:r.fw_flags||'',
        _history:true,
    };
}


// ═══════════════════════════════════════════════════════════════════
// 🔐 MONITOR PSK MANAGER — CRUD chiavi pubbliche/private
// ═══════════════════════════════════════════════════════════════════

async function monitorPskReload(){
    const _tbody=document.getElementById('psk-tbody');
    if(!_tbody) return;
    try{
        const _res=await fetch('/api/monitor/psk?with_pkt_count=1&window_days=30', {credentials:'same-origin'});
        const _data=await _res.json();
        if(!_data.success){
            _tbody.innerHTML='<tr><td colspan="8" style="text-align:center;color:#e74c3c;">'+monitorEscape(_data.message||t('Errore caricamento'))+'</td></tr>';
            return;
        }
        if(!_data.keys.length){
            _tbody.innerHTML='<tr><td colspan="8" style="text-align:center;color:var(--text-muted);">'+t('Nessuna chiave PSK registrata')+'</td></tr>';
            return;
        }
        const _rows=_data.keys.map(k=>{
            const _hex=k.psk_b64?monitorEscape(k.psk_b64):'';
            const _kcls=k.kind==='private'?'psk-priv':'psk-pub';
            const _kind=k.kind==='private'?'🔒 '+t('Privata'):'🌐 '+t('Pubblica');
            const _ch=k.channel_name?monitorEscape(k.channel_name):'—';
            const _en=k.enabled?'✅':'⏸️';
            const _lastMatch=k.last_match_ts?(new Date(k.last_match_ts)).toLocaleString('it-IT'):'—';
            return '<tr class="'+_kcls+(k.enabled?'':' psk-disabled')+'">'+
                '<td>'+monitorEscape(k.label||'')+'</td>'+
                '<td>'+_kind+'</td>'+
                '<td>'+_ch+'</td>'+
                '<td class="psk-hex" title="'+_hex+'" style="word-break:break-all;font-family:monospace;font-size:0.7rem;">'+(k.psk_b64?monitorEscape(k.psk_b64):'')+'</td>'+
                '<td style="text-align:center;">'+(k.match_count||0)+'</td>'+
                '<td style="text-align:center;'+
                  ((k.pkt_count_window||0)>0?' color:var(--success,#0f0);font-weight:600;':' color:var(--text-muted);')+
                  '" title="'+t('Pacchetti totali')+': '+(k.pkt_count||0)+'">'+
                  (k.pkt_count_window!==undefined?(k.pkt_count_window):'-')+'</td>'+
                '<td>'+_lastMatch+'</td>'+
                '<td style="white-space:nowrap;">'+
                '<button class="btn btn-sm" onclick="monitorPskToggle('+k.id+', '+(k.enabled?0:1)+')">'+_en+'</button> '+
                '<button class="btn btn-sm btn-danger" onclick="monitorPskDelete('+k.id+')">🗑️</button>'+
                '</td>'+
                '</tr>';
        }).join('');
        _tbody.innerHTML=_rows;
    }catch(_e){
        _tbody.innerHTML='<tr><td colspan="8" style="text-align:center;color:#e74c3c;">'+t('Errore di rete')+'</td></tr>';
    }
}

async function monitorPskAdd(){
    const _label=document.getElementById('psk-new-label');
    const _psk=document.getElementById('psk-new-key');
    const _kind=document.getElementById('psk-new-kind');
    const _ch=document.getElementById('psk-new-channel');
    if(!_label||!_psk) return;
    const _lv=(_label.value||'').trim();
    const _kv=(_psk.value||'').trim();
    if(!_lv||!_kv){
        showToast(t('Inserisci etichetta e chiave'), 'error');
        return;
    }
    try{
        const _res=await fetch('/api/monitor/psk', {
            method:'POST',
            headers:{'Content-Type':'application/json'},
            credentials:'same-origin',
            body:JSON.stringify({
                label:_lv,
                psk_b64:_kv,
                kind:(_kind&&_kind.value)||'public',
                channel_name:(_ch&&_ch.value.trim())||null,
            }),
        });
        const _data=await _res.json();
        if(_data.success){
            _label.value=''; _psk.value=''; if(_ch)_ch.value='';
            showToast(t('Chiave PSK aggiunta'), 'success');
            monitorPskReload();
        } else {
            showToast(_data.message||t('Errore'), 'error');
        }
    }catch(_e){
        showToast(t('Errore di rete'), 'error');
    }
}

async function monitorPskToggle(_id, _enabled){
    try{
        const _res=await fetch('/api/monitor/psk/'+_id, {
            method:'PUT',
            headers:{'Content-Type':'application/json'},
            credentials:'same-origin',
            body:JSON.stringify({enabled:_enabled?true:false}),
        });
        const _data=await _res.json();
        if(_data.success){
            monitorPskReload();
        }
    }catch(_e){}
}

async function monitorPskDelete(_id){
    if(!confirm(t('Eliminare questa chiave PSK?'))) return;
    try{
        const _res=await fetch('/api/monitor/psk/'+_id, {method:'DELETE', credentials:'same-origin'});
        const _data=await _res.json();
        if(_data.success){
            showToast(t('Chiave eliminata'), 'success');
            monitorPskReload();
        }
    }catch(_e){}
}

async function monitorPskSyncFromNode(){
    const _btn=document.getElementById('psk-sync-btn');
    const _info=document.getElementById('psk-sync-result');
    if(_btn){ _btn.disabled=true; _btn.textContent=t('Importando...'); }
    if(_info){ _info.textContent=''; _info.style.color='var(--accent)'; }
    try{
        const _res=await fetch('/api/monitor/psk/sync-from-node', {
            method:'POST',
            headers:{'Content-Type':'application/json'},
            credentials:'same-origin',
            body:'{}',
        });
        const _data=await _res.json();
        if(_data.success){
            const _msg=t('Importate')+': '+(_data.added||0)+' · '+t('aggiornate')+': '+(_data.updated||0)+' · '+t('saltate')+': '+(_data.skipped||0);
            if(_info){ _info.textContent=_msg; _info.style.color='var(--accent)'; }
            showToast(_msg, 'success');
            monitorPskReload();
        } else {
            const _err=_data.message||_data.error||t('Errore import');
            if(_info){ _info.textContent=_err; _info.style.color='var(--error)'; }
            if(_data.error==='monitor_not_active'){
                showToast(t('Il Monitor deve essere attivo per leggere le chiavi dal nodo.'), 'error');
            } else {
                showToast(_err, 'error');
            }
        }
    }catch(_e){
        if(_info){ _info.textContent=t('Errore di rete'); _info.style.color='var(--error)'; }
        showToast(t('Errore di rete'), 'error');
    }finally{
        if(_btn){ _btn.disabled=false; const _lbl=document.querySelector('#psk-sync-btn'); if(_lbl){ _lbl.setAttribute('data-i18n','monitor.psk_sync_btn'); _lbl.textContent=t('📥 Importa chiavi dal nodo'); } }
    }
}

async function monitorPskRematch(){
    // STEP B — Forza riprocesso di tutti i pacchetti cifrati con le chiavi attualmente disponibili
    const _btn=document.getElementById('psk-rematch-btn');
    const _info=document.getElementById('psk-sync-result');
    if(_btn){ _btn.disabled=true; _btn.textContent=t('Riprocessando...'); }
    if(_info){ _info.textContent=''; _info.style.color='var(--accent)'; }
    try{
        const _res=await fetch('/api/monitor/psk/rematch', {
            method:'POST',
            headers:{'Content-Type':'application/json'},
            credentials:'same-origin',
            body:'{}',
        });
        const _data=await _res.json();
        if(_data.success){
            const _msg=t('Decifrati')+': '+(_data.total_matched||0)+' ('+t('RAM')+': '+(_data.ram_matched||0)+' · '+t('DB')+': '+(_data.db_matched||0)+')';
            if(_info){ _info.textContent=_msg; _info.style.color='var(--accent)'; }
            showToast(_msg, 'success');
            monitorPskReload();
        } else {
            const _err=_data.error||t('Errore rematch');
            if(_info){ _info.textContent=_err; _info.style.color='var(--error)'; }
            if(_data.error==='no_psks_enabled'){
                showToast(t('Nessuna chiave PSK abilitata'), 'warning');
            } else {
                showToast(_err, 'error');
            }
        }
    }catch(_e){
        if(_info){ _info.textContent=t('Errore di rete'); _info.style.color='var(--error)'; }
        showToast(t('Errore di rete'), 'error');
    }finally{
        if(_btn){ _btn.disabled=false; _btn.textContent=t('🔄 Riprocessa con nuove chiavi'); }
    }
}

// STEP 10 — Seed catalogo PSK Italia (33 canali, 11 chiavi uniche)
// Associa tutte le PSK note delle reti italiane così i canali regionali
// escono decifrati anche senza configurarli manualmente sul nodo.
async function monitorPskSeedItalia(){
    const _btn=document.getElementById('psk-seed-italia-btn');
    const _info=document.getElementById('psk-sync-result');
    if(_btn){ _btn.disabled=true; _btn.textContent=t('Caricamento...'); }
    if(_info){ _info.textContent=''; _info.style.color='var(--accent)'; }
    try{
        const _res=await fetch('/api/monitor/psk/seed/italia', {
            method:'POST',
            headers:{'Content-Type':'application/json'},
            credentials:'same-origin',
            body:'{}',
        });
        const _data=await _res.json();
        if(_data.success){
            const _parts=[];
            _parts.push(t('Canali catalogo')+': '+(_data.total||0));
            _parts.push(t('aggiunte')+': '+(_data.added||0));
            _parts.push(t('aggiornate')+': '+(_data.updated||0));
            _parts.push(t('invariate')+': '+(_data.unchanged||0));
            if((_data.errors||0)>0) _parts.push(t('errori')+': '+_data.errors);
            if(_data.rematch && typeof _data.rematch==='object'){
                _parts.push(t('decifrati')+': '+(_data.rematch.total_matched||0));
            }
            const _msg=_parts.join(' · ');
            if(_info){ _info.textContent=_msg; _info.style.color='var(--accent)'; }
            showToast(_msg, 'success');
            if(typeof monitorPskReload==='function') monitorPskReload();
        } else {
            const _err=_data.message||_data.error||t('Errore caricamento catalogo');
            if(_info){ _info.textContent=_err; _info.style.color='var(--error)'; }
            showToast(_err, 'error');
        }
    }catch(_e){
        if(_info){ _info.textContent=t('Errore di rete'); _info.style.color='var(--error)'; }
        showToast(t('Errore di rete'), 'error');
    }finally{
        if(_btn){ _btn.disabled=false; _btn.textContent=t('🇮🇹 Carica 36 canali Italia'); }
    }
}
window.monitorPskSeedItalia = monitorPskSeedItalia;


// ═══════════════════════════════════════════════════════════════════
// 📡 STEP 2 HUNTER — CHANNEL SLOTS (sync + map hash8→nome canale)
// ═══════════════════════════════════════════════════════════════════

// Cache in-memory hash8 → {name, short_name, idx} per arricchire terminale
window.CHANNEL_MAP_CACHE = window.CHANNEL_MAP_CACHE || {};

window.channelNameByHash = function(hash8){
    if (hash8 === null || hash8 === undefined) return null;
    const _h = (hash8 | 0) & 0xFF;
    const _m = window.CHANNEL_MAP_CACHE[_h];
    return _m ? _m : null;
};

// STEP 3 — Risolve etichetta canale "ch162 (Ita-Help)" usando backend channel_name
// o cache hash→name popolata dallo Step 2. Restituisce null se non risolvibile.
// FASE 16a (2026-05-05) — Set di nomi PRESET ambigui che vanno disambiguati con preset radio
window._PRESET_AMBIGUOUS_NAMES = ['LongFast','MediumFast','ShortFast','ShortTurbo','ShortSlow','MediumSlow','LongModerate','LongSlow','VeryLongSlow','PrimaryDefault'];

// FASE 16a — Cache preset radio del nodo USB (popolata da fetch nodo)
window._LOCAL_NODE_PRESET = null;

window.monitorChannelLabel = function(p){
    if (!p) return null;
    // FASE 16a: helper interno per appendere preset radio quando il channel_name e'
    // ambiguo (LongFast/MediumFast/... = nome firmware default, non rappresenta il
    // vero preset radio della rete).
    function _withPreset(name){
        if (!name) return null;
        const _nm = String(name);
        // Se il nome e' uno dei preset ambigui, e abbiamo info preset dal pacchetto
        // o dal nodo locale, mostriamo entrambi: "LongFast (preset MediumFast)"
        const _isAmbig = (window._PRESET_AMBIGUOUS_NAMES || []).indexOf(_nm) >= 0;
        if (!_isAmbig) return _nm;
        // Cerca preset: prima nel pacchetto stesso, poi cache nodo locale
        let _preset = null;
        if (p.modem_preset) _preset = String(p.modem_preset);
        else if (window._LOCAL_NODE_PRESET) _preset = String(window._LOCAL_NODE_PRESET);
        if (!_preset) return _nm;
        // Normalizza "MEDIUM_FAST" → "MediumFast" per leggibilita'
        const _presetClean = _preset.replace(/_/g,'').toLowerCase();
        const _nmClean = _nm.toLowerCase();
        if (_presetClean === _nmClean) return _nm; // preset == nome canale → no duplicato
        return _nm + ' (' + _preset + ')';
    }
    // 1) backend ha già risolto (nodo USB ha questo slot configurato)
    if (p.channel_name && String(p.channel_name).trim().length > 0) {
        return _withPreset(String(p.channel_name));
    }
    // 2) lookup nella cache hash→name (popolata da STEP 2 sync + STEP 4 harvest MQTT)
    const _h = (p.channel_hash != null) ? p.channel_hash : p.channel;
    if (_h == null) return null;
    const _m = window.channelNameByHash(_h);
    if (_m && _m.name) return _withPreset(_m.name);
    return null;
};

// STEP 6 — Badge unificati per flag trasporto/crypto/nodo.
// Utilizzato da RAW dump e (futuro) unificazione RF/TEXT.
// Restituisce array di HTML span. Uso: ' · '.join o spazio.
window.monitorFlagBadges = function(p){
    if (!p) return [];
    const _b = [];
    // Transport
    if (p.via_mqtt === true) _b.push('<span style="color:#06b6d4;" title="via MQTT">☁️MQTT</span>');
    if (p.want_ack) _b.push('<span style="color:#f59e0b;" title="want_ack">🪝ACK?</span>');
    if (p.priority && p.priority !== 'UNSET') _b.push('<span style="color:#fbbf24;" title="priority">⚡'+monitorEscape(p.priority)+'</span>');
    // Routing
    if (p.next_hop) _b.push('<span style="color:#60a5fa;" title="next_hop">→0x'+Number(p.next_hop).toString(16)+'</span>');
    if (p.relay_node) _b.push('<span style="color:#60a5fa;" title="relay_node">▶0x'+Number(p.relay_node).toString(16)+'</span>');
    // Crypto
    if (p.pki_encrypted === true) _b.push('<span style="color:#a78bfa;" title="PKI encrypted">🔑PKI</span>');
    if (p.psk_match_label) {
        const _k = p.psk_match_kind || 'public';
        _b.push('<span style="color:#10b981;" title="PSK '+monitorEscape(_k)+'">🔓'+monitorEscape(p.psk_match_label)+'</span>');
    }
    // Nodo
    if (p.is_licensed === true) _b.push('<span style="color:#f59e0b;" title="HAM licensed">📻HAM</span>');
    if (p.is_stealth === true) _b.push('<span style="color:#8b5cf6;" title="stealth">👤stealth</span>');
    if (p.is_unmessagable === true) _b.push('<span style="color:#ef4444;" title="unmessagable">🔕no-msg</span>');
    // Spam
    if (p.spam_alert) _b.push('<span style="color:#ef4444;" title="spam">⚠️SPAM Δ'+Number(p.spam_alert.delta_s||0)+'s</span>');
    return _b;
};

async function monitorChannelMapReload(){
    // Ricarica snapshot DB channel_map e popola cache + tabella UI
    try{
        const _res = await fetch('/api/monitor/channels', {credentials:'same-origin'});
        const _data = await _res.json();
        if (!_data.success) return;
        const _rows = _data.channels || [];
        // Aggiorna cache
        window.CHANNEL_MAP_CACHE = {};
        for (const _c of _rows) {
            const _h = (_c.hash8 | 0) & 0xFF;
            window.CHANNEL_MAP_CACHE[_h] = {
                name: _c.name || '',
                short_name: _c.short_name || '',
                idx: (_c.idx | 0),
            };
        }
        monitorChannelRender(_rows);
    }catch(_e){}
}

function monitorChannelRender(rows){
    const _tbody = document.getElementById('channel-slots-tbody');
    if (!_tbody) return;
    if (!rows || rows.length === 0) {
        _tbody.innerHTML = '<tr><td colspan="6" style="text-align:center;color:var(--text-muted);padding:1rem;" data-i18n="monitor.channel_slots_empty">'
            + t('Nessun canale mappato. Premi "Sync canali dal nodo" per popolare.') + '</td></tr>';
        return;
    }
    const _lines = [];
    for (const _r of rows) {
        const _idx = (_r.idx === undefined || _r.idx === null) ? '?' : _r.idx;
        const _nm = _escHtml(_r.name || '(—)');
        const _sn = _escHtml(_r.short_name || '');
        const _rl = _escHtml(_r.role || '');
        const _h = (_r.hash8 | 0) & 0xFF;
        const _pskOk = !!(_r.psk_b64 && _r.psk_b64.length > 0);
        const _roleColor = (_r.role === 'PRIMARY') ? 'var(--accent)' : (_r.role === 'SECONDARY' ? '#ffb454' : 'var(--text-muted)');
        _lines.push(
            '<tr style="border-bottom:1px solid var(--border);">'
            + '<td style="text-align:center;font-family:var(--font-display);color:var(--accent);">' + _idx + '</td>'
            + '<td style="color:var(--text-primary);">' + _nm + '</td>'
            + '<td style="color:var(--text-muted);font-family:var(--font-display);font-size:0.72rem;">' + _sn + '</td>'
            + '<td style="color:' + _roleColor + ';font-size:0.72rem;">' + _rl + '</td>'
            + '<td style="text-align:center;font-family:var(--font-display);color:var(--text-secondary);">' + _h + '</td>'
            + '<td style="text-align:center;">' + (_pskOk ? '✅' : '—') + '</td>'
            + '</tr>'
        );
    }
    _tbody.innerHTML = _lines.join('');
}

function _escHtml(s){
    return String(s || '').replace(/[&<>"']/g, function(c){
        return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];
    });
}

// ─────────────────────────────────────────────────────────────
// STEP 5 — PKI Pubkey Harvester: UI refresh + render
// ─────────────────────────────────────────────────────────────
async function monitorPubkeyRefresh(){
    const _btn = document.getElementById('pubkey-refresh-btn');
    if (_btn) { _btn.disabled = true; }
    try {
        const _res = await fetch('/api/monitor/pubkeys?limit=200', {credentials:'same-origin'});
        const _data = await _res.json();
        if (!_data || !_data.success) {
            monitorPubkeyRender({stats: {}, pubkeys: []});
            return;
        }
        monitorPubkeyRender(_data);
    } catch(_e) {
        monitorPubkeyRender({stats: {}, pubkeys: []});
    } finally {
        if (_btn) { _btn.disabled = false; }
    }
}

function monitorPubkeyRender(data){
    const _stats = (data && data.stats) || {};
    const _rows = (data && data.pubkeys) || [];
    const _sNodes = document.getElementById('pubkey-stat-nodes');
    const _sKeys = document.getElementById('pubkey-stat-keys');
    const _sTotal = document.getElementById('pubkey-stat-total');
    if (_sNodes) _sNodes.textContent = String(_stats.unique_nodes || 0);
    if (_sKeys) _sKeys.textContent = String(_stats.unique_keys || 0);
    if (_sTotal) _sTotal.textContent = String(_stats.total_rows || 0);
    const _tbody = document.getElementById('pubkey-harvester-tbody');
    if (!_tbody) return;
    if (!_rows.length) {
        _tbody.innerHTML = '<tr><td colspan="5" style="text-align:center;color:var(--text-muted);padding:1rem;" data-i18n="monitor.pubkey_harvester_empty">'
            + t('Nessuna chiave pubblica ancora raccolta. Avvia il Monitor.') + '</td></tr>';
        return;
    }
    const _lines = [];
    for (const _r of _rows) {
        const _nid = _escHtml(_r.node_id || '');
        const _pk = _escHtml(_r.public_key_hex || '');
        const _cnt = (_r.seen_count | 0);
        const _lastTs = _r.last_seen_ts ? new Date(_r.last_seen_ts).toLocaleString() : '—';
        const _src = _escHtml(_r.source || 'rf');
        const _srcEmoji = (_r.source === 'mqtt') ? '☁️' : '📡';
        _lines.push(
            '<tr style="border-bottom:1px solid var(--border);">'
            + '<td style="font-family:var(--font-display);color:var(--accent);">' + _nid + '</td>'
            + '<td style="font-family:monospace;font-size:0.68rem;word-break:break-all;color:var(--text-secondary);">' + _pk + '</td>'
            + '<td style="text-align:center;color:var(--text-muted);">' + _cnt + '</td>'
            + '<td style="color:var(--text-muted);font-size:0.68rem;">' + _escHtml(_lastTs) + '</td>'
            + '<td style="text-align:center;" title="' + _src + '">' + _srcEmoji + '</td>'
            + '</tr>'
        );
    }
    _tbody.innerHTML = _lines.join('');
}

async function monitorChannelSync(){
    const _btn = document.getElementById('channel-sync-btn');
    const _info = document.getElementById('channel-sync-result');
    if (_btn) { _btn.disabled = true; _btn.textContent = t('Sincronizzando...'); }
    if (_info) { _info.textContent = ''; _info.style.color = 'var(--accent)'; }
    try{
        const _res = await fetch('/api/monitor/channels/sync', {
            method: 'POST',
            headers: {'Content-Type':'application/json'},
            credentials: 'same-origin',
            body: '{}',
        });
        const _data = await _res.json();
        if (_data.success) {
            const _nCh = (_data.channels || []).length;
            const _msg = t('Canali sincronizzati') + ': ' + _nCh
                + ' · PSK +' + (_data.psk_added || 0)
                + ' ~' + (_data.psk_updated || 0);
            if (_info) { _info.textContent = _msg; _info.style.color = 'var(--accent)'; }
            showToast(_msg, 'success');
            // Popola cache + tabella dal live snapshot ritornato
            if (_data.channels && _data.channels.length) {
                window.CHANNEL_MAP_CACHE = {};
                for (const _c of _data.channels) {
                    const _h = (_c.hash8 | 0) & 0xFF;
                    window.CHANNEL_MAP_CACHE[_h] = {
                        name: _c.name || '',
                        short_name: _c.short_name || '',
                        idx: (_c.index !== undefined ? (_c.index | 0) : (_c.idx | 0)),
                    };
                }
                // Render da live (normalizza index→idx)
                const _norm = _data.channels.map(function(c){
                    return {
                        idx: c.index !== undefined ? c.index : c.idx,
                        name: c.name,
                        short_name: c.short_name,
                        role: c.role,
                        hash8: c.hash8,
                        psk_b64: c.psk_b64,
                    };
                });
                monitorChannelRender(_norm);
            } else {
                monitorChannelMapReload();
            }
            // Refresh PSK list se la UI è visibile
            if (typeof monitorPskReload === 'function') monitorPskReload();
        } else {
            const _err = _data.message || _data.error || t('Errore sync canali');
            if (_info) { _info.textContent = _err; _info.style.color = 'var(--error)'; }
            if (_data.error === 'monitor_not_active') {
                showToast(t('Il Monitor deve essere attivo per sincronizzare i canali.'), 'error');
            } else {
                showToast(_err, 'error');
            }
        }
    }catch(_e){
        if (_info) { _info.textContent = t('Errore di rete'); _info.style.color = 'var(--error)'; }
        showToast(t('Errore di rete'), 'error');
    }finally{
        if (_btn) {
            _btn.disabled = false;
            _btn.textContent = t('🔄 Sync canali dal nodo');
        }
    }
}


// ═══════════════════════════════════════════════════════════════════
// 🔧 STEP D — AUTO-TUNE NODE
// ═══════════════════════════════════════════════════════════════════

let _TUNE_LAST_PREVIEW=null;

async function monitorTunePreview(){
    const _btn=document.getElementById('tune-preview-btn');
    const _box=document.getElementById('tune-preview-box');
    const _status=document.getElementById('tune-status');
    const _applyBtn=document.getElementById('tune-apply-btn');
    if(_btn){ _btn.disabled=true; _btn.textContent=t('Lettura nodo...'); }
    if(_status){ _status.textContent=''; _status.style.color='var(--text-muted)'; }
    try{
        const _res=await fetch('/api/monitor/tune/preview', {credentials:'same-origin'});
        const _data=await _res.json();
        if(!_data.success){
            if(_status){ _status.textContent=_data.message||_data.error||t('Errore'); _status.style.color='var(--error)'; }
            if(_box){ _box.style.display='none'; }
            if(_applyBtn) _applyBtn.style.display='none';
            return;
        }
        _TUNE_LAST_PREVIEW=_data;
        let _html='<div style="margin-bottom:0.4rem;"><strong>'+t('Modifiche necessarie')+':</strong> '+_data.changes_needed+'</div>';
        _html+='<table style="width:100%;font-size:0.72rem;border-collapse:collapse;">';
        _html+='<thead><tr style="border-bottom:1px solid var(--border);"><th style="text-align:left;padding:0.2rem;">'+t('Parametro')+'</th><th style="padding:0.2rem;">'+t('Attuale')+'</th><th style="padding:0.2rem;">'+t('Target')+'</th><th style="padding:0.2rem;">'+t('Stato')+'</th></tr></thead><tbody>';
        const _tgt=_data.target||{};
        const _cur=_data.current||{};
        const _diffPaths=new Set((_data.diff||[]).map(function(d){return d.path;}));
        for(const _p of Object.keys(_tgt)){
            const _needed=_diffPaths.has(_p);
            _html+='<tr style="border-bottom:1px solid rgba(255,255,255,0.05);">';
            _html+='<td style="padding:0.25rem;"><code>'+monitorEscape(_p)+'</code></td>';
            _html+='<td style="text-align:center;padding:0.25rem;"><code>'+monitorEscape(String(_cur[_p]!=null?_cur[_p]:'—'))+'</code></td>';
            _html+='<td style="text-align:center;padding:0.25rem;"><code>'+monitorEscape(String(_tgt[_p]))+'</code></td>';
            _html+='<td style="text-align:center;padding:0.25rem;">'+(_needed?'<span style="color:var(--warning,#ffb300);">⚠ '+t('Da aggiornare')+'</span>':'<span style="color:var(--success,#00ff9f);">✓ OK</span>')+'</td>';
            _html+='</tr>';
        }
        _html+='</tbody></table>';
        if(_box){ _box.innerHTML=_html; _box.style.display='block'; }
        if(_status){ _status.textContent=t('Anteprima pronta — conferma per applicare'); _status.style.color='var(--accent)'; }
        if(_applyBtn){ _applyBtn.style.display=(_data.changes_needed>0)?'inline-block':'none'; }
    }catch(_e){
        if(_status){ _status.textContent=t('Errore di rete'); _status.style.color='var(--error)'; }
    }finally{
        if(_btn){ _btn.disabled=false; _btn.textContent=t('👁 Mostra anteprima'); }
    }
}

async function monitorTuneApply(){
    if(!_TUNE_LAST_PREVIEW){
        showToast(t('Esegui prima l\'anteprima'), 'warning');
        return;
    }
    if(!confirm(t('Confermi di applicare le nuove impostazioni al nodo USB?\n\nVerranno scritte le configurazioni LoRa, MQTT, posizione e telemetria. Nessun factory-reset.'))){
        return;
    }
    const _btn=document.getElementById('tune-apply-btn');
    const _status=document.getElementById('tune-status');
    if(_btn){ _btn.disabled=true; _btn.textContent=t('Applicando...'); }
    if(_status){ _status.textContent=''; _status.style.color='var(--accent)'; }
    try{
        const _res=await fetch('/api/monitor/tune/apply', {
            method:'POST',
            headers:{'Content-Type':'application/json'},
            credentials:'same-origin',
            body:JSON.stringify({confirm:true}),
        });
        const _data=await _res.json();
        if(_data.success){
            const _appliedCount=(_data.applied||[]).filter(function(a){return a.status==='applied';}).length;
            if(_status){ _status.textContent=t('Applicate')+': '+_appliedCount+' · '+t('errori')+': '+((_data.errors||[]).length); _status.style.color='var(--success,#00ff9f)'; }
            showToast(t('Configurazione nodo aggiornata'), 'success');
            // Ri-anteprima per aggiornare la tabella
            monitorTunePreview();
        } else {
            const _msg=_data.message||_data.error||t('Errore');
            if(_status){ _status.textContent=_msg; _status.style.color='var(--error)'; }
            showToast(_msg, 'error');
        }
    }catch(_e){
        if(_status){ _status.textContent=t('Errore di rete'); _status.style.color='var(--error)'; }
    }finally{
        if(_btn){ _btn.disabled=false; _btn.textContent=t('✅ Applica configurazione'); }
    }
}


// ═══════════════════════════════════════════════════════════════════
// 🔬 STEP E — ANALYST AGENT (insights live 1h con auto-refresh)
// ═══════════════════════════════════════════════════════════════════

let _ANALYST_TIMER=null;
const _ANALYST_INTERVAL_MS=60000;

function monitorAnalystFormatNode(_n){
    // FASE 6 (2026-05-05) — rendering arricchito con metadati nodo
    const _short=_n.short_name||'';
    const _long=_n.long_name||'';
    const _label=_short||_long||_n.node_hex||'!0';
    const _hex=_n.node_hex||'';
    const _metaParts=[];
    if(_long && _short && _long!==_short){
        _metaParts.push('<span style="color:var(--text-secondary);" title="'+monitorEscape(_long)+'">'+monitorEscape(_long.length>20?_long.substring(0,20)+'…':_long)+'</span>');
    }
    if(_n.region) _metaParts.push('<span style="color:var(--accent);font-size:0.65rem;" title="'+t('Regione')+'">📍'+monitorEscape(_n.region)+'</span>');
    if(_n.network && _n.network!=='unknown') _metaParts.push('<span style="color:var(--text-secondary);font-size:0.65rem;" title="'+t('Rete')+'">'+monitorEscape(_n.network)+'</span>');
    if(_n.role) _metaParts.push('<span style="color:var(--text-muted);font-size:0.65rem;" title="'+t('Ruolo')+'">'+monitorEscape(_n.role)+'</span>');
    if(_n.hops_away!==null && _n.hops_away!==undefined) _metaParts.push('<span style="color:var(--text-muted);font-size:0.65rem;" title="'+t('Hop')+'">↪'+_n.hops_away+'h</span>');
    if(_n.rssi_avg!==null && _n.rssi_avg!==undefined) _metaParts.push('<span style="color:var(--text-muted);font-size:0.65rem;" title="'+t('RSSI medio')+'">'+_n.rssi_avg+'dBm</span>');
    if(_n.snr_avg!==null && _n.snr_avg!==undefined) _metaParts.push('<span style="color:var(--text-muted);font-size:0.65rem;" title="'+t('SNR medio')+'">'+_n.snr_avg+'dB</span>');
    if(_n.hw_model) _metaParts.push('<span style="color:var(--text-muted);font-size:0.65rem;" title="'+t('Hardware')+'">'+monitorEscape(_n.hw_model)+'</span>');
    if(_n.fw_type && _n.fw_type!=='unknown') _metaParts.push('<span style="color:var(--text-muted);font-size:0.65rem;" title="'+t('Firmware')+'">'+monitorEscape(_n.fw_type)+'</span>');
    if(_n.is_licensed===true) _metaParts.push('<span style="color:var(--success,#0f0);font-size:0.65rem;" title="'+t('Licenziato')+'">✓lic</span>');
    const _meta=_metaParts.length>0 ? '<br><span style="margin-left:1.2rem;display:inline-flex;gap:0.4rem;flex-wrap:wrap;">'+_metaParts.join(' · ')+'</span>' : '';
    return '<code>'+monitorEscape(_label)+'</code> <span style="color:var(--text-muted);font-size:0.7rem;">'+monitorEscape(_hex)+'</span>'+_meta;
}

function monitorAnalystRenderSection(_title, _items, _renderRow){
    if(!_items || _items.length===0){
        return '<div style="margin-bottom:0.5rem;"><strong>'+monitorEscape(_title)+':</strong> <span style="color:var(--text-muted);">'+t('Nessuno')+'</span></div>';
    }
    let _h='<div style="margin-bottom:0.5rem;"><strong>'+monitorEscape(_title)+':</strong><ul style="margin:0.2rem 0 0 1rem;padding:0;">';
    for(const _it of _items){ _h+='<li style="margin:0.1rem 0;">'+_renderRow(_it)+'</li>'; }
    _h+='</ul></div>';
    return _h;
}

function monitorAnalystRender(_data){
    const _box=document.getElementById('analyst-box');
    const _status=document.getElementById('analyst-status');
    if(!_box) return;
    const _ins=_data.insights||{};
    const _when=_data.last_run_ts ? new Date(_data.last_run_ts).toLocaleTimeString() : '—';
    if(_status){ _status.textContent=t('Ultimo aggiornamento')+': '+_when+' · '+t('durata')+' '+(_data.last_duration_ms||0)+'ms'; }

    let _h='';
    // Metriche generali
    _h+='<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(130px,1fr));gap:0.4rem;margin-bottom:0.8rem;">';
    _h+='<div style="background:var(--bg);padding:0.4rem;border-radius:var(--radius);text-align:center;"><div style="font-size:0.68rem;color:var(--text-muted);">'+t('Pacchetti (1h)')+'</div><div style="font-size:1.1rem;color:var(--accent);"><strong>'+(_ins.total_packets||0)+'</strong></div></div>';
    _h+='<div style="background:var(--bg);padding:0.4rem;border-radius:var(--radius);text-align:center;"><div style="font-size:0.68rem;color:var(--text-muted);">'+t('Nodi unici')+'</div><div style="font-size:1.1rem;color:var(--accent);"><strong>'+(_ins.unique_nodes||0)+'</strong></div></div>';
    _h+='<div style="background:var(--bg);padding:0.4rem;border-radius:var(--radius);text-align:center;"><div style="font-size:0.68rem;color:var(--text-muted);">'+t('Pkt/min')+'</div><div style="font-size:1.1rem;color:var(--accent);"><strong>'+(_ins.rate_per_min||0)+'</strong></div></div>';
    _h+='<div style="background:var(--bg);padding:0.4rem;border-radius:var(--radius);text-align:center;"><div style="font-size:0.68rem;color:var(--text-muted);">'+t('Cifrati non decodificati')+'</div><div style="font-size:1.1rem;color:var(--accent);"><strong>'+Math.round((_ins.enc_ratio||0)*100)+'%</strong></div></div>';
    _h+='</div>';

    // Top nodes — FASE 6: mostra metric primaria in base a rank_by
    const _rankBy=_ins.rank_by||'packets';
    _h+=monitorAnalystRenderSection('🏆 '+t('Top nodi'), _ins.top_nodes, function(_n){
        let _primary='<strong>'+_n.packets+'</strong> '+t('pkt');
        if(_rankBy==='rssi_avg' && _n.rssi_avg!==null && _n.rssi_avg!==undefined){
            _primary='<strong>'+_n.rssi_avg+' dBm</strong> '+t('RSSI')+' · '+_n.packets+' '+t('pkt');
        } else if(_rankBy==='snr_avg' && _n.snr_avg!==null && _n.snr_avg!==undefined){
            _primary='<strong>'+_n.snr_avg+' dB</strong> '+t('SNR')+' · '+_n.packets+' '+t('pkt');
        } else if(_rankBy==='hops' && _n.hops_away!==null && _n.hops_away!==undefined){
            _primary='<strong>'+_n.hops_away+'</strong> '+t('hop')+' · '+_n.packets+' '+t('pkt');
        } else if(_rankBy==='recency' && _n.last_ts){
            const _ago=Math.round((Date.now()-_n.last_ts)/60000);
            _primary='<strong>'+_ago+' min</strong> '+t('fa')+' · '+_n.packets+' '+t('pkt');
        }
        return monitorAnalystFormatNode(_n)+' · '+_primary;
    });
    // Spam suspects
    _h+=monitorAnalystRenderSection('⚠️ '+t('Sospetti spam'), _ins.spam_suspects, function(_n){
        return monitorAnalystFormatNode(_n)+' · <strong style="color:var(--warning,#ffb300);">'+_n.packets+' pkt</strong> <span style="color:var(--text-muted);">(soglia '+_n.threshold+')</span>';
    });
    // MQTT gateways
    _h+=monitorAnalystRenderSection('🌐 '+t('Gateway MQTT'), _ins.mqtt_gateways, function(_n){
        return monitorAnalystFormatNode(_n)+' · <strong>'+_n.mqtt_packets+'</strong> '+t('pkt MQTT');
    });
    // Stealth
    _h+=monitorAnalystRenderSection('👻 '+t('Sospetti stealth'), _ins.stealth_suspects, function(_n){
        return monitorAnalystFormatNode(_n)+' · '+t('visto')+' '+(_n.total_packets||0)+' '+t('volte');
    });
    // Hot channels
    _h+=monitorAnalystRenderSection('🔥 '+t('Canali caldi'), _ins.hot_channels, function(_c){
        return '<code>'+monitorEscape(_c.channel)+'</code> · <strong>'+_c.packets+'</strong> '+t('pkt');
    });
    // Silent channels
    _h+=monitorAnalystRenderSection('🤫 '+t('Canali silenti'), _ins.silent_channels, function(_c){
        return '<code>'+monitorEscape(_c.channel)+'</code> <span style="color:var(--text-muted);">— '+t('nessun pacchetto')+'</span>';
    });

    _box.innerHTML=_h;
}

async function monitorAnalystRefresh(_forceRecompute){
    // FASE 3 fix + FASE 6 (2026-05-05): legge selettori UI rank_by/window_s/top_n,
    // passa via querystring/body. _forceRecompute=true (default click manuale)
    // chiama POST /refresh; l'auto-timer passa false per leggere cache.
    const _btn=document.getElementById('analyst-refresh-btn');
    const _status=document.getElementById('analyst-status');
    if(_forceRecompute===undefined) _forceRecompute=true;
    if(_btn){ _btn.disabled=true; }
    if(_status){ _status.textContent=t('Analisi in corso...'); }
    // Leggi selettori UI (FASE 6)
    const _rankSel=document.getElementById('analyst-rank-by');
    const _winSel=document.getElementById('analyst-window-s');
    const _topSel=document.getElementById('analyst-top-n');
    const _params=new URLSearchParams();
    if(_rankSel && _rankSel.value) _params.set('rank_by', _rankSel.value);
    if(_winSel && _winSel.value) _params.set('window_s', _winSel.value);
    if(_topSel && _topSel.value) _params.set('top_n', _topSel.value);
    const _qs=_params.toString() ? ('?'+_params.toString()) : '';
    try{
        if(_forceRecompute){
            try{
                await fetch('/api/monitor/analyst/refresh'+_qs, {method:'POST', credentials:'same-origin'});
            }catch(_eRef){ /* ignora errori refresh */ }
        }
        const _res=await fetch('/api/monitor/analyst/insights'+_qs, {credentials:'same-origin'});
        const _data=await _res.json();
        if(_data.success){
            monitorAnalystRender(_data);
        } else {
            const _box=document.getElementById('analyst-box');
            if(_box){ _box.innerHTML='<div style="color:var(--error);padding:1rem;text-align:center;">'+monitorEscape(_data.message||_data.error||t('Errore'))+'</div>'; }
        }
    }catch(_e){
        const _box=document.getElementById('analyst-box');
        if(_box){ _box.innerHTML='<div style="color:var(--error);padding:1rem;text-align:center;">'+t('Errore di rete')+'</div>'; }
    }finally{
        if(_btn){ _btn.disabled=false; }
    }
}

function monitorAnalystStartAuto(){
    if(_ANALYST_TIMER) return;
    _ANALYST_TIMER=setInterval(function(){
        const _chk=document.getElementById('analyst-autorefresh');
        if(_chk && _chk.checked){ monitorAnalystRefresh(false); }
    }, _ANALYST_INTERVAL_MS);
}

function monitorAnalystStopAuto(){
    if(_ANALYST_TIMER){ clearInterval(_ANALYST_TIMER); _ANALYST_TIMER=null; }
}


// ═══════════════════════════════════════════════════════════════════
// 📡 STEP F2 — CONFIG RETE MESH ITALIA (netinfo)
// ═══════════════════════════════════════════════════════════════════

async function monitorNetInfoRefresh(){
    const _box=document.getElementById('netinfo-box');
    if(!_box) return;
    _box.innerHTML='<div style="color:var(--text-muted);text-align:center;padding:0.8rem;">'+t('Lettura dal nodo...')+'</div>';
    try{
        const _res=await fetch('/api/monitor/network/info', {credentials:'same-origin'});
        const _data=await _res.json();
        if(!_data.success){
            _box.innerHTML='<div style="color:#e74c3c;padding:0.6rem;">'+monitorEscape(_data.message||t('Errore lettura rete'))+'</div>';
            return;
        }
        _box.innerHTML=monitorNetInfoRender(_data.expected||{}, _data.current||{}, _data.match||{});
    }catch(_e){
        _box.innerHTML='<div style="color:#e74c3c;padding:0.6rem;">'+t('Errore di rete')+'</div>';
    }
}

function monitorNetInfoRender(_exp, _cur, _match){
    const _rows=[
        ['region', t('Regione')],
        ['modem_preset', t('Preset modem')],
        ['frequency_mhz', t('Frequenza (MHz)')],
        ['bandwidth_khz', t('Bandwidth (kHz)')],
        ['spread_factor', t('Spreading Factor')],
        ['coding_rate', t('Coding Rate')],
        ['bitrate_bps', t('Bitrate (bps)')],
        ['mqtt_root_topic', t('MQTT Root Topic')],
        ['channel_name_primary', t('Canale primario')],
    ];
    let _html='<table style="width:100%;border-collapse:collapse;font-size:0.76rem;">';
    _html+='<thead><tr style="border-bottom:1px solid var(--border);">'
        +'<th style="text-align:left;padding:0.3rem;color:var(--text-muted);font-weight:normal;">'+t('Parametro')+'</th>'
        +'<th style="text-align:left;padding:0.3rem;color:var(--text-muted);font-weight:normal;">'+t('Atteso')+'</th>'
        +'<th style="text-align:left;padding:0.3rem;color:var(--text-muted);font-weight:normal;">'+t('Attuale')+'</th>'
        +'<th style="text-align:center;padding:0.3rem;color:var(--text-muted);font-weight:normal;width:40px;">'+t('Match')+'</th>'
        +'</tr></thead><tbody>';
    _rows.forEach(function(_r){
        const _k=_r[0], _lbl=_r[1];
        const _e=_exp[_k], _c=_cur[_k], _m=_match[_k];
        let _badge='<span style="color:var(--text-muted);">—</span>';
        if(_m===true) _badge='<span style="color:var(--success,#3fb950);" title="'+t('Match')+'">✅</span>';
        else if(_m===false) _badge='<span style="color:var(--warning,#f0b72f);" title="'+t('Diverso')+'">⚠️</span>';
        _html+='<tr style="border-bottom:1px solid var(--border);">'
            +'<td style="padding:0.3rem;color:var(--text-primary);">'+monitorEscape(_lbl)+'</td>'
            +'<td style="padding:0.3rem;color:var(--text-secondary);"><code>'+monitorEscape(String(_e==null?'—':_e))+'</code></td>'
            +'<td style="padding:0.3rem;color:var(--text-primary);"><code>'+monitorEscape(String(_c==null?'—':_c))+'</code></td>'
            +'<td style="padding:0.3rem;text-align:center;">'+_badge+'</td>'
            +'</tr>';
    });
    _html+='</tbody></table>';
    return _html;
}


// ═══════════════════════════════════════════════════════════════════
// 🛡️ STEP F3 — MONITOR MODE (preview/apply + scheduler opt-in)
// ═══════════════════════════════════════════════════════════════════

let _MMODE_LAST_PREVIEW=null;

async function monitorModePreview(){
    const _box=document.getElementById('mmode-preview-box');
    const _applyBtn=document.getElementById('mmode-apply-btn');
    const _status=document.getElementById('mmode-status');
    const _profEl=document.getElementById('mmode-profile');
    const _profile=_profEl?_profEl.value:'auto';
    if(!_box) return;
    _box.style.display='block';
    _box.innerHTML='<div style="color:var(--text-muted);text-align:center;padding:0.6rem;">'+t('Lettura config attuale dal nodo...')+'</div>';
    if(_applyBtn) _applyBtn.style.display='none';
    if(_status) _status.textContent='';
    try{
        const _res=await fetch('/api/monitor/mode/preview', {
            method:'POST', credentials:'same-origin',
            headers:{'Content-Type':'application/json'},
            body:JSON.stringify({profile:_profile}),
        });
        const _data=await _res.json();
        if(!_data.success){
            _box.innerHTML='<div style="color:#e74c3c;padding:0.6rem;">'+monitorEscape(_data.message||t('Preview fallita'))+'</div>';
            return;
        }
        _MMODE_LAST_PREVIEW=_data;
        const _diff=_data.diff||[];
        let _html='<div style="margin-bottom:0.4rem;">'
            +'<strong>'+t('Profilo rilevato')+':</strong> <code>'+monitorEscape(_data.profile_used||'-')+'</code> '
            +'<span style="color:var(--text-muted);">('+t('richiesto')+': '+monitorEscape(_data.profile_requested||'-')+')</span>'
            +'</div>';
        if(_diff.length===0){
            _html+='<div style="color:var(--success,#3fb950);padding:0.4rem 0;">✅ '+t('Il nodo è già configurato per Monitor Mode.')+'</div>';
            if(_applyBtn) _applyBtn.style.display='none';
        }else{
            _html+='<div style="color:var(--warning,#f0b72f);margin-bottom:0.4rem;">'+_diff.length+' '+t('modifiche da applicare')+':</div>';
            _html+='<table style="width:100%;border-collapse:collapse;font-size:0.74rem;">';
            _html+='<thead><tr style="border-bottom:1px solid var(--border);">'
                +'<th style="text-align:left;padding:0.25rem;color:var(--text-muted);font-weight:normal;">'+t('Parametro')+'</th>'
                +'<th style="text-align:left;padding:0.25rem;color:var(--text-muted);font-weight:normal;">'+t('Attuale')+'</th>'
                +'<th style="text-align:left;padding:0.25rem;color:var(--text-muted);font-weight:normal;">'+t('Target')+'</th>'
                +'</tr></thead><tbody>';
            _diff.forEach(function(_d){
                _html+='<tr style="border-bottom:1px solid var(--border);">'
                    +'<td style="padding:0.25rem;"><code>'+monitorEscape(_d.path)+'</code></td>'
                    +'<td style="padding:0.25rem;color:var(--text-secondary);"><code>'+monitorEscape(String(_d.current))+'</code></td>'
                    +'<td style="padding:0.25rem;color:var(--success,#3fb950);"><code>'+monitorEscape(String(_d.target))+'</code></td>'
                    +'</tr>';
            });
            _html+='</tbody></table>';
            if(_applyBtn) _applyBtn.style.display='inline-block';
        }
        _box.innerHTML=_html;
    }catch(_e){
        _box.innerHTML='<div style="color:#e74c3c;padding:0.6rem;">'+t('Errore di rete')+'</div>';
    }
}

async function monitorModeApply(){
    const _box=document.getElementById('mmode-preview-box');
    const _applyBtn=document.getElementById('mmode-apply-btn');
    const _status=document.getElementById('mmode-status');
    const _profEl=document.getElementById('mmode-profile');
    const _profile=_profEl?_profEl.value:'auto';
    if(!confirm(t('Questa operazione modificherà i parametri del nodo collegato. Confermi?'))) return;
    if(_applyBtn) _applyBtn.disabled=true;
    if(_status) _status.textContent=t('Applicazione in corso...');
    try{
        const _res=await fetch('/api/monitor/mode/apply', {
            method:'POST', credentials:'same-origin',
            headers:{'Content-Type':'application/json'},
            body:JSON.stringify({profile:_profile, confirm:true}),
        });
        const _data=await _res.json();
        if(!_data.success){
            if(_status) _status.textContent='❌ '+(_data.message||t('Applicazione fallita'));
            return;
        }
        const _applied=(_data.applied||[]).filter(function(_a){return _a.status==='applied';}).length;
        const _errors=(_data.errors||[]).length;
        if(_status) _status.textContent='✅ '+t('Applicate')+': '+_applied+' · '+t('Errori')+': '+_errors;
        if(_applyBtn) _applyBtn.style.display='none';
        if(_box) _box.style.display='none';
        // Ricarica netinfo dopo apply
        setTimeout(monitorNetInfoRefresh, 800);
    }catch(_e){
        if(_status) _status.textContent='❌ '+t('Errore di rete');
    }finally{
        if(_applyBtn) _applyBtn.disabled=false;
    }
}

async function monitorModeScheduleLoad(){
    const _st=document.getElementById('mmode-sched-status');
    try{
        const _res=await fetch('/api/monitor/mode/schedule', {credentials:'same-origin'});
        const _data=await _res.json();
        if(!_data.success) return;
        const _rbEl=document.getElementById('mmode-reboot-enabled');
        const _rsEl=document.getElementById('mmode-reset-enabled');
        if(_rbEl) _rbEl.checked=!!(_data.reboot && _data.reboot.enabled);
        if(_rsEl) _rsEl.checked=!!(_data.reset_nodedb && _data.reset_nodedb.enabled);
        if(_st) _st.textContent=monitorModeFormatSched(_data);
    }catch(_e){}
}

function monitorModeFormatSched(_d){
    if(!_d) return '';
    const _parts=[];
    const _rb=_d.reboot||{};
    if(_rb.enabled && _rb.remaining_s!=null){
        _parts.push('🔁 '+t('Prossimo riavvio')+': '+monitorFormatDuration(_rb.remaining_s));
    }
    const _rs=_d.reset_nodedb||{};
    if(_rs.enabled && _rs.remaining_s!=null){
        _parts.push('🧹 '+t('Prossimo reset NodeDB')+': '+monitorFormatDuration(_rs.remaining_s));
    }
    if(_parts.length===0) return t('Nessuna pianificazione attiva.');
    return _parts.join(' · ');
}

function monitorFormatDuration(_s){
    if(_s==null || _s<0) return '-';
    const _h=Math.floor(_s/3600), _m=Math.floor((_s%3600)/60);
    if(_h>=24){ const _d=Math.floor(_h/24); return _d+'g '+(_h%24)+'h'; }
    if(_h>0) return _h+'h '+_m+'m';
    return _m+'m';
}

async function monitorModeScheduleSave(){
    const _rbEl=document.getElementById('mmode-reboot-enabled');
    const _rsEl=document.getElementById('mmode-reset-enabled');
    const _st=document.getElementById('mmode-sched-status');
    const _body={
        reboot_enabled: !!(_rbEl && _rbEl.checked),
        reboot_hours: 6,
        reset_enabled: !!(_rsEl && _rsEl.checked),
        reset_days: 7,
    };
    if(_st) _st.textContent=t('Salvataggio pianificazione...');
    try{
        const _res=await fetch('/api/monitor/mode/schedule', {
            method:'POST', credentials:'same-origin',
            headers:{'Content-Type':'application/json'},
            body:JSON.stringify(_body),
        });
        const _data=await _res.json();
        if(!_data.success){
            if(_st) _st.textContent='❌ '+(_data.message||t('Errore'));
            return;
        }
        if(_st) _st.textContent='✅ '+monitorModeFormatSched(_data);
    }catch(_e){
        if(_st) _st.textContent='❌ '+t('Errore di rete');
    }
}

async function monitorModeRebootNow(){
    if(!confirm(t('Riavviare ORA il nodo collegato?'))) return;
    const _st=document.getElementById('mmode-sched-status');
    if(_st) _st.textContent=t('Invio comando reboot...');
    try{
        const _res=await fetch('/api/monitor/mode/reboot-now', {
            method:'POST', credentials:'same-origin',
            headers:{'Content-Type':'application/json'},
            body:JSON.stringify({confirm:true}),
        });
        const _data=await _res.json();
        if(_st) _st.textContent=_data.success?('✅ '+t('Reboot inviato')):('❌ '+(_data.message||t('Errore')));
    }catch(_e){
        if(_st) _st.textContent='❌ '+t('Errore di rete');
    }
}

async function monitorModeResetNow(){
    if(!confirm(t('Resettare ORA il database dei nodi? I nodi verranno riscoperti dalla rete.'))) return;
    const _st=document.getElementById('mmode-sched-status');
    if(_st) _st.textContent=t('Invio reset NodeDB...');
    try{
        const _res=await fetch('/api/monitor/mode/reset-nodedb-now', {
            method:'POST', credentials:'same-origin',
            headers:{'Content-Type':'application/json'},
            body:JSON.stringify({confirm:true}),
        });
        const _data=await _res.json();
        if(_st) _st.textContent=_data.success?('✅ '+t('Reset NodeDB inviato')):('❌ '+(_data.message||t('Errore')));
    }catch(_e){
        if(_st) _st.textContent='❌ '+t('Errore di rete');
    }
}


// ═══════════════════════════════════════════════════════════════════
// 🗺️ STEP F4 — NODI CON GPS (lista + Google Maps)
// ═══════════════════════════════════════════════════════════════════

let _GPS_TIMER=null;
const _GPS_INTERVAL_MS=30000;

async function monitorGpsRefresh(){
    const _box=document.getElementById('gps-box');
    const _status=document.getElementById('gps-status');
    const _winEl=document.getElementById('gps-window');
    const _hours=_winEl?parseInt(_winEl.value,10):24;
    if(!_box) return;
    try{
        const _res=await fetch('/api/monitor/nodes/gps?hours='+encodeURIComponent(_hours), {credentials:'same-origin'});
        const _data=await _res.json();
        if(!_data.success){
            _box.innerHTML='<div style="color:#e74c3c;padding:0.6rem;">'+monitorEscape(_data.message||t('Errore lettura GPS'))+'</div>';
            return;
        }
        const _nodes=_data.nodes||[];
        if(_status) _status.textContent=t('Nodi trovati')+': '+_nodes.length+' · '+t('finestra')+': '+_hours+'h';
        if(_nodes.length===0){
            _box.innerHTML='<div style="color:var(--text-muted);text-align:center;padding:0.8rem;">'+t('Nessun nodo con GPS nella finestra selezionata.')+'</div>';
            return;
        }
        let _html='<table style="width:100%;border-collapse:collapse;font-size:0.76rem;">';
        _html+='<thead><tr style="border-bottom:1px solid var(--border);">'
            +'<th style="text-align:left;padding:0.3rem;color:var(--text-muted);font-weight:normal;">ID</th>'
            +'<th style="text-align:left;padding:0.3rem;color:var(--text-muted);font-weight:normal;">'+t('Nome')+'</th>'
            +'<th style="text-align:right;padding:0.3rem;color:var(--text-muted);font-weight:normal;">'+t('Latitudine')+'</th>'
            +'<th style="text-align:right;padding:0.3rem;color:var(--text-muted);font-weight:normal;">'+t('Longitudine')+'</th>'
            +'<th style="text-align:right;padding:0.3rem;color:var(--text-muted);font-weight:normal;">SNR</th>'
            +'<th style="text-align:left;padding:0.3rem;color:var(--text-muted);font-weight:normal;">'+t('Ultimo')+'</th>'
            +'<th style="text-align:center;padding:0.3rem;color:var(--text-muted);font-weight:normal;width:40px;">🌍</th>'
            +'</tr></thead><tbody>';
        _nodes.forEach(function(_n){
            const _name=_n.long_name||_n.short_name||'-';
            const _lat=_n.latitude, _lon=_n.longitude;
            const _snr=_n.snr_avg!=null?_n.snr_avg+' dB':'-';
            const _last=_n.pos_ts?new Date(_n.pos_ts).toLocaleString():'-';
            const _mapsUrl='https://www.google.com/maps?q='+_lat+','+_lon;
            _html+='<tr style="border-bottom:1px solid var(--border);">'
                +'<td style="padding:0.3rem;font-family:var(--font-mono,monospace);">'+monitorEscape(_n.node_hex||'-')+'</td>'
                +'<td style="padding:0.3rem;">'+monitorEscape(_name)+'</td>'
                +'<td style="padding:0.3rem;text-align:right;font-family:var(--font-mono,monospace);">'+(_lat!=null?_lat.toFixed(6):'-')+'</td>'
                +'<td style="padding:0.3rem;text-align:right;font-family:var(--font-mono,monospace);">'+(_lon!=null?_lon.toFixed(6):'-')+'</td>'
                +'<td style="padding:0.3rem;text-align:right;color:var(--text-secondary);">'+_snr+'</td>'
                +'<td style="padding:0.3rem;color:var(--text-secondary);font-size:0.72rem;">'+monitorEscape(_last)+'</td>'
                +'<td style="padding:0.3rem;text-align:center;">'
                +'<a href="'+_mapsUrl+'" target="_blank" rel="noopener" title="'+t('Apri in Google Maps')+'" style="text-decoration:none;font-size:1rem;">🌍</a>'
                +'</td>'
                +'</tr>';
        });
        _html+='</tbody></table>';
        _box.innerHTML=_html;
    }catch(_e){
        _box.innerHTML='<div style="color:#e74c3c;padding:0.6rem;">'+t('Errore di rete')+'</div>';
    }
}

function monitorGpsStartAuto(){
    if(_GPS_TIMER) return;
    _GPS_TIMER=setInterval(function(){
        const _chk=document.getElementById('gps-autorefresh');
        if(_chk && _chk.checked){ monitorGpsRefresh(); }
    }, _GPS_INTERVAL_MS);
}

function monitorGpsStopAuto(){
    if(_GPS_TIMER){ clearInterval(_GPS_TIMER); _GPS_TIMER=null; }
}


// ═══════════════════════════════════════════════════════════════════
// 👤 NODE PROFILE — scheda tecnica + comportamento nodo
// ═══════════════════════════════════════════════════════════════════

async function showNodeProfile(_nodeId){
    if(!_nodeId) return;
    const _modal=document.getElementById('node-profile-modal');
    const _body=document.getElementById('node-profile-body');
    if(!_modal||!_body) return;
    _body.innerHTML='<div style="text-align:center;padding:2rem;color:var(--text-muted);">'+t('Caricamento...')+'</div>';
    _modal.style.display='flex';
    try{
        const _res=await fetch('/api/monitor/node/'+encodeURIComponent(_nodeId)+'?window=7d', {credentials:'same-origin'});
        const _data=await _res.json();
        if(!_data.success){
            _body.innerHTML='<div style="color:#e74c3c;padding:1rem;">'+monitorEscape(_data.message||t('Nodo non trovato'))+'</div>';
            return;
        }
        _body.innerHTML=monitorRenderNodeProfile(_data.profile);
    }catch(_e){
        _body.innerHTML='<div style="color:#e74c3c;padding:1rem;">'+t('Errore di rete')+'</div>';
    }
}

function monitorRenderNodeProfile(prof){
    if(!prof) return '';
    const _b=prof.base||{};
    const _role=prof.role_inferred||'client';
    const _roleCls='node-card-role '+_role;
    const _rName=(_role==='spam'?'⚠️ SPAM':
                  _role==='stealth'?'🕵️ '+t('Stealth'):
                  _role==='gateway_mqtt'?'☁️ MQTT Gateway':
                  _role==='router'?'🔀 Router':
                  _role==='tracker'?'📍 Tracker GPS':
                  _role==='telemetry'?'📊 Telemetry':
                  _role==='chatty'?'💬 Chatty':
                  _role==='neighbor_map'?'👥 Neighbor Map':
                  _role==='silent'?'🔇 Silent':
                  '📡 Client');
    // by_portnum
    const _byPort=(prof.by_portnum||[]).map(p=>{
        return '<tr><td>'+monitorEscape(p.port_name||'?')+'</td><td style="text-align:right;">'+p.n+'</td></tr>';
    }).join('');
    // by_channel
    const _byCh=(prof.by_channel||[]).map(c=>{
        return '<tr><td>'+monitorEscape(c.channel_name||('Ch'+c.channel_idx))+'</td><td style="text-align:right;">'+c.n+'</td></tr>';
    }).join('');
    // recent packets (ultimi 20)
    const _recent=(prof.recent||[]).map(r=>{
        const _t=r.ts?(new Date(r.ts)).toLocaleString('it-IT'):'';
        const _rssi=(r.rssi!=null)?(r.rssi+'dBm'):'—';
        const _snr=(r.snr!=null)?(Number(r.snr).toFixed(1)+'dB'):'—';
        const _txt=r.payload_text?('<span style="word-break:break-word;white-space:pre-wrap;">'+monitorEscape(r.payload_text)+'</span>'):'';
        return '<tr>'+
               '<td style="white-space:nowrap;">'+monitorEscape(_t)+'</td>'+
               '<td>'+monitorEscape(r.port_name||'?')+'</td>'+
               '<td>'+_rssi+'</td><td>'+_snr+'</td>'+
               '<td>'+_txt+'</td>'+
               '</tr>';
    }).join('');
    const _hops=(_b.hops_used_avg!=null)?Number(_b.hops_used_avg).toFixed(1):'—';
    return '<div class="node-card">'+
        '<div class="node-card-head">'+
        '<div><h3 style="margin:0;">'+monitorEscape(_b.long_name||_b.node_id||'?')+'</h3>'+
        '<div style="color:var(--text-muted);font-size:0.9em;">'+monitorEscape(_b.short_name||'')+' · '+monitorEscape(_b.node_id||'')+' · HW: '+monitorEscape(_b.hw_model||'?')+'</div></div>'+
        '<div class="'+_roleCls+'">'+_rName+'</div>'+
        '</div>'+
        '<div class="node-card-grid">'+
            '<div class="node-card-field"><label>'+t('Pacchetti 7gg')+'</label><value>'+(prof.pkt_total||0)+'</value></div>'+
            '<div class="node-card-field"><label>'+t('Ultime 24h')+'</label><value>'+(prof.pkt_24h||0)+'</value></div>'+
            '<div class="node-card-field"><label>'+t('Ultima 1h')+'</label><value>'+(prof.pkt_1h||0)+'</value></div>'+
            '<div class="node-card-field"><label>'+t('Rate pkt/min')+'</label><value>'+(prof.rate_pkt_per_min||0).toFixed(2)+'</value></div>'+
            '<div class="node-card-field"><label>RSSI '+t('medio')+'</label><value>'+(_b.rssi_avg!=null?_b.rssi_avg+'dBm':'—')+'</value></div>'+
            '<div class="node-card-field"><label>SNR '+t('medio')+'</label><value>'+(_b.snr_avg!=null?Number(_b.snr_avg).toFixed(1)+'dB':'—')+'</value></div>'+
            '<div class="node-card-field"><label>Best RSSI</label><value>'+(_b.rssi_best!=null?_b.rssi_best+'dBm':'—')+'</value></div>'+
            '<div class="node-card-field"><label>Best SNR</label><value>'+(_b.snr_best!=null?Number(_b.snr_best).toFixed(1)+'dB':'—')+'</value></div>'+
            '<div class="node-card-field"><label>'+t('Hop medi')+'</label><value>'+_hops+'</value></div>'+
            '<div class="node-card-field"><label>Firmware</label><value>'+monitorEscape(_b.fw_type||'unknown')+'</value></div>'+
            '<div class="node-card-field"><label>'+t('Network')+'</label><value>'+monitorEscape(_b.network||'unknown')+'</value></div>'+
            '<div class="node-card-field"><label>'+t('Vista')+'</label><value>'+monitorEscape(_b.last_source||'—')+'</value></div>'+
        '</div>'+
        '<h4>📊 '+t('Distribuzione PortNum')+'</h4>'+
        '<table class="psk-table"><thead><tr><th>'+t('PortNum')+'</th><th style="text-align:right;">'+t('Count')+'</th></tr></thead><tbody>'+(_byPort||'<tr><td colspan="2" style="text-align:center;color:var(--text-muted);">—</td></tr>')+'</tbody></table>'+
        '<h4>📡 '+t('Per Canale')+'</h4>'+
        '<table class="psk-table"><thead><tr><th>'+t('Canale')+'</th><th style="text-align:right;">'+t('Count')+'</th></tr></thead><tbody>'+(_byCh||'<tr><td colspan="2" style="text-align:center;color:var(--text-muted);">—</td></tr>')+'</tbody></table>'+
        '<h4>🕐 '+t('Ultimi 20 pacchetti')+'</h4>'+
        '<table class="psk-table"><thead><tr><th>'+t('Data')+'</th><th>'+t('Port')+'</th><th>RSSI</th><th>SNR</th><th>'+t('Testo')+'</th></tr></thead><tbody>'+(_recent||'<tr><td colspan="5" style="text-align:center;color:var(--text-muted);">—</td></tr>')+'</tbody></table>'+
        '</div>';
}

function hideNodeProfile(){
    const _modal=document.getElementById('node-profile-modal');
    if(_modal) _modal.style.display='none';
}

// ═══════════════════════════════════════════════════════════════════
// STEP C — Packet Detail Modal (JSON completo)
// ═══════════════════════════════════════════════════════════════════
function monitorShowPacketDetail(_btn){
    if(!_btn) return;
    const _raw=_btn.getAttribute('data-pkt')||'{}';
    let _p;
    try{ _p=JSON.parse(_raw); } catch(_e){ _p={error:'parse_error',raw:_raw}; }
    const _modal=document.getElementById('pkt-detail-modal');
    const _body=document.getElementById('pkt-detail-body');
    if(!_modal||!_body) return;
    // Formatta il JSON leggibile + estrai campi chiave
    const _pretty=JSON.stringify(_p, null, 2);
    let _html='';
    _html+='<div style="display:grid;grid-template-columns:1fr 1fr;gap:0.5rem;margin-bottom:0.8rem;font-size:0.78rem;">';
    _html+='<div><strong>'+t('ID pacchetto')+':</strong> <code>'+monitorEscape(_p.packet_id||'—')+'</code></div>';
    _html+='<div><strong>'+t('Timestamp')+':</strong> '+monitorEscape(_p.ts_hms||'—')+'</div>';
    _html+='<div><strong>'+t('Mittente')+':</strong> '+monitorEscape(_p.long_name||_p.sender_id||'—')+'</div>';
    _html+='<div><strong>'+t('Destinatario')+':</strong> '+monitorEscape(_p.to_id||'—')+(_p.is_broadcast?' 📢':'')+'</div>';
    _html+='<div><strong>Portnum:</strong> '+monitorEscape(_p.portnum||'—')+' ('+(_p.portnum_num!=null?_p.portnum_num:'?')+')</div>';
    _html+='<div><strong>Network:</strong> '+monitorEscape(_p.network||'—')+'</div>';
    _html+='<div><strong>Channel idx:</strong> '+(_p.channel_idx!=null?_p.channel_idx:'—')+'</div>';
    // STEP 3 — nome canale risolto nel detail modal
    const _pChLbl=(typeof window.monitorChannelLabel==='function')?window.monitorChannelLabel(_p):null;
    const _pChSfx=_pChLbl?(' <span style="color:#10b981;">→ '+monitorEscape(_pChLbl)+'</span>'):'';
    _html+='<div><strong>Channel hash:</strong> '+(_p.channel_hash!=null?(_p.channel_hash+' (0x'+Number(_p.channel_hash).toString(16)+')'+_pChSfx):'—')+'</div>';
    _html+='<div><strong>Channel name:</strong> '+monitorEscape(_p.channel_name||'—')+'</div>';
    _html+='<div><strong>RSSI/SNR:</strong> '+(_p.rssi||0)+' dBm / '+Number(_p.snr||0).toFixed(1)+' dB</div>';
    _html+='<div><strong>Hop:</strong> '+(_p.hop_start!=null?_p.hop_start:'?')+'→'+(_p.hop_limit!=null?_p.hop_limit:'?')+' ('+(_p.hops_used!=null?_p.hops_used:'?')+' '+t('usati')+')</div>';
    _html+='<div><strong>Priority:</strong> '+monitorEscape(_p.priority||'—')+(_p.priority_num!=null?' (#'+_p.priority_num+')':'')+'</div>';
    _html+='<div><strong>PKI:</strong> '+(_p.pki_encrypted?'🔑 '+t('Sì'):t('No'))+'</div>';
    _html+='<div><strong>viaMQTT:</strong> '+(_p.via_mqtt===true?t('Sì'):(_p.via_mqtt===false?t('No'):'—'))+'</div>';
    _html+='<div><strong>wantAck:</strong> '+(_p.want_ack?t('Sì'):t('No'))+'</div>';
    _html+='<div><strong>PSK match:</strong> '+(_p.psk_match_label?('🔓 '+monitorEscape(_p.psk_match_label)+' ('+monitorEscape(_p.psk_match_kind||'?')+')'):'—')+'</div>';
    if(_p.public_key_hex){
        _html+='<div style="grid-column:span 2;"><strong>'+t('Chiave pubblica')+':</strong> <code style="word-break:break-all;font-size:0.72rem;">'+monitorEscape(_p.public_key_hex)+'</code></div>';
    }
    if(_p.encrypted_hex){
        _html+='<div style="grid-column:span 2;"><strong>'+t('Payload cifrato')+' ('+(_p.encrypted_len||0)+'B):</strong> <code style="word-break:break-all;font-size:0.72rem;color:var(--error);">'+monitorEscape(_p.encrypted_hex)+'</code></div>';
    }
    if(_p.raw_payload_hex){
        _html+='<div style="grid-column:span 2;"><strong>'+t('Payload decifrato')+' ('+(_p.raw_payload_len||0)+'B):</strong> <code style="word-break:break-all;font-size:0.72rem;">'+monitorEscape(_p.raw_payload_hex)+'</code></div>';
    }
    _html+='</div>';
    _html+='<details style="margin-top:0.8rem;"><summary style="cursor:pointer;color:var(--accent);">'+t('Mostra JSON completo')+'</summary>';
    _html+='<pre style="background:var(--bg-input);border:1px solid var(--border);padding:0.6rem;border-radius:var(--radius);overflow:auto;max-height:400px;font-size:0.72rem;color:var(--text-primary);">'+monitorEscape(_pretty)+'</pre>';
    _html+='</details>';
    _body.innerHTML=_html;
    _modal.style.display='flex';
}

function hidePacketDetail(){
    const _modal=document.getElementById('pkt-detail-modal');
    if(_modal) _modal.style.display='none';
}

// Click delegato su node-link nei terminali
document.addEventListener('click', function(ev){
    const _t=ev.target.closest('.node-link');
    if(_t){
        ev.preventDefault();
        const _id=_t.getAttribute('data-node-id');
        if(_id) showNodeProfile(_id);
    }
});

// ═══════════════════════════════════════════════════════════════════
// H3 — HUB MONITOR SCANNER: tabella nodi + ricerca FTS5 + detail modal
// ═══════════════════════════════════════════════════════════════════
const _hubState = {
    nodes: [],
    sortKey: 'last_seen',
    sortDir: 'desc',
    loading: false,
    curNodeHex: null,
    // H5 — render cap per grandi dataset (reti con molti nodi)
    renderLimit: 300,
    renderStep: 300
};

function _hubEsc(s){
    if(s==null) return '';
    return String(s).replace(/[&<>"']/g, c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}

function _hubFmtTs(ts){
    if(!ts) return '—';
    try{
        const _d = (typeof ts === 'number') ? new Date(ts*1000) : new Date(ts);
        const _now = Date.now();
        const _diff = (_now - _d.getTime())/1000;
        if(_diff < 60) return Math.floor(_diff)+'s';
        if(_diff < 3600) return Math.floor(_diff/60)+'m';
        if(_diff < 86400) return Math.floor(_diff/3600)+'h';
        return Math.floor(_diff/86400)+'g';
    }catch(_e){ return '—'; }
}

function _hubFmtNum(v, digits){
    if(v==null || v==='') return '—';
    const _n = Number(v);
    if(!isFinite(_n)) return '—';
    return (digits!=null) ? _n.toFixed(digits) : String(_n);
}

function _hubNodeFlags(n){
    const _f = [];
    if(n.is_licensed) _f.push('<span title="HAM" style="color:#f59e0b;">HAM</span>');
    if(n.is_stealth) _f.push('<span title="Stealth" style="color:#8b5cf6;">👤</span>');
    if(n.is_unmessagable) _f.push('<span title="No messaging" style="color:#ef4444;">🔕</span>');
    if(n.via_mqtt_last) _f.push('<span title="via MQTT" style="color:#06b6d4;">☁️</span>');
    if(n.has_public_key || n.public_key_hex) _f.push('<span title="Public key" style="color:#10b981;">🔑</span>');
    return _f.join(' ') || '—';
}

async function hubLoadNodes(){
    if(_hubState.loading) return;
    _hubState.loading = true;
    const _tbody = document.getElementById('hub-nodes-tbody');
    const _cnt = document.getElementById('hub-node-count');
    if(!_tbody) { _hubState.loading=false; return; }
    const _net = (document.getElementById('hub-flt-net')||{}).value || '';
    const _fw = (document.getElementById('hub-flt-fw')||{}).value || '';
    const _win = (document.getElementById('hub-flt-win')||{}).value || '7d';
    const _qs = new URLSearchParams();
    if(_net) _qs.set('network', _net);
    if(_fw) _qs.set('fw_type', _fw);
    if(_win) _qs.set('window', _win);
    _qs.set('limit', '500');
    _tbody.innerHTML = '<tr><td colspan="16" style="text-align:center;padding:1rem;color:var(--text-muted);">'+t('Caricamento')+'…</td></tr>';
    if(_cnt) _cnt.textContent = '';
    try{
        const _r = await fetch('/api/monitor/nodes?'+_qs.toString());
        const _j = await _r.json();
        if(!_r.ok || _j.success === false){
            _tbody.innerHTML = '<tr><td colspan="16" style="text-align:center;padding:1rem;color:var(--error);">'+_hubEsc(_j.message||_j.error||'error')+'</td></tr>';
            return;
        }
        _hubState.nodes = _j.nodes || [];
        _hubRenderTable();
        if(_cnt) _cnt.textContent = (_hubState.nodes.length+' nodi');
    }catch(_e){
        _tbody.innerHTML = '<tr><td colspan="16" style="text-align:center;padding:1rem;color:var(--error);">'+_hubEsc(String(_e))+'</td></tr>';
    }finally{
        _hubState.loading = false;
    }
}

function _hubSortNodes(){
    const _k = _hubState.sortKey;
    const _d = (_hubState.sortDir === 'asc') ? 1 : -1;
    _hubState.nodes.sort((a,b)=>{
        const _av = a[_k];
        const _bv = b[_k];
        if(_av==null && _bv==null) return 0;
        if(_av==null) return 1;
        if(_bv==null) return -1;
        if(typeof _av === 'number' && typeof _bv === 'number') return (_av-_bv)*_d;
        const _sa = String(_av).toLowerCase();
        const _sb = String(_bv).toLowerCase();
        if(_sa<_sb) return -1*_d;
        if(_sa>_sb) return 1*_d;
        return 0;
    });
}

function hubSort(colKey){
    if(_hubState.sortKey === colKey){
        _hubState.sortDir = (_hubState.sortDir === 'asc') ? 'desc' : 'asc';
    } else {
        _hubState.sortKey = colKey;
        _hubState.sortDir = 'desc';
    }
    _hubRenderTable();
}

// H5 — render cap: incrementa il limite e re-renderizza
function _hubShowMore(){
    _hubState.renderLimit += _hubState.renderStep;
    _hubRenderTable();
}
window._hubShowMore = _hubShowMore;

function _hubRenderTable(){
    const _tbody = document.getElementById('hub-nodes-tbody');
    if(!_tbody) return;
    _hubSortNodes();
    // H5 — slice alla renderLimit per ridurre il costo innerHTML su grandi dataset
    const _total = _hubState.nodes.length;
    const _limit = _hubState.renderLimit || _total;
    const _slice = (_total > _limit) ? _hubState.nodes.slice(0, _limit) : _hubState.nodes;
    const _rows = _slice.map(n=>{
        const _hex = n.node_hex || n.node_id || '?';
        const _nm = n.long_name || n.short_name || '—';
        const _hw = n.hw_model || '—';
        const _fw = n.firmware_version || n.fw_type || '—';
        const _rg = n.region || '—';
        const _pr = n.modem_preset || '—';
        const _ro = n.role || '—';
        const _net = n.network || '—';
        const _rssi = (n.rssi_avg!=null) ? _hubFmtNum(n.rssi_avg, 0)+' dBm' : '—';
        const _snr = (n.snr_avg!=null) ? _hubFmtNum(n.snr_avg, 1)+' dB' : '—';
        const _hops = (n.hops_away!=null) ? n.hops_away : '—';
        const _p1 = n.pkt_1h || 0;
        const _p24 = n.pkt_24h || 0;
        const _tot = n.total_packets || 0;
        const _flags = _hubNodeFlags(n);
        const _last = _hubFmtTs(n.last_seen);
        return '<tr style="cursor:pointer;border-bottom:1px solid #1a1a1a;" onclick="hubOpenNodeDetail('+JSON.stringify(_hex)+')" onmouseover="this.style.background=\'#141414\'" onmouseout="this.style.background=\'\'">'+
            '<td style="padding:0.35rem 0.5rem;white-space:nowrap;color:#60a5fa;font-family:monospace;">'+_hubEsc(_hex)+'</td>'+
            '<td style="padding:0.35rem 0.5rem;white-space:nowrap;max-width:220px;overflow:hidden;text-overflow:ellipsis;">'+_hubEsc(_nm)+'</td>'+
            '<td style="padding:0.35rem 0.5rem;white-space:nowrap;color:var(--text-muted);">'+_hubEsc(_hw)+'</td>'+
            '<td style="padding:0.35rem 0.5rem;white-space:nowrap;color:var(--text-muted);max-width:110px;overflow:hidden;text-overflow:ellipsis;">'+_hubEsc(_fw)+'</td>'+
            '<td style="padding:0.35rem 0.5rem;white-space:nowrap;">'+_hubEsc(_rg)+'</td>'+
            '<td style="padding:0.35rem 0.5rem;white-space:nowrap;">'+_hubEsc(_pr)+'</td>'+
            '<td style="padding:0.35rem 0.5rem;white-space:nowrap;">'+_hubEsc(_ro)+'</td>'+
            '<td style="padding:0.35rem 0.5rem;white-space:nowrap;">'+_hubEsc(_net)+'</td>'+
            '<td style="padding:0.35rem 0.5rem;text-align:right;white-space:nowrap;">'+_rssi+'</td>'+
            '<td style="padding:0.35rem 0.5rem;text-align:right;white-space:nowrap;">'+_snr+'</td>'+
            '<td style="padding:0.35rem 0.5rem;text-align:right;white-space:nowrap;">'+_hops+'</td>'+
            '<td style="padding:0.35rem 0.5rem;text-align:right;white-space:nowrap;color:#10b981;">'+_p1+'</td>'+
            '<td style="padding:0.35rem 0.5rem;text-align:right;white-space:nowrap;color:#06b6d4;">'+_p24+'</td>'+
            '<td style="padding:0.35rem 0.5rem;text-align:right;white-space:nowrap;color:var(--text-muted);">'+_tot+'</td>'+
            '<td style="padding:0.35rem 0.5rem;text-align:center;white-space:nowrap;">'+_flags+'</td>'+
            '<td style="padding:0.35rem 0.5rem;white-space:nowrap;color:var(--text-muted);">'+_last+'</td>'+
            '</tr>';
    }).join('');
    // H5 — footer "Mostra altri N di M" se il dataset supera il cap
    let _footer = '';
    if (_total > _limit) {
        const _more = _total - _limit;
        _footer = '<tr><td colspan="16" style="text-align:center;padding:0.6rem;border-top:1px dashed #222;">'+
            '<button class="btn btn-sm btn-secondary" onclick="_hubShowMore()">'+
            t('Mostra altri')+' '+Math.min(_hubState.renderStep, _more)+' / '+_more+' '+t('nodi')+
            '</button></td></tr>';
    }
    _tbody.innerHTML = (_rows + _footer) || '<tr><td colspan="16" style="text-align:center;padding:1rem;color:var(--text-muted);">'+t('Nessun nodo trovato')+'</td></tr>';
}

async function hubSearchRun(){
    const _inp = document.getElementById('hub-search-input');
    const _res = document.getElementById('hub-search-results');
    if(!_inp || !_res) return;
    const _q = (_inp.value||'').trim();
    if(!_q){ _res.style.display='none'; _res.innerHTML=''; return; }
    _res.style.display = 'block';
    _res.innerHTML = '<div style="color:var(--text-muted);padding:0.4rem;">'+t('Caricamento')+'…</div>';
    const _win = (document.getElementById('hub-flt-win')||{}).value || '7d';
    try{
        const _r = await fetch('/api/monitor/search?q='+encodeURIComponent(_q)+'&limit=80&window='+encodeURIComponent(_win));
        const _j = await _r.json();
        if(!_r.ok || _j.success === false){ _res.innerHTML='<div style="color:var(--error);padding:0.4rem;">'+_hubEsc(_j.message||_j.error||'error')+'</div>'; return; }
        _hubRenderSearchResults(_j.results||[]);
    }catch(_e){
        _res.innerHTML = '<div style="color:var(--error);padding:0.4rem;">'+_hubEsc(String(_e))+'</div>';
    }
}

function _hubRenderSearchResults(rows){
    const _res = document.getElementById('hub-search-results');
    if(!_res) return;
    if(!rows.length){ _res.innerHTML='<div style="color:var(--text-muted);padding:0.4rem;">—</div>'; return; }
    const _h = rows.map(r=>{
        const _ts = r.ts ? _hubFmtTs(r.ts) : '—';
        const _snd = r.sender_hex || r.sender_id || '?';
        const _port = r.port_name || r.portnum || '?';
        const _txt = (r.payload_text||'');
        return '<div style="padding:0.3rem 0.4rem;border-bottom:1px solid #1a1a1a;cursor:pointer;word-break:break-word;white-space:pre-wrap;" onclick="hubOpenNodeDetail('+JSON.stringify(_snd)+')" onmouseover="this.style.background=\'#141414\'" onmouseout="this.style.background=\'\'">'+
            '<span style="color:var(--text-muted);">'+_ts+'</span> '+
            '<span style="color:#60a5fa;font-family:monospace;">'+_hubEsc(_snd)+'</span> '+
            '<span style="color:var(--accent);">['+_hubEsc(_port)+']</span> '+
            '<span>'+_hubEsc(_txt)+'</span>'+
            '</div>';
    }).join('');
    _res.innerHTML = _h;
}

function hubSearchClear(){
    const _inp = document.getElementById('hub-search-input');
    const _res = document.getElementById('hub-search-results');
    if(_inp) _inp.value = '';
    if(_res){ _res.style.display='none'; _res.innerHTML=''; }
}

// ─── Modal 8 pannelli ─────────────────────────────────────────────
async function hubOpenNodeDetail(nodeHex){
    if(!nodeHex) return;
    _hubState.curNodeHex = nodeHex;
    const _mod = document.getElementById('nodeDetailModal');
    const _hex = document.getElementById('nodeDetailHex');
    const _body = document.getElementById('nodeDetailBody');
    if(!_mod || !_body) return;
    _mod.style.display = 'flex';
    if(_hex) _hex.textContent = nodeHex;
    _body.innerHTML = '<div style="text-align:center;padding:2rem;color:var(--text-muted);">'+t('Caricamento')+'…</div>';
    try{
        const _id = encodeURIComponent(nodeHex);
        const [prof, nbrs, tr, mr, wp, tel, meta, sf] = await Promise.all([
            fetch('/api/monitor/node/'+_id+'?window=7d').then(r=>r.json()).catch(_e=>({success:false,error:String(_e)})),
            fetch('/api/monitor/node/'+_id+'/neighbors').then(r=>r.json()).catch(_e=>({ok:false})),
            fetch('/api/monitor/node/'+_id+'/traceroutes').then(r=>r.json()).catch(_e=>({ok:false})),
            fetch('/api/monitor/node/'+_id+'/map_reports').then(r=>r.json()).catch(_e=>({ok:false})),
            fetch('/api/monitor/node/'+_id+'/waypoints').then(r=>r.json()).catch(_e=>({ok:false})),
            fetch('/api/monitor/node/'+_id+'/telemetry').then(r=>r.json()).catch(_e=>({ok:false})),
            fetch('/api/monitor/node/'+_id+'/metadata').then(r=>r.json()).catch(_e=>({ok:false})),
            fetch('/api/monitor/node/'+_id+'/storeforward').then(r=>r.json()).catch(_e=>({ok:false}))
        ]);
        _body.innerHTML = _hubBuildDetailPanels(prof, nbrs, tr, mr, wp, tel, meta, sf);
    }catch(_e){
        _body.innerHTML = '<div style="padding:1rem;color:var(--error);">'+_hubEsc(String(_e))+'</div>';
    }
}

function hubCloseNodeDetail(){
    const _mod = document.getElementById('nodeDetailModal');
    if(_mod) _mod.style.display = 'none';
    _hubState.curNodeHex = null;
}

// Scroll rapido ai pannelli del detail modal (usato dai bottoni meta-row)
function hubScrollToPanel(which){
    const _body = document.getElementById('nodeDetailBody');
    if(!_body) return;
    const _targets = {
        id:  'panel-identity',
        rf:  'panel-radio',
        gps: 'panel-gps',
        nb:  'panel-neighbors',
        tel: 'panel-telemetry',
        tr:  'panel-traceroutes',
        wp:  'panel-mapwp',
        raw: 'panel-raw'
    };
    const _id = _targets[which];
    if(!_id) return;
    const _el = document.getElementById(_id);
    if(_el) _el.scrollIntoView({behavior:'smooth', block:'start'});
}

function _hubPanelHdr(title, panelId){
    const _id = panelId ? ' id="'+panelId+'"' : '';
    return '<h4'+_id+' style="font-family:var(--font-display);color:var(--accent);margin:0.8rem 0 0.4rem 0;border-bottom:1px solid var(--border);padding-bottom:0.3rem;scroll-margin-top:3rem;">'+title+'</h4>';
}

function _hubQuickBar(){
    return '<div class="hub-quickbar" style="display:flex;gap:0.3rem;flex-wrap:wrap;margin:0.4rem 0 0.8rem 0;padding:0.4rem;background:#0a0a0a;border:1px solid var(--border);border-radius:var(--radius);position:sticky;top:3rem;z-index:1;">'+
        '<button class="btn btn-sm" onclick="hubScrollToPanel(\'id\')" style="font-size:0.72rem;" title="Identità">👤</button>'+
        '<button class="btn btn-sm" onclick="hubScrollToPanel(\'rf\')" style="font-size:0.72rem;" title="Radio/RF">📡</button>'+
        '<button class="btn btn-sm" onclick="hubScrollToPanel(\'gps\')" style="font-size:0.72rem;" title="GPS/Posizione">📍</button>'+
        '<button class="btn btn-sm" onclick="hubScrollToPanel(\'nb\')" style="font-size:0.72rem;" title="Vicini">🕸️</button>'+
        '<button class="btn btn-sm" onclick="hubScrollToPanel(\'tel\')" style="font-size:0.72rem;" title="Telemetria">📊</button>'+
        '<button class="btn btn-sm" onclick="hubScrollToPanel(\'tr\')" style="font-size:0.72rem;" title="Traceroutes">🛰️</button>'+
        '<button class="btn btn-sm" onclick="hubScrollToPanel(\'wp\')" style="font-size:0.72rem;" title="Map reports &amp; Waypoints">🗺️</button>'+
        '<button class="btn btn-sm" onclick="hubScrollToPanel(\'raw\')" style="font-size:0.72rem;" title="Raw JSON">🧬</button>'+
        '</div>';
}

function _hubKV(label, value){
    const _v = (value==null||value==='') ? '—' : value;
    return '<div style="display:flex;justify-content:space-between;padding:0.2rem 0.4rem;border-bottom:1px dashed #1a1a1a;font-size:0.75rem;">'+
        '<span style="color:var(--text-muted);">'+_hubEsc(label)+'</span>'+
        '<span style="color:var(--text-primary);font-family:monospace;text-align:right;word-break:break-all;max-width:60%;">'+_hubEsc(_v)+'</span>'+
        '</div>';
}

function _hubBuildDetailPanels(prof, nbrs, tr, mr, wp, tel, meta, sf){
    let _h = '';
    // FIX BUG (2026-04-20): /api/monitor/node/<id> ritorna {success:true, profile:{...flat}}
    // — precedentemente si leggeva prof.ok + prof.base (URL e shape errati → panel vuoti).
    // FIX BUG (2026-04-21): stesso problema (.ok vs .success) per nbrs/tr/mr/wp/tel sotto-endpoint.
    const _p = (prof && prof.success && prof.profile) ? prof.profile : {};
    const _b = _p;  // Il profilo è flat: long_name/short_name/node_id/hw_model/rssi_avg/... tutti al root
    const _profileMissing = !_p || Object.keys(_p).length === 0;
    // QUICK BAR — navigazione veloce
    _h += _hubQuickBar();
    // Banner warning se il profilo non è ancora disponibile nel DB Monitor
    if(_profileMissing){
        _h += '<div style="margin:0.4rem 0 0.6rem 0;padding:0.5rem 0.7rem;background:rgba(245,158,11,0.08);border:1px solid rgba(245,158,11,0.35);border-radius:var(--radius);color:#f59e0b;font-size:0.78rem;">'+
            '⚠️ <strong>'+t('Nodo non ancora profilato')+'</strong><br>'+
            '<span style="color:var(--text-muted);font-size:0.72rem;">'+t('Serve più traffico per popolare il profilo completo')+'</span>'+
            '</div>';
    }
    // PANEL 1 — Identità
    _h += _hubPanelHdr('👤 '+t('Identità'), 'panel-identity');
    _h += '<div style="display:grid;grid-template-columns:1fr 1fr;gap:0 0.8rem;">';
    _h += _hubKV(t('Long Name'), _b.long_name);
    _h += _hubKV(t('Short Name'), _b.short_name);
    _h += _hubKV(t('Node ID'), _b.node_id);
    _h += _hubKV('Node Hex', _b.node_hex);
    _h += _hubKV('MAC', _p.macaddr);
    _h += _hubKV(t('Ruolo'), _p.role);
    _h += _hubKV('HAM', _p.is_licensed ? 'Sì' : 'No');
    _h += _hubKV('Stealth', _p.is_stealth ? 'Sì' : 'No');
    _h += _hubKV('No-Msg', _p.is_unmessagable ? 'Sì' : 'No');
    _h += _hubKV(t('Rete'), _b.network);
    _h += '</div>';
    if(_p.public_key_hex){
        _h += '<div style="margin-top:0.4rem;padding:0.4rem;background:#0a0a0a;border:1px solid var(--border);border-radius:var(--radius);font-size:0.7rem;">'+
            '<strong style="color:var(--text-muted);">'+t('Chiave pubblica')+':</strong><br>'+
            '<code style="color:#10b981;word-break:break-all;">'+_hubEsc(_p.public_key_hex)+'</code></div>';
    }

    // PANEL 1b — Attività 7d (breakdown pacchetti per portnum: aiuta a diagnosticare cosa manca)
    if(!_profileMissing && (_p.total_packets || (_p.by_portnum||[]).length)){
        _h += _hubPanelHdr('📦 '+t('Attività (finestra 7d)'), 'panel-activity');
        _h += '<div style="display:grid;grid-template-columns:1fr 1fr 1fr 1fr;gap:0 0.8rem;">';
        _h += _hubKV(t('Totale pacchetti'), _p.total_packets!=null?_p.total_packets:'—');
        _h += _hubKV(t('Ultime 24h'), _p.pkt_24h!=null?_p.pkt_24h:'—');
        _h += _hubKV(t('Ultima 1h'), _p.pkt_1h!=null?_p.pkt_1h:'—');
        _h += _hubKV(t('Rate pkt/min'), _p.rate_pkt_per_min!=null?Number(_p.rate_pkt_per_min).toFixed(2):'—');
        _h += '</div>';
        const _bp = (_p.by_portnum||[]).slice(0, 12);
        if(_bp.length){
            _h += '<div style="margin-top:0.3rem;display:flex;flex-wrap:wrap;gap:0.3rem;">';
            _bp.forEach(x=>{
                _h += '<span style="padding:0.15rem 0.4rem;background:#0a0a0a;border:1px solid var(--border);border-radius:10px;font-size:0.7rem;font-family:monospace;">'+
                    '<span style="color:var(--accent);">'+_hubEsc(x.port_name)+'</span> '+
                    '<span style="color:var(--text-muted);">×'+x.count+'</span></span>';
            });
            _h += '</div>';
        }
    }

    // PANEL 2 — Radio
    _h += _hubPanelHdr('📡 '+t('Radio'), 'panel-radio');
    _h += '<div style="display:grid;grid-template-columns:1fr 1fr;gap:0 0.8rem;">';
    _h += _hubKV('HW', _b.hw_model);
    _h += _hubKV('Firmware', _p.firmware_version || _b.fw_type);
    _h += _hubKV(t('Regione'), _p.region);
    _h += _hubKV('Preset', _p.modem_preset);
    _h += _hubKV('RSSI avg', _b.rssi_avg!=null?_b.rssi_avg+' dBm':'—');
    _h += _hubKV('SNR avg', _b.snr_avg!=null?Number(_b.snr_avg).toFixed(1)+' dB':'—');
    _h += _hubKV('RSSI best', _b.rssi_best!=null?_b.rssi_best+' dBm':'—');
    _h += _hubKV('SNR best', _b.snr_best!=null?Number(_b.snr_best).toFixed(1)+' dB':'—');
    _h += _hubKV('Hops away', _p.hops_away);
    _h += _hubKV('via MQTT', _p.via_mqtt_last!=null ? (_p.via_mqtt_last?'Sì':'No') : '—');
    _h += '</div>';
    // Diagnostica metadati radio (se mancano campi chiave)
    if(!_profileMissing && _p.region==null && _p.modem_preset==null && _p.hops_away==null){
        _h += '<div style="margin-top:0.3rem;padding:0.35rem 0.5rem;background:rgba(245,158,11,0.06);border-left:2px solid rgba(245,158,11,0.5);color:var(--text-muted);font-size:0.72rem;border-radius:2px;">'+
            'ℹ️ '+t('Serve un MAP_REPORT o NODEINFO completo per popolare Regione/Preset/Hops')+'</div>';
    }

    // PANEL 3 — GPS / Posizione (arricchito: sats veri vs fissa, HDOP, ground_speed, precision)
    _h += _hubPanelHdr('📍 '+t('Posizione GPS'), 'panel-gps');
    const _lp = _p.last_position || {};
    const _pq2 = _lp.position_quality || {};
    // Conteggio POSITION_APP pkt ricevuti (per diagnosi)
    const _posPkts = ((_p.by_portnum||[]).find(x=>x.port_name==='POSITION_APP')||{}).count || 0;
    if(_lp.latitude!=null || _lp.position_lat!=null){
        const _lat = _lp.latitude!=null?_lp.latitude:((_lp.position_lat||0)/1e7);
        const _lon = _lp.longitude!=null?_lp.longitude:((_lp.position_lon||0)/1e7);
        const _ls = _pq2.location_source || _lp.location_source || 'UNKNOWN';
        const _lsIco = (_ls==='LOC_INTERNAL'||_ls==='INTERNAL')?'🎯 '+t('GPS interno (sats veri)'):
                       (_ls==='LOC_MANUAL'||_ls==='MANUAL')?'📌 '+t('Posizione fissa (manuale)'):
                       (_ls==='LOC_EXTERNAL'||_ls==='EXTERNAL')?'📱 '+t('GPS esterno (phone)'):
                       '📍 '+_hubEsc(_ls);
        _h += '<div style="display:grid;grid-template-columns:1fr 1fr;gap:0 0.8rem;">';
        _h += _hubKV('Lat', Number(_lat).toFixed(6));
        _h += _hubKV('Lon', Number(_lon).toFixed(6));
        _h += _hubKV(t('Altitudine'), _lp.position_alt!=null?_lp.position_alt+' m':'—');
        _h += _hubKV(t('Satelliti'), _pq2.sats_in_view!=null?_pq2.sats_in_view:_lp.position_sats);
        _h += _hubKV(t('Origine posizione'), _lsIco);
        _h += _hubKV('HDOP', _pq2.HDOP!=null?Number(_pq2.HDOP).toFixed(2):'—');
        _h += _hubKV('PDOP', _lp.position_pdop!=null?Number(_lp.position_pdop).toFixed(2):(_pq2.PDOP!=null?Number(_pq2.PDOP).toFixed(2):'—'));
        _h += _hubKV('VDOP', _pq2.VDOP!=null?Number(_pq2.VDOP).toFixed(2):'—');
        _h += _hubKV(t('Velocità (m/s)'), _pq2.ground_speed!=null?Number(_pq2.ground_speed).toFixed(2):'—');
        _h += _hubKV(t('Direzione (°)'), _pq2.ground_track!=null?Number(_pq2.ground_track).toFixed(1):'—');
        _h += _hubKV(t('Precisione (bit)'), _pq2.precision_bits!=null?_pq2.precision_bits+' bit':'—');
        _h += _hubKV('Timestamp fix', _pq2.time?new Date(_pq2.time*1000).toISOString():'—');
        _h += _hubKV(t('Ultimo aggiornamento'), _lp.ts?_hubFmtTs(_lp.ts):'—');
        _h += '</div>';
        if(_lat && _lon){
            _h += '<div style="margin-top:0.4rem;display:flex;gap:0.5rem;flex-wrap:wrap;">'+
                '<a href="https://www.google.com/maps?q='+_lat+','+_lon+'" target="_blank" rel="noopener" style="color:#60a5fa;font-size:0.75rem;">🗺️ '+t('Apri in Google Maps')+'</a>'+
                '<a href="https://www.openstreetmap.org/?mlat='+_lat+'&mlon='+_lon+'#map=15/'+_lat+'/'+_lon+'" target="_blank" rel="noopener" style="color:#60a5fa;font-size:0.75rem;">🗺️ OpenStreetMap</a>'+
                '</div>';
        }
    } else {
        // Messaggio diagnostico dettagliato quando GPS assente
        if(_profileMissing){
            _h += '<div style="color:var(--text-muted);font-size:0.78rem;padding:0.4rem;">—</div>';
        } else if(_posPkts === 0){
            _h += '<div style="padding:0.4rem 0.5rem;background:rgba(96,165,250,0.06);border-left:2px solid rgba(96,165,250,0.45);color:var(--text-muted);font-size:0.73rem;border-radius:2px;">'+
                '📡 '+t('Nessun POSITION_APP ricevuto nella finestra 7d')+'<br>'+
                '<span style="font-size:0.7rem;">'+t('Abilita condivisione posizione sul dispositivo o aspetta il prossimo broadcast')+'</span></div>';
        } else {
            _h += '<div style="padding:0.4rem 0.5rem;background:rgba(245,158,11,0.06);border-left:2px solid rgba(245,158,11,0.45);color:var(--text-muted);font-size:0.73rem;border-radius:2px;">'+
                '⚠️ '+t('POSITION_APP ricevuti ma senza coordinate valide')+' ('+_posPkts+' pkt)<br>'+
                '<span style="font-size:0.7rem;">'+t('Il dispositivo non ha ancora un fix GPS o sta trasmettendo posizione zero')+'</span></div>';
        }
    }

    // PANEL 4 — Topology (vicini)
    _h += _hubPanelHdr('🕸️ '+t('Vicini (NeighborInfo)'), 'panel-neighbors');
    const _nbrs = (nbrs && nbrs.success && nbrs.neighbors) ? nbrs.neighbors : [];
    if(_nbrs.length){
        _h += '<div style="max-height:180px;overflow-y:auto;border:1px solid var(--border);border-radius:var(--radius);">';
        _h += '<table style="width:100%;border-collapse:collapse;font-size:0.72rem;">';
        _h += '<thead><tr style="background:var(--bg-input);position:sticky;top:0;"><th style="padding:0.3rem;text-align:left;">Vicino</th><th style="padding:0.3rem;text-align:right;">SNR</th><th style="padding:0.3rem;text-align:right;">'+t('Ultimo')+'</th></tr></thead><tbody>';
        _nbrs.slice(0, 30).forEach(x=>{
            _h += '<tr style="border-bottom:1px solid #141414;"><td style="padding:0.25rem 0.3rem;font-family:monospace;color:#60a5fa;">'+_hubEsc(x.neighbor_hex||x.neighbor_id)+'</td>'+
                '<td style="padding:0.25rem 0.3rem;text-align:right;">'+(x.snr!=null?Number(x.snr).toFixed(1)+' dB':'—')+'</td>'+
                '<td style="padding:0.25rem 0.3rem;text-align:right;color:var(--text-muted);">'+(x.last_rx?_hubFmtTs(x.last_rx):'—')+'</td></tr>';
        });
        _h += '</tbody></table></div>';
    } else {
        _h += '<div style="color:var(--text-muted);font-size:0.78rem;padding:0.4rem;">—</div>';
    }

    // PANEL 5 — Telemetry timeseries
    _h += _hubPanelHdr('📊 '+t('Telemetria'), 'panel-telemetry');
    _h += '<div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:0 0.8rem;">';
    _h += _hubKV(t('Batteria'), _p.last_battery!=null?_p.last_battery+' %':'—');
    _h += _hubKV(t('Voltaggio'), _p.last_voltage!=null?Number(_p.last_voltage).toFixed(2)+' V':'—');
    _h += _hubKV('Ch util', _p.last_ch_util!=null?Number(_p.last_ch_util).toFixed(2)+' %':'—');
    _h += _hubKV('Tx util', _p.last_tx_util!=null?Number(_p.last_tx_util).toFixed(2)+' %':'—');
    _h += _hubKV('Uptime', _p.last_uptime!=null?Math.floor(_p.last_uptime/3600)+' h':'—');
    _h += '</div>';
    const _tels = (tel && tel.success && tel.telemetry) ? tel.telemetry : [];
    // Diagnostica se nessun campo telemetria popolato
    const _noTlmFields = (_p.last_battery==null && _p.last_voltage==null && _p.last_ch_util==null && _p.last_tx_util==null && _p.last_uptime==null);
    const _tlmPkts = ((_p.by_portnum||[]).find(x=>x.port_name==='TELEMETRY_APP')||{}).count || 0;
    if(!_profileMissing && _noTlmFields && !_tels.length){
        if(_tlmPkts === 0){
            _h += '<div style="margin-top:0.3rem;padding:0.4rem 0.5rem;background:rgba(96,165,250,0.06);border-left:2px solid rgba(96,165,250,0.45);color:var(--text-muted);font-size:0.72rem;border-radius:2px;">'+
                '📡 '+t('Nessun TELEMETRY_APP ricevuto nella finestra 7d')+'</div>';
        } else {
            _h += '<div style="margin-top:0.3rem;padding:0.4rem 0.5rem;background:rgba(245,158,11,0.06);border-left:2px solid rgba(245,158,11,0.45);color:var(--text-muted);font-size:0.72rem;border-radius:2px;">'+
                '⚠️ '+_tlmPkts+' TELEMETRY_APP '+t('ricevuti ma non decodificati (probabile telemetry_json mancante o cifrato)')+'</div>';
        }
    }
    if(_tels.length){
        _h += '<div style="max-height:140px;overflow-y:auto;border:1px solid var(--border);border-radius:var(--radius);margin-top:0.3rem;">';
        _h += '<table style="width:100%;border-collapse:collapse;font-size:0.7rem;">';
        _h += '<thead><tr style="background:var(--bg-input);position:sticky;top:0;"><th style="padding:0.3rem;text-align:left;">'+t('Quando')+'</th><th style="padding:0.3rem;text-align:right;">Batt</th><th style="padding:0.3rem;text-align:right;">V</th><th style="padding:0.3rem;text-align:right;">ChU</th><th style="padding:0.3rem;text-align:right;">TxU</th></tr></thead><tbody>';
        _tels.slice(0, 40).forEach(x=>{
            const _te = x.telemetry || {};
            _h += '<tr style="border-bottom:1px solid #141414;"><td style="padding:0.25rem 0.3rem;color:var(--text-muted);">'+(x.ts?_hubFmtTs(x.ts):'—')+'</td>'+
                '<td style="padding:0.25rem 0.3rem;text-align:right;">'+(_te.battery_level!=null?_te.battery_level+'%':'—')+'</td>'+
                '<td style="padding:0.25rem 0.3rem;text-align:right;">'+(_te.voltage!=null?Number(_te.voltage).toFixed(2):'—')+'</td>'+
                '<td style="padding:0.25rem 0.3rem;text-align:right;">'+(_te.channel_utilization!=null?Number(_te.channel_utilization).toFixed(1):'—')+'</td>'+
                '<td style="padding:0.25rem 0.3rem;text-align:right;">'+(_te.air_util_tx!=null?Number(_te.air_util_tx).toFixed(1):'—')+'</td></tr>';
        });
        _h += '</tbody></table></div>';
    }

    // PANEL 6 — Traceroutes
    _h += _hubPanelHdr('🛰️ '+t('Traceroutes'), 'panel-traceroutes');
    const _trs = (tr && tr.success && tr.traceroutes) ? tr.traceroutes : [];
    if(_trs.length){
        _h += '<div style="max-height:160px;overflow-y:auto;border:1px solid var(--border);border-radius:var(--radius);">';
        _trs.slice(0, 20).forEach(x=>{
            const _route = Array.isArray(x.route) ? x.route.join(' → ') : (x.route||'—');
            const _back = Array.isArray(x.route_back) ? x.route_back.join(' ← ') : (x.route_back||'');
            const _resp = x.is_response ? ' 🟢' : '';
            _h += '<div style="padding:0.3rem 0.4rem;border-bottom:1px solid #141414;font-size:0.72rem;">'+
                '<div style="color:var(--text-muted);">'+(x.ts?_hubFmtTs(x.ts):'—')+' · hops: '+(x.hop_count!=null?x.hop_count:'?')+_resp+'</div>'+
                '<div style="font-family:monospace;color:#60a5fa;">'+_hubEsc(_route)+'</div>'+
                (_back?'<div style="font-family:monospace;color:#a78bfa;">'+_hubEsc(_back)+'</div>':'')+
                '</div>';
        });
        _h += '</div>';
    } else {
        _h += '<div style="color:var(--text-muted);font-size:0.78rem;padding:0.4rem;">—</div>';
    }

    // PANEL 7 — Map Reports + Waypoints
    _h += _hubPanelHdr('🗺️ '+t('Map Reports & Waypoints'), 'panel-mapwp');
    const _mrs = (mr && mr.success && mr.map_reports) ? mr.map_reports : [];
    const _wps = (wp && wp.success && wp.waypoints) ? wp.waypoints : [];
    if(_mrs.length){
        _h += '<div style="font-size:0.72rem;margin-bottom:0.3rem;"><strong style="color:var(--accent);">'+t('Map Reports')+':</strong> '+_mrs.length+'</div>';
        _h += '<div style="max-height:120px;overflow-y:auto;border:1px solid var(--border);border-radius:var(--radius);margin-bottom:0.4rem;">';
        _mrs.slice(0, 10).forEach(x=>{
            _h += '<div style="padding:0.25rem 0.4rem;border-bottom:1px solid #141414;font-size:0.7rem;">'+
                '<span style="color:var(--text-muted);">'+(x.ts?_hubFmtTs(x.ts):'—')+'</span> · '+
                '<span>fw: <code>'+_hubEsc(x.firmware_version||'?')+'</code></span> · '+
                '<span>'+_hubEsc(x.region||'?')+'/'+_hubEsc(x.modem_preset||'?')+'</span> · '+
                '<span>online: '+(x.num_online_local_nodes||'—')+'</span></div>';
        });
        _h += '</div>';
    }
    if(_wps.length){
        _h += '<div style="font-size:0.72rem;margin-bottom:0.3rem;"><strong style="color:var(--accent);">'+t('Waypoints')+':</strong> '+_wps.length+'</div>';
        _h += '<div style="max-height:120px;overflow-y:auto;border:1px solid var(--border);border-radius:var(--radius);">';
        _wps.slice(0, 20).forEach(x=>{
            const _lat = x.lat_i!=null?(x.lat_i/1e7).toFixed(5):'—';
            const _lon = x.lon_i!=null?(x.lon_i/1e7).toFixed(5):'—';
            _h += '<div style="padding:0.25rem 0.4rem;border-bottom:1px solid #141414;font-size:0.7rem;">'+
                '<strong>'+_hubEsc(x.name||'?')+'</strong> '+_hubEsc(x.icon||'')+' '+
                '<span style="color:var(--text-muted);">('+_lat+', '+_lon+')</span></div>';
        });
        _h += '</div>';
    }
    if(!_mrs.length && !_wps.length){
        _h += '<div style="color:var(--text-muted);font-size:0.78rem;padding:0.4rem;">—</div>';
    }

    // PANEL 8 — Raw JSON (profile + metadata + storeforward)
    _h += _hubPanelHdr('🧬 '+t('Dati grezzi (Raw JSON)'), 'panel-raw');
    _h += '<details style="margin-bottom:0.3rem;"><summary style="cursor:pointer;color:var(--accent);font-size:0.78rem;">'+t('Profilo completo')+'</summary>';
    if(_profileMissing){
        _h += '<pre style="background:#0a0a0a;border:1px solid var(--border);padding:0.5rem;border-radius:var(--radius);font-size:0.72rem;color:#f59e0b;">⚠️ '+_hubEsc(t('Nodo non ancora profilato'))+'\n\n'+_hubEsc(t('Serve più traffico per popolare il profilo completo'))+'</pre></details>';
    } else {
        _h += '<pre style="background:#0a0a0a;border:1px solid var(--border);padding:0.5rem;border-radius:var(--radius);max-height:280px;overflow:auto;font-size:0.68rem;color:#d4d4d4;">'+_hubEsc(JSON.stringify(prof.profile, null, 2))+'</pre></details>';
    }
    _h += '<details style="margin-bottom:0.3rem;"><summary style="cursor:pointer;color:var(--accent);font-size:0.78rem;">'+t('Metadata history')+'</summary>';
    _h += '<pre style="background:#0a0a0a;border:1px solid var(--border);padding:0.5rem;border-radius:var(--radius);max-height:220px;overflow:auto;font-size:0.68rem;color:#d4d4d4;">'+_hubEsc(JSON.stringify(meta||{}, null, 2))+'</pre></details>';
    _h += '<details><summary style="cursor:pointer;color:var(--accent);font-size:0.78rem;">'+t('Store & Forward stats')+'</summary>';
    _h += '<pre style="background:#0a0a0a;border:1px solid var(--border);padding:0.5rem;border-radius:var(--radius);max-height:220px;overflow:auto;font-size:0.68rem;color:#d4d4d4;">'+_hubEsc(JSON.stringify(sf||{}, null, 2))+'</pre></details>';

    return _h;
}

// Auto-load Hub table quando il tab monitor è attivo
document.addEventListener('DOMContentLoaded', function(){
    // Refresh quando il tab Monitor diventa visibile
    const _monTab = document.querySelector('[data-tab="monitor"], .tab-monitor, #tab-monitor');
    // Fallback: load at first scroll-into-view of the card
    try{
        const _card = document.getElementById('mon-hub-scanner');
        if(_card && 'IntersectionObserver' in window){
            const _io = new IntersectionObserver((entries)=>{
                entries.forEach(en=>{
                    if(en.isIntersecting && _hubState.nodes.length===0 && !_hubState.loading){
                        hubLoadNodes();
                    }
                });
            }, { threshold: 0.1 });
            _io.observe(_card);
        }
    }catch(_e){}
});


// ══════════════════════════════════════════════════════════════════════════════
// ══════════════════════════════════════════════════════════════════════════════
// CRYPTO HUNTER — Brute force catalogo PSK sul buffer RAM + DB 7g
// ══════════════════════════════════════════════════════════════════════════════
// Entry points:
//   - window.cryptoHunterRun(): click "🎯 Avvia Brute Force"
//   - window.cryptoHunterRefreshPskCount(): click "🔄 Aggiorna stato"
//
// Backend: POST /api/monitor/crypto/hunter (PRO required)
// UI card: #mon-crypto-hunter con badge PSK/Buffer/Scanned/Decrypted + progress
// + tabella breakdown per-PSK + sample risultati.
//
// Rispetta NO SHADOWING (t() globale): usa _el / _btn / _row / _tmp.

window.cryptoHunterRun = async function(){
    const _btn = document.getElementById('hunter-btn-run');
    const _wrapProg = document.getElementById('hunter-progress-wrap');
    const _bar = document.getElementById('hunter-progress-bar');
    const _lbl = document.getElementById('hunter-progress-label');
    const _wrapPsk = document.getElementById('hunter-per-psk-wrap');
    const _wrapRes = document.getElementById('hunter-results-wrap');
    const _wrapReasons = document.getElementById('hunter-reasons-wrap');
    const _windowEl = document.getElementById('hunter-window');
    const _limitEl = document.getElementById('hunter-limit');
    const _win = Math.max(1, Math.min(30, parseInt(_windowEl && _windowEl.value || '7', 10)));
    const _lim = Math.max(10, Math.min(5000, parseInt(_limitEl && _limitEl.value || '500', 10)));

    // UI: disable button + show indeterminate progress
    if (_btn) { _btn.disabled = true; _btn.textContent = '⏳ ' + t('In corso...'); }
    if (_wrapProg) _wrapProg.style.display = 'block';
    if (_bar) { _bar.style.width = '10%'; }
    if (_lbl) _lbl.textContent = t('Invio richiesta brute force...');
    if (_wrapPsk) _wrapPsk.style.display = 'none';
    if (_wrapRes) _wrapRes.style.display = 'none';
    if (_wrapReasons) _wrapReasons.style.display = 'none';

    // Simulate progress ticks during request
    let _tick = 10;
    const _ticker = setInterval(function(){
        _tick = Math.min(_tick + 3, 85);
        if (_bar) _bar.style.width = _tick + '%';
    }, 400);

    try {
        const _r = await fetch('/api/monitor/crypto/hunter', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({window_days: _win, limit: _lim}),
        });
        const _data = await _r.json();
        clearInterval(_ticker);
        if (_bar) _bar.style.width = '100%';
        if (_lbl) _lbl.textContent = t('Completato');

        if (!_r.ok || !_data || !_data.success) {
            const _msg = (_data && (_data.message || _data.error)) || ('HTTP ' + _r.status);
            window.cryptoHunterRenderError(_msg);
            return;
        }

        // Update status badges
        const _psk = document.getElementById('hunter-stat-psk');
        const _buf = document.getElementById('hunter-stat-buf');
        const _sc = document.getElementById('hunter-stat-scanned');
        const _dec = document.getElementById('hunter-stat-decrypted');
        if (_psk) _psk.textContent = String(_data.psk_count || 0);
        if (_buf) _buf.textContent = String(_data.buffer_size || 0);
        if (_sc) _sc.textContent = String(_data.total_scanned || 0);
        if (_dec) _dec.textContent = String(_data.total_decrypted || 0);

        window.cryptoHunterRenderPerPsk(_data.per_psk || []);
        window.cryptoHunterRenderResults(_data.results || []);
        window.cryptoHunterRenderReasons(_data.reasons || {}, _data.total_scanned || 0, _data.total_decrypted || 0);
    } catch(_err) {
        clearInterval(_ticker);
        window.cryptoHunterRenderError(String(_err));
    } finally {
        if (_btn) { _btn.disabled = false; _btn.textContent = t('🎯 Avvia Brute Force'); }
        setTimeout(function(){
            if (_wrapProg) _wrapProg.style.display = 'none';
        }, 1500);
    }
};

window.cryptoHunterRefreshPskCount = async function(){
    try {
        const _r = await fetch('/api/monitor/psk');
        const _data = await _r.json();
        const _list = (_data && _data.psks) || [];
        const _enabled = _list.filter(function(p){ return (p.enabled|0) === 1; }).length;
        const _psk = document.getElementById('hunter-stat-psk');
        if (_psk) _psk.textContent = String(_enabled);
    } catch(_e) {}
    // Buffer size: prova endpoint status monitor
    try {
        const _r2 = await fetch('/api/monitor/tools/status');
        const _d2 = await _r2.json();
        const _buf = document.getElementById('hunter-stat-buf');
        if (_buf && _d2) _buf.textContent = String(_d2.buffer_size || 0);
    } catch(_e) {}
};

window.cryptoHunterRenderPerPsk = function(perPsk){
    const _wrap = document.getElementById('hunter-per-psk-wrap');
    const _tbody = document.getElementById('hunter-per-psk-tbody');
    if (!_wrap || !_tbody) return;
    if (!perPsk || !perPsk.length) {
        _wrap.style.display = 'block';
        _tbody.innerHTML = '<tr><td colspan="3" style="text-align:center;color:var(--text-muted);padding:0.6rem;">' +
            t('Nessuna PSK ha decrittato pacchetti in questo run.') + '</td></tr>';
        return;
    }
    const _max = perPsk[0].matches || 1;
    const _rows = perPsk.map(function(p){
        const _pct = Math.round((p.matches / _max) * 100);
        const _label = (p.label || ('PSK#' + p.psk_id)).replace(/</g, '&lt;');
        return '<tr>' +
            '<td style="padding:0.3rem 0.5rem;border-bottom:1px solid var(--border);">' + _label + '</td>' +
            '<td style="text-align:center;padding:0.3rem 0.5rem;border-bottom:1px solid var(--border);color:var(--accent);font-weight:bold;">' + (p.matches|0) + '</td>' +
            '<td style="padding:0.3rem 0.5rem;border-bottom:1px solid var(--border);">' +
              '<div style="background:var(--bg);border-radius:3px;overflow:hidden;height:10px;">' +
                '<div style="background:linear-gradient(90deg,#ef4444,#f87171);height:100%;width:' + _pct + '%;"></div>' +
              '</div>' +
            '</td>' +
        '</tr>';
    }).join('');
    _tbody.innerHTML = _rows;
    _wrap.style.display = 'block';
};

window.cryptoHunterRenderResults = function(results){
    const _wrap = document.getElementById('hunter-results-wrap');
    const _out = document.getElementById('hunter-results-output');
    if (!_wrap || !_out) return;
    if (!results || !results.length) {
        _wrap.style.display = 'block';
        _out.textContent = t('Nessun pacchetto decrittato nell\'intervallo selezionato.');
        return;
    }
    const _lines = results.map(function(r){
        const _src = r.source ? ('[' + r.source.toUpperCase() + '] ') : '';
        const _pid = r.packet_id != null ? ('0x' + (r.packet_id >>> 0).toString(16).padStart(8,'0')) : '—';
        const _from = r.from_node != null ? ('!' + (r.from_node >>> 0).toString(16).padStart(8,'0')) : '—';
        const _port = r.port_name || ('PORT_' + (r.portnum != null ? r.portnum : '?'));
        const _snip = (r.snippet || '').replace(/\s+/g, ' ');
        return _src + _pid + ' ' + _from + ' ' + _port + ' [' + (r.psk_label || '?') + ']' +
               (_snip ? '  → ' + _snip : '');
    });
    _out.textContent = _lines.join('\n');
    _wrap.style.display = 'block';
};

window.cryptoHunterRenderError = function(msg){
    const _wrap = document.getElementById('hunter-results-wrap');
    const _out = document.getElementById('hunter-results-output');
    if (_wrap) _wrap.style.display = 'block';
    if (_out) _out.textContent = t('Errore:') + ' ' + (msg || '?');
};

// Task #66 — Render breakdown motivi fallimento decrittazione
window.cryptoHunterRenderReasons = function(reasons, totalScanned, totalDecrypted){
    const _wrap = document.getElementById('hunter-reasons-wrap');
    if (!_wrap) return;
    const _r = reasons || {};
    const _pki = _r.pki_encrypted | 0;
    const _zpid = _r.zero_packetid | 0;
    const _zfrom = _r.zero_from | 0;
    const _apf = _r.decrypt_fail_all_psk | 0;
    const _sum = _pki + _zpid + _zfrom + _apf;
    // Mostra la card solo se ci sono scansionati (anche se 0 fallimenti, per dare feedback)
    if ((totalScanned | 0) === 0) {
        _wrap.style.display = 'none';
        return;
    }
    const _elPki = document.getElementById('hunter-reason-pki');
    const _elZpid = document.getElementById('hunter-reason-zero-pid');
    const _elZfrom = document.getElementById('hunter-reason-zero-from');
    const _elApf = document.getElementById('hunter-reason-all-psk-fail');
    if (_elPki) _elPki.textContent = String(_pki);
    if (_elZpid) _elZpid.textContent = String(_zpid);
    if (_elZfrom) _elZfrom.textContent = String(_zfrom);
    if (_elApf) _elApf.textContent = String(_apf);
    _wrap.style.display = 'block';
};

// ══════════════════════════════════════════════════════════════════════════════
// H4.2 — CRYPTO AGENT (frontend): decripta pacchetti con TUTTE le chiavi
// ══════════════════════════════════════════════════════════════════════════════
// Entry point chiamato dai bottoni "🔓 Crypto Agent" nel Monitor.
// Invia POST /api/monitor/crypto/agent → riceve JSON con decrypt completo (PSK/PKI
// + parsing protobuf di tutti i 23 portnum Meshtastic inclusi ADMIN e ATAK).

window.cryptoAgentDecrypt = async function(arg){
    try{
        const _pkt = (typeof arg === 'string') ? JSON.parse(arg) : (arg||{});
        // Leggi PKI manualmente inserito (se presente)
        const _pkiListEl = document.getElementById('crypto-agent-pki-list');
        let _pki=[];
        try{
            const _raw = (_pkiListEl && _pkiListEl.value) || localStorage.getItem('cryptoAgentPKI') || '';
            if(_raw && _raw.trim()){
                _pki = JSON.parse(_raw);
                if(!Array.isArray(_pki)) _pki=[];
            }
        }catch(_e){ _pki=[]; }
        _pkt.pki_list = _pki;

        window.__cryptoAgentShowModal({loading:true, packet:_pkt});
        const _res = await fetch('/api/monitor/crypto/agent', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify(_pkt),
        });
        const _data = await _res.json();
        window.__cryptoAgentShowModal({data:_data, packet:_pkt});
    }catch(_err){
        window.__cryptoAgentShowModal({error:String(_err)});
    }
};

window.__cryptoAgentShowModal = function(state){
    let _m = document.getElementById('crypto-agent-modal');
    if(!_m){
        _m = document.createElement('div');
        _m.id = 'crypto-agent-modal';
        _m.style.cssText='position:fixed;inset:0;background:rgba(0,0,0,0.85);z-index:10050;display:flex;align-items:center;justify-content:center;padding:2rem;';
        _m.innerHTML='<div id="crypto-agent-modal-inner" style="background:#0a0a0a;border:2px solid #7c3aed;border-radius:8px;max-width:1000px;width:100%;max-height:90vh;overflow:auto;padding:1.2rem;"></div>';
        _m.onclick=function(ev){ if(ev.target===_m) _m.remove(); };
        document.body.appendChild(_m);
    }
    const _inner = document.getElementById('crypto-agent-modal-inner');
    if(state.loading){
        _inner.innerHTML = '<div style="color:#a78bfa;font-size:1.1rem;">🔐 '+t('Crypto Agent al lavoro... tento tutte le PSK del DB + PKI configurate')+'</div>';
        return;
    }
    if(state.error){
        _inner.innerHTML = '<div style="color:#f87171;">❌ '+monitorEscape(state.error)+'</div>'+
            '<button onclick="document.getElementById(\'crypto-agent-modal\').remove()" style="margin-top:0.8rem;background:#7c3aed;border:0;color:#fff;padding:0.4rem 0.8rem;border-radius:4px;cursor:pointer;">'+t('Chiudi')+'</button>';
        return;
    }
    const _d = state.data || {};
    const _p = state.packet || {};
    const _ok = _d.success===true;
    const _title = _ok ? '✅ <span style="color:#10b981;">'+t('Decrypt riuscito')+'</span>' : '⚠️ <span style="color:#fbbf24;">'+t('Decrypt non riuscito')+'</span>';
    let _h = '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:0.8rem;">'+
             '<h3 style="margin:0;color:#a78bfa;">🔓 Crypto Agent — '+_title+'</h3>'+
             '<button onclick="document.getElementById(\'crypto-agent-modal\').remove()" style="background:transparent;color:#fff;border:1px solid #444;padding:0.2rem 0.6rem;border-radius:3px;cursor:pointer;">✕</button>'+
             '</div>';
    // Pacchetto input
    _h += '<details style="margin-bottom:0.6rem;"><summary style="cursor:pointer;color:#94a3b8;">📦 '+t('Pacchetto input')+'</summary>'+
          '<pre style="background:#1a1a1a;padding:0.6rem;border-radius:4px;overflow:auto;color:#cbd5e1;font-size:0.7rem;max-height:200px;">'+monitorEscape(JSON.stringify(_p,null,2))+'</pre></details>';
    if(_ok){
        _h += '<div style="background:#052e16;border:1px solid #10b981;padding:0.8rem;border-radius:4px;margin-bottom:0.8rem;">'+
              '<div style="color:#10b981;"><strong>'+t('Metodo')+':</strong> '+monitorEscape(_d.method||'?')+'</div>'+
              '<div style="color:#10b981;"><strong>'+t('Chiave matchata')+':</strong> '+monitorEscape(JSON.stringify(_d.matched||{}))+'</div>'+
              '<div style="color:#10b981;"><strong>Portnum:</strong> '+monitorEscape(String(_d.portnum||'?'))+' ('+monitorEscape(_d.portnum_decoded||'?')+')</div>'+
              '</div>';
        const _df = _d.decoded_fields||{};
        _h += '<h4 style="color:#a78bfa;margin:0.8rem 0 0.4rem;">📋 '+t('Campi decodificati')+' ('+monitorEscape(_df.decoded_type||'?')+')</h4>'+
              '<pre style="background:#1a1a1a;padding:0.8rem;border-radius:4px;overflow:auto;color:#fff;font-size:0.8rem;max-height:400px;word-break:break-all;white-space:pre-wrap;">'+monitorEscape(JSON.stringify(_df.decoded,null,2))+'</pre>';
        if(_d.cleartext_hex){
            _h += '<details style="margin-top:0.6rem;"><summary style="cursor:pointer;color:#94a3b8;">🔢 '+t('Cleartext hex (protobuf Data completo)')+'</summary>'+
                  '<pre style="background:#1a1a1a;padding:0.6rem;border-radius:4px;overflow:auto;color:#94a3b8;font-size:0.7rem;word-break:break-all;white-space:pre-wrap;">'+monitorEscape(_d.cleartext_hex)+'</pre></details>';
        }
    } else {
        _h += '<div style="background:#3f1515;border:1px solid #dc2626;padding:0.8rem;border-radius:4px;margin-bottom:0.8rem;">'+
              '<div style="color:#f87171;">'+monitorEscape(_d.error||_d.message||t('Tutte le chiavi hanno fallito'))+'</div>'+
              '</div>';
        _h += '<div style="margin:0.8rem 0;">'+
              '<label style="color:#94a3b8;display:block;margin-bottom:0.3rem;">🔑 '+t('Aggiungi PKI manualmente (JSON array [{label,my_priv_hex,their_pub_hex}])')+':</label>'+
              '<textarea id="crypto-agent-pki-input" placeholder=\'[{"label":"MyKey","my_priv_hex":"aabbcc...","their_pub_hex":"112233..."}]\' style="width:100%;height:80px;background:#111;color:#e5e7eb;border:1px solid #444;padding:0.4rem;font-family:monospace;font-size:0.75rem;border-radius:4px;"></textarea>'+
              '<button onclick="(function(){var v=document.getElementById(\'crypto-agent-pki-input\').value;try{JSON.parse(v);localStorage.setItem(\'cryptoAgentPKI\',v);window.cryptoAgentDecrypt('+JSON.stringify(_p).replace(/"/g,'&quot;')+');}catch(e){alert(\'JSON invalido: \'+e.message);}})()" style="margin-top:0.4rem;background:#7c3aed;border:0;color:#fff;padding:0.4rem 0.8rem;border-radius:4px;cursor:pointer;">🔓 '+t('Ritenta con queste PKI')+'</button>'+
              '</div>';
    }
    // Tentativi
    const _atts = _d.attempts||[];
    if(_atts.length){
        _h += '<details style="margin-top:0.6rem;"><summary style="cursor:pointer;color:#94a3b8;">🧪 '+t('Tentativi')+' ('+_atts.length+')</summary>'+
              '<pre style="background:#1a1a1a;padding:0.6rem;border-radius:4px;overflow:auto;color:#cbd5e1;font-size:0.7rem;max-height:260px;">'+monitorEscape(JSON.stringify(_atts,null,2))+'</pre></details>';
    }
    _inner.innerHTML = _h;
};


// ═══════════════════════════════════════════════════════════
// H4.3-T9 — UI Crypto Tool-Suite (PKI + Path Tracer + MQTT Bridge)
// ═══════════════════════════════════════════════════════════

function h43WriteOutput(_elId, _text){
    const _el = document.getElementById(_elId);
    if(_el) _el.textContent = _text;
}

function h43AppendOutput(_elId, _text){
    const _el = document.getElementById(_elId);
    if(!_el) return;
    _el.textContent = (_el.textContent||'') + '\n' + _text;
    _el.scrollTop = _el.scrollHeight;
}

async function h43Fetch(_url, _opts){
    try{
        const _r = await fetch(_url, _opts||{});
        const _d = await _r.json();
        return {ok: _r.ok, status: _r.status, data: _d};
    }catch(_e){
        return {ok: false, status: 0, data: {error: String(_e)}};
    }
}

// ─── Status badges (tools/status) ───
async function h43RefreshStatus(){
    const _r = await h43Fetch('/api/monitor/tools/status');
    if(!_r.ok){
        const _el_err = document.getElementById('h43-stat-pki');
        if(_el_err) _el_err.textContent = '!';
        return;
    }
    const _d = _r.data || {};
    const _mq = _d.mqtt || {};
    const _setEl = (_id, _v)=>{ const _el=document.getElementById(_id); if(_el) _el.textContent=_v; };
    _setEl('h43-stat-pki', (_d.pki_count||0) + ' / ' + (_d.pki_device_own_count||0));
    _setEl('h43-stat-psk', _d.psk_count||0);
    _setEl('h43-stat-buf', _d.buffer_size||0);
    _setEl('h43-stat-mqtt', _mq.running ? (_mq.connected ? '●' : '○') : '—');
}

// ─── PKI Keystore (T1-T2-T4) ───
async function h43PkiList(){
    h43WriteOutput('h43-pki-output', t('Caricamento chiavi PKI...'));
    const _r = await h43Fetch('/api/monitor/pki');
    if(!_r.ok){ h43WriteOutput('h43-pki-output', 'ERROR: '+JSON.stringify(_r.data,null,2)); return; }
    const _keys = (_r.data && _r.data.keys) || [];
    if(!_keys.length){
        h43WriteOutput('h43-pki-output', t('Nessuna chiave PKI registrata.'));
        return;
    }
    let _out = t('Chiavi PKI registrate')+' ('+_keys.length+'):\n';
    _keys.forEach(function(_k){
        _out += '\n#'+_k.id+' ['+(_k.source||'?')+'] '+(_k.label||'')+'\n';
        _out += '  device_own: '+(_k.is_device_own?'YES':'no')+' | enabled: '+(_k.enabled?'yes':'no')+'\n';
        _out += '  my_pub_hex: '+(_k.my_pub_hex||'-')+'\n';
        _out += '  their_pub_hex: '+(_k.their_pub_hex||'-')+'\n';
        _out += '  match_count: '+(_k.match_count||0)+'\n';
    });
    h43WriteOutput('h43-pki-output', _out);
    h43RefreshStatus();
}

async function h43PkiImportNode(){
    h43WriteOutput('h43-pki-output', t('Import priv key da USB in corso...'));
    const _r = await h43Fetch('/api/monitor/pki/import-from-node', {method:'POST'});
    if(!_r.ok){
        h43WriteOutput('h43-pki-output', 'ERROR: '+JSON.stringify(_r.data,null,2));
        return;
    }
    const _d = _r.data || {};
    let _out = '';
    if(_d.action === 'created'){
        _out = '✅ '+t('Chiave importata')+' (id='+_d.pki_id+')\n';
    }else if(_d.action === 'existing'){
        _out = 'ℹ️ '+t('Chiave già presente')+' (id='+_d.pki_id+')\n';
    }else{
        _out = JSON.stringify(_d, null, 2);
    }
    _out += 'my_pub_hex: '+(_d.my_pub_hex||'-')+'\n';
    _out += 'label: '+(_d.label||'-')+'\n';
    h43WriteOutput('h43-pki-output', _out);
    h43RefreshStatus();
}

async function h43PkiDiscover(){
    h43WriteOutput('h43-pki-output', t('Scansione nodi × priv device-own in corso...'));
    const _r = await h43Fetch('/api/monitor/pki/discover', {method:'POST'});
    if(!_r.ok){
        h43WriteOutput('h43-pki-output', 'ERROR: '+JSON.stringify(_r.data,null,2));
        return;
    }
    const _d = _r.data || {};
    let _out = '🔍 '+t('Discovery completata')+':\n';
    _out += '  '+t('Priv device-own')+': '+(_d.device_own_priv_count||0)+'\n';
    _out += '  '+t('Nodi scansionati')+': '+(_d.nodes_scanned||0)+'\n';
    _out += '  '+t('Nodi con publicKey')+': '+(_d.nodes_with_pub||0)+'\n';
    _out += '  '+t('Coppie aggiunte')+': '+(_d.pairings_added||0)+'\n';
    _out += '  '+t('Coppie già esistenti')+': '+(_d.pairings_existing||0)+'\n';
    _out += '  '+t('Errori')+': '+(_d.pairings_errors||0)+'\n';
    const _det = _d.details || [];
    if(_det.length){
        _out += '\n'+t('Dettaglio')+':\n';
        _det.forEach(function(_x){
            _out += '  ['+(_x.action||'?')+'] '+(_x.peer_name||_x.node_id||'-')+' ('+(_x.their_pub_hex||'?').substring(0,16)+'...)\n';
        });
    }
    h43WriteOutput('h43-pki-output', _out);
    h43RefreshStatus();
}

// ─── Path Tracer (T5) ───
async function h43TraceLoadIds(){
    const _encOnly = document.getElementById('h43-trace-enc-only').checked ? 1 : 0;
    const _r = await h43Fetch('/api/monitor/packet/recent_ids?limit=50&encrypted_only='+_encOnly);
    const _sel = document.getElementById('h43-trace-pid');
    if(!_sel) return;
    _sel.innerHTML = '<option value="">-- '+t('Seleziona packet_id')+' --</option>';
    if(!_r.ok){
        h43WriteOutput('h43-trace-output', 'ERROR: '+JSON.stringify(_r.data,null,2));
        return;
    }
    const _ids = (_r.data && _r.data.packet_ids) || [];
    _ids.forEach(function(_pid){
        const _o = document.createElement('option');
        _o.value = String(_pid);
        _o.textContent = _pid + ' (0x' + _pid.toString(16) + ')';
        _sel.appendChild(_o);
    });
    h43WriteOutput('h43-trace-output', t('ID caricati')+': '+_ids.length);
}

async function h43TraceRun(){
    const _sel = document.getElementById('h43-trace-pid');
    const _pid = _sel ? _sel.value : '';
    if(!_pid){
        h43WriteOutput('h43-trace-output', '⚠️ '+t('Seleziona prima un packet_id'));
        return;
    }
    h43WriteOutput('h43-trace-output', t('Ricostruzione percorso in corso...'));
    const _r = await h43Fetch('/api/monitor/packet/trace/'+encodeURIComponent(_pid));
    if(!_r.ok){
        h43WriteOutput('h43-trace-output', 'ERROR: '+JSON.stringify(_r.data,null,2));
        return;
    }
    const _d = _r.data || {};
    let _out = '🗺️ '+t('Percorso packet_id')+' '+_pid+':\n\n';
    _out += '  rows: '+(_d.rows_count||0)+'\n';
    _out += '  hops_used: '+(_d.hops_used===null?'?':_d.hops_used)+'\n';
    _out += '  decrypt_status: '+(_d.decrypt_status||'?')+'\n';
    _out += '  gateways: '+((_d.gateways||[]).join(', ')||'-')+'\n';
    const _tl = _d.timeline || [];
    if(_tl.length){
        _out += '\n--- timeline ---\n';
        _tl.forEach(function(_row, _i){
            const _tag = (_i===0?'DEPARTURE':(_i===_tl.length-1?'ARRIVAL':'TRANSIT  '));
            _out += '['+_tag+'] '+(_row.ts_iso||'?')+'\n';
            _out += '  from: '+(_row.from_hex||'-')+(_row.from_name?' ('+_row.from_name+')':'')+'\n';
            _out += '  hop_start='+_row.hop_start+' hop_limit='+_row.hop_limit+' rssi='+_row.rssi+' snr='+_row.snr+'\n';
            _out += '  port: '+(_row.port_name||_row.portnum||'-')+' enc='+_row.is_encrypted+'\n';
        });
    }
    if(_d.traceroute){
        _out += '\n--- '+t('Traceroute')+' ---\n';
        _out += JSON.stringify(_d.traceroute, null, 2);
    }
    h43WriteOutput('h43-trace-output', _out);
}

// ─── MQTT Bridge (T6) ───
// STEP 14 — Default credenziali broker pubblico Meshtastic ufficiale
const _MQTT_DEFAULT_USER = 'meshdev';
const _MQTT_DEFAULT_PASS = 'large4cats';
const _MQTT_DEFAULT_BROKER = 'mqtt.meshtastic.org';
const _MQTT_DEFAULT_TOPIC = 'msh/#';

async function h43MqttLoadConfig(){
    const _r = await h43Fetch('/api/monitor/mqtt/config');
    if(!_r.ok){
        h43WriteOutput('h43-mqtt-output', 'ERROR: '+JSON.stringify(_r.data,null,2));
        return;
    }
    const _c = (_r.data && _r.data.config) || {};
    const _setVal = function(_id, _v){ const _el=document.getElementById(_id); if(_el) _el.value = _v==null?'':String(_v); };
    // STEP 14 — Se config vuota/null, applica default pubblici meshdev/large4cats per mqtt.meshtastic.org
    _setVal('h43-mqtt-broker', _c.broker || _MQTT_DEFAULT_BROKER);
    _setVal('h43-mqtt-port', _c.port || 1883);
    _setVal('h43-mqtt-topic', _c.topic || _MQTT_DEFAULT_TOPIC);
    _setVal('h43-mqtt-user', _c.username || _MQTT_DEFAULT_USER);
    // Password: se backend segnala config già salvata (has_password=true o username presente),
    // lasciamo vuoto l'input così il Save non la sovrascrive. Altrimenti pre-compiliamo default.
    const _passEl = document.getElementById('h43-mqtt-pass');
    if(_passEl){
        const _hasSaved = !!(_c.username || _c.has_password || _c.broker);
        _passEl.value = _hasSaved ? '' : _MQTT_DEFAULT_PASS;
    }
    const _tls = document.getElementById('h43-mqtt-tls');
    if(_tls) _tls.checked = !!_c.tls;
    h43WriteOutput('h43-mqtt-output', t('Configurazione caricata')+':\n'+JSON.stringify(_c, null, 2));
}

async function h43MqttSaveConfig(){
    const _cfg = {
        broker: (document.getElementById('h43-mqtt-broker')||{}).value || null,
        port: parseInt((document.getElementById('h43-mqtt-port')||{}).value || '1883', 10),
        topic: (document.getElementById('h43-mqtt-topic')||{}).value || 'msh/#',
        username: (document.getElementById('h43-mqtt-user')||{}).value || null,
        tls: ((document.getElementById('h43-mqtt-tls')||{}).checked) || false,
    };
    const _pw = (document.getElementById('h43-mqtt-pass')||{}).value || '';
    if(_pw) _cfg.password = _pw;  // invia solo se utente l'ha digitata
    const _r = await h43Fetch('/api/monitor/mqtt/config', {
        method:'POST',
        headers:{'Content-Type':'application/json'},
        body: JSON.stringify(_cfg)
    });
    h43WriteOutput('h43-mqtt-output', t('Salvataggio config MQTT')+':\n'+JSON.stringify(_r.data, null, 2));
}

async function h43MqttStart(){
    h43WriteOutput('h43-mqtt-output', t('Avvio bridge MQTT...'));
    const _r = await h43Fetch('/api/monitor/mqtt/start', {method:'POST'});
    h43WriteOutput('h43-mqtt-output', (_r.ok?'✅ ':'❌ ')+t('Start bridge MQTT')+':\n'+JSON.stringify(_r.data, null, 2));
    h43RefreshStatus();
}

async function h43MqttStop(){
    const _r = await h43Fetch('/api/monitor/mqtt/stop', {method:'POST'});
    h43WriteOutput('h43-mqtt-output', (_r.ok?'✅ ':'❌ ')+t('Stop bridge MQTT')+':\n'+JSON.stringify(_r.data, null, 2));
    h43RefreshStatus();
}

async function h43MqttStatus(){
    const _r = await h43Fetch('/api/monitor/mqtt/status');
    h43WriteOutput('h43-mqtt-output', t('Stato bridge MQTT')+':\n'+JSON.stringify(_r.data, null, 2));
    h43RefreshStatus();
}

// STEP 9 — Diagnostica MQTT: mostra subscribed_topics + top_roots + top_senders + suggestions
async function h43MqttDiagnose(){
    const _r = await h43Fetch('/api/monitor/mqtt/diagnose');
    const _d = (_r.data && _r.data.diagnose) || {};
    const _st = _d.status || {};
    const _cfg = _d.config || {};
    const _sub = _d.subscribed_topics || [];
    const _roots = _d.top_roots || [];
    const _senders = _d.top_senders || [];
    const _recent = _d.recent_topics || [];
    const _sugg = _d.suggestions || [];
    const _lines = [];
    _lines.push('🔍 '+t('Diagnostica MQTT Bridge'));
    _lines.push('═══════════════════════════════════════════');
    _lines.push('🌐 '+t('Broker')+': '+(_cfg.broker||'—')+':'+(_cfg.port||'—')+(_cfg.tls?' (TLS)':''));
    _lines.push('📡 '+t('Topic configurato')+': '+(_cfg.topic||'—'));
    _lines.push('🔗 '+t('Connesso')+': '+(_st.connected?'✅':'❌')+'   '+t('Running')+': '+(_st.running?'✅':'❌'));
    _lines.push('📊 '+t('Messaggi ricevuti')+': '+(_st.msgs_received||0)+'   parse_ok='+(_st.msgs_parse_ok||0)+'   not_envelope='+(_st.msgs_not_envelope||0)+'   err='+(_st.msgs_parse_err||0));
    if(_st.last_error) _lines.push('⚠️ '+t('Ultimo errore')+': '+_st.last_error);
    _lines.push('');
    _lines.push('📬 '+t('Topic sottoscritti')+' ('+_sub.length+'):');
    if(_sub.length===0) _lines.push('   (nessuno)');
    else _sub.forEach(_t => _lines.push('   • '+_t));
    _lines.push('');
    _lines.push('🌲 '+t('Root topic visti')+' ('+_roots.length+' top):');
    if(_roots.length===0) _lines.push('   (nessun messaggio ricevuto)');
    else _roots.forEach(_r2 => _lines.push('   • '+_r2.root+' — '+_r2.count));
    _lines.push('');
    _lines.push('📡 '+t('Nodi visibili')+' ('+_senders.length+' top):');
    if(_senders.length===0) _lines.push('   (nessun sender)');
    else _senders.forEach(_s => _lines.push('   • '+_s.id+' — '+_s.count));
    if(_recent.length){
        _lines.push('');
        _lines.push('🕐 '+t('Ultimi topic')+' (sample):');
        _recent.slice(-10).forEach(_t2 => _lines.push('   • '+_t2));
    }
    if(_sugg.length){
        _lines.push('');
        _lines.push('💡 '+t('Suggerimenti'));
        const _map = {
            topic_no_wildcard: t('Topic senza wildcard: aggiungi /# per vedere tutti i sotto-canali'),
            connected_no_messages: t('Connesso ma 0 messaggi: verifica topic o broker'),
            mostly_not_envelope: t('La maggior parte dei messaggi non è ServiceEnvelope (forse altro formato MQTT)'),
            root_mismatch_subscribe: t('Il root topic dominante non coincide con il subscribe'),
            paho_missing: t('paho-mqtt non installato'),
            protobuf_missing: t('meshtastic protobuf non installato')
        };
        _sugg.forEach(_s => _lines.push('   ⚠️ '+(_map[_s]||_s)));
    }
    h43WriteOutput('h43-mqtt-output', _lines.join('\n'));
    h43RefreshStatus();
}

// STEP 9 — Setup rapido Italia: compila topic multipli + root msh/EU_868/IT
async function h43MqttQuickIt(){
    const _el = document.getElementById('h43-mqtt-topic');
    if(_el){
        _el.value = 'msh/EU_868/IT/#, msh/EU_868/#, msh/#';
    }
    const _broker = document.getElementById('h43-mqtt-broker');
    if(_broker && !_broker.value){
        _broker.value = 'mqtt.meshtastic.org';
    }
    const _port = document.getElementById('h43-mqtt-port');
    if(_port && !_port.value) _port.value = '1883';
    h43WriteOutput('h43-mqtt-output', '🇮🇹 '+t('Setup Italia compilato')+':\n'
        +' • '+t('Topic')+': msh/EU_868/IT/#, msh/EU_868/#, msh/#\n'
        +' • '+t('Broker')+': '+(_broker?_broker.value:'')+'\n\n'
        +t('Clicca "Salva config" e poi "Avvia bridge"'));
}

// Expose globally per gli onclick inline
window.h43RefreshStatus = h43RefreshStatus;
window.h43PkiList = h43PkiList;
window.h43PkiImportNode = h43PkiImportNode;
window.h43PkiDiscover = h43PkiDiscover;
window.h43TraceLoadIds = h43TraceLoadIds;
window.h43TraceRun = h43TraceRun;
window.h43MqttLoadConfig = h43MqttLoadConfig;
window.h43MqttSaveConfig = h43MqttSaveConfig;
window.h43MqttStart = h43MqttStart;
window.h43MqttStop = h43MqttStop;
window.h43MqttStatus = h43MqttStatus;
window.h43MqttDiagnose = h43MqttDiagnose;
window.h43MqttQuickIt = h43MqttQuickIt;

// ═══════════════════════════════════════════════════════════════════
// H4.4 — ADMIN CONTROL SUITE (30 AdminMessage commands)
// ═══════════════════════════════════════════════════════════════════
let _h44Catalog = null;   // { commands, families, config_types, module_config_types, channel_roles, ... }
let _h44SelCmd = null;    // selected command object

// Declarative arg schema for each of the 30 commands.
// Types: text, int, float, bool, select, json
//   select → options (static) OR options_source (one of: config_types, module_config_types, channel_roles)
const _H44_ARG_SCHEMA = {
    reboot:                {args: [
        {name:'seconds',  type:'int',   label_key:'h44_arg_seconds',  def:10, min:0, max:300},
        {name:'confirm',  type:'bool',  label_key:'h44_arg_confirm',  def:false, danger:true}
    ]},
    shutdown:              {args: [
        {name:'seconds',  type:'int',   label_key:'h44_arg_seconds',  def:10, min:0, max:300},
        {name:'confirm',  type:'bool',  label_key:'h44_arg_confirm',  def:false, danger:true}
    ]},
    factory_reset:         {args: [
        {name:'full_device', type:'bool', label_key:'h44_arg_full_device', def:true},
        {name:'confirm',     type:'bool', label_key:'h44_arg_confirm',     def:false, danger:true}
    ]},
    set_owner:             {args: [
        {name:'long_name',   type:'text', label_key:'h44_arg_long_name',   maxlen:40},
        {name:'short_name',  type:'text', label_key:'h44_arg_short_name',  maxlen:4},
        {name:'is_licensed', type:'bool', label_key:'h44_arg_is_licensed', def:false}
    ]},
    get_device_metadata:   {args: []},
    get_config:            {args: [
        {name:'config_type', type:'select', label_key:'h44_arg_config_type', options_source:'config_types', required:true}
    ]},
    set_config:            {args: [
        {name:'config_type', type:'select', label_key:'h44_arg_config_type', options_source:'config_types', required:true},
        {name:'values',      type:'json',   label_key:'h44_arg_values',      def:'{}'}
    ]},
    get_module_config:     {args: [
        {name:'module_type', type:'select', label_key:'h44_arg_module_type', options_source:'module_config_types', required:true}
    ]},
    set_module_config:     {args: [
        {name:'module_type', type:'select', label_key:'h44_arg_module_type', options_source:'module_config_types', required:true},
        {name:'values',      type:'json',   label_key:'h44_arg_values',      def:'{}'}
    ]},
    get_channel:           {args: [
        {name:'index', type:'int', label_key:'h44_arg_channel_index', def:0, min:0, max:7}
    ]},
    set_channel:           {args: [
        {name:'index', type:'int',    label_key:'h44_arg_channel_index', def:0, min:0, max:7, required:true},
        {name:'name',  type:'text',   label_key:'h44_arg_channel_name',  maxlen:12},
        {name:'role',  type:'select', label_key:'h44_arg_channel_role',  options_source:'channel_roles', def:'SECONDARY'},
        {name:'psk_base64', type:'text', label_key:'h44_arg_psk_base64', maxlen:64}
    ]},
    delete_channel:        {args: [
        {name:'index',   type:'int',  label_key:'h44_arg_channel_index', min:1, max:7, required:true},
        {name:'confirm', type:'bool', label_key:'h44_arg_confirm',       def:false, danger:true}
    ]},
    nodedb_reset:          {args: [
        {name:'confirm', type:'bool', label_key:'h44_arg_confirm', def:false, danger:true}
    ]},
    remove_by_nodenum:     {args: [
        {name:'node_num', type:'int', label_key:'h44_arg_node_num', required:true}
    ]},
    set_favorite:          {args: [
        {name:'node_num', type:'int', label_key:'h44_arg_node_num', required:true}
    ]},
    remove_favorite:       {args: [
        {name:'node_num', type:'int', label_key:'h44_arg_node_num', required:true}
    ]},
    set_ignored:           {args: [
        {name:'node_num', type:'int',  label_key:'h44_arg_node_num', required:true},
        {name:'ignore',   type:'bool', label_key:'h44_arg_ignore',   def:true}
    ]},
    toggle_muted:          {args: [
        {name:'node_num', type:'int', label_key:'h44_arg_node_num', required:true}
    ]},
    set_fixed_position:    {args: [
        {name:'lat', type:'float', label_key:'h44_arg_lat', required:true, min:-90, max:90},
        {name:'lon', type:'float', label_key:'h44_arg_lon', required:true, min:-180, max:180},
        {name:'alt', type:'int',   label_key:'h44_arg_alt', def:0}
    ]},
    remove_fixed_position: {args: []},
    set_time:              {args: [
        {name:'unix_ts', type:'int', label_key:'h44_arg_unix_ts'}
    ]},
    get_canned:            {args: []},
    set_canned:            {args: [
        {name:'messages', type:'text', label_key:'h44_arg_messages', maxlen:200, required:true}
    ]},
    get_ringtone:          {args: []},
    set_ringtone:          {args: [
        {name:'ringtone', type:'text', label_key:'h44_arg_ringtone', maxlen:230, required:true}
    ]},
    begin_edit:            {args: []},
    commit_edit:           {args: []},
    enter_dfu:             {args: [
        {name:'confirm', type:'bool', label_key:'h44_arg_confirm', def:false, danger:true}
    ]},
    exit_simulator:        {args: []},
    reboot_ota:            {args: [
        {name:'seconds', type:'int',  label_key:'h44_arg_seconds', def:10, min:0, max:300},
        {name:'confirm', type:'bool', label_key:'h44_arg_confirm', def:false, danger:true}
    ]}
};

async function h44Fetch(url, opts){
    try {
        const _r = await fetch(url, opts || {});
        let _data = null;
        try { _data = await _r.json(); } catch(_e) { _data = null; }
        return { ok: _r.ok, status: _r.status, data: _data };
    } catch(_err){
        return { ok: false, status: 0, data: { error: String(_err) } };
    }
}

function h44WriteOutput(txt){
    const _el = document.getElementById('h44-output');
    if (_el) _el.textContent = txt;
}

function h44ClearOutput(){ h44WriteOutput(''); }

async function h44LoadCatalog(){
    const _r = await h44Fetch('/api/admin/tools/index');
    if (!_r.ok || !_r.data || _r.data.success !== true) {
        h44WriteOutput(t('Errore caricamento catalogo Admin')+': '+JSON.stringify(_r.data));
        return null;
    }
    _h44Catalog = _r.data;
    return _h44Catalog;
}

function h44PopulateFamilySelect(){
    const _sel = document.getElementById('h44-family-select');
    if (!_sel || !_h44Catalog) return;
    // Keep first option "-- Tutte --"
    while (_sel.options.length > 1) _sel.remove(1);
    (_h44Catalog.families || []).forEach(function(f){
        const _o = document.createElement('option');
        _o.value = f;
        _o.textContent = f;
        _sel.appendChild(_o);
    });
}

function h44PopulateCommandSelect(family){
    const _sel = document.getElementById('h44-command-select');
    if (!_sel || !_h44Catalog) return;
    while (_sel.options.length > 1) _sel.remove(1);
    const _cmds = (_h44Catalog.commands || []).filter(function(c){
        return !family || c.family === family;
    });
    _cmds.forEach(function(c){
        const _o = document.createElement('option');
        _o.value = c.name;
        _o.textContent = (c.destructive ? '⚠️ ' : '') + c.name + '  ('+c.family+')';
        _sel.appendChild(_o);
    });
}

function h44OnFamilyChange(){
    const _sel = document.getElementById('h44-family-select');
    const _fam = _sel ? _sel.value : '';
    h44PopulateCommandSelect(_fam);
    _h44SelCmd = null;
    const _desc = document.getElementById('h44-command-desc');
    if (_desc) _desc.textContent = '';
    h44RenderArgsForm(null);
}

function h44OnCommandChange(){
    const _sel = document.getElementById('h44-command-select');
    const _name = _sel ? _sel.value : '';
    if (!_name || !_h44Catalog) { _h44SelCmd = null; h44RenderArgsForm(null); return; }
    _h44SelCmd = (_h44Catalog.commands || []).find(function(c){ return c.name === _name; }) || null;
    const _desc = document.getElementById('h44-command-desc');
    if (_desc && _h44SelCmd) {
        _desc.textContent = (_h44SelCmd.destructive ? '⚠️ DESTRUCTIVE — ' : '') + (_h44SelCmd.desc || '');
        _desc.style.color = _h44SelCmd.destructive ? 'var(--danger)' : 'var(--text-muted)';
    }
    h44RenderArgsForm(_h44SelCmd);
}

function h44RenderArgsForm(cmd){
    const _form = document.getElementById('h44-args-form');
    if (!_form) return;
    _form.innerHTML = '';
    if (!cmd) return;
    const _schema = _H44_ARG_SCHEMA[cmd.name];
    if (!_schema || !_schema.args || _schema.args.length === 0) {
        const _p = document.createElement('div');
        _p.style.cssText = 'font-size:0.72rem;color:var(--text-muted);font-style:italic;';
        _p.setAttribute('data-i18n', 'monitor.h44_no_args');
        _p.textContent = t('Nessun argomento richiesto');
        _form.appendChild(_p);
        return;
    }
    _schema.args.forEach(function(a){
        const _wrap = document.createElement('div');
        _wrap.style.cssText = 'display:flex;gap:0.5rem;align-items:center;flex-wrap:wrap;';
        const _lbl = document.createElement('label');
        _lbl.style.cssText = 'font-size:0.72rem;color:'+(a.danger?'var(--danger)':'var(--text-muted)')+';min-width:140px;';
        if (a.label_key) _lbl.setAttribute('data-i18n', 'monitor.'+a.label_key);
        _lbl.textContent = a.name + (a.required ? ' *' : '');
        _wrap.appendChild(_lbl);

        let _input;
        if (a.type === 'bool') {
            _input = document.createElement('input');
            _input.type = 'checkbox';
            _input.checked = !!a.def;
        } else if (a.type === 'select') {
            _input = document.createElement('select');
            _input.className = 'form-control';
            _input.style.flex = '1';
            let _opts = a.options || [];
            if (a.options_source && _h44Catalog) {
                _opts = _h44Catalog[a.options_source] || [];
            }
            if (!a.required) {
                const _o = document.createElement('option');
                _o.value = ''; _o.textContent = '—';
                _input.appendChild(_o);
            }
            _opts.forEach(function(v){
                const _o = document.createElement('option');
                _o.value = v; _o.textContent = v;
                if (a.def === v) _o.selected = true;
                _input.appendChild(_o);
            });
        } else if (a.type === 'json') {
            _input = document.createElement('textarea');
            _input.className = 'form-control';
            _input.rows = 4;
            _input.style.cssText = 'flex:1;font-family:monospace;font-size:0.72rem;';
            _input.value = (a.def !== undefined) ? a.def : '{}';
            _input.placeholder = '{"key": "value"}';
        } else {
            _input = document.createElement('input');
            _input.type = (a.type === 'int' || a.type === 'float') ? 'number' : 'text';
            if (a.type === 'float') _input.step = 'any';
            if (a.maxlen) _input.maxLength = a.maxlen;
            if (a.min !== undefined) _input.min = a.min;
            if (a.max !== undefined) _input.max = a.max;
            _input.className = 'form-control';
            _input.style.flex = '1';
            if (a.def !== undefined && a.def !== null) _input.value = String(a.def);
        }
        _input.id = 'h44-arg-' + a.name;
        _input.dataset.h44argtype = a.type;
        _input.dataset.h44argname = a.name;
        _wrap.appendChild(_input);
        _form.appendChild(_wrap);
    });
    // Re-apply i18n on newly-rendered form
    if (window.I18N && typeof window.I18N.apply === 'function') {
        try { window.I18N.apply(); } catch(_e){}
    }
}

function h44CollectArgs(){
    const _out = {};
    if (!_h44SelCmd) return _out;
    const _schema = _H44_ARG_SCHEMA[_h44SelCmd.name];
    if (!_schema) return _out;
    for (const a of _schema.args) {
        const _el = document.getElementById('h44-arg-'+a.name);
        if (!_el) continue;
        let _v;
        if (a.type === 'bool') {
            _v = !!_el.checked;
        } else if (a.type === 'int') {
            if (_el.value === '' || _el.value === null) {
                if (a.required) throw new Error(t('Campo richiesto')+': '+a.name);
                continue;
            }
            _v = parseInt(_el.value, 10);
            if (isNaN(_v)) throw new Error(t('Valore numerico non valido')+': '+a.name);
        } else if (a.type === 'float') {
            if (_el.value === '' || _el.value === null) {
                if (a.required) throw new Error(t('Campo richiesto')+': '+a.name);
                continue;
            }
            _v = parseFloat(_el.value);
            if (isNaN(_v)) throw new Error(t('Valore numerico non valido')+': '+a.name);
        } else if (a.type === 'json') {
            const _raw = (_el.value || '').trim();
            if (!_raw) { if (a.required) throw new Error(t('JSON richiesto')+': '+a.name); continue; }
            try { _v = JSON.parse(_raw); }
            catch(_e) { throw new Error(t('JSON non valido')+' ('+a.name+'): '+_e.message); }
        } else if (a.type === 'select') {
            _v = _el.value;
            if (!_v && a.required) throw new Error(t('Selezione richiesta')+': '+a.name);
            if (!_v) continue;
        } else {
            _v = _el.value || '';
            if (!_v && a.required) throw new Error(t('Campo richiesto')+': '+a.name);
            if (!_v) continue;
        }
        _out[a.name] = _v;
    }
    return _out;
}

async function h44Execute(){
    if (!_h44SelCmd) {
        h44WriteOutput(t('Seleziona prima un comando'));
        return;
    }
    let _args;
    try { _args = h44CollectArgs(); }
    catch(_e) { h44WriteOutput('⚠️ '+_e.message); return; }

    if (_h44SelCmd.destructive) {
        const _msg = t('ATTENZIONE: operazione distruttiva')+'\n\n' +
                     _h44SelCmd.name + '\n\n' + (_h44SelCmd.desc || '') +
                     '\n\n' + t('Confermi?');
        if (!confirm(_msg)) { h44WriteOutput(t('Annullato dall\u2019utente')); return; }
    }

    h44WriteOutput('⏳ '+t('Esecuzione in corso')+'...');
    const _r = await h44Fetch('/api/admin/execute', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({name: _h44SelCmd.name, args: _args})
    });
    const _prefix = _r.ok ? '✅ OK ' : '❌ '+_r.status+' ';
    h44WriteOutput(_prefix+(_h44SelCmd.name)+'\n\n'+JSON.stringify(_r.data, null, 2));
    // Refresh readiness badge after dispatch
    h44RefreshStatus();
}

async function h44RefreshStatus(){
    const _r = await h44Fetch('/api/admin/tools/status');
    const _badge = document.getElementById('h44-ready-badge');
    const _sTotal = document.getElementById('h44-stat-total');
    const _sDestr = document.getElementById('h44-stat-destr');
    const _sFam   = document.getElementById('h44-stat-fam');
    const _sIface = document.getElementById('h44-stat-iface');

    if (!_r.ok || !_r.data) {
        if (_badge) { _badge.textContent = '◌ '+t('Stato non disponibile'); _badge.style.borderColor = 'var(--border)'; }
        return;
    }
    const d = _r.data;
    if (_badge) {
        if (d.ready) {
            _badge.textContent = '🟢 '+t('Pronto');
            _badge.style.borderColor = 'var(--success, var(--accent))';
        } else {
            _badge.textContent = '🔴 '+t('Non pronto');
            _badge.style.borderColor = 'var(--danger)';
        }
    }
    if (_sTotal) _sTotal.textContent = d.total_commands ?? '—';
    if (_sDestr) _sDestr.textContent = d.destructive_commands ?? '—';
    if (_sFam)   _sFam.textContent   = d.commands_by_family ? Object.keys(d.commands_by_family).length : '—';
    if (_sIface) _sIface.textContent = d.has_interface ? '✓' : '—';

    // Lazy-load catalog the first time we become ready
    if (!_h44Catalog) {
        await h44LoadCatalog();
        if (_h44Catalog) {
            h44PopulateFamilySelect();
            h44PopulateCommandSelect('');
        }
    }
}

// Expose globally per gli onclick inline
window.h44RefreshStatus  = h44RefreshStatus;
window.h44OnFamilyChange = h44OnFamilyChange;
window.h44OnCommandChange = h44OnCommandChange;
window.h44Execute        = h44Execute;
window.h44ClearOutput    = h44ClearOutput;


// ═══════════════════════════════════════════════════════════
// FASE 4 — Soglie configurabili + preset FW standard
// ═══════════════════════════════════════════════════════════

// Schema descrittivo delle soglie per il rendering dinamico del form.
// key → {type, label_i18n_key, step, min/max}
const _F4_SCHEMA = [
    {key: "nodeinfo_min_interval_s", type: "number", step: 1,   min: 30,    max: 7200,  label: "f4_th_nodeinfo"},
    {key: "ch_util_max_pct",         type: "number", step: 0.1, min: 1,     max: 100,   label: "f4_th_chutil"},
    {key: "airtime_max_pct",         type: "number", step: 0.1, min: 1,     max: 100,   label: "f4_th_airtime"},
    {key: "rf_flood_per_min",        type: "number", step: 1,   min: 1,     max: 500,   label: "f4_th_rfflood"},
    {key: "mqtt_flood_per_min",      type: "number", step: 1,   min: 1,     max: 1000,  label: "f4_th_mqttflood"},
    {key: "hop_flood_threshold",     type: "number", step: 1,   min: 1,     max: 10,    label: "f4_th_hopflood"},
    {key: "spam_count_alert",        type: "number", step: 1,   min: 1,     max: 20,    label: "f4_th_spamalert"},
    {key: "weak_signal_rssi",        type: "number", step: 1,   min: -140,  max: -60,   label: "f4_th_rssi"},
    {key: "weak_signal_snr",         type: "number", step: 0.1, min: -25,   max: 15,    label: "f4_th_snr"},
];

async function f4Fetch(url, opts){
    try {
        const _r = await fetch(url, Object.assign({credentials:'same-origin'}, opts || {}));
        const _data = await _r.json().catch(()=>({}));
        if (!_r.ok) throw new Error(_data.error || _r.statusText);
        return _data;
    } catch (_e) {
        return {_error: _e.message || String(_e)};
    }
}

function f4SetStatus(msg, is_error){
    const _el = document.getElementById('f4-status');
    if (!_el) return;
    _el.textContent = msg || '';
    _el.style.color = is_error ? 'var(--danger)' : 'var(--success)';
}

function f4RenderThresholdsForm(thresholds){
    const _box = document.getElementById('f4-thresholds-form');
    if (!_box) return;
    _box.innerHTML = '';
    for (const _s of _F4_SCHEMA) {
        const _val = thresholds[_s.key];
        const _row = document.createElement('div');
        _row.style.cssText = "display:flex;flex-direction:column;gap:0.2rem;";
        const _lbl = document.createElement('label');
        _lbl.style.cssText = "font-size:0.7rem;color:var(--text-muted);";
        _lbl.setAttribute('data-i18n', 'monitor.' + _s.label);
        _lbl.textContent = _s.key;
        const _in = document.createElement('input');
        _in.type = _s.type; _in.step = _s.step; _in.min = _s.min; _in.max = _s.max;
        _in.className = 'form-control';
        _in.id = 'f4-in-' + _s.key;
        _in.value = (_val !== undefined && _val !== null) ? _val : '';
        _in.style.cssText = 'font-size:0.78rem;padding:0.3rem 0.4rem;';
        _row.appendChild(_lbl);
        _row.appendChild(_in);
        _box.appendChild(_row);
    }
    // Applica traduzioni alle label appena create
    if (typeof I18N !== 'undefined' && I18N.applyI18n) I18N.applyI18n();
}

async function f4RefreshThresholds(){
    const _res = await f4Fetch('/api/monitor/thresholds');
    if (_res._error) { f4SetStatus(_res._error, true); return; }
    const _badge = document.getElementById('f4-preset-badge');
    if (_badge) _badge.textContent = '◆ ' + t('Preset') + ': ' + (_res.preset || 'MediumFast');
    f4RenderThresholdsForm(_res);
    f4SetStatus(t('Caricamento') + ' ✓', false);
    setTimeout(()=>f4SetStatus('', false), 1200);
}

async function f4ApplyPreset(){
    const _sel = document.getElementById('f4-preset-select');
    if (!_sel || !_sel.value) { f4SetStatus(t('Seleziona un preset'), true); return; }
    const _preset = _sel.value;
    f4SetStatus(t('Caricamento') + '…', false);
    const _res = await f4Fetch('/api/monitor/thresholds/apply-preset', {
        method: 'POST',
        headers: {'Content-Type':'application/json'},
        body: JSON.stringify({preset: _preset}),
    });
    if (_res._error || _res.success === false) {
        f4SetStatus((_res._error || _res.error || t('Errore')), true);
        return;
    }
    f4RenderThresholdsForm(_res.thresholds || {});
    const _badge = document.getElementById('f4-preset-badge');
    if (_badge) _badge.textContent = '◆ ' + t('Preset') + ': ' + _preset;
    f4SetStatus(t('Preset applicato') + ' ✓', false);
    setTimeout(()=>f4SetStatus('', false), 1500);
}

async function f4SaveThresholds(){
    const _payload = {};
    for (const _s of _F4_SCHEMA) {
        const _in = document.getElementById('f4-in-' + _s.key);
        if (!_in) continue;
        const _v = _in.value.trim();
        if (_v === '') continue;
        const _n = Number(_v);
        if (Number.isFinite(_n)) _payload[_s.key] = _n;
    }
    if (Object.keys(_payload).length === 0) {
        f4SetStatus(t('Nessuna soglia modificata'), true);
        return;
    }
    f4SetStatus(t('Caricamento') + '…', false);
    const _res = await f4Fetch('/api/monitor/thresholds', {
        method: 'POST',
        headers: {'Content-Type':'application/json'},
        body: JSON.stringify(_payload),
    });
    if (_res._error) { f4SetStatus(_res._error, true); return; }
    f4RenderThresholdsForm(_res);
    f4SetStatus(t('Soglie salvate') + ' ✓', false);
    setTimeout(()=>f4SetStatus('', false), 1500);
}

async function f4ResetThresholds(){
    if (!confirm(t('Ripristinare tutte le soglie ai valori default (MediumFast)?'))) return;
    f4SetStatus(t('Caricamento') + '…', false);
    const _res = await f4Fetch('/api/monitor/thresholds', {
        method: 'POST',
        headers: {'Content-Type':'application/json'},
        body: JSON.stringify({reset: true}),
    });
    if (_res._error) { f4SetStatus(_res._error, true); return; }
    f4RenderThresholdsForm(_res);
    const _badge = document.getElementById('f4-preset-badge');
    if (_badge) _badge.textContent = '◆ ' + t('Preset') + ': ' + (_res.preset || 'MediumFast');
    f4SetStatus(t('Soglie resettate') + ' ✓', false);
    setTimeout(()=>f4SetStatus('', false), 1500);
}

// Expose globally per gli onclick inline
window.f4RefreshThresholds = f4RefreshThresholds;
window.f4ApplyPreset       = f4ApplyPreset;
window.f4SaveThresholds    = f4SaveThresholds;
window.f4ResetThresholds   = f4ResetThresholds;


