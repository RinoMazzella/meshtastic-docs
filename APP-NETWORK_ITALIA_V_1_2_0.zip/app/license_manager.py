# -*- coding: utf-8 -*-
"""
🔐 Meshtastic Italia Network App v1.1.0 — License Manager v2
Ed25519 Verify + Multi-URL Revocation + Anti-Tampering + Encrypted Cache
© 2026 🌐🥭MANGOLINK🥭🌐 — Tutti i diritti riservati
"""

import os, sys, json, uuid, hashlib, platform, subprocess, time, struct, socket
from datetime import datetime, timedelta
from pathlib import Path

_FP_SALT = b'MANGOLINK_MESHTASTIC_ITALIA_FP_v2_2026_ED25519'

REVOKE_URLS = [
    # ★ URL primario (unico funzionante) — Cloudflare Workers KV
    "https://meshtastic-italia.meshtastic-italia-network.workers.dev/revoked",
    # ★ URL futuri: aggiungere qui quando deployati (GitHub e Vercel rimossi: 404)
    # "https://raw.githubusercontent.com/MeshtasticItalia/license-server/main/revoked.json",
    # "https://meshtastic-italia-revoke.vercel.app/api/revoked",
]

GRACE_PERIOD_DAYS = 10
NTP_SERVERS = ['pool.ntp.org', 'time.google.com', 'time.windows.com', 'time.cloudflare.com']
MAX_CLOCK_DRIFT_SECS = 300

_EMBEDDED_PUB_KEY_OBF = None
_FALLBACK_PUB_KEY = None

def _load_or_init_pub_key():
    global _FALLBACK_PUB_KEY
    if _FALLBACK_PUB_KEY is not None:
        return _FALLBACK_PUB_KEY
    from app.license_crypto import load_key_from_file, deobfuscate_public_key
    app_dir = get_app_dir()
    for name in ['.pub_key', 'pub_key']:
        key_file = os.path.join(app_dir, name)
        if os.path.exists(key_file):
            try:
                key = load_key_from_file(key_file)
                if key and len(key) == 32:
                    _FALLBACK_PUB_KEY = key
                    return key
            except Exception:
                pass
    if _EMBEDDED_PUB_KEY_OBF is not None:
        try:
            key = deobfuscate_public_key(_EMBEDDED_PUB_KEY_OBF)
            if len(key) == 32:
                _FALLBACK_PUB_KEY = key
                return key
        except Exception:
            pass
    return None

# ═══════════════════════════════════════════════════════════
# FINGERPRINT HARDWARE v2 (5 fonti)
# ═══════════════════════════════════════════════════════════

def _get_cpu_id():
    system = platform.system()
    try:
        if system == 'Windows':
            result = subprocess.run(['wmic', 'cpu', 'get', 'ProcessorId'],
                capture_output=True, text=True, timeout=5, encoding='utf-8', errors='replace',
                creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
            for line in (result.stdout or '').split('\n'):
                line = line.strip()
                if line and line != 'ProcessorId': return line
        elif system == 'Darwin':
            result = subprocess.run(['sysctl', '-n', 'machdep.cpu.brand_string'],
                capture_output=True, text=True, timeout=5)
            return (result.stdout or '').strip()
        else:
            with open('/proc/cpuinfo', 'r', encoding='utf-8') as f:
                for line in f:
                    if 'model name' in line.lower() or 'serial' in line.lower():
                        return line.split(':')[1].strip()
    except Exception: pass
    return platform.processor() or 'unknown_cpu'

def _get_disk_id():
    system = platform.system()
    try:
        if system == 'Windows':
            result = subprocess.run(['wmic', 'diskdrive', 'get', 'SerialNumber'],
                capture_output=True, text=True, timeout=5, encoding='utf-8', errors='replace',
                creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
            for line in (result.stdout or '').split('\n'):
                line = line.strip()
                if line and line != 'SerialNumber': return line
        elif system == 'Darwin':
            result = subprocess.run(['system_profiler', 'SPHardwareDataType'],
                capture_output=True, text=True, timeout=5)
            for line in (result.stdout or '').split('\n'):
                if 'Serial Number' in line or 'Hardware UUID' in line:
                    return line.split(':')[1].strip()
        else:
            for p in ['/etc/machine-id', '/var/lib/dbus/machine-id']:
                pp = Path(p)
                if pp.exists(): return pp.read_text().strip()
    except Exception: pass
    return 'unknown_disk'

def _get_mac_address():
    try:
        mac = uuid.getnode()
        return ':'.join(f'{(mac >> i) & 0xFF:02x}' for i in range(40, -1, -8))
    except Exception: return 'unknown_mac'

def _get_motherboard_id():
    system = platform.system()
    try:
        if system == 'Windows':
            result = subprocess.run(['wmic', 'baseboard', 'get', 'SerialNumber'],
                capture_output=True, text=True, timeout=5, encoding='utf-8', errors='replace',
                creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
            for line in (result.stdout or '').split('\n'):
                line = line.strip()
                if line and line != 'SerialNumber' and 'be filled' not in line.lower(): return line
        elif system == 'Darwin':
            result = subprocess.run(['ioreg', '-rd1', '-c', 'IOPlatformExpertDevice'],
                capture_output=True, text=True, timeout=5)
            for line in (result.stdout or '').split('\n'):
                if 'IOPlatformSerialNumber' in line:
                    parts = line.split('"')
                    if len(parts) >= 4: return parts[-2]
        else:
            dmi = Path('/sys/class/dmi/id/board_serial')
            if dmi.exists(): return dmi.read_text().strip()
    except Exception: pass
    return 'unknown_board'

def _get_os_install_id():
    system = platform.system()
    try:
        if system == 'Windows':
            result = subprocess.run(
                ['reg', 'query', 'HKLM\\SOFTWARE\\Microsoft\\Cryptography', '/v', 'MachineGuid'],
                capture_output=True, text=True, timeout=5, encoding='utf-8', errors='replace',
                creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
            for line in (result.stdout or '').split('\n'):
                if 'MachineGuid' in line:
                    parts = line.strip().split()
                    if len(parts) >= 3: return parts[-1]
        elif system == 'Darwin':
            result = subprocess.run(['ioreg', '-rd1', '-c', 'IOPlatformExpertDevice'],
                capture_output=True, text=True, timeout=5)
            for line in (result.stdout or '').split('\n'):
                if 'IOPlatformUUID' in line:
                    parts = line.split('"')
                    if len(parts) >= 4: return parts[-2]
        else:
            p = Path('/etc/machine-id')
            if p.exists(): return p.read_text().strip()
    except Exception: pass
    return 'unknown_os_id'

def generate_fingerprint():
    cpu = _get_cpu_id()
    disk = _get_disk_id()
    mac = _get_mac_address()
    board = _get_motherboard_id()
    os_id = _get_os_install_id()
    raw = f"{cpu}|{disk}|{mac}|{board}|{os_id}".encode('utf-8')
    h1 = hashlib.sha256(_FP_SALT + raw + _FP_SALT).digest()
    h2 = hashlib.sha256(h1 + _FP_SALT + raw).hexdigest().upper()
    fp = h2[:16]
    return f"{fp[:4]}-{fp[4:8]}-{fp[8:12]}-{fp[12:16]}"

def fingerprint_raw(fp_formatted):
    return fp_formatted.replace('-', '')

# ═══════════════════════════════════════════════════════════
# ANTI-TAMPERING (v1.2.0 — con verifica firma Ed25519 .integrity)
# ═══════════════════════════════════════════════════════════

def _compute_module_hash(filepath):
    try:
        with open(filepath, 'rb') as f:
            return hashlib.sha256(f.read()).hexdigest()
    except Exception: return None

def _verify_integrity_signature():
    """
    Verifica la firma Ed25519 del file .integrity.
    Se .integrity ha un campo "signature", verifica che i checksums
    non siano stati rigenerati da qualcuno senza la chiave privata.
    Ritorna: True (firma valida o assente), False (firma invalida).
    """
    app_dir = os.path.dirname(os.path.abspath(__file__))
    integrity_path = os.path.join(app_dir, '.integrity')
    if not os.path.exists(integrity_path):
        return True  # Nessun file .integrity — OK (sviluppo)

    try:
        with open(integrity_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
    except Exception:
        return True  # File corrotto — lascia passare, gli altri check cattureranno

    signature_hex = data.get("signature")
    if not signature_hex:
        return True  # Nessuna firma — vecchio formato, OK

    # Ricostruisci il payload firmato (stessi campi usati nel build)
    try:
        sign_payload = json.dumps({
            "version": data.get("version", ""),
            "generated": data.get("generated", ""),
            "copyright": data.get("copyright", ""),
            "checksums": data.get("checksums", {})
        }, sort_keys=True, ensure_ascii=False).encode('utf-8')

        signature = bytes.fromhex(signature_hex)

        # Carica la chiave pubblica (stessa usata per le licenze)
        pub_key = _load_or_init_pub_key()
        if pub_key is None:
            return True  # Nessuna chiave pubblica — non possiamo verificare

        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
        public_key = Ed25519PublicKey.from_public_bytes(pub_key)
        public_key.verify(signature, sign_payload)
        return True  # Firma valida!

    except Exception:
        return False  # Firma non valida — file .integrity manomesso!

def _verify_integrity_checksums():
    """
    Verifica che i checksums SHA-256 in .integrity corrispondano ai file effettivi.
    Se .integrity e firmato, questa verifica e ridondante con la firma,
    ma fornisce diagnostica specifica su QUALE file e stato modificato.
    Ritorna: True (tutto OK), False (mismatch trovato).
    """
    app_dir = os.path.dirname(os.path.abspath(__file__))
    integrity_path = os.path.join(app_dir, '.integrity')
    if not os.path.exists(integrity_path):
        return True  # No .integrity — OK (ambiente sviluppo)

    try:
        with open(integrity_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        checksums = data.get("checksums", {})
        if not checksums:
            return True

        for filename, expected_hash in checksums.items():
            filepath = os.path.join(app_dir, filename)
            if not os.path.exists(filepath):
                continue  # File mancante — non e tampering, potrebbe essere un update
            actual_hash = _compute_module_hash(filepath)
            if actual_hash and actual_hash != expected_hash:
                return False  # File modificato!
        return True
    except Exception:
        return True  # Errore lettura — lascia passare

def verify_code_integrity():
    """
    Verifica anti-tampering a 3 livelli:
    1. Firma Ed25519 di .integrity (se presente) — impedisce rigenerazione checksums
    2. Checksums SHA-256 di .integrity — verifica che i file non siano stati modificati
    3. Module hashes cifrati (.module_hashes) — verifica legacy per i moduli Python
    """
    # ── Livello 1: Verifica firma Ed25519 di .integrity ──
    if not _verify_integrity_signature():
        return False  # Firma non valida — .integrity manomesso

    # ── Livello 2: Verifica checksums di .integrity ──
    if not _verify_integrity_checksums():
        # Se .integrity e firmato (non rigenerabile), il mismatch e tampering reale
        app_dir = os.path.dirname(os.path.abspath(__file__))
        integrity_path = os.path.join(app_dir, '.integrity')
        if os.path.exists(integrity_path):
            try:
                with open(integrity_path, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                if data.get("signature"):
                    return False  # Firmato + mismatch = tampering certo
            except Exception:
                pass
        # Non firmato — fallback al comportamento tollerante (legacy)

    # ── Livello 3: Module hashes legacy (.module_hashes) ──
    app_dir = os.path.dirname(os.path.abspath(__file__))
    hash_file = os.path.join(app_dir, '.module_hashes')
    critical = [
        os.path.join(app_dir, 'license_crypto.py'),
        os.path.join(app_dir, 'license_manager.py'),
    ]
    actual = []
    for mod in critical:
        if os.path.exists(mod): actual.append(mod)
        elif os.path.exists(mod + 'c'): actual.append(mod + 'c')
    if not actual: return True
    current_hashes = {}
    for mod in actual:
        h = _compute_module_hash(mod)
        if h: current_hashes[os.path.basename(mod)] = h
    if not os.path.exists(hash_file):
        try:
            from app.license_crypto import encrypt_cache
            fp = fingerprint_raw(generate_fingerprint())
            encrypted = encrypt_cache(current_hashes, fp)
            with open(hash_file, 'wb') as f: f.write(encrypted)
        except Exception: pass
        return True
    try:
        from app.license_crypto import decrypt_cache, encrypt_cache
        fp = fingerprint_raw(generate_fingerprint())
        with open(hash_file, 'rb') as f: raw = f.read()
        saved = decrypt_cache(raw, fp)
        if saved is None: return True
        mismatched = False
        for name, expected in saved.items():
            current = current_hashes.get(name)
            if current and current != expected:
                mismatched = True
                break
        if mismatched:
            # Check if mismatch is due to .py↔.pyc change (protect_app.py or Python upgrade)
            saved_names = set(saved.keys())
            current_names = set(current_hashes.keys())
            py_to_pyc = any(n.endswith('.py') and (n+'c') in current_names for n in saved_names)
            pyc_to_py = any(n.endswith('.pyc') and n[:-1] in current_names for n in saved_names)
            if py_to_pyc or pyc_to_py or saved_names != current_names:
                # File type changed (.py → .pyc or vice versa) — recalculate
                encrypted = encrypt_cache(current_hashes, fp)
                with open(hash_file, 'wb') as f: f.write(encrypted)
                return True
            # Same filenames but different hashes
            # Auto-rehash if license is valid (legitimate update, not tampering)
            # This prevents blocking users after app updates
            license_path = get_license_path()
            if os.path.exists(license_path):
                # License file exists → likely a legitimate update, rehash
                encrypted = encrypt_cache(current_hashes, fp)
                with open(hash_file, 'wb') as f: f.write(encrypted)
                return True
            # No license file + hash mismatch → suspicious
            return False
    except Exception: pass
    return True

# ═══════════════════════════════════════════════════════════
# NTP Anti clock-tampering
# ═══════════════════════════════════════════════════════════

def get_app_dir():
    """Ritorna la cartella app/ (struttura flat v1.2.0+)"""
    return os.path.dirname(os.path.abspath(__file__))

def get_license_path():
    return os.path.join(get_app_dir(), 'license.key')

def get_cache_path():
    return os.path.join(get_app_dir(), '.license_cache_v2')

def _get_ntp_time():
    NTP_EPOCH = 2208988800
    for server in NTP_SERVERS:
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            sock.settimeout(3)
            data = b'\x1b' + 47 * b'\0'
            sock.sendto(data, (server, 123))
            response, _ = sock.recvfrom(1024)
            sock.close()
            if len(response) >= 48:
                t = struct.unpack('!I', response[40:44])[0]
                return datetime.fromtimestamp(t - NTP_EPOCH)
        except Exception: continue
    # Fallback: HTTPS Date header
    try:
        import urllib.request
        req = urllib.request.Request('https://www.google.com', method='HEAD')
        req.add_header('User-Agent', 'MeshtasticItaliaApp/1.1.0')
        resp = urllib.request.urlopen(req, timeout=5)
        date_str = resp.headers.get('Date', '')
        if date_str:
            from email.utils import parsedate_to_datetime
            return parsedate_to_datetime(date_str).replace(tzinfo=None)
    except Exception: pass
    return None

def _verify_system_clock():
    ntp_time = _get_ntp_time()
    if ntp_time is None: return (None, None, 0)
    local_time = datetime.now()
    drift = abs((local_time - ntp_time).total_seconds())
    if drift > MAX_CLOCK_DRIFT_SECS: return (False, ntp_time, drift)
    return (True, ntp_time, drift)

# ═══════════════════════════════════════════════════════════
# MULTI-URL REVOCATION + Challenge-Response
# ═══════════════════════════════════════════════════════════

def _check_local_revoked_json(revoke_id):
    """Controlla il file revoked.json locale (aggiornato dall'admin tool)"""
    local_path = os.path.join(get_app_dir(), 'revoked.json')
    try:
        if os.path.exists(local_path):
            with open(local_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            revoked_list = data.get("revoked", [])
            if revoke_id in revoked_list:
                return True
    except Exception:
        pass
    return False

def _check_revocation_online(revoke_id, fp_raw=None):
    fp = fp_raw or fingerprint_raw(generate_fingerprint())

    # ── STEP 0: Se revoke_id vuoto, non revocabile (licenze vecchie) ──
    if not revoke_id:
        print("  [REVOKE] revoke_id vuoto — licenza non revocabile")
        return (False, GRACE_PERIOD_DAYS)

    # ── STEP 1: Controlla file revoked.json locale (admin tool sync) ──
    if _check_local_revoked_json(revoke_id):
        print(f"  [REVOKE] ✓ Trovato in revoked.json LOCALE — revoke_id={revoke_id[:8]}...")
        _save_cache({
            "last_check": datetime.now().isoformat(),
            "revoked_list": [revoke_id], "online": True,
            "source": "local_revoked_json",
        }, fp)
        return (True, GRACE_PERIOD_DAYS)

    # ── STEP 2: Controlla URL remoti (3 fonti indipendenti) ──
    _last_revoke_errors = []
    _urls_checked = 0
    print(f"  [REVOKE] Checking {len(REVOKE_URLS)} URL remoti per revoke_id={revoke_id[:8]}...")
    for url in REVOKE_URLS:
        try:
            import urllib.request
            _urls_checked += 1
            timestamp = str(int(time.time()))
            challenge = hashlib.sha256(f"{revoke_id}:{timestamp}:{fp}".encode()).hexdigest()[:16]
            sep = '&' if '?' in url else '?'
            full_url = f"{url}{sep}t={timestamp}&c={challenge}"
            req = urllib.request.Request(full_url, headers={
                'User-Agent': 'MeshtasticItaliaApp/1.2.0',
                'X-App-Fingerprint': fp[:8], 'X-Challenge': challenge,
            })
            response = urllib.request.urlopen(req, timeout=10)
            data = json.loads(response.read().decode('utf-8'))

            # Validazione risposta: deve avere il campo "revoked" (lista)
            if not isinstance(data.get("revoked"), list):
                _err = f"{url}: risposta non valida (no revoked list)"
                _last_revoke_errors.append(_err)
                print(f"  [REVOKE] ✗ {_err}")
                continue

            revoked_list = data["revoked"]
            is_revoked = revoke_id in revoked_list
            print(f"  [REVOKE] ✓ URL #{_urls_checked} OK — {len(revoked_list)} revocati, this_revoked={is_revoked}")
            cache_data = {
                "last_check": datetime.now().isoformat(),
                "revoked_list": revoked_list, "online": True,
                "source": url.split('/')[2], "challenge_used": challenge,
            }
            _save_cache(cache_data, fp)
            return (is_revoked, GRACE_PERIOD_DAYS)
        except Exception as _e:
            _err = f"{url}: {str(_e)[:100]}"
            _last_revoke_errors.append(_err)
            print(f"  [REVOKE] ✗ URL #{_urls_checked} FALLITO — {_err}")
            continue

    # ── STEP 3: Tutti URL falliti → fallback cache offline ──
    print(f"  [REVOKE] ⚠ TUTTI i {len(REVOKE_URLS)} URL falliti! Fallback cache offline...")
    # Log errori per diagnostica (visibili in /api/license/diagnose)
    global _last_revocation_errors
    _last_revocation_errors = _last_revoke_errors
    return _check_cache_offline(revoke_id, fp)

# Variabile globale per diagnostica errori revoca
_last_revocation_errors = []

def _save_cache(data, fp):
    try:
        from app.license_crypto import encrypt_cache
        encrypted = encrypt_cache(data, fp)
        with open(get_cache_path(), 'wb') as f: f.write(encrypted)
    except Exception: pass

def _check_cache_offline(revoke_id, fp):
    cache_path = get_cache_path()
    try:
        if os.path.exists(cache_path):
            from app.license_crypto import decrypt_cache
            with open(cache_path, 'rb') as f: raw = f.read()
            cache = decrypt_cache(raw, fp)
            if cache is None:
                # Cache corrotto o fingerprint cambiato → NON dare grace period
                # Impedisce bypass tramite cancellazione/corruzione cache
                try: os.remove(cache_path)
                except OSError: pass
                return (None, 0)  # Forza connessione internet
            last_check = datetime.fromisoformat(cache.get("last_check", "2020-01-01"))
            days_offline = (datetime.now() - last_check).days
            grace_left = max(0, GRACE_PERIOD_DAYS - days_offline)
            if revoke_id in cache.get("revoked_list", []): return (True, grace_left)
            return (None, grace_left) if grace_left > 0 else (None, 0)
        else:
            # Nessuna cache → mai verificato online → forza connessione
            # Impedisce bypass tramite cancellazione file .license_cache_v2
            return (None, 0)
    except Exception: return (None, 0)  # Errore = forza connessione

# ═══════════════════════════════════════════════════════════
# VERIFICA COMPLETA
# ═══════════════════════════════════════════════════════════

def verify_license():
    fp = generate_fingerprint()
    result = {
        "status": "free", "fingerprint": fp, "expires": None, "days_left": 0,
        "grace_days_left": GRACE_PERIOD_DAYS, "online_verified": False,
        "user": None, "message": "Nessuna licenza trovata. Modalità FREE.",
        "level": "FREE", "security_version": "v2-ed25519"
    }

    if not verify_code_integrity():
        result["status"] = "tampered"
        result["message"] = "⚠️ Integrità del codice compromessa. Reinstalla l'app."
        return result

    license_path = get_license_path()
    if not os.path.exists(license_path): return result

    pub_key = _load_or_init_pub_key()
    if pub_key is None:
        data = _try_v1_license(license_path)
        if data is not None:
            result["message"] = "⚠️ Licenza formato v1. Contatta l'admin per upgrade a v2."
            result["status"] = "invalid"
        else:
            result["message"] = "Chiave pubblica non trovata. Metti pub_key nella cartella app."
        return result

    try:
        from app.license_crypto import verify_and_decrypt_license
        with open(license_path, 'rb') as f: file_data = f.read()
        data = verify_and_decrypt_license(file_data, pub_key)
        if data is None:
            data = _try_v1_license(license_path)
            if data is not None:
                result["security_version"] = "v1-legacy"
            else:
                result["status"] = "invalid"
                result["message"] = "Firma digitale non valida. File licenza corrotto o contraffatto."
                return result
    except Exception as e:
        result["status"] = "invalid"
        result["message"] = f"Errore lettura licenza: {str(e)}"
        return result

    license_fp = data.get("fp", "").replace('-', '')
    my_fp = fingerprint_raw(fp)
    if license_fp != my_fp:
        result["status"] = "invalid"
        result["message"] = "Licenza non valida per questo PC. Codice macchina non corrisponde."
        return result

    expires = data.get("expires", "unlimited")
    if expires != "unlimited":
        try:
            exp_date = datetime.fromisoformat(expires)
            clock_ok, ntp_time, drift = _verify_system_clock()
            if clock_ok is False:
                now = ntp_time
                result["clock_warning"] = f"⚠️ Orologio non sincronizzato (scarto: {int(drift)}s)"
            elif clock_ok is True: now = ntp_time
            else:
                now = datetime.now()
                result["ntp_warning"] = "⚠️ Impossibile verificare l'ora via NTP. Usando orologio locale."
            if now > exp_date:
                result["status"] = "expired"
                result["expires"] = expires; result["days_left"] = 0
                result["level"] = data.get("level", "BASE")
                result["message"] = f"Licenza scaduta il {expires}. Contatta la community."
                return result
            result["days_left"] = (exp_date - now).days
            result["expires"] = expires
        except Exception:
            # Formato data scadenza non valido → tratta come scaduta per sicurezza
            result["status"] = "expired"
            result["level"] = data.get("level", "BASE")
            result["message"] = "Formato data scadenza non valido nella licenza."
            return result
    else:
        result["days_left"] = -1
        result["expires"] = "unlimited"

    revoke_id = data.get("revoke_id", "")
    online_ok, grace_left = _check_revocation_online(revoke_id, fp_raw=my_fp)
    result["online_verified"] = online_ok is not None
    result["grace_days_left"] = grace_left

    if online_ok == True:
        result["status"] = "revoked"
        result["message"] = "Licenza revocata dall'amministratore."
        return result
    if grace_left <= 0 and online_ok is None:
        result["status"] = "invalid"
        result["message"] = f"Connetti a internet per verificare (offline da più di {GRACE_PERIOD_DAYS} giorni)."
        return result

    level = data.get("level", "BASE").upper()
    result["status"] = level.lower()
    result["level"] = level
    result["user"] = data.get("user", "")
    sig_mark = " — Firma digitale verificata ✓" if result.get("security_version") == "v2-ed25519" else ""
    if level == "PRO":
        result["message"] = f"⭐ Licenza PRO attivata{sig_mark}"
    elif level == "PRO_MOD":
        result["status"] = "pro_mod"
        result["message"] = f"🔧 Licenza PRO+MOD attivata{sig_mark}"
    else:
        result["message"] = f"🟢 Licenza BASE attivata{sig_mark}"
    return result

def _try_v1_license(license_path):
    try:
        from app.license_crypto import decrypt_license_v1, load_key_from_file
        with open(license_path, 'rb') as f: file_data = f.read()
        if not file_data.startswith(b'MSHIT01\x00'): return None
        app_dir = get_app_dir()
        for name in ['.verify_key', 'verify_key']:
            key_file = os.path.join(app_dir, name)
            if os.path.exists(key_file):
                key = load_key_from_file(key_file)
                if key:
                    data = decrypt_license_v1(file_data, key)
                    if data: return data
    except Exception: pass
    return None

# ═══════════════════════════════════════════════════════════
# API Frontend
# ═══════════════════════════════════════════════════════════

def get_license_info():
    result = verify_license()
    # Imposta grace_percent per TUTTE le licenze valide (online o offline)
    if result["status"] not in ["free", "invalid", "tampered", "expired", "revoked"]:
        result.setdefault("grace_percent", 100)
    if not result["online_verified"] and result["status"] not in ["free", "invalid", "tampered"]:
        grace = result.get("grace_days_left", GRACE_PERIOD_DAYS)
        if grace < GRACE_PERIOD_DAYS:
            offline_days = GRACE_PERIOD_DAYS - grace
            result["offline_warning"] = f"⚠️ Offline da {offline_days} giorni. Connetti entro {grace} giorni."
            result["grace_percent"] = round(grace / GRACE_PERIOD_DAYS * 100)
        elif grace == GRACE_PERIOD_DAYS and result["status"] not in ["free"]:
            result["grace_percent"] = 100
    status = result["status"]
    sections = {
        "guida": True, "flash": True, "tecnica": True,
        "assistente": True, "links": True,
        "cli": False, "nodo": False, "dev": False,
        "config_auto": False, "config_manual": False,
        "config_pro": False, "config_mod": False
    }
    if status in ["base", "pro", "pro_mod"]:
        sections.update({"cli": True, "nodo": True, "dev": True, "config_auto": True, "config_manual": True})
    if status in ["pro", "pro_mod"]:
        sections["config_pro"] = True
    if status == "pro_mod":
        sections["config_mod"] = True
    result["sections"] = sections
    return result

def reload_license():
    """Ricarica licenza: resetta cache revoca + chiave pubblica per verifica pulita"""
    global _FALLBACK_PUB_KEY
    _FALLBACK_PUB_KEY = None
    # Cancella cache revoca per forzare nuova verifica (anche locale)
    cache_path = get_cache_path()
    try:
        if os.path.exists(cache_path):
            os.remove(cache_path)
    except OSError:
        pass
    return get_license_info()

# ═══════════════════════════════════════════════════════════
# RESET CACHE LICENZA
# ═══════════════════════════════════════════════════════════

def reset_license_cache():
    """
    Cancella cache e hash per forzare una verifica pulita.
    Utile quando anti-tampering o cache sono corrotti.
    Ritorna lo stato dei file eliminati.
    """
    results = []
    app_dir = os.path.dirname(os.path.abspath(__file__))
    root_dir = get_app_dir()

    # 1. Cancella .module_hashes (anti-tampering)
    hash_file = os.path.join(app_dir, '.module_hashes')
    if os.path.exists(hash_file):
        try:
            os.remove(hash_file)
            results.append({"file": ".module_hashes", "deleted": True})
        except Exception as e:
            results.append({"file": ".module_hashes", "deleted": False, "error": str(e)})
    else:
        results.append({"file": ".module_hashes", "deleted": False, "reason": "non presente"})

    # 2. Cancella .license_cache_v2 (cache revoca online)
    cache_file = get_cache_path()
    if os.path.exists(cache_file):
        try:
            os.remove(cache_file)
            results.append({"file": ".license_cache_v2", "deleted": True})
        except Exception as e:
            results.append({"file": ".license_cache_v2", "deleted": False, "error": str(e)})
    else:
        results.append({"file": ".license_cache_v2", "deleted": False, "reason": "non presente"})

    # 3. Reset chiave pubblica in memoria
    global _FALLBACK_PUB_KEY
    _FALLBACK_PUB_KEY = None
    results.append({"file": "pub_key (memoria)", "deleted": True})

    # 4. Verifica file licenza presenti
    license_exists = os.path.exists(get_license_path())
    pub_key_exists = any(
        os.path.exists(os.path.join(root_dir, n)) for n in ['.pub_key', 'pub_key']
    )

    return {
        "results": results,
        "license_file": license_exists,
        "pubkey_file": pub_key_exists,
        "message": "Cache resettata. Clicca 'Verifica Licenza' per riprovare."
    }

# ═══════════════════════════════════════════════════════════
# DIAGNOSTICA LICENZA (Agent step-by-step)
# ═══════════════════════════════════════════════════════════

def diagnose_license():
    """
    Esegue ogni step di verifica separatamente e ritorna un report
    dettagliato per debug. Usato dall'endpoint /api/license/diagnose.
    """
    steps = []
    fp = generate_fingerprint()
    fp_raw_val = fingerprint_raw(fp)

    # ── Step 1: Fingerprint generato ──
    steps.append({
        "id": "fingerprint",
        "ok": bool(fp and len(fp) == 19),  # XXXX-XXXX-XXXX-XXXX
        "label": "Fingerprint hardware generato",
        "detail": fp if fp else "Impossibile generare fingerprint"
    })

    # ── Step 2: Integrità codice (anti-tampering) ──
    integrity_ok = verify_code_integrity()
    # Dettaglio specifico sulla firma
    integrity_detail = "Hash moduli verificato"
    if not integrity_ok:
        if not _verify_integrity_signature():
            integrity_detail = "Firma .integrity non valida — file manomesso o rigenerato senza chiave"
        elif not _verify_integrity_checksums():
            integrity_detail = "Checksums .integrity non corrispondono — file dell'app modificati"
        else:
            integrity_detail = "Hash mismatch — reinstalla l'app o cancella .module_hashes"
    else:
        sig_ok = _verify_integrity_signature()
        chk_ok = _verify_integrity_checksums()
        if sig_ok and chk_ok:
            integrity_detail = "Anti-tampering OK (firma Ed25519 + checksums + module hashes)"
    steps.append({
        "id": "integrity",
        "ok": integrity_ok,
        "label": "Integrità codice (anti-tampering v2 con firma Ed25519)",
        "detail": integrity_detail
    })

    # ── Step 3: File license.key presente ──
    license_path = get_license_path()
    lic_exists = os.path.exists(license_path)
    lic_size = 0
    if lic_exists:
        try:
            lic_size = os.path.getsize(license_path)
        except Exception:
            pass
    steps.append({
        "id": "license_file",
        "ok": lic_exists and lic_size > 100,
        "label": "File license.key presente",
        "detail": f"Trovato ({lic_size} bytes)" if lic_exists else f"Non trovato in: {os.path.dirname(license_path)}"
    })

    if not lic_exists:
        # Senza license.key i prossimi step non hanno senso
        steps.append({"id": "pubkey_file", "ok": False, "label": "File pub_key presente", "detail": "Skippato — license.key non trovato"})
        steps.append({"id": "signature", "ok": False, "label": "Firma digitale Ed25519", "detail": "Skippato — license.key non trovato"})
        steps.append({"id": "fingerprint_match", "ok": False, "label": "Fingerprint corrisponde", "detail": "Skippato — license.key non trovato"})
        steps.append({"id": "expiry", "ok": False, "label": "Scadenza licenza", "detail": "Skippato — license.key non trovato"})
        steps.append({"id": "revocation", "ok": False, "label": "Stato revoca", "detail": "Skippato — license.key non trovato"})
        return {"fingerprint": fp, "steps": steps, "summary": "free", "message": "License.key non trovato. Metti il file nella cartella app."}

    # ── Step 4: File pub_key presente e valido ──
    pub_key = _load_or_init_pub_key()
    pub_ok = pub_key is not None and len(pub_key) == 32
    pub_detail = "Chiave pubblica caricata (32 bytes Ed25519)" if pub_ok else "Non trovato — metti pub_key nella cartella app"
    if pub_key and len(pub_key) != 32:
        pub_detail = f"Dimensione errata: {len(pub_key)} bytes (attesi 32)"
    steps.append({
        "id": "pubkey_file",
        "ok": pub_ok,
        "label": "File pub_key presente",
        "detail": pub_detail
    })

    if not pub_ok:
        steps.append({"id": "signature", "ok": False, "label": "Firma digitale Ed25519", "detail": "Skippato — pub_key mancante o invalido"})
        steps.append({"id": "fingerprint_match", "ok": False, "label": "Fingerprint corrisponde", "detail": "Skippato — pub_key mancante"})
        steps.append({"id": "expiry", "ok": False, "label": "Scadenza licenza", "detail": "Skippato — pub_key mancante"})
        steps.append({"id": "revocation", "ok": False, "label": "Stato revoca", "detail": "Skippato — pub_key mancante"})
        return {"fingerprint": fp, "steps": steps, "summary": "invalid", "message": "Pub_key mancante o invalido."}

    # ── Step 5: Firma digitale Ed25519 ──
    data = None
    sig_ok = False
    sig_detail = ""
    crypto_version = "v2-ed25519"
    try:
        from app.license_crypto import verify_and_decrypt_license
        with open(license_path, 'rb') as f:
            file_data = f.read()
        data = verify_and_decrypt_license(file_data, pub_key)
        if data is not None:
            sig_ok = True
            sig_detail = "Firma Ed25519 + HMAC-SHA256 validi"
        else:
            # Prova v1
            data = _try_v1_license(license_path)
            if data is not None:
                sig_ok = True
                sig_detail = "Formato v1 legacy — contatta admin per upgrade v2"
                crypto_version = "v1-legacy"
            else:
                sig_detail = "Firma non valida — file corrotto o chiave pubblica errata"
    except Exception as e:
        sig_detail = f"Errore verifica: {str(e)}"

    steps.append({
        "id": "signature",
        "ok": sig_ok,
        "label": "Firma digitale Ed25519",
        "detail": sig_detail
    })

    if not sig_ok or data is None:
        steps.append({"id": "fingerprint_match", "ok": False, "label": "Fingerprint corrisponde", "detail": "Skippato — firma non valida"})
        steps.append({"id": "expiry", "ok": False, "label": "Scadenza licenza", "detail": "Skippato — firma non valida"})
        steps.append({"id": "revocation", "ok": False, "label": "Stato revoca", "detail": "Skippato — firma non valida"})
        return {"fingerprint": fp, "steps": steps, "summary": "invalid", "message": "Firma digitale non valida."}

    # ── Step 6: Fingerprint corrisponde ──
    license_fp = data.get("fp", "").replace('-', '')
    fp_match = license_fp == fp_raw_val
    steps.append({
        "id": "fingerprint_match",
        "ok": fp_match,
        "label": "Fingerprint corrisponde",
        "detail": f"Licenza: {license_fp[:8]}... | PC: {fp_raw_val[:8]}..." if not fp_match else "Fingerprint licenza = fingerprint PC"
    })

    if not fp_match:
        steps.append({"id": "expiry", "ok": False, "label": "Scadenza licenza", "detail": "Skippato — fingerprint non corrisponde"})
        steps.append({"id": "revocation", "ok": False, "label": "Stato revoca", "detail": "Skippato — fingerprint non corrisponde"})
        return {"fingerprint": fp, "steps": steps, "summary": "invalid", "message": "Licenza generata per un altro PC."}

    # ── Step 7: Scadenza ──
    expires = data.get("expires", "unlimited")
    exp_ok = True
    exp_detail = ""
    days_left = -1

    if expires == "unlimited":
        exp_detail = "Licenza illimitata"
        days_left = -1
    else:
        try:
            exp_date = datetime.fromisoformat(expires)
            clock_ok, ntp_time, drift = _verify_system_clock()
            now = ntp_time if ntp_time else datetime.now()
            ntp_note = ""
            if clock_ok is None:
                ntp_note = " (NTP non raggiungibile, orologio locale)"
            elif clock_ok is False:
                ntp_note = f" (orologio desincronizzato, drift: {int(drift)}s)"

            if now > exp_date:
                exp_ok = False
                exp_detail = f"Scaduta il {expires.split('T')[0]}{ntp_note}"
                days_left = 0
            else:
                days_left = (exp_date - now).days
                exp_detail = f"Valida — scade il {expires.split('T')[0]} ({days_left} giorni){ntp_note}"
        except Exception as e:
            exp_ok = False
            exp_detail = f"Formato data non valido: {expires}"

    steps.append({
        "id": "expiry",
        "ok": exp_ok,
        "label": "Scadenza licenza",
        "detail": exp_detail
    })

    # ── Step 8: Revoca online ──
    revoke_id = data.get("revoke_id", "")
    rev_ok = True
    rev_detail = ""

    if not revoke_id:
        rev_detail = "Nessun revoke_id nella licenza (non revocabile online)"
    else:
        try:
            online_result, grace_left = _check_revocation_online(revoke_id, fp_raw=fp_raw_val)
            if online_result is True:
                rev_ok = False
                rev_detail = "REVOCATA dall'amministratore"
            elif online_result is False:
                rev_detail = f"Non revocata — verifica online OK (grace: {grace_left} giorni)"
            elif online_result is None:
                if grace_left > 0:
                    rev_detail = f"Offline — grace period: {grace_left}/{GRACE_PERIOD_DAYS} giorni"
                else:
                    rev_ok = False
                    rev_detail = f"Offline da oltre {GRACE_PERIOD_DAYS} giorni — connetti a internet"
        except Exception as e:
            rev_detail = f"Errore controllo revoca: {str(e)}"

    # Aggiungi dettaglio errori connessione remota (se disponibili)
    _rev_errors = _last_revocation_errors if _last_revocation_errors else []
    steps.append({
        "id": "revocation",
        "ok": rev_ok,
        "label": "Stato revoca",
        "detail": rev_detail,
        "remote_errors": _rev_errors,
        "revoke_urls": REVOKE_URLS,
    })

    # ── Riepilogo finale ──
    all_ok = all(s["ok"] for s in steps)
    level = data.get("level", "BASE").upper()
    user = data.get("user", "")

    if not exp_ok:
        summary = "expired"
        msg = "Licenza scaduta."
    elif not rev_ok:
        summary = "revoked"
        msg = "Licenza revocata."
    elif all_ok:
        summary = level.lower()
        level_labels = {"BASE": "BASE", "PRO": "PRO", "PRO_MOD": "PRO+MOD"}
        msg = f"Licenza {level_labels.get(level, level)} attiva — tutti i check superati."
    else:
        summary = "invalid"
        msg = "Alcuni check falliti."

    return {
        "fingerprint": fp,
        "steps": steps,
        "summary": summary,
        "level": level,
        "user": user,
        "expires": expires,
        "days_left": days_left,
        "crypto_version": crypto_version,
        "message": msg
    }
