# -*- coding: utf-8 -*-
"""
license_manager — Protected Module
© 2026 MANGOLINK — Tutti i diritti riservati.
Questo modulo e protetto. Il sorgente originale e cifrato.
Compatibile con Python 3.9+ su Windows/macOS/Linux.
"""

import hashlib, zlib, base64, types, sys, os

# ══ Payload cifrato ══
_PAYLOAD = (
    "yo1nrtX3vjWqhf2Ca7dge4OrahPf3y4Hmu15gXZCA6zbLOa021c7Zz5OF8pV2TSCeS+H1LdFqn0/"
    "saGOci8ZaLmj6lJLdl9G09jpJ5FYmw/dqitCJzFRM+B7wOXJjXtZGHsD30h9mfRPXMGjFNdakNof"
    "Oo0l1RUMtY8ub9G5LbPU5HsUUWezyuKobkeiP0lA0DutszVrsYpkQwVfYTjs5Pzqc6k+hvEEA52z"
    "E9IB3dBmVzvWosejOsRElA0WM/a45QgnLFxjczffgtMLpodc1M4UOQZY9I6JdpaPJhR9PlDdGvom"
    "uoQSrFIRx/fVbxu1HihQLAyUl55Pd43rBDDxpHR4NuxwZrIDx6SZA9mDHHZeFR5MRVeguhbwZW+d"
    "SYRCPepSyErxEaLuW80uV/qEGh8HApny+k541u8Ek6RR+ez7kBEebNmaxjDQja0SIpRpiNXsi1KR"
    "DNcLYkb/3PetmENvSEayBagOQEW7Sz8ifWniPegpws0WjDUKiDsF93PdjkOHdO/WftVKJL4lBgj7"
    "0t6rRVv0NCxeUBRlw+BXTIxOI2E3+vfmykvZ80PZuYgpMNhx7NT+5jA220aY7FEMAgOMievBSJyW"
    "uuQ5oxTDm2iUFPtvaL1/NoUtCuj3/MBt3W8RL47o2u4ACXVE2Lusoxv5dsRf9O5MYGO+bWrzQKwO"
    "m3m6WMUAYNeuGXUXD+YFvnB67Txp/FnPqTblTvqMhYRNvugroVAaxU/LRzCEFN7kwzM/c3KsnSpO"
    "k3ILlrQWiB0kY9EGohCgXNlhFe3EgRT/koZ8wPdQJZYZWUFcZEN5Y/bE0lykmNAfwPGB2z0uD+oJ"
    "ZMM8Ie9tCtk1Gkoc+qoGMOmAe9TnUCO+XAmgak0+NM01SEXjwdbsf7EqX9PN9LRRMCN1gKPtjbci"
    "j7IKqMDKmtJtXnu2S2mcy3gBQfHLlNAAqoFY7kB5YhUrV4Z6I4BxJp8wefTYzA//xuLHwnn74a4z"
    "4yGEkJI0FzlBiDLoCOQQJmrc1kupGo3dl4vItGtRrndVs7PyjQgThilScjxejHSAdYeogq9WhZOm"
    "j8sNqEfFkAxqqLGlZuYUQTTdJZ+6dzCuEG93f7xt9E0cwW8yso4CCq4N2DY8HPUN1bXobsDCKW29"
    "DgQzjLOKPlUsYVoVzc6hzQbrAJRsxn+hHOhxiXkVvu321MvxPqLx+UxiwAK1Ap/0eMvlyIbO8z0t"
    "bnEESZTWwaUiDEUfcsJ4zovW1vjPxCBAF4WKvwzIkVtP5G5DW14ojR3U5Qt1R5rlsU8ginqmk4/w"
    "NFtI5cKMkLW7Krpf6XkWVmXQhVHNL+4slUshyEnZZ4reC1ytutC40QKxr746k45V7JfNShVJSn/q"
    "1y2OPfRzCG71sM16duq2DaKsMonmynvMFdGtkgeC32fTxZCWBVG64MB9Eq75+7stjFdWSpu+n8/E"
    "YWsD2Y9jplQSJ28hlkSEvVGNoZWy5Br5yrK13EzMZlfehX+wgMaBAdQEQBwV9MB3DC41bU6Tx1oq"
    "PiyhgTnNoX3mwd8JeZEO50S4U9yDIZT0vCWhsPafxCNAzReB0swSPG+fE6SWvlRz+070HV5c2v7P"
    "Xjv94EJA0Ui9/CD8o8/BxC8CDt2kIV2Z1dm9i7okfWFhIqaxQSrLkIxqvxfgucfm9IbGtMH5QuP6"
    "FxyixPjVSknTQFxSvdrAjuYMA0Z8YJVRcMHZOnE3nxFAuC9F90JuvPUqKCk4bibfyqyIYiOKYEMA"
    "7eTs8Pl3SRCD/AAvwJth4UCw1BYOlNYNa1xa2LXcmbwtieV9v6nUnAurvXTAtzMie2bO4FeAD727"
    "lZeyAJ0JHphg9HOdoKY1muZuQRXH/QbGETTbJlc83TIoVVdFSy/hVB8yn4ADv575WvzwViYukw3n"
    "/qVaf1WzEHcIcqQ2nzUfKs7oWNRqS/OuFFdkQTN83XL5fYdMVXyrJ6bKNgtI7BQNCbVgWMZ8uylh"
    "6rOdqIRHtzSfX80b3Sr8pBoP348nGd0o2HnOi0XZzV90lK31JiBL080iabZwNtejdR3jcb1EUp6U"
    "/Rwoy4+yfnvzvT1eB8TekrMl1ywSY/loKIt8QyC3B7bam+1xhE1WNxO7V9jSVk4oFUSgFOLE67dC"
    "kw2cL2wIr0kE5gufPWI2iXBatSjlsvT9QEUa1uJwAZzGz6KlLW370VQdybfnGbmNY6RYJzpRDlum"
    "AOuX8sUqW3FvTohwloqoHLFXH61rmjs6NU3eixz36WiJ8FtQamCsXV5Ck2FU1axjXTCSW72cBwkz"
    "36QwCpz3tzL50etvAQdioeFEbJ2wLfFC8yZ+GqAUtmYdXXSjGtQ5NJ74RW4Ljt7SvEHj6MWTc2AL"
    "lgCRBlsoLcUK8b1qiMSDa6jL2LYgC3tDznzINgj1HxpvjRWZP1RkiotYvfJTztir02KHWgFJK17m"
    "VM5U/L/c7qiScNm0MxkiFfUyaHMoCylgWWZZDfzl/5bSS6E5WcKYc5GVAVw4V91zMeqlaDIfs+ap"
    "/DS1sYuT9a3Wvlnd9M3lGODX1e1tCDs4tWunX9bWlapPFAA+gjIETDV1NhWvevrzLQ8tEw+Dqveq"
    "YIGibw5vgAI//LnjkOnl1bMCUQ/fVEFYzQOjlgm7a6nDcV7daQV+TF1vr/Cg8XStU0zGDGy6GSfw"
    "MyZmw8pKz/rVrsOFIzyPdAO5TJTXontjCxeQeyhOLYZ/XDXgft63eRExo6AQWKz87FLGxuRhDhDn"
    "b2CsKZ+jPWnrTDXAC9pszQMg1iIYwp5Dn6kssnkU2mt9KKLrR/H4cz/X+TsELPOgNFF+T+vNKs+v"
    "d/OZ4kCIIdCpozFb49GZ9x6O60hP6PeA5HVjiOSC8gCiSItfxfIUo4Br13nqfPcOeoq/UD1Pa8fn"
    "n1t2t7URHSxokLnIVhrDqz1vKpqMZq4zOmHIlBrWsDuqwQ8aLe5BycH2CShueoV1PW1jJ9/ea2t+"
    "Gkw0rHzl/bG/whKF/FqOAeP0jVacVu/kjIbYuHdd71B/twQH2ExAuHzmzAvE5sSIQ1/55Rshc0aJ"
    "6G76duLEch4Pr7C2yoU1UCPWtzsWxymn9tk80OBY46n77KZ5oz5n0Bs6/9W0BvfZgZBmyjbolXY4"
    "hMVhsWRyErqAVwt3vZ4u0/md7YYvTqhPRhhcRaSPNXrPilxLU/AQbnRANTb8jS/b5WfPtS52IZc1"
    "jd6aHXRW1Owl9bYX7AUTiNUzW30K2wjrYYQ9NGV0xnyFJG8UF+9DZwwGsInz/a2krefpHhXP6J3e"
    "SaMVbdNydVIU/PtEtlBpwjuBp9kvBvtghO7yNf+3ExchCRB2Px6Fc3KgMMGvGYJJQFBGU10JRB6G"
    "UQKI8IsijZF/B6xjvFFwxqEgzW9tA23AM5gln6gIro1tn06KhOys4hjWJkzQAcTr0OGBuct/VmJL"
    "LqenQeZX3rSZarMIQuJXypbx//BD/2AeizOqbBeKhnjcOum8VETqIAlGrZON07DlM+DeVRcGPX7A"
    "ZWlqaDgtRbbwnmub8Z6Rjbzs/kZ+aAUZU/CyN4ScWIgBvrOgOyJKQX2gXN0bF0rnEs0CzQoArmu7"
    "kay+pv8pm0fEBSUwJhwklnrjGXg0qHppDqsOKDboJWQ/+3H2g+DEM12y4/pZbGS3XAcGUnKuZFnM"
    "MfYGWnIrJ8+5JkezK5+cKNaLtKRUKnizqFuMbAvw2qKadDa7r0oWf3fAp8UrAVKPd9Mindp+U6KV"
    "Dl1pGXLt8RB/eICvnYd1UPXWA6/xg2AW4CNU5+5X+VzhCoOVk9YWc/nNP407WS3I9QUv/6iFzCpT"
    "kBuoO6PxUnGbW8e9W8TM9OKef1wp/5yt8RzWLJk54PttWFfT8+w8s18NwIqitD2nDf5MnD7YN2XA"
    "ZlTFWEfMxlkT2SeejrBdu+KVQR7ygkvnjR0y1P8V53Mnsmy3hCPaKTcSL+YWayFThMdc7Mg7QvNb"
    "aXeR0NDNk+9C0ik/VlenjAoDqx1LE/l8E3s95S5L97mnaW5qW+GvxG9x5sJJXt6abEVpFqRlvHSf"
    "3o/DuT6yKfxFreXOv2I6vFK15oIeTnG6NqgNfqtrs+b9OywwvZssYfOBpyQbsVbIdXADEgho2hwG"
    "KX3d5SJNqRzy27bg5bMozVC8Q7ls9PpC+/ky1nrysIZstGujqfWgKZzjNejvIS0vueJx+XIZ/Q1e"
    "mO0MkQPqEV8cfz4lJYSmYpf2U0ZtHZt1tjqit0NM3coayNL5qhfDkmlr/olUPZJabISTT0Ygy2MJ"
    "TSnEIjwevjJY9QJnL4V/EbRUvxjY13dzLsst/DHq2rNEshDKQ7PopNm0A/yfQMo3TsQuNoJgB/dp"
    "XKqM1NqpI/0hJt4FqKv1vp6rPkqF/Bn2VOzNrLeJH7nge/oln8CRfXpbEzlr1Dqhgb65VooHogxl"
    "Q2uP8yUOqyFMlTwl+bSNx0cI3NZlg5LFvo0E6M+ZIxJ2N2XfwWsjijLXcCR5acaz9Nd0JcLIr0qO"
    "UamNZq6N0/uhIdZvfdWgkJSJqkkPkinSMWLsNs3+Y02zzfsvvUIygcFbArO95Pd8XvUXDhxsPOHX"
    "WPa+Vqz8x9Bs5DxRmnFLe38+Iyiabk7rMR/x0+6QUjpjhDPQi7c0IQbdbbj+WBT7SXZQrsaH4yqs"
    "GuUz5RC7WtLp1hGBuKWN43Wyt1VTbbJSNF2dZJdBdMfPRUoc9LNOXJ+xd0R4yxku6Lm0fwTrdeVf"
    "9+HgXwPif9M4cjpZx6+fn6IuYuDhWgHZGN3pslAsgJzf/wATMrHjVUT9Oux3J28Im2KW9s4OVAUP"
    "IGsPKnKz1iwYvdxg7wev55Ftsq7x2E5/G1ayoHuVCYg0oiWhjEMd7ZzLyjcLopJBHWJyDBg6vRsL"
    "QUELbLLlriRuB4sjnog8v8cztl+iveonSL6TAbXSiuUG4sH19Sjv9XjLlt0A9d/o4vsCdzl/tONQ"
    "IRDxrnaKrslb1OoB+JNtM89BbpSWGO0dKmYyKr1+uPUs1RLF+jrm6H7vU0xe/u/e01eEtelPpFzI"
    "l5swuVIwx1puDF3fwIKKp9Qh4Ct3a1n99ihO1Fn/m8U5d02JwlnOXS2nIy5qsJLvlI5rD5TZWO2/"
    "DRmD6DC7S7Pt8TWU3+16kxTbZ/AyCOEOpTmscgmNosCHrOc4RPYs3hVA7Up9uD0k1W3SqBgeZwj/"
    "+vhh7YhWlc2gxvPDsLOSLwGmgkjMV5EYIUBSQAf2XcwPD3G+by/ZVyV9P9d2hhC7jWIwAMMqtKgL"
    "AwLH3Zs8k4EQkmcZO87PA1lsRJo9KqRVb2iT5OOUESXWq5Oo2wwcQKasjxA0SYDvKpKJAQ+Y3Fv3"
    "qq+6U2HPLJ/TOIiEzOvGBEClpWmH6FYlPDmyVLsy4WdAYuKd7DZrhHA8K2CCAH0rfpNqm3r44Vgg"
    "UsL5+4EkTG0IDl/w5R9Ix7k7GaLGqAJRhaaONVFQ+Gmi3r5d6l6U8sdlh68ceGsQXrf9Q65MgvMS"
    "9gjWc4QVscU+M1ecVezWZRHaxx6RrlU6ERBEGwssHaXpu5Ci/jIVhK2u1z9a8xz/aQJsMpS47mJc"
    "oc8KGr6PhEn4MAvQQQ0HoUBzFDmVixTtvq1/CEQAcmxW5fHRl4zTc+/2dSWFHhKF6sQhW0ZIpz0Y"
    "c88mLtIgwjbJhbDINFoSD2TMcPBdhO7h3LdgucQ56N/bWoj7B868fiPqeVCJo+52KsHvDPs0X070"
    "3zxY8Aw7fQCK8W9N/NY9fw4eP/ZB//noSX4JitP7n5ivGvGlXwL6U3ABoz8qsR9eC/NI4WLDlTEE"
    "tXtNi6prbSIjBH1iTmVcSjzmPl+3FVPzqfo0CDDEWFH0FGIHgsrT6i05kxC9UUBNDK7fBN4tXxgd"
    "hhAML3P6DklMxsIZp9gSfr36UAb+bAdCjY0VP5RxeDnMAVEzs1Hf1vuNBDrDXBazD9h+7NUyxRDO"
    "oMqsxxZ+iJzipYiY6J7oqM69r944sHhbCC4kzGjeZcdJ+Laspse85kfsKxVw1oV2eoni22c3bhhM"
    "8ngXLlQ+glBOhMQ9y8i+Yz1eOePb2JocTde3UkW0tCha5FArQfuvPTKrkKpBROvaxLKFtxE8e8JY"
    "U/MJcKfKA7cch80z0m7FGoF4ljVeDi0tWDywkHpd8L0cnHxg8Pdk9qYdvXpHmFb8+E+dhaHm1axc"
    "d/lxKDQ5Ozdu5h3C2Tmx12e6SnLN6YQwzVtBPcHbFbFb35njxpSx4l3VzPPz+S+BFTVlsu6YMcoN"
    "gn2BTzwQ2Xst/+BIgX3E5rLfawgji2kalu/TifVGNvdHD502oDpRBvpsFYBiQmwqMZMB1DbGQOoq"
    "JbU6JZzeeinosMQqk5BzmASfBeMlueY/PbNWwqGkZFFzUAEpY9xoTXJQQAUGxqjhs/He/JIi2NEo"
    "JJH2ILoOMtw9RDq6B+7ykK6mIYRXiB+TgZySm76T++ODBH/oEJ6pg6XGzzj0PXBcVbb+jEWIiweb"
    "D3OB0XbMXsXHXma2HxwwGNLGlytZEzLcFpwn4xua0skF9GgJ5rpHcmAiZQB+OzZtOeBILG/sW30L"
    "GMMPhB8JSH5QUH0MwSoF+8A6jIfrVCgZbCFe4rCplDfC0Un8esUFQzv0gMZxB72PWhcE+jRRQiGK"
    "69AYnbqLUu1RkWaJWOddjvIU2M6XSv/pkLDzqJjJqT/GYlDsOgYaZa+0/nN65A1+BYVUnat8a7Le"
    "RSN9+UVThNWCl9GkF5RrJvMU8Yo0WuIjHOSxh8DrT88HpERn/uU9e5XyHrjBOAG3FjQNTRQ0wxoi"
    "BNTemHUXt+miDj8G+ngstdaSjIZocP+ybzZOA7aZR2gUt0nmtWvXlY24Am/+jeX3q4IXsi3GU/KH"
    "KhTFPb/1zc8MLInCVvgt6ERWLPRyXSG/EuqmgvwVumkU0QZ0MwV+bkEvXlrOP8tP3J9t8rrZiIPi"
    "X7b5SBS36pb9b1mQsogUebMdlIW4Wqp7A1sMtii0P4ErVzdgKqHtJK6iF151kGuLAdbLp6bySziF"
    "nCTCIQyNzZOVT1k/AfirUb3BIbMVZykq2JYg8LSI5IJ8z/DTI1lRwIa7VrjIq0oQ5eNtXx0HOexG"
    "W+XVbul0aALrXSpy/8X2+tDXbU2FztcrqqvLEZTBf1kLeX6Jhl0l/Z2z6InmLP9Tc+OmSQqjuf3H"
    "vwVEVmCGs6sDhlvtwqyd4Zvnp7ktkkPBzDsrvh15lxnGl65NncPBI2rsGSN7s8/6TDBoX1NzisWx"
    "a32KpE6pooUqh7BFzEZtFUYk6pmEtElvi87B2ieMIywFcoeCDRLlPeyITlEbeP7FStxnvxWsfxJb"
    "OAcXRomKgzAtUxjm3aXs/nqxXP+NQNiBlF34JSkOt5ax1hZMxyfhzdmsIk2wXdwvNBo4krnKWWMu"
    "cVonnH5A9FVHTNhXQ7vIwpncrmR+Rf8LNNCWMV04+t3Xggd8jIFcKpzqmc8UqU4y5LU3f5xDSchc"
    "JNdLuqU65f0enMN85f3rZcmypUQ2K12wqmRfn8PhRhZVSI37om2k03J/H9ojRshIASG/hnh9rDxm"
    "XjTOgzHe/dXf8qtyH5zQhjakizUe3kea+Q37WqSOK6BsBW7pQkGPHrbIs4XjstNlX7wv//q5Ed3Y"
    "mgqY31YWY3N+dQo0AHCbgP//E+EWPWlUmcSsUacUJ3VDuL44k4ngh8MHoDjKUbtwCgrBOlCo323f"
    "2qSofQ0WoHh3ZLCwQwSFMQi+WRaCu4kZMv2OaJ5FweMQEaGG0XWK8WsHMsfFH55s9yG2/py0R7JQ"
    "h8Rpeen04Vl5IjWtZxsi9KAXOdQRcOLikY8SprzcA/kyesIJ3vH0mUSd5KUch4hOiqc3wNPOwxss"
    "eC9PAfQKEieZSonlyerCtfZGt1LrYpj1cDDkWPQ9NszzGV2v3OJrfNkJPVCcqCAi5UYOkfs//xVh"
    "yMeF1Cab3I+jS20koqfg8ej0HlOsI11J56Uq7wJs7heBENQLkRQ4nMB+lRaNfcjAd+2ATLQ0CVTD"
    "8WL5pelo73WAkMWQ33ZlBEre58rK8MMoytyTXbFDdnDxbsKuSzhMt66tHhWFpA1zxqIBwQePdnPt"
    "TtxnV683a9uAuNnh99aUTvS9crJ6dDWJLrnW1Ba/gTMZZnqM7isZ5mili0jBQZOtgr0ck8rbrrm1"
    "UNAriQxkeZ7MQbe+hm9eS7geQ9RFaJYoE5qsBUAgHp5hDHBYU9T1e0C1G35nxy7m9FqpEcBYW6KA"
    "CH/EdM0dbFJishzElgv1bjX0MVN1r8hIBnRcd+JvIb8c3TcpLtrErsp0WBn5tSE4DCyCQhfO+IY4"
    "Cmt2aY8UPzB2kM3VwEppAU4gW3mswaVEti1rinAtvKWS8aJD5OaFT0vuBm9wNmWOA0iFBlZxT9KG"
    "Hnh0PNY8UEGik0rbkUcLVqJl+/44W14sHYDZt1dFiLUzIgOH6IdnaG/aje8QoNqTuubvJvm/E9jG"
    "OlIm+ClLBY5DtBYzKjctbjh+xiqsbWFLW3OcQzHeRTDQ1EHuotBXmw4LoJOabfy9lU0sgWbwo7Sx"
    "KlvSf5+5aTji4XlOu7eSX9VlgGaMuehQiHRiTaHfFtSBS7Eskw5GrWHqeFeyPUAbrjO5pxxmHUT2"
    "8E9ZfNk5QCoboDmEP7wXdqroMN80yPylpXZXwvxtMkxOUoQwpzyU7Jo+2+JL2nv4X9B1RAiETvJB"
    "l5JW2z6WVb3AIkaehioTmRwCgnF0i932K3rb36Eewya8bvrTtx0N391xZMx+YkPdkGPk8grzZUFf"
    "fTZVkfojlkkrxGBVbovtUtqiYW0xaElaERAEmtFEfRc/IFkt9cI9+8EnHSdPTB+VzbX7DzuuSp1C"
    "YleXJ1vMiuTzkcAKWbaQpCvvH5OBDJwNsirfSX6DVb0TEnW/0xL+q33eulbH4OPvWbxQbqtzM+mN"
    "nZnbMzcXnvBOZSY6u5OgsiC4BwUlaGYetQFRDWiMPnirkYyaxzbFrxDvSbgr1iz9JP1ZYNnI3VEf"
    "9+vDgtlBCTvedKqEx8c1KTE/BNDIVbBqqBp0Zl+WqP0uw41BVR/qKB4cG0hipmiqa2FS55KyiyOR"
    "9peXcPkjTN/FJQeIA5lDmhHwdi7Pvh0c/LpaTMH1r0dnBVh6LYzBUfhXWcZNWTfD/xpla1fJOFVf"
    "/ONJmF07zAwbxwEBrj0vqj98qzG5yUuUaHIvJBoyN0aBEa+BU8ykBpuTC14O0HYbdNGXauqmfGGs"
    "1VNU/VkVR4Pfwtq8gRkevpnjvhkqYbTsM2bOFwZQGw35W8z95U1vGAq62YlHnjACRVy3zR/dEVLo"
    "a/ccIOIT52+3hRReblQHdklIvm3jpke9BAyH58u/HQjZN1p+EqGVW9Ffv+WFGQJKoD4o/mY6aFkG"
    "THqO1bUMK0Peyq00jmjZ1fCChObyDMdgInBqe/eAIvxR5qk81hChcwUPT/G1DcLYALfYmtfFW7cq"
    "Nt7QcxV1f2/UwdgevMw8MhaXwLc/BH55tRjCTSz2KnroMcdE+8yrwpqu+i9xQ2TEIiw0aKEPfiQt"
    "zC/BWEkqXZ2CtjyDMkqwiB4Xf97DbobOYqXtpj74kbjx4RLFW0ceQot+oxGfAo18Lk9mfCSV5Sqt"
    "NM5O6oeD4ofJL8hZaf7V42cFxBPF+1WrnIN3R9LQjuxrUC8rmDSzgVyvGRoixxIFA27LGgpEqrHU"
    "xbr46qFQHcBWuXci8I84CXCmrSMINRtnwVQ9Pnu+fid9UPBv9mx89uoTg4DX4FuIoDsy0QzOZ23H"
    "QgYcu4wrogpsFZIKQbujywHJ086xsMgEEE+d4lasCUJh+biEqdotRo/TGKBtMhp8XlcowZTMJjYW"
    "yRC9nF2r3a75b2fg1AT91+LLDYDesXRyY4s7/Dw2VweCx1TLmN+2uZc/NyWlhTsMdVfl16TFgqNh"
    "gqmHCHeZRiw7Notv5dt/TX0JfGOz6ae4m0p+3WlmoZU+a5YFrItsX29MwoEbpLjU+OWUHeo4KEtq"
    "B/aMMD8NtDX9U7ElqcHyugu52q9HK81ROAR+Ge7oQN9+4wkxlgBGVCfy4CQWBNkhckvCUfJ4nj7P"
    "7QxWc1mDluRMy1HCS8C3KeFXRpaKsYLZ2sEPzXYN/ypD1qprZdWPNi8OEmcmiI/ht6OKmm+pw+5j"
    "4cj5APcl+NR20LqtMTcHeOHoAeNHoM6uBhWdYCrZNELjwO9WOFzu2Dewrvb0TAgr6lV9abZBio1Q"
    "UOL+9Md3sMqwHuHPYGvENBVfEiiJoL0zMX2uiL6rNvj9ga+z/5gV4ayj6aFjFPFh8KvWs5j3x3pv"
    "6VhIFYA+wgdqumbPgRzV+rsKVQ9IXKwyvinf7wzRZ/a3r3vk4X/M7XvxT4ypceBehdksobKcY0Zr"
    "lSKbh4nKz3RYMQICBYONUgU4oBo6NZfMnMJ4Ngqq4djMh78ihyafVNyOmAAN1JIfdkEta1x01EPZ"
    "BbhGIcJuA6E2mAYba1Jh9gxexqR98wRpaIzDRt3iEvmS/PtGxX7bAt8VGJr/SKFSURSQ8HBsP282"
    "7+A4GKx8bdyWyudscKaweJwlri1LTeKrGqgomqBFJKDMfU+vJByqJsoyRNBhtlfAH3wvsYBUN7uY"
    "Tglroqwvjag/HyV5X+TLHxqrfZ0dnUL4BiOX07cnFPnAgPXV/4yTk/flHQMYlgsGSJhXdjZlaOXP"
    "+qiGMlJQZtAPrO0Ijz2a5DufeDBLDbc/WBFWPNq5Wrmn0snXIpTbDzPAjivrY8XLMW6KTYY3EB+e"
    "u3/rh4kePKF3uBwXvvF1DldEhxwdyfJPOFIQJb/NvOZJ7MW3vyis0zCTU3cFJq8aA3UzN7W8xlAM"
    "EIxzpowPPooUqTiC0lnbd6PP1j5fd6+s+ASDdRn0JtK+j6E2+N1JkZECf6tM3RyG6HnZzznRG7kk"
    "TL+hDgqUy+0/YX8IRCYc3f0lINsWPSw8bjXfdqneZeIzjZHAfGaFjkS7VjPrd9PxMMLT0ZgxKE5t"
    "4NKeem/n/mOHwo9x/Ru33Bkayf3SSF7yXJUmZP1FQBB+2hnJAr0DMExVr/W/IInS0v7metrd1mhH"
    "FX33S/fs487fYQu1CsrBeDRYd/gP3ArZCFl4DKvZQuZ92PoNW1R7jix/RytiwAgqxlZbygN4Yk0F"
    "lUjfEprV8c/uDrp7Tyw3Cm1BJfO66jd+BatmU9qjMah6UzNH0YkBSLZdMlbLS7JHOT4+EIX0wqx7"
    "RyAcYjBA6faWyDHHLB6YBTAdXtnhmrDZvgOkCtjikyf1CIJ/NijdZwkWeplmBWex0kFpQ4bFsY1J"
    "iqwWFm42L3ER4JPHclihhNulxjapQWwyBy25DpSQR0TOGvshP2/sUwjXMKL/S9iz/hx4oWCUWLof"
    "t2u974oadtFeC0wbXW3s6cgVawpJOn8QQOGsp98nkhzFTQfYyPmAH+vyTyZsBMRE1KXFTumQPhkc"
    "JQQ9/CiTeXORnp2SSozVVIB2+LBw3MwP2e7BkYrnTOxi7Z+0aL3r3529t1OAkl+1/rWKxDnV1sPg"
    "aulZ1IoK/e7xX7Y+adjlHZ0XohYqkbyK1cunh0T//HHlxOyikorzzZGvLwcWxdysIq3M/bV5NuWl"
    "y6GCIagwf8cqUno/C4KwTajRtFz3QUtssvQOGZaGUHqQpV6kFiA2myTRPeeRLhl/ZV/jVHyRBXBS"
    "TSFmdVe3Bus2VbGPUhDbpZht/6SElRWGEThJLGNqNwbG2UdkqJVCC99kSzsSbwyD3vMaau2NrzcR"
    "nr4Wrt3JTSFWbD6hU5JZM76vOWA3X78JJ5M8kRqNe4T1941JBGw9Kw+ZGjEL1q4zX6tLyjunV+Fa"
    "kG9Kt7CFj+XXUl/xFWqut2MWcJ+bNcoQsOseG0oLfUSfsnjVOx/xl8Q+9YDDtsa0urhi9r6Nv5Cj"
    "2EyrmxCghPLwYgF7KNkYU8saDMEiPVBNvg4yo9d0Lfdl3gqHUO6+4U+7ktAvX46YW55jqpeFqjMI"
    "m/HEwegA504rA7QjIa5lqiI7QYKuAFaigMyMmtuBM4duW+JOpQAHZjIDE8Gxtmnrl53vOe2tenmS"
    "T2yzVVhTBCcXvZXvzWrdU0c4goAsvgAiHkjf2d/p+1cufABnc+USWfK1m1RSWTi6wtzylHBuXq3i"
    "RQ2/yNwLeaNmMl0v+18MA2W1CTtQUhSAC39aQorbsZh9YJDX49CB6JSdZ7VIQWTra2M98MMU6lHU"
    "KOhnNZzcGXJmQmfacIt5G8ozICST2h/Gb4SToAiAo+kM16TvYIKc/J7p0GpIsRd/d5nDEHoqL/VH"
    "NyhEcMLJX2A2t/Fs1qvNfDR24jp/BY1fQNUNyPg1PdpVXsjApWVV3fg7oX92N0T/zI+Wso0XTDFN"
    "SJT62nTDHB4nyawMekhf8YfkT7TbsD9+YbC743V/fVPg9Rsz0ChrFRC4Rk41kk75p7BgkBwztVbL"
    "WdK98SW5uzPp37tKu5ZqcoDr2xKlPFMtgf30LVT5wUZpb16DBvCdyaB2S3/DmvS2YknaIz9VM0Yk"
    "HE0TuDYN1tuf76kKv5lrh5QT8iAL57af5Wx+z0G6IK2ov3dpd4k3Yw72IPf/Z5od7sTVTVyYWmNV"
    "e928YTTPzBFsJkt6g4Np99wG508eHWzvnd6bSlX49CSf5pCVxfxEAR1KlFxdZYMXVXHD0SCvdfNN"
    "MeCO64hDChkTfI2JWhwXStYQTnM49FbimQgwZ5u4R8IEzIzlU/MBmrzI2ivBWc0rwUZu+qDrWjHL"
    "OnXLznra+mYQWaLjOJJVOjmGCxFcxapWC7D0Mh5jker4vXf3gRHfA6eODMdKOqTRYq720lYF6NZs"
    "hvzZKsdFjvjGwRnoMbZQDMf+nmWJVAzxT0ajDywpsjTm7zb77UZ4GsSZ/lBBI4oIHXrWTammfiWv"
    "4tCCtgG0L30fomemxSWCbvGJNm4V3H5zTSZvnDiQMTYlLf3ngAv3fbjmgDgu6FHIGCiGwxxzDKU4"
    "BWA6fJ6gmWrVLIIBBYh3EWq3CQrMOJMtpL4wMZ/baq7+5k7sDCu27MFpGZONU9fg31A7Hs9NcNBk"
    "ZHA7J2JV57j0+chuU3OOhmXfejYfL786MaO7eUOGfVgmCkAcN9Vv7/1sFy61AuP9TB0pgQTQ7I6k"
    "eHGYnjKujvMYEsxNLgd2DSAGBRZufu/DCPGosxaQv7Gtnhj4YFaxamnIM1KY30M1wPbdSqm7Ye9E"
    "+p/XEMOxq6bJoVJJF0nNG4fQ5+enwK+iWMWt60Hwp2asedVC2dkNBuj25U6qjXPoO7WF0lvzR8Lv"
    "5SifNSYzUDnqGU8Z7weyAHwFms8Lt7xs72hIJbdwqIz5FZne7el+zfkoqZAWywUONSKFMclOqj61"
    "fTyAMoOKERw32+L5kSPqvQHYdWKDPL/5YoNlmeAlJTrT3q41J4xS7vw5t9gGaEG5/4Ev245QFAi2"
    "hZDqFH7ZSREKWjwRCntrVbMAR34z80/X+iK9uTqySdUZtNoIwiMDzEucCJ1bI4IkchpZgoQiHcmJ"
    "RkLD3QGI5rRrGtPswektGgkSyKv43J/G2RO4v9OZuRDjL5XsqgOpunUqgCnh9qPfpF0+KqgGcaU0"
    "JuGJnxpR2tmG1ZxI7hcyxgVknw6qlplTKJ+JPCLtoInYEVT2c/fle6WnZ1KXIoygKsGiPLTtakW7"
    "qpz/qwxNQ16RADC7RaVArnAWu6s7VzQyGLqr6kCDCOBShpqdTDdN6LaDuoFVBn6ThvFTocJZx8Fp"
    "AbuEcNLfudpfo5dVp5FgDT7ykCrZCpaooyYTOcezGD7rIkV/oXnkzjTr5H23HKpdypPvHKk1GDLf"
    "kbviv4odfcdy0xlbo5I8gd7FwpZIXkK+EfchVXWeH2wgRHCInzPPph6IpQT+FdDOsORQxh4PDeX2"
    "7H0cICDqvbY2rwY0uBz+xxvYpQF8TMIumR105esWJNh1ZyXI8qZfjcUdho2Qef5k2XgCwG5b+OYy"
    "IgPGPu993efVqK4OekHC1+ibScBcxawflsyw1GsUEl+00/nBubiR7h0E5aTeqpMCWqiUhcyxL9PH"
    "rtHWAdC8aKnRcsdtWjv/OVr0RMLAEs829f+/kP2KL+P+cZtcu5tTMAevYsvnSKHozvXdy8sVcOoY"
    "Sz5joiUdEM+39zneyh6NY5kzweG0f1MMiG/VRY2FQw7M0/lyRPahNnOJAbxEBCfEYOIFy/wLqRDQ"
    "gGHHknwYnj/WEoIDpzgp51jFSmlGy5rHrWwXH5LVusT5Z6er8xa6T7X2rBXwEWwh/v5nEfbJuTI="
)

# ══ Chiave di decifratura (derivata dalle stesse costanti del build) ══
_K_MAT = b'MANGOLINK_MESH_IT_2026_BUILD_PROTECTION_v2_ED25519'
_K_SALT = b'MeshtasticItaliaNetwork_SourceProtection_Salt_v1'

def _xd(data, key):
    kl = len(key)
    return bytes(b ^ key[i % kl] for i, b in enumerate(data))

def _load_module():
    """Decodifica, decripta, decomprime ed esegue il modulo in memoria"""
    key = hashlib.pbkdf2_hmac('sha256', _K_MAT, _K_SALT, 100_000, dklen=32)
    encrypted = base64.b64decode(_PAYLOAD)
    compressed = _xd(encrypted, key)
    source = zlib.decompress(compressed).decode('utf-8')
    code = compile(source, 'license_manager.py', 'exec')
    # Crea un namespace pulito con i builtins
    ns = {"__builtins__": __builtins__, "__name__": __name__,
           "__file__": __file__, "__package__": __package__}
    exec(code, ns)
    return ns

# ══ Carica ed esporta tutto ══
try:
    _ns = _load_module()
    # Esporta tutti i nomi pubblici nel namespace del modulo
    for _name, _val in _ns.items():
        if not _name.startswith('_') or _name in (
            '_EMBEDDED_PUB_KEY_OBF', '_FALLBACK_PUB_KEY',
            '_FP_SALT', '_OBF_KEY_SEED', '_OBF_APP_SECRET',
        ):
            globals()[_name] = _val
    # Costruisci __all__ per import *
    __all__ = [k for k in _ns if not k.startswith('_')]
except Exception as _e:
    raise ImportError(
        f"Impossibile caricare {__name__}: {_e}. "
        "Il file potrebbe essere corrotto. Reinstalla l'app."
    ) from _e
