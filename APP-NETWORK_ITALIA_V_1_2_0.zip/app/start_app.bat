@echo off
chcp 65001 >nul 2>&1
title Meshtastic Italia Network App v1.2.0
cd /d "%~dp0"

:: Prova python, poi py, poi python3
where python >nul 2>&1
if %errorlevel%==0 (
    python start_app.py
    goto end
)

where py >nul 2>&1
if %errorlevel%==0 (
    py start_app.py
    goto end
)

where python3 >nul 2>&1
if %errorlevel%==0 (
    python3 start_app.py
    goto end
)

echo.
echo  Python non trovato!
echo  Scarica da: https://www.python.org/downloads/
echo  Spunta "Add Python to PATH" durante installazione
echo.

:end
pause
