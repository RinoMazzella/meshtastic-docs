# -*- coding: utf-8 -*-
"""
🗺️  Meshtastic Italia Network App v1.2.0 — Path Tracer (H4.3-T5)

Ricostruisce il percorso di un pacchetto attraverso la rete mesh.

Definizione operativa:
  - DEPARTURE: prima riga di packets con packet_id richiesto (la più vecchia).
    Se hop_limit == hop_start allora il pacchetto è originale (non ancora
    relayato) → sender è il vero autore.
  - TRANSIT: righe successive con hop_limit decrescente (relayer dalla mesh).
  - ARRIVAL: ultima riga (is_encrypted=0 o più recente).
  - TRACEROUTE: integra dati da traceroutes table se presenti (RouteDiscovery
    dai portnum 70 TRACEROUTE_APP).

Ritorna dict strutturato con timeline, decrypt_status, hops, signal (rssi/snr),
gateway_ids e nodi coinvolti.

© 2026 🌐🥭MANGOLINK🥭🌐 — Tutti i diritti riservati
"""

import sqlite3
from typing import Optional, Dict, Any, List

try:
    import monitor_db
    _DB_OK = True
except Exception:
    monitor_db = None
    _DB_OK = False


def _fmt_node(node_int: Optional[int]) -> str:
    if node_int is None:
        return "(unknown)"
    try:
        return f"!{int(node_int) & 0xffffffff:08x}"
    except Exception:
        return str(node_int)


def _node_name(conn, node_int: Optional[int]) -> Optional[str]:
    if node_int is None:
        return None
    try:
        _r = conn.execute(
            "SELECT long_name, short_name FROM nodes WHERE node_id=?",
            (int(node_int),)
        ).fetchone()
    except Exception:
        _r = None
    if not _r:
        return None
    return (_r[0] or _r[1] or None)


def trace_packet(packet_id: int, window_sec: int = 3600) -> Dict[str, Any]:
    """Traccia il percorso di un packet_id nel DB 7gg.

    Args:
        packet_id: ID del pacchetto Meshtastic (uint32).
        window_sec: finestra di ricerca in secondi (default 1h).

    Returns:
        {
            "ok": bool,
            "packet_id": int,
            "rows_count": int,
            "timeline": [
                {"ts", "ts_iso", "from_node", "from_name", "to_node", "to_name",
                 "hop_limit", "hop_start", "rssi", "snr", "source",
                 "is_encrypted", "portnum", "port_name", "psk_match",
                 "channel_name", "network"},
                ...
            ],
            "departure": {...} | None,
            "arrival":   {...} | None,
            "decrypt_status": "none" | "pki" | "psk" | "clear",
            "hops_used": int | None,
            "gateways": [from_node_hex, ...],
            "traceroute": [...] | None
        }
        oppure {"ok": False, "error": ...}
    """
    if not _DB_OK or monitor_db is None:
        return {"ok": False, "error": "db_not_available"}
    try:
        _pid = int(packet_id)
    except Exception:
        return {"ok": False, "error": "bad_packet_id"}
    if _pid <= 0:
        return {"ok": False, "error": "bad_packet_id"}

    _db_path = monitor_db.get_db_path()
    try:
        _conn = sqlite3.connect(_db_path)
        _conn.row_factory = sqlite3.Row
    except Exception as _e:
        return {"ok": False, "error": "db_open_fail", "detail": str(_e)[:120]}

    try:
        # Righe packets con packet_id match (ordinate per ts asc)
        _rows = _conn.execute(
            "SELECT ts, from_node, to_node, channel_idx, channel_name, "
            "psk_match, network, portnum, port_name, payload_text, "
            "payload_len, rssi, snr, hop_start, hop_limit, "
            "is_encrypted, is_compressed, fw_type, source "
            "FROM packets WHERE packet_id=? ORDER BY ts ASC",
            (_pid,)
        ).fetchall()

        _timeline = []
        _gateways = set()
        _decrypt_status = "none"
        _hops_used = None

        for _r in _rows:
            _from = _r["from_node"]
            _to = _r["to_node"]
            _ts = int(_r["ts"] or 0)
            _ts_iso = None
            try:
                import datetime as _dt
                _ts_iso = _dt.datetime.utcfromtimestamp(_ts).isoformat() + "Z"
            except Exception:
                _ts_iso = None
            _hs = _r["hop_start"]
            _hl = _r["hop_limit"]
            _src = _r["source"] or "rf"
            _is_enc = int(_r["is_encrypted"] or 0)
            _psk_match = _r["psk_match"]
            _item = {
                "ts": _ts,
                "ts_iso": _ts_iso,
                "from_node": _from,
                "from_hex": _fmt_node(_from),
                "from_name": _node_name(_conn, _from),
                "to_node": _to,
                "to_hex": _fmt_node(_to),
                "to_name": _node_name(_conn, _to),
                "hop_start": _hs,
                "hop_limit": _hl,
                "rssi": _r["rssi"],
                "snr": _r["snr"],
                "source": _src,
                "is_encrypted": bool(_is_enc),
                "portnum": _r["portnum"],
                "port_name": _r["port_name"],
                "psk_match": _psk_match,
                "channel_name": _r["channel_name"],
                "network": _r["network"],
            }
            _timeline.append(_item)
            if _from is not None:
                _gateways.add(_fmt_node(_from))
            # Determina stato decrypt più aggiornato
            if not _is_enc:
                if _psk_match and str(_psk_match).startswith("PKI:"):
                    _decrypt_status = "pki"
                elif _psk_match:
                    _decrypt_status = "psk"
                else:
                    _decrypt_status = "clear"
            # Hop usati
            if _hs is not None and _hl is not None:
                try:
                    _hu = int(_hs) - int(_hl)
                    if _hops_used is None or _hu > _hops_used:
                        _hops_used = _hu
                except Exception:
                    pass

        _departure = _timeline[0] if _timeline else None
        _arrival = _timeline[-1] if _timeline else None

        # Integrazione traceroute (TRACEROUTE_APP) se presente
        _traceroute = None
        try:
            _tr = _conn.execute(
                "SELECT ts, source_node, destination_node, route_forward_json, "
                "route_back_json, hop_count, is_response "
                "FROM traceroutes WHERE packet_id=? ORDER BY ts ASC",
                (_pid,)
            ).fetchone()
            if _tr:
                import json as _json
                _traceroute = {
                    "ts": _tr["ts"],
                    "source_node": _tr["source_node"],
                    "source_hex": _fmt_node(_tr["source_node"]),
                    "destination_node": _tr["destination_node"],
                    "destination_hex": _fmt_node(_tr["destination_node"]),
                    "hop_count": _tr["hop_count"],
                    "is_response": bool(_tr["is_response"] or 0),
                }
                try:
                    _rf = _tr["route_forward_json"]
                    _rb = _tr["route_back_json"]
                    _traceroute["route_forward"] = _json.loads(_rf) if _rf else []
                    _traceroute["route_back"] = _json.loads(_rb) if _rb else []
                except Exception:
                    _traceroute["route_forward"] = []
                    _traceroute["route_back"] = []
        except sqlite3.OperationalError:
            _traceroute = None
        except Exception:
            _traceroute = None

        return {
            "ok": True,
            "packet_id": _pid,
            "rows_count": len(_timeline),
            "timeline": _timeline,
            "departure": _departure,
            "arrival": _arrival,
            "decrypt_status": _decrypt_status,
            "hops_used": _hops_used,
            "gateways": sorted(_gateways),
            "traceroute": _traceroute,
        }
    except Exception as _e:
        return {"ok": False, "error": "trace_fail", "detail": str(_e)[:200]}
    finally:
        try:
            _conn.close()
        except Exception:
            pass


def recent_packet_ids(limit: int = 50, encrypted_only: bool = False) -> List[int]:
    """Lista packet_id recenti (utile per populare dropdown UI trace)."""
    if not _DB_OK or monitor_db is None:
        return []
    _db_path = monitor_db.get_db_path()
    try:
        _conn = sqlite3.connect(_db_path)
        _q = "SELECT DISTINCT packet_id FROM packets WHERE packet_id IS NOT NULL"
        if encrypted_only:
            _q += " AND is_encrypted=1"
        _q += " ORDER BY ts DESC LIMIT ?"
        _rows = _conn.execute(_q, (int(limit),)).fetchall()
        _conn.close()
        return [int(r[0]) for r in _rows if r[0] is not None]
    except Exception:
        return []
