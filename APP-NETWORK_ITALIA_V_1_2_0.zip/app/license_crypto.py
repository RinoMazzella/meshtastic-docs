# -*- coding: utf-8 -*-
"""
license_crypto — Protected Module
© 2026 MANGOLINK — Tutti i diritti riservati.
Questo modulo e protetto. Il sorgente originale e cifrato.
Compatibile con Python 3.9+ su Windows/macOS/Linux.
"""

import hashlib, zlib, base64, types, sys, os

# ══ Payload cifrato ══
_PAYLOAD = (
    "yo1HiVPqhrsp3aGvAhSM34fN/eTwA83nceBXzEk2pUIkxTxwJgB4zRy0Qkye/sWxGXw6rk+rdggj"
    "5F1sSnnf3VZeeNuzf7Gfs7fZwR/ae9YP80jKdGbWVvBBa01kDQ2NJnhpOoBT7h1BeAGmg4reOuCq"
    "zFN7BySLJ8noXxTzUkImyxdbYtK0ROcoVEp2CuIyKh4KVqRQ0EMf4cNrtl17M4dY6jnsTEeGn66L"
    "HWWKRWg5M0CeggQYJ4dwpM5FFlsDBu4/LeRnRZPinbMJrze0NcoULVNBUIBvCsGm7ESR7xaCjehs"
    "cmzyYkKaryORwbv0UpAJS1NtVG8MkZ9qBYmuGiCumCQY1JYp1GaJ2Cct956JkTX5YeqO4vlGqpo8"
    "XWcwUhxObpADrSlQDrKkRMBI/bNwlZdMOzcRuXUOiBKicfzrfU+uJf2FCLOtgROYMuqBZCsrg2CT"
    "bW0t0aJsphCwhdQreDlyiFviszlhW0kHhqUvwch2wPq/Kd6PUisiiXDRGKYnXlh5JZJcn4jBsIcQ"
    "eyTGYGNKUIBgFdGG226O5xcv2k3UYEcToiH//wfJo/hT6Gki6xB87UwQUoXmXBBJhDzKxFGybR1g"
    "FtWF0ZkIyuB2geF6oCPk1zFSg8+6ptLcUArSPKDeQM5cjKunNkyaoac+v8OJGFumwbeNEEyxxWDu"
    "yI2r86mZ1ovikTEjQO+il+u01V4a/+z/3ZPre9dpg52mMJZ93t/VRBub3DRvqK3m0z6zaWXhRzBD"
    "G6GMWgiTi/d/r9o0hOHcnnANmBnlGTiIshmNAeq4vajPfsaYbFPtU0Zu2EJoT76qJ1vXRIwhOyCK"
    "pVkOQ8ecOTTW9pwqJScbUuz/atgZQ+Pva0Ks/4bb19XOnWtdo/bt+p7tZYrqB8ciJfzLfAGHwmND"
    "rG6QLFXfEL3+x9gbA3rbXqhJk5E5cGSjYawWFRZR0dvn1weA9MEb/JXFELvGTXgiSDZat90tJjL3"
    "lbBo7kfVRXFwOUNmQvAPuocVy6TKG2cU43rKR8+11P10CzzrzgM8d0yqEeXR99RadARhUIhIVczY"
    "eaJUJqwxFi8mkDXsOwCahKmMKrqPANl1dQA84vuZmcMJmpDpTzzdCKn346PxZb4lCBQTu+i9mIYy"
    "tC9eJ1j/CAUq5WtBM+UwaVOxYxsdTapbAXiDKOneD9MQH5CV7I3xXJD5q8YWWmrIVJGSdfNd3tKf"
    "CvdE1ucCOaSoyUoHgfl4jIYCq5qp3dVegmt1QHniu85HouLkHrXu9XnXzLeIHB6wOEOi2JePVoFs"
    "/aZEeUwLCWrSKQFtjPiF/9A3MYh0D7CHyBB2hYk6hUVoivcUOlorGdEFrUCbqjEHJ5dWzSy+LraL"
    "5s9+CJl9p3NzZUr2kQYIWWqG9X0j0CCoeynUnxeYwgkO9rM9lBG1FkXMrshRDWP1NTX7rqNddHjb"
    "p9rCCts/f6CfyjEk6aN1CzzlNPXR/PbmfiOGi5+0tucGcJ5BdFBYRODtaaqhE4qLzZyo6a3jaW3r"
    "x5PqJVKzfSWKTHL25kWIP0leKl+Y+4ys/PizxVvB6JN7h4d67s2seuHFVCyXmD+iWBFLyotFaMzU"
    "xXzt5g915YjnBXgv+eAaSHfTKNtl1NstOM2+VSnab4Se8B6BoVmEPt6ASb5hytj6ent/HB+wHJtJ"
    "DKz4GwzEX/AvJA31VAh5i/TL34Ntfq0YOiXTuRvUamDRSRtFVWbKSNl6dXlb3foNu5jb/t/M23X9"
    "BlnVyYmuUDD+fPGUhUrBBqFlK/nzeshN0gHYXlsrh2Id4kyWQkToTWau48B8SfpD75jE3Xj/G2ej"
    "ok0xvAjmxQrxfW+y4CRPf/qnWwTLDZNKt/9JkU0lIAgaCZOGLwW0lqe5ihNHPL1B3KVxqXbUZ3Ub"
    "x3gvVC53Ui6hU2aVCTRJlHHpy9QJl7HiUkHK4ikwzUpLfnD4HLj5PyhGPEwOIxrA2FlFHu3MYbpD"
    "DvkE3/qRo7XpwbiZLyVgoIl4I9n8toFFmdOdIV1CGBguiD3oMt7AYBjXAsfMG2zFFGvmdOymLSZI"
    "hQYhRYQKEt87Pb7x9ocAz4kCiEX72pJslC/qBse15wmxKQzAJ/1uDeMc39pZattGrajuNxvgDWjm"
    "LnorMilNrYuGx0VYYeIlf7TIxHF9Mhs9MeuA52x20zSJjJzzaznL2V3mR/nvPdevBJ/Az0t7EYj0"
    "oS9AgJcBzWIBztxWMITiwwhO1xX+SqRorCWesmXhSuIbBpUChL/SSO9KOzn+Drc1agPFLxe+mATS"
    "dS3ZwadxnNgqUrD4beSLegN0e4V+osVSNyCmLyN2Zvw1i/JuaH1K1sWYqjtmGeV1xYmjQKyjlMZk"
    "5etWtH8Aa1f3PDbENY2cr8MibM+6PN8g82dAWPUOIIETQLptQneiDuORfIEokhHpwuuFmrENAXuh"
    "KnjBkbqusb4/Equgm719braL7FmQmqb7nTQeBtYthMZEExhiIZlouSTuiYSkuNBEzbW5eKWyIErB"
    "sTPewuLyeq7OWFQh4PPuKK8OTa1CcBCeqIHqediz+4n31emF7ONPpwGVk+J2KYNOa79hglKNBjll"
    "Qy4ewtjfUdFT7zJwbfLuDMymLgbxy4K7X5Izqgw++FY9J/8GeVhdJNi5U9Co8QgcJISWim+ZuCgr"
    "kNeHZ4FH6Lmonayz6cOWwY1lYug4rqMotoqg7m1V/OHLP9ilSXU6IYaR2DrpU2RyegKWGhAsG5kj"
    "yRq0E3EqHmzlsXbPbynUPZ81ZcUJmcK3xDKp1sPOcUjmktE+aS0FYt4HYXgdy+sLjg7CtnxZsewg"
    "rc9txR4Gx+aTBcme2XhWo9FDVjEuJ5APEXXTO2da4zDpecv/vmdeF5WP+JKYqUzElQ0XJzBGId4V"
    "hBPO7BxKa54Qnyh2+3dvYEjWgekyM3ZcM/Fy29MxC/gy5bwH2BKJjI5odmc7LQMN/yzm3sMfvb/U"
    "753j26/pSHiZ3G9ZlAapdMrjdyjb+ClWldPFZmIF9TY6wOf7rA5Lwts6hcjsE87BGrDCq9c9eCNs"
    "U7O9ftgrAgwqLQ+Mqpu2OXFph/xgl6Pav5ZoxzToc9nOMahCiuzjEpWlDLz1DpsxcbdyvS9hAvwd"
    "dS0FNSpsYSuyt2w9LDH3HNkiiezm7yil7dZFtGxuOPvZL7yQgjgn7a+KQrMyRCWWrwuzED6uHdDR"
    "GtKXkLTXt4fip1ZO0cFX9ZdJtIr6xQ8SiP1yBgg52pBx0QbIhBjzV0NMBR7h/ss5NQkPxfvVsFHq"
    "K5kXoEE9PreD+PnAVOTBEYL5h+to2whTnX129RDiBXWPap5Hm2fR3nvJRIW6DYjt/5zjGFUKkXDU"
    "5PwPofo9KA0+JGwJ0K6zc9N5GsQf5TZTlBX4e4aPidnrdgOC6H2uOVj8uiTIn6SJFJgZ5cFxQGzn"
    "VIT8dbbaW5R2rOc4BJZNCYaavQJJ+tnDF5ZJ0t/y+cQ4Nw/RxxREMI+qIcifurklKOJDkrfcNu9P"
    "NxpfVSw/TmfokPdclwhbzDJSAF4XJt2NXw+ZjKpB7LVKeeI6NSkiujdtRvYY8cbXJ3rqd7EscSJF"
    "Wwzto74UeHNkcosup1fIndqfjAzK2OAV2VQOynwGETDjgLUaZRBQ9lsV49FcU52UyGYJCuN+5Or0"
    "6KLvNjQX63qLD08OtnghedHyRGjAXkfiqFHmgMevN4pJEB8NYPM5XVZ59ufQLtlQNCLmXG69/q1S"
    "ltgZObyWSU6qLLEXNSeqdmYaGXrDixvSBxMFTummbz/cYgu1/ZRyy78aQ0wKzmpjUmHezax9k2bs"
    "lV4ILVi+7aRns3uRatgxcN22Dk/Gp/YuW2zQAcyCEwxcUdH9rYsc2O/r79ViG4GAXuOyJqeg/y+/"
    "ulyy/hJ09224TJNCiWSE7H/rdEyVXO4dHbKcNX3oTFn+5a0ppsyRQH3BGaE4ya9GAIc7Zb8fVA5+"
    "KArCHmOxrNArDN/13bX8JMDq8jGz4gU7xITUEKRE+HVWSioebLsVsWAzqrV/+IwpHTVQJgg2QbfH"
    "kc9ia3vGe52TVCS5LPHJxY2DSZi7/XaZ7ARHoYpOu+dhwido2rayO1ZABQEAyw6vH7z4xb4puxuu"
    "w5614xVcXt3NezgExugxZVksiyxXUjcRF95m0h/P2a9339YTAjWPIfj4ZBY79JXl94vIBGXoPc2z"
    "Pgcosg3x5auoDZ0YX7Vj7CQpCAJtUcpCrjdwFLlpE0ujvZysQ1MrwfllOatrb0kDHtbKAGyTP7Sq"
    "mLelydWYMd1ZuLC3hmJ8OXnfHRhoi1fKqJLaD0qS4sMiuzE99sKnG60Jhlq0HEgwHGxZKHXYlUlS"
    "71zUWmQqVy5+fWgmQtMpXZom50lvqr0nqdiE6TaISRvgRkPp2yH7lGNDb4Qv1Q7Ot03KEURaV4WY"
    "0rJ+WBk/4MMh4RxoykZ7rf+6ThYw9tikXxxohtDZ6Tn+JJiewlEk87mBJMsnCF3AC2HFunmkav/v"
    "ljEBnOJcrMkz7KoINTL2UlK4VAy67g=="
)

# ══ Chiave di decifratura (derivata dalle stesse costanti del build) ══
_K_MAT = b'MANGOLINK_MESH_IT_2026_BUILD_PROTECTION_v2_ED25519'
_K_SALT = b'MeshtasticItaliaNetwork_SourceProtection_Salt_v1'

def _xd(data, key):
    kl = len(key)
    return bytes(b ^ key[i % kl] for i, b in enumerate(data))

def _load_module():
    """Decodifica, decripta, decomprime ed esegue il modulo in memoria"""
    key = hashlib.pbkdf2_hmac('sha256', _K_MAT, _K_SALT, 100_000, dklen=32)
    encrypted = base64.b64decode(_PAYLOAD)
    compressed = _xd(encrypted, key)
    source = zlib.decompress(compressed).decode('utf-8')
    code = compile(source, 'license_crypto.py', 'exec')
    # Crea un namespace pulito con i builtins
    ns = {"__builtins__": __builtins__, "__name__": __name__,
           "__file__": __file__, "__package__": __package__}
    exec(code, ns)
    return ns

# ══ Carica ed esporta tutto ══
try:
    _ns = _load_module()
    # Esporta tutti i nomi pubblici nel namespace del modulo
    for _name, _val in _ns.items():
        if not _name.startswith('_') or _name in (
            '_EMBEDDED_PUB_KEY_OBF', '_FALLBACK_PUB_KEY',
            '_FP_SALT', '_OBF_KEY_SEED', '_OBF_APP_SECRET',
        ):
            globals()[_name] = _val
    # Costruisci __all__ per import *
    __all__ = [k for k in _ns if not k.startswith('_')]
except Exception as _e:
    raise ImportError(
        f"Impossibile caricare {__name__}: {_e}. "
        "Il file potrebbe essere corrotto. Reinstalla l'app."
    ) from _e
