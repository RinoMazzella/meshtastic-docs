# -*- coding: utf-8 -*-
"""
Meshtastic Italia Network App v1.1.3 - Setup Doctor v1.0
Self-diagnosis del fingerprint hardware al primo avvio + ancoraggio
fingerprint persistente per resistere a piccole variazioni di sistema.

Modalita di funzionamento:
  - "dev" mode (sorgente non cifrato): puo' chiamare le funzioni private
    _get_cpu_id, _get_disk_id, ecc. per rilevare quale dei 5 componenti
    e' instabile (diagnostica granulare).
  - "loader" mode (loader criptato distribuito): le funzioni private non
    sono esposte dal loader -> usa solo generate_fingerprint() come API
    pubblica + uuid.getnode() per il MAC random check (diagnostica
    sufficiente: rileva FP stabile/instabile + MAC random/reale).

Anchor "morbido" (per scelta di Rino):
  - Chiave di cifratura derivata da CPU + OS_ID (NON dal fingerprint intero)
  - Sopravvive a cambi di MAC/Disk/Board (es. Windows Update che ruota
    il SerialNumber del disco)
  - Cambia SOLO se cambia la CPU o il MachineGuid/machine-id (eventi rari)
  - Anti-tampering: spostare .fp_anchor su altro PC -> CPU/OS_ID diversi
    -> decifratura fallisce -> ricalcolo onesto da hardware

(c) 2026 MANGOLINK - Tutti i diritti riservati
"""

import os
import sys
import json
import time
import hashlib
import platform
import subprocess
import uuid as _uuid_mod
from datetime import datetime
from pathlib import Path

# ===========================================================
# COSTANTI
# ===========================================================

ANCHOR_FILENAME = '.fp_anchor'
DOCTOR_STATE_FILENAME = '.doctor_state'
N_ITERATIONS = 10
ANCHOR_VERSION = 'v1'

# Variabile di stato runtime (popolata da run_first_boot_check)
_runtime_state = {
    'last_check': None,
    'stable': None,
    'unstable_components': [],
    'mac_is_random': False,
    'fp_anchored': None,
    'remedies': [],
    'system': {},
}


# ===========================================================
# PATH HELPERS
# ===========================================================

def _app_dir():
    """Ritorna la cartella app/ (struttura flat)."""
    return os.path.dirname(os.path.abspath(__file__))


def _anchor_path():
    return os.path.join(_app_dir(), ANCHOR_FILENAME)


def _state_path():
    return os.path.join(_app_dir(), DOCTOR_STATE_FILENAME)


# ===========================================================
# ANCHOR KEY - derivata da componenti molto stabili (CPU + OS_ID)
# ===========================================================

def _read_cpu_raw():
    """Lettura grezza del CPU ID, senza dipendere da license_manager."""
    system = platform.system()
    try:
        if system == 'Windows':
            result = subprocess.run(
                ['wmic', 'cpu', 'get', 'ProcessorId'],
                capture_output=True, text=True, timeout=8,
                encoding='utf-8', errors='replace',
                creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0)
            )
            for line in (result.stdout or '').split('\n'):
                line = line.strip()
                if line and line != 'ProcessorId':
                    return line
        elif system == 'Darwin':
            result = subprocess.run(
                ['sysctl', '-n', 'machdep.cpu.brand_string'],
                capture_output=True, text=True, timeout=8
            )
            return (result.stdout or '').strip()
        else:
            with open('/proc/cpuinfo', 'r', encoding='utf-8') as f:
                for line in f:
                    if 'model name' in line.lower() or 'serial' in line.lower():
                        return line.split(':')[1].strip()
    except Exception:
        pass
    return platform.processor() or 'unknown_cpu'


def _read_os_install_id_raw():
    """Lettura grezza dell'OS Install ID."""
    system = platform.system()
    try:
        if system == 'Windows':
            result = subprocess.run(
                ['reg', 'query', 'HKLM\\SOFTWARE\\Microsoft\\Cryptography',
                 '/v', 'MachineGuid'],
                capture_output=True, text=True, timeout=8,
                encoding='utf-8', errors='replace',
                creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0)
            )
            for line in (result.stdout or '').split('\n'):
                if 'MachineGuid' in line:
                    parts = line.strip().split()
                    if len(parts) >= 3:
                        return parts[-1]
        elif system == 'Darwin':
            result = subprocess.run(
                ['ioreg', '-rd1', '-c', 'IOPlatformExpertDevice'],
                capture_output=True, text=True, timeout=8
            )
            for line in (result.stdout or '').split('\n'):
                if 'IOPlatformUUID' in line:
                    parts = line.split('"')
                    if len(parts) >= 4:
                        return parts[-2]
        else:
            for p in ['/etc/machine-id', '/var/lib/dbus/machine-id']:
                pp = Path(p)
                if pp.exists():
                    return pp.read_text().strip()
    except Exception:
        pass
    return 'unknown_os_id'


def _get_anchor_passphrase():
    """
    Passphrase per crittare l'anchor: SHA-256(CPU_raw + '|' + OS_ID_raw).
    Stabile fintanto che CPU e MachineGuid non cambiano.
    """
    cpu = _read_cpu_raw()
    osid = _read_os_install_id_raw()
    seed = f'{cpu}|{osid}|MANGOLINK_FP_ANCHOR_v1'.encode('utf-8')
    return hashlib.sha256(seed).hexdigest()


# ===========================================================
# ANCHOR I/O - usa encrypt_cache/decrypt_cache di license_crypto
# ===========================================================

def save_anchor(fingerprint):
    """Salva il fingerprint stabile in .fp_anchor crittato."""
    try:
        from app.license_crypto import encrypt_cache
        data = {
            'version': ANCHOR_VERSION,
            'fingerprint': fingerprint,
            'created': datetime.now().isoformat(),
            'hostname': platform.node(),
            'os': platform.system(),
        }
        passphrase = _get_anchor_passphrase()
        encrypted = encrypt_cache(data, passphrase)
        with open(_anchor_path(), 'wb') as f:
            f.write(encrypted)
        try:
            os.chmod(_anchor_path(), 0o600)
        except Exception:
            pass
        return True
    except Exception as e:
        print(f'[DOCTOR] save_anchor failed: {e}', file=sys.stderr)
        return False


def load_anchor():
    """Legge il fingerprint dall'anchor. Ritorna None se assente/invalido."""
    path = _anchor_path()
    if not os.path.exists(path):
        return None
    try:
        from app.license_crypto import decrypt_cache
        with open(path, 'rb') as f:
            raw = f.read()
        passphrase = _get_anchor_passphrase()
        data = decrypt_cache(raw, passphrase)
        if data is None:
            return None
        if data.get('version') != ANCHOR_VERSION:
            return None
        return data.get('fingerprint')
    except Exception:
        return None


def clear_anchor():
    """Cancella l'anchor (es. dopo cambio hardware volontario)."""
    try:
        if os.path.exists(_anchor_path()):
            os.remove(_anchor_path())
        return True
    except Exception:
        return False


def get_stable_fp():
    """
    Funzione che license_manager chiama per ottenere il FP "ancorato".
    Ritorna None se anchor mancante o invalido.
    """
    return load_anchor()


# ===========================================================
# MAC RANDOM DETECTION (bit multicast)
# ===========================================================

def is_mac_random(mac_str):
    """
    Riconosce se uuid.getnode() ha generato un MAC random:
    Python imposta il bit multicast (LSB del primo octet) a 1 in caso
    di fallback random. MAC hardware veri hanno multicast bit = 0.
    """
    if not mac_str or mac_str == 'unknown_mac':
        return False
    try:
        first_octet = int(mac_str.split(':')[0], 16)
        return bool(first_octet & 0x01)
    except Exception:
        return False


def _current_mac_uuid():
    """Calcolo MAC autonomo usando uuid.getnode() (non dipende da license_manager)."""
    try:
        m = _uuid_mod.getnode()
        return ':'.join(f'{(m >> i) & 0xFF:02x}' for i in range(40, -1, -8))
    except Exception:
        return 'unknown_mac'


# ===========================================================
# CHECK DEPENDENCIES - Verifica librerie opzionali installate
# ===========================================================

def check_optional_deps():
    """Verifica getmac/psutil installati."""
    deps = {}
    for name in ('getmac', 'psutil'):
        try:
            __import__(name)
            deps[name] = True
        except ImportError:
            deps[name] = False
    return deps


# ===========================================================
# STRESS CHECK PRINCIPALE - 10 letture rapide del fingerprint
# ===========================================================

def run_first_boot_check(iterations=N_ITERATIONS, force=False):
    """
    Esegue il controllo di stabilita del fingerprint.

    Tenta diagnostica granulare (chiamando _get_cpu_id, _get_disk_id, ecc.)
    se in modalita sviluppo. Sul pacchetto distribuito (loader criptato),
    le funzioni private non sono esposte: ricade su check semplificato
    basato solo su generate_fingerprint() + uuid.getnode().
    """
    # Sempre disponibile: API pubblica del modulo
    from app.license_manager import generate_fingerprint

    # Tenta diagnostica granulare (solo dev mode, ImportError se loader)
    _priv = {}
    try:
        from app.license_manager import (
            _get_cpu_id as _gcpu, _get_disk_id as _gdisk,
            _get_mac_address as _gmac, _get_motherboard_id as _gboard,
            _get_os_install_id as _gosid
        )
        _priv = {'cpu': _gcpu, 'disk': _gdisk, 'mac': _gmac,
                 'board': _gboard, 'os_id': _gosid}
    except ImportError:
        pass  # Loader criptato: modalita diagnostica ridotta

    t0 = time.time()
    fps = []
    samples = {k: set() for k in ('cpu', 'disk', 'mac', 'board', 'os_id')}

    for _ in range(iterations):
        fps.append(generate_fingerprint())
        if _priv:
            for k, fn in _priv.items():
                try:
                    samples[k].add(fn())
                except Exception:
                    pass

    duration = time.time() - t0

    # Analisi base sui FP completi
    distinct_fps = len(set(fps))
    stable = (distinct_fps == 1)
    fp_current = fps[-1]

    # Analisi granulare (solo se private accessibili)
    unstable = []
    if _priv:
        for k, s in samples.items():
            if len(s) > 1:
                unstable.append(k)

    # MAC sample: dev mode usa _get_mac_address, altrimenti uuid.getnode()
    if _priv and samples.get('mac'):
        sample_mac = next(iter(samples['mac']))
    else:
        sample_mac = _current_mac_uuid()
    mac_random = is_mac_random(sample_mac)

    # Rimedi mirati per la UI
    remedies = _generate_remedies(unstable, mac_random)

    # Anchor: salva solo se stabile + MAC reale
    fp_anchored = load_anchor()
    if stable and not mac_random and not force:
        if fp_anchored != fp_current:
            save_anchor(fp_current)
            fp_anchored = fp_current

    sysinfo = {
        'os': platform.system(),
        'os_release': platform.release(),
        'hostname': platform.node(),
        'python': platform.python_version(),
    }

    result = {
        'stable': stable,
        'iterations': iterations,
        'distinct_fps': distinct_fps,
        'mac_is_random': mac_random,
        'mac_sample': sample_mac,
        'unstable_components': unstable,
        'fp_current': fp_current,
        'fp_anchored': fp_anchored,
        'remedies': remedies,
        'system': sysinfo,
        'optional_deps': check_optional_deps(),
        'duration_seconds': round(duration, 2),
        'timestamp': datetime.now().isoformat(),
        'diagnostic_mode': 'granular' if _priv else 'simplified',
    }

    # Salva stato per UI
    try:
        with open(_state_path(), 'w', encoding='utf-8') as f:
            json.dump(result, f, ensure_ascii=False, indent=2)
    except Exception:
        pass

    _runtime_state.update(result)
    return result


def _generate_remedies(unstable_components, mac_random):
    """Costruisce lista di CHIAVI i18n (la UI le traduce con t())."""
    remedies = []
    system = platform.system()

    if mac_random:
        if system == 'Linux':
            remedies.append('doctor_remedy.mac_random_linux')
        elif system == 'Windows':
            remedies.append('doctor_remedy.mac_random_windows')
        elif system == 'Darwin':
            remedies.append('doctor_remedy.mac_random_macos')

    if 'cpu' in unstable_components or 'disk' in unstable_components or 'board' in unstable_components:
        if system == 'Windows':
            remedies.append('doctor_remedy.wmic_unstable_windows')

    if 'os_id' in unstable_components:
        remedies.append('doctor_remedy.osid_unstable')

    if not remedies and len(unstable_components) > 0:
        remedies.append('doctor_remedy.generic_unstable')

    return remedies


# ===========================================================
# STATO PER API/UI
# ===========================================================

def _state_belongs_to_current_system(state):
    """
    True solo se lo state appartiene a QUESTO PC (OS + hostname).
    Difesa contro state copiato da altro PC o residui di test.
    """
    try:
        s = state.get('system') or {}
        if s.get('os') and s.get('os') != platform.system():
            return False
        if s.get('hostname') and s.get('hostname') != platform.node():
            return False
        return True
    except Exception:
        return False


def get_doctor_state():
    """
    Stato corrente del Doctor. None se mai eseguito.
    Auto-invalida state da altro PC/OS.
    """
    if _runtime_state.get('last_check') or _runtime_state.get('stable') is not None:
        if _state_belongs_to_current_system(_runtime_state):
            return _runtime_state
    try:
        if os.path.exists(_state_path()):
            with open(_state_path(), 'r', encoding='utf-8') as f:
                data = json.load(f)
            if not _state_belongs_to_current_system(data):
                try:
                    os.remove(_state_path())
                except Exception:
                    pass
                for k in list(_runtime_state.keys()):
                    _runtime_state[k] = None if not isinstance(_runtime_state[k], list) else []
                return None
            _runtime_state.update(data)
            return data
    except Exception:
        pass
    return None


def needs_first_boot_check():
    """True se primo avvio (no anchor, no stato VALIDO)."""
    if not os.path.exists(_anchor_path()) and not os.path.exists(_state_path()):
        return True
    if os.path.exists(_state_path()):
        try:
            with open(_state_path(), 'r', encoding='utf-8') as f:
                data = json.load(f)
            if not _state_belongs_to_current_system(data):
                return True
        except Exception:
            return True
    return False


# ===========================================================
# CLI per testing manuale
# ===========================================================

if __name__ == '__main__':
    print('Setup Doctor - Self-check fingerprint hardware')
    print('-' * 60)
    result = run_first_boot_check()
    print(json.dumps(result, indent=2, ensure_ascii=False))
    print()
    if result['stable'] and not result['mac_is_random']:
        print('OK Sistema stabile. Anchor salvato.')
    else:
        print('WARNING Sistema instabile. Rimedi:')
        for r in result['remedies']:
            print(f'  - {r}')

# ============================================================================
# End of file marker - padding di sicurezza per il filesystem sandbox.
# Modifica intenzionalmente questa sezione SOLO se aggiungi nuove funzioni
# alla fine del file, mai rimuovere - serve a evitare null-byte residui
# dovuti a Edit precedenti che non troncano correttamente la coda del file.
# ============================================================================
#
# Cronologia modifiche:
#   v1.0 (2026-05-21) - Versione iniziale.
#                       10 letture FP, anchor CPU+OS_ID, MAC random detection,
#                       banner non bloccante con chiavi i18n.
#   v1.0.1 (2026-05-22) - Fix loader criptato.
#                          run_first_boot_check ora tenta l'import delle
#                          funzioni private; se ImportError (loader criptato
#                          in distribuzione), ricade su modalita semplificata
#                          basata solo su generate_fingerprint() + uuid.getnode()
#                          per il MAC. Aggiunto campo 'diagnostic_mode' nello
#                          stato per distinguere granular vs simplified.
#                          Auto-invalidazione state da altro OS/hostname.
# ============================================================================
