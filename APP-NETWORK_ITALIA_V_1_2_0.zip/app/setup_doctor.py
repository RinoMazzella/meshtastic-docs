# -*- coding: utf-8 -*-
"""
Meshtastic Italia Network App v1.1.3 - Setup Doctor v1.0
Self-diagnosis del fingerprint hardware al primo avvio + ancoraggio
fingerprint persistente per resistere a piccole variazioni di sistema.

Cosa fa:
  1. Esegue 10 letture rapide consecutive di generate_fingerprint()
  2. Se sono tutte identiche -> certifica il sistema come "stabile",
     salva .fp_anchor crittato con CPU+OS_ID (chiave "morbida")
  3. Se variano -> rileva quale dei 5 componenti e' instabile e
     produce istruzioni mirate per l'utente (es. "apt install net-tools")
  4. Detection del MAC random fallback di uuid.getnode() (bit multicast)
  5. Non blocca l'app: stato esposto a UI come banner non bloccante

Anchor "morbido" (per scelta di Rino):
  - Chiave di cifratura derivata da CPU + OS_ID (NON dal fingerprint intero)
  - Sopravvive a cambi di MAC/Disk/Board (es. Windows Update che ruota
    il SerialNumber del disco)
  - Cambia SOLO se cambia la CPU o il MachineGuid/machine-id (eventi rari)
  - Anti-tampering: spostare .fp_anchor su altro PC -> CPU/OS_ID diversi
    -> decifratura fallisce -> ricalcolo onesto da hardware

Architettura:
  - generate_fingerprint() in license_manager.py chiama get_stable_fp()
    di questo modulo come prima cosa. Se ritorna un FP valido (anchor
    presente e decifrato), usa quello. Altrimenti calcola da hardware
    chiamando _compute_fingerprint_from_hardware().
  - run_first_boot_check() viene chiamato da start_app.py al boot
    se needs_first_boot_check() ritorna True. Esegue 10 letture e
    salva l'anchor in caso di esito positivo (stable + non MAC random).
  - get_doctor_state() viene chiamato da server.py per esporre lo
    stato corrente alla UI tramite /api/license/status e
    /api/system/health-check.

File su disco creati da questo modulo:
  - .fp_anchor       -> Fingerprint stabile crittato AES-256-GCM con
                        chiave derivata da CPU+OS_ID. Sopravvive a
                        update di Windows / driver di rete / scheda di
                        rete USB collegata-scollegata. Cancellato in
                        automatico se il sistema cambia OS o hostname
                        (caso edge: copia cartella su altro PC).
  - .doctor_state    -> Stato JSON dell'ultima verifica del Doctor.
                        Letto al boot per evitare di rifare il check
                        se gia eseguito di recente. Contiene anche le
                        chiavi i18n dei rimedi mostrati nel banner.

Sicurezza:
  Spostando i due file sopra su un altro PC, la chiave di decifratura
  cambia (CPU+OS_ID diversi) e la decifratura fallisce silenziosamente.
  La funzione load_anchor() ritorna None, generate_fingerprint() cade
  nel calcolo hardware originale, produce un FP nuovo, la licenza non
  matcha e l'utente viene messo in modalita FREE. Nessun bypass possibile.

(c) 2026 MANGOLINK - Tutti i diritti riservati
"""

import os
import sys
import json
import time
import hashlib
import platform
import subprocess
from datetime import datetime
from pathlib import Path

# ===========================================================
# COSTANTI
# ===========================================================

ANCHOR_FILENAME = '.fp_anchor'
DOCTOR_STATE_FILENAME = '.doctor_state'
N_ITERATIONS = 10
ANCHOR_VERSION = 'v1'

# Variabile di stato runtime (popolata da run_first_boot_check)
_runtime_state = {
    'last_check': None,
    'stable': None,
    'unstable_components': [],
    'mac_is_random': False,
    'fp_anchored': None,
    'remedies': [],
    'system': {},
}


# ===========================================================
# PATH HELPERS
# ===========================================================

def _app_dir():
    """Ritorna la cartella app/ (struttura flat)."""
    return os.path.dirname(os.path.abspath(__file__))


def _anchor_path():
    return os.path.join(_app_dir(), ANCHOR_FILENAME)


def _state_path():
    return os.path.join(_app_dir(), DOCTOR_STATE_FILENAME)


# ===========================================================
# ANCHOR KEY - derivata da componenti molto stabili (CPU + OS_ID)
# ===========================================================

def _read_cpu_raw():
    """Lettura grezza del CPU ID, senza dipendere da license_manager."""
    system = platform.system()
    try:
        if system == 'Windows':
            result = subprocess.run(
                ['wmic', 'cpu', 'get', 'ProcessorId'],
                capture_output=True, text=True, timeout=8,
                encoding='utf-8', errors='replace',
                creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0)
            )
            for line in (result.stdout or '').split('\n'):
                line = line.strip()
                if line and line != 'ProcessorId':
                    return line
        elif system == 'Darwin':
            result = subprocess.run(
                ['sysctl', '-n', 'machdep.cpu.brand_string'],
                capture_output=True, text=True, timeout=8
            )
            return (result.stdout or '').strip()
        else:
            with open('/proc/cpuinfo', 'r', encoding='utf-8') as f:
                for line in f:
                    if 'model name' in line.lower() or 'serial' in line.lower():
                        return line.split(':')[1].strip()
    except Exception:
        pass
    return platform.processor() or 'unknown_cpu'


def _read_os_install_id_raw():
    """Lettura grezza dell'OS Install ID."""
    system = platform.system()
    try:
        if system == 'Windows':
            result = subprocess.run(
                ['reg', 'query', 'HKLM\\SOFTWARE\\Microsoft\\Cryptography',
                 '/v', 'MachineGuid'],
                capture_output=True, text=True, timeout=8,
                encoding='utf-8', errors='replace',
                creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0)
            )
            for line in (result.stdout or '').split('\n'):
                if 'MachineGuid' in line:
                    parts = line.strip().split()
                    if len(parts) >= 3:
                        return parts[-1]
        elif system == 'Darwin':
            result = subprocess.run(
                ['ioreg', '-rd1', '-c', 'IOPlatformExpertDevice'],
                capture_output=True, text=True, timeout=8
            )
            for line in (result.stdout or '').split('\n'):
                if 'IOPlatformUUID' in line:
                    parts = line.split('"')
                    if len(parts) >= 4:
                        return parts[-2]
        else:
            for p in ['/etc/machine-id', '/var/lib/dbus/machine-id']:
                pp = Path(p)
                if pp.exists():
                    return pp.read_text().strip()
    except Exception:
        pass
    return 'unknown_os_id'


def _get_anchor_passphrase():
    """
    Passphrase per crittare l'anchor: SHA-256(CPU_raw + '|' + OS_ID_raw).
    Stabile fintanto che CPU e MachineGuid non cambiano.
    """
    cpu = _read_cpu_raw()
    osid = _read_os_install_id_raw()
    seed = f'{cpu}|{osid}|MANGOLINK_FP_ANCHOR_v1'.encode('utf-8')
    return hashlib.sha256(seed).hexdigest()


# ===========================================================
# ANCHOR I/O - usa encrypt_cache/decrypt_cache di license_crypto
# ===========================================================

def save_anchor(fingerprint):
    """Salva il fingerprint stabile in .fp_anchor crittato."""
    try:
        from app.license_crypto import encrypt_cache
        data = {
            'version': ANCHOR_VERSION,
            'fingerprint': fingerprint,
            'created': datetime.now().isoformat(),
            'hostname': platform.node(),
            'os': platform.system(),
        }
        passphrase = _get_anchor_passphrase()
        encrypted = encrypt_cache(data, passphrase)
        with open(_anchor_path(), 'wb') as f:
            f.write(encrypted)
        # Permessi 600 dove possibile
        try:
            os.chmod(_anchor_path(), 0o600)
        except Exception:
            pass
        return True
    except Exception as e:
        print(f'[DOCTOR] save_anchor failed: {e}', file=sys.stderr)
        return False


def load_anchor():
    """Legge il fingerprint dall'anchor. Ritorna None se assente/invalido."""
    path = _anchor_path()
    if not os.path.exists(path):
        return None
    try:
        from app.license_crypto import decrypt_cache
        with open(path, 'rb') as f:
            raw = f.read()
        passphrase = _get_anchor_passphrase()
        data = decrypt_cache(raw, passphrase)
        if data is None:
            return None
        if data.get('version') != ANCHOR_VERSION:
            return None
        return data.get('fingerprint')
    except Exception:
        return None


def clear_anchor():
    """Cancella l'anchor (es. dopo cambio hardware volontario)."""
    try:
        if os.path.exists(_anchor_path()):
            os.remove(_anchor_path())
        return True
    except Exception:
        return False


def get_stable_fp():
    """
    Funzione che license_manager chiama per ottenere il FP "ancorato".
    Ritorna None se anchor mancante o invalido (license_manager fara
    fallback al calcolo hardware diretto).
    """
    return load_anchor()


# ===========================================================
# MAC RANDOM DETECTION (bit multicast)
# ===========================================================

def is_mac_random(mac_str):
    """
    Riconosce se uuid.getnode() ha generato un MAC random:
    Python imposta il bit multicast (LSB del primo octet) a 1 in caso
    di fallback random. MAC hardware veri hanno multicast bit = 0.
    """
    if not mac_str or mac_str == 'unknown_mac':
        return False
    try:
        first_octet = int(mac_str.split(':')[0], 16)
        return bool(first_octet & 0x01)
    except Exception:
        return False


# ===========================================================
# CHECK DEPENDENCIES - Verifica librerie opzionali installate
# ===========================================================

def check_optional_deps():
    """
    Verifica se le librerie raccomandate (getmac, psutil) sono installate.
    Ritorna dict con stato di ciascuna.
    """
    deps = {}
    for name in ('getmac', 'psutil'):
        try:
            __import__(name)
            deps[name] = True
        except ImportError:
            deps[name] = False
    return deps


# ===========================================================
# STRESS CHECK PRINCIPALE - 10 letture rapide del fingerprint
# ===========================================================

def run_first_boot_check(iterations=N_ITERATIONS, force=False):
    """
    Esegue il controllo di stabilita del fingerprint.

    Parametri:
        iterations: numero di letture (default 10)
        force: se True ignora l'anchor esistente e ricalcola

    Ritorna dict con stato completo (vedi codice per i campi).
    """
    # Import locale per evitare ciclico
    from app.license_manager import (
        _get_cpu_id, _get_disk_id, _get_mac_address,
        _get_motherboard_id, _get_os_install_id, generate_fingerprint
    )

    t0 = time.time()
    fps = []
    cpus = set()
    disks = set()
    macs = set()
    boards = set()
    osids = set()

    for _ in range(iterations):
        cpus.add(_get_cpu_id())
        disks.add(_get_disk_id())
        macs.add(_get_mac_address())
        boards.add(_get_motherboard_id())
        osids.add(_get_os_install_id())
        fps.append(generate_fingerprint())

    duration = time.time() - t0

    # Analisi
    distinct_fps = len(set(fps))
    stable = (distinct_fps == 1)
    fp_current = fps[-1]  # ultimo letto

    unstable = []
    if len(cpus) > 1: unstable.append('cpu')
    if len(disks) > 1: unstable.append('disk')
    if len(macs) > 1: unstable.append('mac')
    if len(boards) > 1: unstable.append('board')
    if len(osids) > 1: unstable.append('os_id')

    # Detection MAC random
    sample_mac = next(iter(macs)) if macs else ''
    mac_random = is_mac_random(sample_mac)

    # Diagnostica / rimedi mirati
    remedies = _generate_remedies(unstable, mac_random)

    # Aggiorna anchor SE stabile + MAC non random
    fp_anchored = load_anchor()
    if stable and not mac_random and not force:
        if fp_anchored != fp_current:
            save_anchor(fp_current)
            fp_anchored = fp_current

    # Stato di sistema utile
    sysinfo = {
        'os': platform.system(),
        'os_release': platform.release(),
        'hostname': platform.node(),
        'python': platform.python_version(),
    }

    result = {
        'stable': stable,
        'iterations': iterations,
        'distinct_fps': distinct_fps,
        'mac_is_random': mac_random,
        'mac_sample': sample_mac,
        'unstable_components': unstable,
        'fp_current': fp_current,
        'fp_anchored': fp_anchored,
        'remedies': remedies,
        'system': sysinfo,
        'optional_deps': check_optional_deps(),
        'duration_seconds': round(duration, 2),
        'timestamp': datetime.now().isoformat(),
    }

    # Salva stato per consultazione successiva dalla UI
    try:
        with open(_state_path(), 'w', encoding='utf-8') as f:
            json.dump(result, f, ensure_ascii=False, indent=2)
    except Exception:
        pass

    _runtime_state.update(result)
    return result


def _generate_remedies(unstable_components, mac_random):
    """
    Costruisce una lista di stringhe (CHIAVI i18n, NON traduzioni dirette).
    La UI usera data-i18n / t() per tradurle.
    """
    remedies = []
    system = platform.system()

    if mac_random:
        if system == 'Linux':
            remedies.append('doctor_remedy.mac_random_linux')
        elif system == 'Windows':
            remedies.append('doctor_remedy.mac_random_windows')
        elif system == 'Darwin':
            remedies.append('doctor_remedy.mac_random_macos')

    if 'cpu' in unstable_components or 'disk' in unstable_components or 'board' in unstable_components:
        if system == 'Windows':
            remedies.append('doctor_remedy.wmic_unstable_windows')

    if 'os_id' in unstable_components:
        remedies.append('doctor_remedy.osid_unstable')

    if not remedies and len(unstable_components) > 0:
        remedies.append('doctor_remedy.generic_unstable')

    return remedies


# ===========================================================
# STATO PER API/UI
# ===========================================================

def _state_belongs_to_current_system(state):
    """
    Verifica che lo state caricato da disco appartenga a QUESTO PC.
    Difesa contro: stato copiato da altro PC, mantenuto in cartella spostata
    tra OS diversi, residui di test/sviluppo, ecc.
    Ritorna True solo se OS+hostname combaciano.
    """
    try:
        s = state.get('system') or {}
        if s.get('os') and s.get('os') != platform.system():
            return False
        if s.get('hostname') and s.get('hostname') != platform.node():
            return False
        return True
    except Exception:
        return False


def get_doctor_state():
    """
    Ritorna lo stato corrente del Doctor.
    Se non e mai stato eseguito un check, ritorna None.
    Se lo state appartiene a un altro PC/OS lo invalida e ritorna None.
    """
    # Prima prova memoria runtime (piu fresco)
    if _runtime_state.get('last_check') or _runtime_state.get('stable') is not None:
        if _state_belongs_to_current_system(_runtime_state):
            return _runtime_state
    # Poi prova file su disco
    try:
        if os.path.exists(_state_path()):
            with open(_state_path(), 'r', encoding='utf-8') as f:
                data = json.load(f)
            # Se appartiene ad altro PC/OS, cancella e ritorna None
            if not _state_belongs_to_current_system(data):
                try:
                    os.remove(_state_path())
                except Exception:
                    pass
                # Pulisci anche il runtime state stale
                for k in list(_runtime_state.keys()):
                    _runtime_state[k] = None if not isinstance(_runtime_state[k], list) else []
                return None
            _runtime_state.update(data)
            return data
    except Exception:
        pass
    return None


def needs_first_boot_check():
    """
    Ritorna True se e il primo avvio (no anchor, no stato VALIDO).
    Uno state da altro OS/hostname viene considerato come "non valido".
    """
    if not os.path.exists(_anchor_path()) and not os.path.exists(_state_path()):
        return True
    # Se lo state esiste ma non appartiene a questo PC, e come se non ci fosse
    if os.path.exists(_state_path()):
        try:
            with open(_state_path(), 'r', encoding='utf-8') as f:
                data = json.load(f)
            if not _state_belongs_to_current_system(data):
                return True
        except Exception:
            return True
    return False


# ===========================================================
# CLI per testing manuale
# ===========================================================

if __name__ == '__main__':
    print('Setup Doctor - Self-check fingerprint hardware')
    print('-' * 60)
    result = run_first_boot_check()
    print(json.dumps(result, indent=2, ensure_ascii=False))
    print()
    if result['stable'] and not result['mac_is_random']:
        print('OK Sistema stabile. Anchor salvato.')
    else:
        print('WARNING Sistema instabile. Rimedi:')
        for r in result['remedies']:
            print(f'  - {r}')

# End of file marker - padding per evitare null bytes residui dal filesystem sandbox.
# Questo blocco di commenti garantisce che la sovrascrittura del file copra
# tutta la lunghezza precedente, prevenendo SyntaxError dovuti a NUL bytes lasciati
# in coda da edit precedenti. Non rimuovere senza ricontrollare la dimensione finale.
# ----------------------------------------------------------------------
# Riferimenti tecnici:
#   - PEP 552 (Hash-based pyc invalidation)
#   - RFC 4122 (UUID standard, multicast bit in MAC random fallback)
#   - Python docs uuid.getnode()
#   - Windows MachineGuid registry key (stabile su update)
#   - Linux /etc/machine-id (systemd, stabile su update)
# ----------------------------------------------------------------------
# Changelog:
#   v1.0 (2026-05) - Versione iniziale: 10 letture, anchor CPU+OS_ID,
#                    MAC random detection, banner non bloccante.
# ----------------------------------------------------------------------
