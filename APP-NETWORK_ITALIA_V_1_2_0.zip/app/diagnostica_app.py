# -*- coding: utf-8 -*-
"""
🩺 DIAGNOSTICA APP — Meshtastic Italia Network App
© 2026 MANGOLINK — Strumento per utenti.

Cosa fa: verifica i file licenza (license.key + pub_key), fa uno STRESS TEST
del codice macchina (fingerprint), verifica la licenza (firma/fingerprint/
scadenza/revoca), controlla le dipendenze, e SCRIVE UN REPORT dettagliato che
dice ESATTAMENTE cosa non va e come risolvere.

Lancia:  doppio-click su  diagnostica.bat   (oppure:  python diagnostica_app.py)
"""
import os, sys, platform, datetime

APP_DIR = os.path.dirname(os.path.abspath(__file__))   # cartella app/
ROOT = os.path.dirname(APP_DIR)
for _p in (ROOT, APP_DIR):
    if _p not in sys.path:
        sys.path.insert(0, _p)

REPORT = []
def log(s=""):
    print(s)
    REPORT.append(s)
def section(t):
    log("")
    log("=" * 62)
    log("  " + t)
    log("=" * 62)

PROBLEMS = []   # (gravita, problema, soluzione)
def add_problem(sev, prob, sol):
    PROBLEMS.append((sev, prob, sol))

# ── import moduli licenza (struttura pacchetto: app/ con __init__.py) ──
lm = lc = None
import_err = None
try:
    from app import license_manager as lm
    from app import license_crypto as lc
except Exception as e1:
    try:
        import license_manager as lm
        import license_crypto as lc
    except Exception as e2:
        import_err = "%s / %s" % (e1, e2)

def _search_key_file(names):
    """Cerca un file (per nome esatto) nelle cartelle vicine. Ritorna (dir, nome) o None."""
    dirs = [APP_DIR, ROOT,
            os.path.expanduser("~/Desktop"), os.path.expanduser("~/Downloads"),
            os.path.expanduser("~")]
    for d in dirs:
        for n in names:
            p = os.path.join(d, n)
            if os.path.isfile(p):
                return (d, n)
    return None

def _search_by_keyword(keyword):
    """Cerca un file che contiene 'keyword' nel nome (per estensioni sbagliate)."""
    dirs = [APP_DIR, ROOT, os.path.expanduser("~/Desktop"), os.path.expanduser("~/Downloads")]
    for d in dirs:
        try:
            for f in os.listdir(d):
                if keyword in f.lower() and os.path.isfile(os.path.join(d, f)):
                    return (d, f)
        except Exception:
            pass
    return None

def check_license_files():
    section("1. FILE LICENZA (devono stare ENTRAMBI nella cartella app/)")
    log("  Cartella app/: " + APP_DIR)
    # license.key
    lk = os.path.join(APP_DIR, "license.key")
    if os.path.isfile(lk):
        log("  [OK] license.key presente (%d byte)" % os.path.getsize(lk))
    else:
        log("  [X]  license.key NON presente nella cartella app/")
        hit = _search_key_file(["license.key"]) or _search_by_keyword("license")
        if hit:
            add_problem("ALTA", "license.key si trova in '%s' (file: %s), non nella cartella app/" % hit,
                        "Sposta license.key dentro la cartella app/: %s" % APP_DIR)
        else:
            add_problem("ALTA", "license.key non trovato sul PC",
                        "Chiedi a MANGOLINK il file license.key per questo PC e mettilo nella cartella app/")
    # pub_key — l'app ORA accetta anche estensioni (pub_key.dat/.txt/...) - audit 2026-06-04
    import glob as _g
    _pk = None
    _cands = (['pub_key', '.pub_key']
              + sorted(os.path.basename(p) for p in _g.glob(os.path.join(APP_DIR, 'pub_key.*')))
              + sorted(os.path.basename(p) for p in _g.glob(os.path.join(APP_DIR, '.pub_key.*'))))
    for _n in _cands:
        _p = os.path.join(APP_DIR, _n)
        if os.path.isfile(_p):
            _pk = (_n, _p)
            break
    if _pk:
        _n, _p = _pk
        _valid = False
        if lc is not None:
            try:
                _k = lc.load_key_from_file(_p)
                _valid = bool(_k and len(_k) == 32)
            except Exception:
                _valid = False
        if _valid:
            log("  [OK] chiave pubblica presente: %s (32 byte Ed25519)" % _n)
            if _n not in ('pub_key', '.pub_key'):
                log("       (l'app l'accetta anche cosi'; volendo puoi rinominarlo in 'pub_key')")
        else:
            log("  [X]  '%s' presente ma contenuto NON valido" % _n)
            add_problem("ALTA", "il file chiave '%s' non e' una chiave valida (32 byte)" % _n,
                        "Sostituisci col file pub_key ORIGINALE ricevuto dall'admin")
    else:
        log("  [X]  chiave pubblica (pub_key) NON presente nella cartella app/")
        hit = _search_key_file(["pub_key", ".pub_key"]) or _search_by_keyword("pub")
        if hit:
            add_problem("ALTA", "la chiave pub_key e' in '%s' (file: %s) ma deve stare nella cartella app/" % hit,
                        "Sposta il file pub_key dentro la cartella app/: %s" % APP_DIR)
        else:
            add_problem("ALTA", "pub_key non trovato sul PC",
                        "Chiedi a MANGOLINK il file pub_key (va SEMPRE insieme a license.key) e mettilo nella cartella app/")
        log("       NB: license.key e pub_key vanno SEMPRE INSIEME nella cartella app/.")

def check_deps():
    section("2. DIPENDENZE PYTHON")
    log("  Python %s su %s %s" % (platform.python_version(), platform.system(), platform.release()))
    miss = []
    for m in ["flask", "flask_cors", "cryptography", "serial", "meshtastic"]:
        try:
            __import__(m)
            log("  [OK] %s" % m)
        except Exception:
            log("  [X]  %s MANCANTE" % m)
            miss.append("pyserial" if m == "serial" else m.replace("_", "-"))
    if miss:
        add_problem("MEDIA", "dipendenze Python mancanti: %s" % ", ".join(miss),
                    "Apri un terminale nella cartella app/ e lancia:  python -m pip install %s" % " ".join(miss))

def fingerprint_stress():
    section("3. CODICE MACCHINA (fingerprint) — STRESS TEST 10 letture")
    if lm is None:
        log("  [!] Modulo licenza non caricato: %s" % import_err)
        return
    fps = []
    try:
        for _ in range(10):
            fps.append(lm.generate_fingerprint())
    except Exception as e:
        log("  [X] Errore nel calcolo del codice macchina: %s" % e)
        add_problem("CRITICA", "errore nel calcolo del codice macchina: %s" % e,
                    "Manda questo report a MANGOLINK")
        return
    uniq = sorted(set(fps))
    log("  Codice macchina di questo PC: %s" % fps[0])
    log("  10 letture -> %d valore/i distinto/i" % len(uniq))
    if len(uniq) == 1:
        log("  [OK] STABILE — il codice macchina non cambia (perfetto per la licenza).")
    else:
        log("  [X]  INSTABILE — il codice macchina cambia tra le letture:")
        for v in uniq:
            log("        - %s" % v)
        add_problem("CRITICA",
            "il codice macchina e' INSTABILE (cambia tra un avvio e l'altro): la licenza non potra' mai combaciare",
            "Linux: 'sudo apt install net-tools uuid-runtime' poi riavvia. Windows/macOS: manda il report a MANGOLINK (serve un anchor del fingerprint).")
    anchor = os.path.join(APP_DIR, ".fp_anchor")
    log("  Anchor fingerprint (.fp_anchor): %s" % ("presente" if os.path.isfile(anchor) else "assente"))

def license_verify():
    section("4. VERIFICA LICENZA (firma + fingerprint + scadenza + revoca)")
    if lm is None:
        log("  [!] Modulo licenza non caricato.")
        return
    try:
        d = lm.diagnose_license()
    except Exception as e:
        log("  [X] diagnose_license errore: %s" % e)
        return
    summ = d.get("summary", "?")
    log("  Stato licenza: %s" % summ)
    if d.get("message"):
        log("  Messaggio app: %s" % d.get("message"))
    fp_mismatch = expired = revoked = False
    for s in d.get("steps", []):
        if not isinstance(s, dict):
            continue
        name = s.get("name") or s.get("step") or s.get("label") or ""
        ok = s.get("ok")
        if ok is None:
            ok = s.get("status") in (True, "ok", "OK", "pass")
        det = s.get("detail") or s.get("message") or ""
        log("   %s %s%s" % ("[OK]" if ok else "[X] ", name, (" -> " + str(det)) if det else ""))
        low = (str(name) + " " + str(det)).lower()
        skipped = "skippato" in low or "skip" in low
        if not ok and not skipped:
            if "corrispond" in low:
                fp_mismatch = True
            if "scaden" in low or "expir" in low:
                expired = True
            if "revoc" in low:
                revoked = True
    if summ == "valid":
        log("  [OK] LICENZA VALIDA E ATTIVA — modalita' PRO.")
    if fp_mismatch:
        add_problem("ALTA", "la licenza e' di un ALTRO PC (fingerprint diverso da questo)",
                    "Serve una licenza NUOVA generata per QUESTO PC. Manda all'admin il codice macchina mostrato al punto 3.")
    if expired:
        add_problem("ALTA", "la licenza e' SCADUTA",
                    "Chiedi a MANGOLINK il rinnovo della licenza.")
    if revoked:
        add_problem("ALTA", "la licenza risulta REVOCATA",
                    "Contatta MANGOLINK.")

def write_report():
    section("RIEPILOGO — COSA NON VA E COME RISOLVERE")
    if not PROBLEMS:
        log("  [OK] NESSUN PROBLEMA RILEVATO. Se l'app resta in FREE, riavviala.")
    else:
        order = {"CRITICA": 0, "ALTA": 1, "MEDIA": 2}
        for i, (sev, prob, sol) in enumerate(sorted(PROBLEMS, key=lambda x: order.get(x[0], 9)), 1):
            log("")
            log("  PROBLEMA %d  [%s]" % (i, sev))
            log("     Cosa: " + prob)
            log("     Come risolvere: " + sol)
    # salva il report
    fname = "REPORT_DIAGNOSTICA_%s.txt" % datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    saved = None
    for d in (os.path.expanduser("~/Desktop"), APP_DIR, os.path.expanduser("~")):
        try:
            p = os.path.join(d, fname)
            with open(p, "w", encoding="utf-8") as f:
                f.write("\n".join(REPORT))
                f.write("\n\n--- Invia questo file a MANGOLINK per assistenza ---\n")
            saved = p
            break
        except Exception:
            continue
    section("REPORT SALVATO")
    if saved:
        log("  File: " + saved)
        log("  Se serve aiuto, invia questo file a MANGOLINK: dice esattamente dov'e' il problema.")
    else:
        log("  [!] Impossibile salvare il report (permessi cartella).")

def main():
    section("DIAGNOSTICA APP — Meshtastic Italia Network  (c) 2026 MANGOLINK")
    log("  Data: " + datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
    check_license_files()
    check_deps()
    fingerprint_stress()
    license_verify()
    write_report()

if __name__ == "__main__":
    try:
        main()
    except Exception:
        import traceback
        traceback.print_exc()
    print("")
    try:
        input("Premi INVIO per chiudere...")
    except Exception:
        pass
