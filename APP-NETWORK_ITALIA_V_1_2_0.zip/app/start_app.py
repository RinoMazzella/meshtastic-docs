# -*- coding: utf-8 -*-
"""
Meshtastic Italia Network App v1.2.0 - Launcher
Avvia l'app in modo automatico su qualsiasi OS.
(c) 2026 MANGOLINK - Tutti i diritti riservati
"""

import os
import sys
import time
import subprocess
import webbrowser
import socket

# ===========================================================
# FIX PATH - garantisce che 'from app.xxx' funzioni sempre,
# sia lanciando da dentro app/ che dalla directory padre.
# ===========================================================
_this_dir = os.path.dirname(os.path.abspath(__file__))
_parent_dir = os.path.dirname(_this_dir)
if _parent_dir not in sys.path:
    sys.path.insert(0, _parent_dir)

# ===========================================================
# CONFIGURAZIONE
# ===========================================================

APP_NAME = "Meshtastic Italia Network App v1.2.0"
DEFAULT_PORT = 5555
MAX_PORT_TRIES = 10

# ===========================================================
# COLORI TERMINALE
# ===========================================================

import ctypes
import platform as _plat

if _plat.system() == "Windows":
    try:
        kernel32 = ctypes.windll.kernel32
        kernel32.SetConsoleMode(kernel32.GetStdHandle(-11), 7)
    except Exception:
        pass

class C:
    G  = "\033[32m"
    LG = "\033[92m"
    R  = "\033[31m"
    LR = "\033[91m"
    Y  = "\033[93m"
    CY = "\033[96m"
    W  = "\033[97m"
    DM = "\033[90m"
    B  = "\033[1m"
    X  = "\033[0m"


def banner():
    g=C.G; lg=C.LG; r=C.LR; w=C.W; cy=C.CY; dm=C.DM; b=C.B; x=C.X
    fl=f"{g}████{w}████{r}████{x}"
    ln=f"{dm}════════════════════════════════════{x}"
    print(f"""
{dm}  ╔════════════════════════════════════════════════════════════════════╗{x}
{dm}  ║{x}  {lg}{b}MESHTASTIC ITALIA NETWORK — LoRa 868 MHz Mesh{x}                       {dm}║{x}
{dm}  ║{x}  {fl}{ln}{fl}  {dm}║{x}
{dm}  ║{x}  {fl}    {w}{b}M E S H T A S T I C  I T A L I A . I T{x}    {fl}  {dm}║{x}
{dm}  ║{x}  {fl}{ln}{fl}  {dm}║{x}
{dm}  ║{x}   {w}\U0001f4e1  Comunicazione Off-Grid per Tutti — LoRa 868 MHz Mesh{x}        {dm}║{x}
{dm}  ║{x}   {cy}\U0001f310 www.meshtasticitalia.it{x}        {cy}✈  t.me/MeshtasticItalia{x}     {dm}║{x}
{dm}  ║{x}   {cy}\U0001f4e7 info@meshtasticitalia.it{x}       {cy}\U0001f47e discord.gg/Rbhwf54nB3{x}     {dm}║{x}
{dm}  ║{x}   {lg}{b}⚡ App v1.2.0{x}  {dm}│{x}  {lg}Regione: EU_868{x}  {dm}│{x}  {lg}Preset: MediumFast{x}        {dm}║{x}
{dm}  ╚════════════════════════════════════════════════════════════════════╝{x}
""")


def log(msg, level="info"):
    icons  = {"info":"ℹ ", "ok":"✅", "warn":"⚠ ", "error":"❌", "start":"🚀"}
    colors = {"info":C.CY, "ok":C.LG, "warn":C.Y, "error":C.LR, "start":C.LG+C.B}
    print(f"  {colors.get(level,'')}{icons.get(level,'')} {msg}{C.X}")


def check_python():
    v = sys.version_info
    log(f"Python {v.major}.{v.minor}.{v.micro} trovato", "ok")
    if v.major < 3 or (v.major == 3 and v.minor < 9):
        log("Serve Python 3.9 o superiore!", "error")
        return False
    # Avviso per Python troppo nuovo (3.14+ non compatibile con meshtastic)
    if v.major == 3 and v.minor >= 14:
        log(f"Python {v.major}.{v.minor} potrebbe NON essere compatibile con meshtastic!", "warn")
        log("   Raccomandata: Python 3.11 o 3.12", "info")
        log("   Download: https://www.python.org/downloads/release/python-3120/", "info")
        log("   L'app tenterà di funzionare comunque - eventuali errori", "info")
        log("   verranno gestiti dall'auto-diagnosi nel browser.", "info")
    return True


def check_meshtastic_version():
    """Verifica che meshtastic CLI sia compatibile con la versione Python"""
    try:
        import meshtastic
        ver = getattr(meshtastic, '__version__', None)
        if ver:
            log(f"Meshtastic CLI v{ver} trovato", "ok")
            try:
                from meshtastic import mesh_interface
                log("Meshtastic mesh_interface OK", "ok")
            except Exception as e:
                log(f"Meshtastic mesh_interface errore: {e}", "warn")
                log("   Provo a reinstallare meshtastic...", "info")
                try:
                    subprocess.check_call(
                        [sys.executable, "-m", "pip", "install", "--force-reinstall", "meshtastic", "-q"],
                        timeout=180
                    )
                    log("Meshtastic reinstallato - riprova", "ok")
                except Exception:
                    log("Reinstallazione fallita - l'auto-diagnosi nel browser proporra fix", "warn")
        else:
            log("Meshtastic trovato ma versione sconosciuta", "warn")
    except ImportError:
        log("Meshtastic CLI non installato - verra richiesto nel browser", "info")


def _is_in_venv():
    """Verifica se stiamo gia girando dentro un virtual environment."""
    return (hasattr(sys, 'real_prefix') or
            (hasattr(sys, 'base_prefix') and sys.base_prefix != sys.prefix))


def _is_externally_managed():
    """Rileva se pip e bloccato da PEP 668 (macOS Homebrew, Linux moderno)."""
    try:
        _result = subprocess.run(
            [sys.executable, "-m", "pip", "install", "--dry-run", "flask"],
            capture_output=True, text=True, timeout=30
        )
        _output = (_result.stdout + _result.stderr).lower()
        return "externally-managed" in _output or "externally managed" in _output
    except Exception:
        return False


def _create_and_restart_in_venv():
    """Crea un venv nella cartella app/ e rilancia start_app.py al suo interno."""
    _venv_dir = os.path.join(_this_dir, "venv")
    _is_macos = _plat.system() == "Darwin"
    _is_linux = _plat.system() == "Linux"

    if os.path.isdir(_venv_dir):
        log("Virtual environment trovato in ./venv/", "ok")
    else:
        log("Creo ambiente virtuale Python (una tantum)...", "info")
        try:
            import venv as _venv_mod
        except ImportError:
            log("Modulo 'venv' non disponibile!", "error")
            if _is_linux:
                log("Installa: sudo apt install python3-venv", "info")
            elif _is_macos:
                log("Reinstalla Python: brew reinstall python", "info")
            return False
        try:
            subprocess.check_call(
                [sys.executable, "-m", "venv", _venv_dir],
                timeout=60
            )
            log("Virtual environment creato in ./venv/", "ok")
        except Exception as _e:
            log(f"Errore creazione venv: {_e}", "error")
            return False

    if _plat.system() == "Windows":
        _venv_python = os.path.join(_venv_dir, "Scripts", "python.exe")
    else:
        _venv_python = os.path.join(_venv_dir, "bin", "python3")
        if not os.path.exists(_venv_python):
            _venv_python = os.path.join(_venv_dir, "bin", "python")

    if not os.path.exists(_venv_python):
        log(f"Python del venv non trovato: {_venv_python}", "error")
        return False

    try:
        subprocess.check_call(
            [_venv_python, "-m", "pip", "install", "--upgrade", "pip", "-q"],
            timeout=60
        )
    except Exception:
        pass

    log("Riavvio l'app dentro il virtual environment...", "start")
    _script = os.path.join(_this_dir, "start_app.py")
    try:
        _exit_code = subprocess.call([_venv_python, _script])
        sys.exit(_exit_code)
    except KeyboardInterrupt:
        sys.exit(0)


def install_dependencies():
    req_file = os.path.join(os.path.dirname(__file__), "requirements.txt")
    if not os.path.exists(req_file):
        log("File requirements.txt non trovato!", "error")
        return False
    log("Verifico dipendenze Python...", "info")

    # ---- Check TUTTE le dipendenze richieste ----
    missing = []
    checks = {
        "flask": "flask",
        "flask_cors": "flask-cors",
        "serial": "pyserial",
        "qrcode": "qrcode[pil]",
        "PIL": "Pillow",
        "cryptography": "cryptography",
        "meshtastic": "meshtastic",
        # v1.1.3+: Setup Doctor - fingerprint hardware robusto
        "getmac": "getmac",
        "psutil": "psutil",
    }
    for module_name, pip_name in checks.items():
        try:
            __import__(module_name)
        except ImportError:
            missing.append((module_name, pip_name))
            log(f"Dipendenza mancante: {pip_name}", "warn")

    if not missing:
        log("Tutte le dipendenze sono gia installate", "ok")
        return True

    log(f"Installo {len(missing)} dipendenze mancanti...", "warn")

    # Check PEP 668: se externally-managed e non siamo in venv -> crea venv
    if not _is_in_venv() and _is_externally_managed():
        log("Rilevato ambiente Python protetto (PEP 668 / Homebrew)", "warn")
        log("Serve un virtual environment per installare le dipendenze", "info")
        _create_and_restart_in_venv()
        log("Fallback: provo installazione diretta...", "warn")

    # Verifica che pip sia disponibile
    try:
        subprocess.check_call(
            [sys.executable, "-m", "pip", "--version"],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
        )
    except (subprocess.CalledProcessError, FileNotFoundError):
        log("pip non trovato! Provo a installare pip...", "warn")
        try:
            subprocess.check_call([sys.executable, "-m", "ensurepip", "--upgrade"])
            log("pip installato con successo", "ok")
        except Exception:
            log("Impossibile installare pip automaticamente!", "error")
            log("Installa pip manualmente: python -m ensurepip --upgrade", "info")
            return False

    # v1.1.3+: installa SOLO i pacchetti mancanti uno per uno.
    # Evita "pip install -r requirements.txt" perche ricompila tutto
    # (es. unishox2-py3 richiede MSVC e fallisce su Windows senza Build Tools).
    log(f"Installo {len(missing)} pacchetti mancanti (uno per uno)...", "info")
    all_ok = True
    for mod_name, pip_name in missing:
        installed = False
        # Tentativo 1: install normale
        try:
            subprocess.check_call(
                [sys.executable, "-m", "pip", "install", pip_name, "-q"],
                timeout=180
            )
            log(f"  OK {pip_name} installato", "ok")
            installed = True
        except subprocess.CalledProcessError:
            pass
        except subprocess.TimeoutExpired:
            pass
        # Tentativo 2: install --user (no permessi admin)
        if not installed:
            try:
                subprocess.check_call(
                    [sys.executable, "-m", "pip", "install", "--user", pip_name, "-q"],
                    timeout=180
                )
                log(f"  OK {pip_name} installato (--user)", "ok")
                installed = True
            except (subprocess.CalledProcessError, subprocess.TimeoutExpired):
                pass
        if not installed:
            log(f"  FAIL {pip_name} - installalo manualmente: pip install {pip_name}", "error")
            # Eccezione: getmac e psutil sono opzionali (Setup Doctor v1.1.3+)
            if pip_name in ('getmac', 'psutil'):
                log(f"     (opzionale: l'app funziona comunque, il Setup Doctor sara degradato)", "info")
            else:
                all_ok = False
    return all_ok


def find_port():
    for port in range(DEFAULT_PORT, DEFAULT_PORT + MAX_PORT_TRIES):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            try:
                s.bind(("127.0.0.1", port))
                return port
            except OSError:
                continue
    return None


def start_server():
    port = find_port()
    if port is None:
        log(f"Nessuna porta disponibile ({DEFAULT_PORT}-{DEFAULT_PORT + MAX_PORT_TRIES})!", "error")
        return
    if port != DEFAULT_PORT:
        log(f"Porta {DEFAULT_PORT} occupata, uso {port}", "warn")
    url = f"http://localhost:{port}"
    log(f"Avvio server su {url}", "start")

    def _try_chrome():
        """Restituisce un oggetto browser Chrome cross-platform, o None."""
        import sys
        for name in ("chrome", "google-chrome", "chromium", "chromium-browser"):
            try:
                return webbrowser.get(name)
            except webbrowser.Error:
                continue
        if sys.platform == "darwin":
            mac_paths = [
                "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
                "/Applications/Chromium.app/Contents/MacOS/Chromium",
            ]
            for p in mac_paths:
                if os.path.exists(p):
                    try:
                        webbrowser.register("chrome-mac", None,
                                            webbrowser.BackgroundBrowser(p))
                        return webbrowser.get("chrome-mac")
                    except webbrowser.Error:
                        pass
        if sys.platform == "win32":
            win_paths = [
                r"C:\Program Files\Google\Chrome\Application\chrome.exe",
                r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
                os.path.expandvars(r"%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe"),
            ]
            for p in win_paths:
                if p and os.path.exists(p):
                    try:
                        webbrowser.register("chrome-win", None,
                                            webbrowser.BackgroundBrowser(p))
                        return webbrowser.get("chrome-win")
                    except webbrowser.Error:
                        pass
        return None

    def open_browser():
        # Patch by Andrea Marotta (IU0CRY) — apre Chrome se disponibile,
        # altrimenti fallback al browser di sistema.
        time.sleep(1.5)
        chrome = _try_chrome()
        if chrome is not None:
            try:
                chrome.open(url)
                log(f"Browser aperto usando Chrome su {url}", "ok")
                return
            except Exception as e:
                log(f"Chrome trovato ma apertura fallita ({e}), uso default", "warn")
        webbrowser.open(url)
        log(f"Browser aperto usando default su {url}", "ok")

    import threading
    threading.Thread(target=open_browser, daemon=True).start()

    from app.server import create_app
    flask_app = create_app(port)

    print(f"""
{C.LG}{C.B}  ┌──────────────────────────────────────────────┐
  │  🟢  SERVER ATTIVO — {url}       │
  │  📡  Premi Ctrl+C per fermare il server      │
  └──────────────────────────────────────────────┘{C.X}
""")
    try:
        flask_app.run(host="127.0.0.1", port=port, debug=False, use_reloader=False)
    except KeyboardInterrupt:
        pass


def run_setup_doctor():
    """Setup Doctor: verifica stabilita fingerprint hardware al primo avvio.
    Non blocca l'app: se rileva instabilita, salva lo stato in .doctor_state
    e la UI mostrera un banner di warning multilingua con istruzioni di rimedio."""
    try:
        from app.setup_doctor import (
            needs_first_boot_check, run_first_boot_check, get_doctor_state,
            load_anchor
        )
        # Decisione esecuzione: primo avvio OPPURE state esiste ma senza anchor valido
        do_check = needs_first_boot_check()
        if not do_check:
            # State esiste - controlla se ha anchor valido per QUESTO PC
            anchor = load_anchor()
            state = get_doctor_state()
            if anchor is None and (state is None or not state.get('stable')):
                # State degradato/parziale -> rifacciamo il check
                do_check = True

        if do_check:
            log("Setup Doctor: verifico stabilita fingerprint hardware (10 letture)...", "info")
            result = run_first_boot_check()
            if result['stable'] and not result['mac_is_random']:
                fp_cur = result.get('fp_current', '?')
                log(f"Setup Doctor: OK sistema stabile (FP {fp_cur})", "ok")
                if result.get('fp_anchored'):
                    log("  -> anchor salvato: il fingerprint sopravvivera a piccoli update di sistema", "info")
            else:
                log("Setup Doctor: fingerprint INSTABILE - banner di rimedio mostrato nella UI", "warn")
                for r in result.get('remedies', []):
                    log(f"  -> rimedio suggerito (chiave i18n): {r}", "info")
        else:
            anchor = load_anchor()
            if anchor:
                log(f"Setup Doctor: OK anchor stabile presente (FP {anchor})", "ok")
            else:
                state = get_doctor_state()
                if state and state.get('stable'):
                    fp = state.get('fp_current', '?')
                    log(f"Setup Doctor: OK sistema stabile (FP {fp})", "ok")
                else:
                    log("Setup Doctor: stato indeterminato - sara rifatto al prossimo avvio", "warn")
    except Exception as e:
        log(f"Setup Doctor errore (non bloccante): {e}", "warn")


def main():
    banner()
    if not check_python():
        input("\nPremi INVIO per chiudere...")
        sys.exit(1)
    if not install_dependencies():
        input("\nPremi INVIO per chiudere...")
        sys.exit(1)
    # Verifica compatibilita meshtastic con Python corrente
    check_meshtastic_version()
    # Setup Doctor: verifica fingerprint hardware (non bloccante)
    run_setup_doctor()
    import platform
    os_name = platform.system()
    os_map = {"Windows": "Windows", "Darwin": "macOS", "Linux": "Linux"}
    log(f"Sistema operativo: {os_map.get(os_name, os_name)}", "ok")
    start_server()
    print(f"""
{C.LG}  ┌──────────────────────────────────────────────┐
  │  📡  App chiusa. 73 de Meshtastic Italia!    │
  │  🇮🇹  www.meshtasticitalia.it                 │
  └──────────────────────────────────────────────┘{C.X}
""")


if __name__ == "__main__":
    main()

# End of file marker - padding di sicurezza per evitare null bytes residui
# dovuti a Edit precedenti sul filesystem sandbox. Non rimuovere senza
# verificare che la dimensione finale del file non sia inferiore a quella
# del precedente salvataggio (controllo: wc -c start_app.py).
# ----------------------------------------------------------------------
# Cronologia file:
#   v1.0    - Launcher originale con banner ASCII art e check Python
#   v1.1.3  - Aggiunte dipendenze getmac/psutil (Setup Doctor)
#             Cambiata strategia pip: solo pacchetti mancanti, non bulk
#             (evita ricompilazione di unishox2-py3 che richiede MSVC)
#             Aggiunta funzione run_setup_doctor() chiamata dopo
#             install_dependencies() nel flusso main()
# ----------------------------------------------------------------------
# Flusso di esecuzione (main):
#   1. banner()                  - Stampa ASCII art di benvenuto
#   2. check_python()            - Verifica Python >= 3.9 (consigliato 3.11/3.12)
#                                  Warning se Python 3.14+ (compat meshtastic)
#   3. install_dependencies()    - Installa solo le librerie mancanti, una
#                                  per una. Tenta prima senza --user, poi
#                                  con --user. getmac/psutil sono opzionali
#                                  e non bloccano l'app se la build fallisce.
#   4. check_meshtastic_version()- Verifica meshtastic CLI importabile
#   5. run_setup_doctor()        - 10 letture del fingerprint hardware,
#                                  salva .fp_anchor se stabile, popola
#                                  .doctor_state per il banner UI.
#   6. start_server()            - Trova porta libera 5555-5564, lancia
#                                  Flask, apre browser su http://localhost:PORT
# ----------------------------------------------------------------------
# Note compatibilita Windows 11 22H2+:
#   - wmic NON e piu pre-installato. Setup Doctor lo rileva e suggerisce
#     all'utente di reinstallarlo da Optional Features oppure di aggiornare
#     l'app a versione futura che usera Get-CimInstance.
#   - Nel frattempo, l'anchor salvato sopravvive ai cambiamenti di driver
#     del disco e della scheda di rete, quindi la maggior parte degli
#     utenti Win11 non noteranno il problema.
# ----------------------------------------------------------------------
# Note compatibilita Linux:
#   - uuid.getnode() puo ritornare MAC random se mancano net-tools.
#     Setup Doctor lo rileva (bit multicast) e suggerisce all'utente
#     di lanciare "sudo apt install net-tools uuid-runtime".
#   - Su distribuzioni con PEP 668 (Ubuntu 23.04+, Debian 12+), pip
#     install fallisce su system Python. La funzione _create_and_restart_in_venv
#     crea automaticamente un venv in ./venv/ e rilancia start_app.py.
# ----------------------------------------------------------------------
# Variabili d'ambiente supportate (opzionali):
#   MESHTASTIC_PORT     - Forza una porta specifica (override DEFAULT_PORT)
#   MESHTASTIC_NO_BROWSER - Se "1", non apre il browser automaticamente
# ----------------------------------------------------------------------
