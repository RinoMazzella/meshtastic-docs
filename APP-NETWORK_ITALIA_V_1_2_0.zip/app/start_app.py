# -*- coding: utf-8 -*-
"""
🚀 Meshtastic Italia Network App v1.2.0 — Launcher
Avvia l'app in modo automatico su qualsiasi OS.
© 2026 🌐🥭MANGOLINK🥭🌐 — Tutti i diritti riservati
"""

import os
import sys
import time
import subprocess
import webbrowser
import socket

# ═══════════════════════════════════════════════════════════
# FIX PATH — garantisce che 'from app.xxx' funzioni sempre,
# sia lanciando da dentro app/ che dalla directory padre.
# ═══════════════════════════════════════════════════════════
_this_dir = os.path.dirname(os.path.abspath(__file__))
_parent_dir = os.path.dirname(_this_dir)
if _parent_dir not in sys.path:
    sys.path.insert(0, _parent_dir)

# ═══════════════════════════════════════════════════════════
# CONFIGURAZIONE
# ═══════════════════════════════════════════════════════════

APP_NAME = "📡 Meshtastic Italia Network App v1.2.0"
DEFAULT_PORT = 5555
MAX_PORT_TRIES = 10

# ═══════════════════════════════════════════════════════════
# COLORI TERMINALE
# ═══════════════════════════════════════════════════════════

import ctypes
import platform as _plat

if _plat.system() == "Windows":
    try:
        kernel32 = ctypes.windll.kernel32
        kernel32.SetConsoleMode(kernel32.GetStdHandle(-11), 7)
    except Exception:
        pass

class C:
    G  = "\033[32m"
    LG = "\033[92m"
    R  = "\033[31m"
    LR = "\033[91m"
    Y  = "\033[93m"
    CY = "\033[96m"
    W  = "\033[97m"
    DM = "\033[90m"
    B  = "\033[1m"
    X  = "\033[0m"

def banner():
    g=C.G; lg=C.LG; r=C.LR; w=C.W; cy=C.CY; dm=C.DM; b=C.B; x=C.X
    fl=f"{g}████{w}████{r}████{x}"
    ln=f"{dm}════════════════════════════════════{x}"
    print(f"""
{dm}  ╔══════════════════════════════════════════════════════════════════════╗{x}
{dm}  ║{x}                                                                      {dm}║{x}
{dm}  ║{x}  {lg}{b}  ██╗   ██╗ ██████╗ ██████╗██╗  ██╗████████╗ █████╗ ██████╗██╗ ██████╗{x}{dm}║{x}
{dm}  ║{x}  {lg}{b}  ███╗ ███║██╔════╝██╔════╝██║  ██║╚══██╔══╝██╔══██╗██╔═══╝██║██╔════╝{x}{dm}║{x}
{dm}  ║{x}  {lg}{b}  ████████║█████╗  ╚█████╗ ███████║   ██║   ███████║╚████╗ ██║██║     {x}{dm}║{x}
{dm}  ║{x}  {lg}{b}  ██╔═██╔═╝██╔══╝   ╚═══██╗██╔══██║   ██║   ██╔══██║ ╚══██╗██║██║     {x}{dm}║{x}
{dm}  ║{x}  {lg}{b}  ██║ ██║  ██████╗██████╔╝██║  ██║   ██║   ██║  ██║█████╔╝██║╚██████╗{x}{dm}║{x}
{dm}  ║{x}  {lg}{b}  ╚═╝ ╚═╝  ╚═════╝╚═════╝ ╚═╝  ╚═╝   ╚═╝   ╚═╝  ╚═╝╚════╝ ╚═╝ ╚═════╝{x}{dm}║{x}
{dm}  ║{x}                                                                      {dm}║{x}
{dm}  ║{x}  {fl}{ln}{fl}  {dm}║{x}
{dm}  ║{x}  {fl}    {w}{b}M E S H T A S T I C I T A L I A . I T{x}    {fl}  {dm}║{x}
{dm}  ║{x}  {fl}{ln}{fl}  {dm}║{x}
{dm}  ║{x}                                                                      {dm}║{x}
{dm}  ║{x}   {w}📡  Comunicazione Off-Grid per Tutti — LoRa 868 MHz Mesh{x}          {dm}║{x}
{dm}  ║{x}                                                                      {dm}║{x}
{dm}  ║{x}   {cy}🌐 www.meshtasticitalia.it{x}        {cy}✈  t.me/MeshtasticItalia{x}        {dm}║{x}
{dm}  ║{x}   {cy}📧 info@meshtasticitalia.it{x}       {cy}👾 discord.gg/Rbhwf54nB3{x}        {dm}║{x}
{dm}  ║{x}                                                                      {dm}║{x}
{dm}  ║{x}   {lg}{b}⚡ App v1.2.0{x}  {dm}│{x}  {lg}Regione: EU_868{x}  {dm}│{x}  {lg}Preset: MediumFast{x}         {dm}║{x}
{dm}  ║{x}                                                                      {dm}║{x}
{dm}  ╚══════════════════════════════════════════════════════════════════════╝{x}
""")

def log(msg, level="info"):
    icons  = {"info":"ℹ ", "ok":"✅", "warn":"⚠ ", "error":"❌", "start":"🚀"}
    colors = {"info":C.CY, "ok":C.LG, "warn":C.Y, "error":C.LR, "start":C.LG+C.B}
    print(f"  {colors.get(level,'')}{icons.get(level,'')} {msg}{C.X}")

def check_python():
    v = sys.version_info
    log(f"Python {v.major}.{v.minor}.{v.micro} trovato", "ok")
    if v.major < 3 or (v.major == 3 and v.minor < 9):
        log("Serve Python 3.9 o superiore!", "error")
        return False
    # Avviso per Python troppo nuovo (3.14+ non compatibile con meshtastic)
    if v.major == 3 and v.minor >= 14:
        log(f"⚠️  Python {v.major}.{v.minor} potrebbe NON essere compatibile con meshtastic!", "warn")
        log("   Raccomandata: Python 3.11 o 3.12", "info")
        log("   Download: https://www.python.org/downloads/release/python-3120/", "info")
        log("   L'app tenterà di funzionare comunque — eventuali errori", "info")
        log("   verranno gestiti dall'auto-diagnosi nel browser.", "info")
    return True

def check_meshtastic_version():
    """Verifica che meshtastic CLI sia compatibile con la versione Python"""
    try:
        import meshtastic
        ver = getattr(meshtastic, '__version__', None)
        if ver:
            log(f"Meshtastic CLI v{ver} trovato", "ok")
            # Test rapido: prova a importare i moduli critici
            try:
                from meshtastic import mesh_interface
                log("Meshtastic mesh_interface OK", "ok")
            except Exception as e:
                log(f"⚠️  Meshtastic mesh_interface errore: {e}", "warn")
                log("   Provo a reinstallare meshtastic...", "info")
                try:
                    subprocess.check_call(
                        [sys.executable, "-m", "pip", "install", "--force-reinstall", "meshtastic", "-q"],
                        timeout=180
                    )
                    log("Meshtastic reinstallato — riprova", "ok")
                except Exception:
                    log("Reinstallazione fallita — l'auto-diagnosi nel browser proporrà fix", "warn")
        else:
            log("Meshtastic trovato ma versione sconosciuta", "warn")
    except ImportError:
        log("Meshtastic CLI non installato — verrà richiesto nel browser", "info")

def _is_in_venv():
    """Verifica se stiamo già girando dentro un virtual environment."""
    return (hasattr(sys, 'real_prefix') or
            (hasattr(sys, 'base_prefix') and sys.base_prefix != sys.prefix))

def _is_externally_managed():
    """Rileva se pip è bloccato da PEP 668 (macOS Homebrew, Linux moderno)."""
    try:
        _result = subprocess.run(
            [sys.executable, "-m", "pip", "install", "--dry-run", "flask"],
            capture_output=True, text=True, timeout=30
        )
        _output = (_result.stdout + _result.stderr).lower()
        return "externally-managed" in _output or "externally managed" in _output
    except Exception:
        return False

def _create_and_restart_in_venv():
    """Crea un venv nella cartella app/ e rilancia start_app.py al suo interno."""
    _venv_dir = os.path.join(_this_dir, "venv")
    _is_macos = _plat.system() == "Darwin"
    _is_linux = _plat.system() == "Linux"

    if os.path.isdir(_venv_dir):
        log("Virtual environment trovato in ./venv/", "ok")
    else:
        log("Creo ambiente virtuale Python (una tantum)...", "info")
        # Verifica che il modulo venv sia disponibile
        try:
            import venv as _venv_mod
        except ImportError:
            log("Modulo 'venv' non disponibile!", "error")
            if _is_linux:
                log("Installa: sudo apt install python3-venv", "info")
            elif _is_macos:
                log("Reinstalla Python: brew reinstall python", "info")
            return False

        try:
            subprocess.check_call(
                [sys.executable, "-m", "venv", _venv_dir],
                timeout=60
            )
            log("Virtual environment creato in ./venv/", "ok")
        except Exception as _e:
            log(f"Errore creazione venv: {_e}", "error")
            return False

    # Trova il python del venv
    if _plat.system() == "Windows":
        _venv_python = os.path.join(_venv_dir, "Scripts", "python.exe")
    else:
        _venv_python = os.path.join(_venv_dir, "bin", "python3")
        if not os.path.exists(_venv_python):
            _venv_python = os.path.join(_venv_dir, "bin", "python")

    if not os.path.exists(_venv_python):
        log(f"Python del venv non trovato: {_venv_python}", "error")
        return False

    # Aggiorna pip nel venv (silenzioso)
    try:
        subprocess.check_call(
            [_venv_python, "-m", "pip", "install", "--upgrade", "pip", "-q"],
            timeout=60
        )
    except Exception:
        pass  # Non critico

    # Rilancia start_app.py dentro il venv
    log("Riavvio l'app dentro il virtual environment...", "start")
    _script = os.path.join(_this_dir, "start_app.py")
    try:
        _exit_code = subprocess.call([_venv_python, _script])
        sys.exit(_exit_code)
    except KeyboardInterrupt:
        sys.exit(0)

def install_dependencies():
    req_file = os.path.join(os.path.dirname(__file__), "requirements.txt")
    if not os.path.exists(req_file):
        log("File requirements.txt non trovato!", "error")
        return False
    log("Verifico dipendenze Python...", "info")

    # ── Check TUTTE le dipendenze richieste ──────────────────
    missing = []
    checks = {
        "flask": "flask",
        "flask_cors": "flask-cors",
        "serial": "pyserial",
        "qrcode": "qrcode[pil]",
        "PIL": "Pillow",
        "cryptography": "cryptography",
        "meshtastic": "meshtastic",
    }
    for module_name, pip_name in checks.items():
        try:
            __import__(module_name)
        except ImportError:
            missing.append((module_name, pip_name))
            log(f"Dipendenza mancante: {pip_name}", "warn")

    if not missing:
        log("Tutte le dipendenze sono già installate", "ok")
        return True

    log(f"Installo {len(missing)} dipendenze mancanti...", "warn")

    # ── Check PEP 668: se externally-managed e non siamo in venv → crea venv ──
    if not _is_in_venv() and _is_externally_managed():
        log("Rilevato ambiente Python protetto (PEP 668 / Homebrew)", "warn")
        log("Serve un virtual environment per installare le dipendenze", "info")
        _create_and_restart_in_venv()
        # Se _create_and_restart_in_venv ritorna (errore), continua con tentativi classici
        log("Fallback: provo installazione diretta...", "warn")

    # ── Verifica che pip sia disponibile ──────────────────────
    try:
        subprocess.check_call(
            [sys.executable, "-m", "pip", "--version"],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
        )
    except (subprocess.CalledProcessError, FileNotFoundError):
        log("pip non trovato! Provo a installare pip...", "warn")
        try:
            subprocess.check_call([sys.executable, "-m", "ensurepip", "--upgrade"])
            log("pip installato con successo", "ok")
        except Exception:
            log("Impossibile installare pip automaticamente!", "error")
            log("Installa pip manualmente: python -m ensurepip --upgrade", "info")
            return False

    # ── Tentativo 1: installazione normale ────────────────────
    try:
        subprocess.check_call(
            [sys.executable, "-m", "pip", "install", "-r", req_file, "-q"],
            timeout=300
        )
        log("Dipendenze installate con successo", "ok")
        return True
    except subprocess.CalledProcessError:
        log("Installazione standard fallita, provo con --user...", "warn")
    except subprocess.TimeoutExpired:
        log("Timeout installazione (300s), provo con --user...", "warn")

    # ── Tentativo 2: installazione con --user (no permessi admin) ──
    try:
        subprocess.check_call(
            [sys.executable, "-m", "pip", "install", "--user", "-r", req_file, "-q"],
            timeout=300
        )
        log("Dipendenze installate con --user", "ok")
        return True
    except (subprocess.CalledProcessError, subprocess.TimeoutExpired):
        log("Errore nell'installazione dipendenze!", "error")
        log(f"Prova manualmente: pip install -r {req_file}", "info")
        # ── Tentativo 3: installa una per una le mancanti ──
        log("Provo installazione singola dei pacchetti mancanti...", "warn")
        all_ok = True
        for mod_name, pip_name in missing:
            try:
                subprocess.check_call(
                    [sys.executable, "-m", "pip", "install", pip_name, "-q"],
                    timeout=120
                )
                log(f"  {pip_name} installato", "ok")
            except Exception:
                try:
                    subprocess.check_call(
                        [sys.executable, "-m", "pip", "install", "--user", pip_name, "-q"],
                        timeout=120
                    )
                    log(f"  {pip_name} installato (--user)", "ok")
                except Exception:
                    log(f"  {pip_name} FALLITO — installalo manualmente: pip install {pip_name}", "error")
                    all_ok = False
        return all_ok

def find_port():
    for port in range(DEFAULT_PORT, DEFAULT_PORT + MAX_PORT_TRIES):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            try:
                s.bind(("127.0.0.1", port))
                return port
            except OSError:
                continue
    return None

def start_server():
    port = find_port()
    if port is None:
        log(f"Nessuna porta disponibile ({DEFAULT_PORT}-{DEFAULT_PORT + MAX_PORT_TRIES})!", "error")
        return
    if port != DEFAULT_PORT:
        log(f"Porta {DEFAULT_PORT} occupata, uso {port}", "warn")
    url = f"http://localhost:{port}"
    log(f"Avvio server su {url}", "start")

    def open_browser():
        time.sleep(1.5)
        webbrowser.open(url)
        log(f"Browser aperto su {url}", "ok")

    import threading
    threading.Thread(target=open_browser, daemon=True).start()

    from app.server import create_app
    flask_app = create_app(port)

    print(f"""
{C.LG}{C.B}  ┌──────────────────────────────────────────────┐
  │  🟢  SERVER ATTIVO — {url}        │
  │  📡  Premi Ctrl+C per fermare il server      │
  └──────────────────────────────────────────────┘{C.X}
""")
    try:
        flask_app.run(host="127.0.0.1", port=port, debug=False, use_reloader=False)
    except KeyboardInterrupt:
        pass

def main():
    banner()
    if not check_python():
        input("\nPremi INVIO per chiudere...")
        sys.exit(1)
    if not install_dependencies():
        input("\nPremi INVIO per chiudere...")
        sys.exit(1)
    # 🩺 Verifica compatibilità meshtastic con Python corrente
    check_meshtastic_version()
    import platform
    os_name = platform.system()
    os_map = {"Windows": "🪟 Windows", "Darwin": "🍎 macOS", "Linux": "🐧 Linux"}
    log(f"Sistema operativo: {os_map.get(os_name, os_name)}", "ok")
    start_server()
    print(f"""
{C.LG}  ┌──────────────────────────────────────────────┐
  │  📡  App chiusa. 73 de Meshtastic Italia!     │
  │  🇮🇹  www.meshtasticitalia.it                  │
  └──────────────────────────────────────────────┘{C.X}
""")

if __name__ == "__main__":
    main()
