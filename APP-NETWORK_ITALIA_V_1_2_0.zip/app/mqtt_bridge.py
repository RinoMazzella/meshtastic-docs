# -*- coding: utf-8 -*-
"""
📡 Meshtastic Italia Network App v1.2.0 — MQTT Bridge (H4.3-T6)

Bridge verso broker MQTT esterni (es. mqtt.meshtastic.org, broker Mesh Italia)
che riceve ServiceEnvelope protobuf, estrae i MeshPacket, li convertè a dict
e li inietta nella pipeline monitor (analyze → PSK/PKI decrypt → persist).

Architettura:
  - `MqttBridge` classe singleton-friendly (thread-safe), start/stop.
  - paho-mqtt client in thread background (loop_start).
  - Callback `on_message` parse ServiceEnvelope → dict → `monitor._on_receive`.
  - Config in RAM (broker, port, topic, username, password, tls, client_id).
  - Status: connected, msgs_received, msgs_parse_ok, msgs_parse_err, last_error.

Security:
  - Password non viene mai restituita negli endpoint status/config (mascherata).
  - TLS supportato (broker cloud con port 8883).

Integrazione con monitor:
  - Usa lo stesso `interface` di monitor (se presente in _STATE) per node lookup
    in _analyze_packet / _try_pki_decrypt, oppure un FakeInterface minimo che
    espone `nodes={}` per compatibilità.

© 2026 🌐🥭MANGOLINK🥭🌐 — Tutti i diritti riservati
"""

import threading
import time
import uuid
from collections import Counter, deque
from typing import Optional, Dict, Any, List

try:
    import paho.mqtt.client as _mqtt
    _PAHO_OK = True
except Exception:
    _mqtt = None
    _PAHO_OK = False

try:
    from meshtastic.protobuf import mqtt_pb2 as _mqtt_pb2
    from meshtastic.protobuf import mesh_pb2 as _mesh_pb2
    _PB_OK = True
except Exception:
    _mqtt_pb2 = None
    _mesh_pb2 = None
    _PB_OK = False

try:
    from google.protobuf.json_format import MessageToDict as _MessageToDict
    _MTD_OK = True
except Exception:
    _MessageToDict = None
    _MTD_OK = False

try:
    import monitor as _monitor  # modulo sorella
    _MON_OK = True
except Exception:
    _monitor = None
    _MON_OK = False


# ═════════════════════════════════════════════════════════════
# Fake Interface per MQTT (quando monitor non è attivo via USB)
# ═════════════════════════════════════════════════════════════

class _MqttFakeInterface:
    """Interfaccia minima compatibile con _analyze_packet / _try_pki_decrypt.

    Espone `nodes` dict (vuoto di default) e `localNode=None`. Se monitor ha
    un'interfaccia vera in _STATE["interface"], la usiamo preferenzialmente
    per beneficiare del node lookup.
    """
    def __init__(self):
        self.nodes = {}
        self.localNode = None
        self.myInfo = None


_FAKE_IFACE = _MqttFakeInterface()


def _resolve_interface():
    """Ritorna l'interface reale del monitor se attiva, altrimenti la fake."""
    if _MON_OK and _monitor is not None:
        try:
            with _monitor._LOCK:
                _iface = _monitor._STATE.get("interface")
            if _iface is not None:
                return _iface
        except Exception:
            pass
    return _FAKE_IFACE


# ═════════════════════════════════════════════════════════════
# Conversione ServiceEnvelope → packet dict (Meshtastic format)
# ═════════════════════════════════════════════════════════════

def _mesh_packet_to_dict(mp, channel_id: Optional[str] = None,
                        gateway_id: Optional[str] = None) -> Dict[str, Any]:
    """Converte MeshPacket protobuf in dict camelCase compatibile con
    _analyze_packet (stesso formato dell'API Meshtastic serial).

    Args:
        mp: meshtastic.protobuf.mesh_pb2.MeshPacket
        channel_id: canale ServiceEnvelope (es. "LongFast")
        gateway_id: gateway ServiceEnvelope (es. "!aabbccdd")
    """
    if not _PB_OK or mp is None:
        return {}

    # protobuf 'from' è keyword riservato Python → access via getattr/builtin
    try:
        _from = int(getattr(mp, "from") or 0)
    except Exception:
        try:
            _from = int(mp.__getattribute__("from"))
        except Exception:
            _from = 0
    _to = int(getattr(mp, "to", 0) or 0)

    _pkt = {
        "from": _from,
        "fromId": f"!{_from & 0xffffffff:08x}" if _from else "",
        "to": _to,
        "toId": f"!{_to & 0xffffffff:08x}" if _to else "",
        "id": int(getattr(mp, "id", 0) or 0),
        "channel": int(getattr(mp, "channel", 0) or 0),
        "rxTime": int(getattr(mp, "rx_time", 0) or int(time.time())),
        "rxSnr": float(getattr(mp, "rx_snr", 0.0) or 0.0),
        "rxRssi": int(getattr(mp, "rx_rssi", 0) or 0),
        "hopLimit": int(getattr(mp, "hop_limit", 0) or 0),
        "hopStart": int(getattr(mp, "hop_start", 0) or 0),
        "wantAck": bool(getattr(mp, "want_ack", False)),
        "priority": int(getattr(mp, "priority", 0) or 0),
        "delayed": int(getattr(mp, "delayed", 0) or 0),
        "viaMqtt": True,  # sempre True per bridge MQTT
        "pkiEncrypted": bool(getattr(mp, "pki_encrypted", False)),
        "nextHop": int(getattr(mp, "next_hop", 0) or 0),
        "relayNode": int(getattr(mp, "relay_node", 0) or 0),
        "txAfter": int(getattr(mp, "tx_after", 0) or 0),
    }

    # publicKey (bytes → hex)
    _pk = getattr(mp, "public_key", None)
    if _pk:
        try:
            _pkt["publicKey"] = bytes(_pk).hex()
        except Exception:
            pass

    # encrypted payload (bytes)
    _enc = getattr(mp, "encrypted", None)
    if _enc:
        try:
            _enc_b = bytes(_enc)
            # Meshtastic Python lib espone come bytes in decoded mode,
            # ma quando il pacchetto è cifrato lo campo è top-level.
            _pkt["encrypted"] = _enc_b  # _analyze_packet gestirà via hex
        except Exception:
            pass

    # decoded (Data) → sub-dict (solo se decoded è effettivamente presente)
    try:
        if mp.HasField("decoded") and _MTD_OK:
            _dec = mp.decoded
            # Prova prima l'API nuova (protobuf >=5), fallback su quella vecchia
            try:
                _d = _MessageToDict(
                    _dec,
                    preserving_proto_field_name=False,
                    use_integers_for_enums=True,
                )
            except TypeError:
                _d = _MessageToDict(_dec)
            if _d:
                # Forza presenza portnum (0=UNKNOWN_APP è default ma lo vogliamo)
                if "portnum" not in _d:
                    _d["portnum"] = int(getattr(_dec, "portnum", 0) or 0)
                # Payload sempre in bytes (MessageToDict usa base64 per bytes)
                _pld = getattr(_dec, "payload", None)
                if _pld:
                    try:
                        _d["payload"] = bytes(_pld)
                    except Exception:
                        pass
                _pkt["decoded"] = _d
    except Exception:
        pass

    # ServiceEnvelope metadata (solo MQTT) — utile per classify_network
    if channel_id:
        _pkt["channelId_env"] = channel_id
    if gateway_id:
        _pkt["gatewayId_env"] = gateway_id

    return _pkt


def parse_service_envelope(data: bytes) -> Optional[Dict[str, Any]]:
    """Parse ServiceEnvelope bytes → packet dict pronto per _on_receive.

    Returns None se parsing fallisce o envelope vuoto.
    """
    if not _PB_OK or not data:
        return None
    try:
        _env = _mqtt_pb2.ServiceEnvelope()
        _env.ParseFromString(data)
    except Exception:
        return None
    if not _env.HasField("packet"):
        return None
    _channel_id = _env.channel_id or None
    _gateway_id = _env.gateway_id or None
    return _mesh_packet_to_dict(_env.packet, _channel_id, _gateway_id)


# ═════════════════════════════════════════════════════════════
# STEP 9 — Helper: espansione topic (virgola-separato + auto-wildcard)
# ═════════════════════════════════════════════════════════════

def _expand_topics(raw_topic: Optional[str]) -> List[str]:
    """Espande una stringa topic in lista pronta per subscribe().

    Regole:
      - None/"" → ["msh/#"] (cattura-tutto)
      - virgola-separato → split su ',', trim
      - topic senza '+' e senza '#' alla fine → append '/#' automatico
        (es. 'msh/EU_868/IT' → 'msh/EU_868/IT/#')
      - '#' da solo → 'msh/#' (evita subscribe globale, limita a Meshtastic)
      - duplicati e vuoti → rimossi
    """
    if not raw_topic:
        return ["msh/#"]
    _parts = [p.strip() for p in str(raw_topic).split(",") if p.strip()]
    _expanded = []
    _seen = set()
    for _p in _parts:
        # Limita '#' globale a 'msh/#' (evita subscribe ad altre gerarchie)
        if _p == "#":
            _p = "msh/#"
        # Auto-wildcard se manca
        if "+" not in _p and not _p.endswith("#"):
            if _p.endswith("/"):
                _p = _p + "#"
            else:
                _p = _p + "/#"
        if _p not in _seen:
            _seen.add(_p)
            _expanded.append(_p)
    if not _expanded:
        return ["msh/#"]
    return _expanded


def _root_of(topic: str, depth: int = 3) -> str:
    """Ritorna i primi `depth` livelli del topic (es. msh/EU_868/IT)."""
    if not topic:
        return ""
    _parts = topic.split("/")
    return "/".join(_parts[:depth])


# ═════════════════════════════════════════════════════════════
# MqttBridge — classe principale
# ═════════════════════════════════════════════════════════════

class MqttBridge:
    """Bridge MQTT → pipeline monitor.

    Thread-safe: start/stop possono essere chiamati da qualsiasi thread.
    """

    # STEP 9 — limiti tracking (memoria bounded)
    _TRACK_ROOTS_MAX = 40     # root topic unici tracciati (top-N)
    _TRACK_SENDERS_MAX = 80   # sender id unici tracciati
    _TRACK_RECENT_WINDOW = 500  # finestra messaggi recenti

    def __init__(self):
        self._lock = threading.RLock()
        self._client = None
        self._thread_started = False
        self._config = {
            "broker": None,
            "port": 1883,
            "topic": "msh/#",
            "username": None,
            "password": None,
            "tls": False,
            "client_id": f"meshtastic-italia-{uuid.uuid4().hex[:8]}",
        }
        self._status = {
            "running": False,
            "connected": False,
            "started_at": None,
            "msgs_received": 0,
            "msgs_parse_ok": 0,
            "msgs_parse_err": 0,
            "msgs_not_envelope": 0,
            "last_error": None,
            "last_msg_ts": None,
            "last_topic": None,
        }
        # STEP 9 — tracking auto-discovery
        self._subscribed_topics: List[str] = []   # topic effettivamente subscribed
        self._root_counter: Counter = Counter()   # root topic → count
        self._sender_counter: Counter = Counter()  # sender_id → count
        self._recent_topics: deque = deque(maxlen=self._TRACK_RECENT_WINDOW)

    # ---------- Config ----------

    def get_config(self, mask_password: bool = True) -> Dict[str, Any]:
        with self._lock:
            _c = dict(self._config)
        if mask_password and _c.get("password"):
            _c["password"] = "***"
        return _c

    def set_config(self, cfg: Dict[str, Any]) -> Dict[str, Any]:
        """Aggiorna config. Non riavvia il bridge (richiede stop+start)."""
        with self._lock:
            for _k in ("broker", "port", "topic", "username", "password",
                       "tls", "client_id"):
                if _k in cfg and cfg[_k] is not None:
                    self._config[_k] = cfg[_k]
            # sanity
            try:
                self._config["port"] = int(self._config["port"])
            except Exception:
                self._config["port"] = 1883
            self._config["tls"] = bool(self._config.get("tls"))
        return self.get_config(mask_password=True)

    def get_status(self) -> Dict[str, Any]:
        with self._lock:
            _s = dict(self._status)
            _s["paho_available"] = _PAHO_OK
            _s["pb_available"] = _PB_OK
            _s["broker"] = self._config.get("broker")
            _s["port"] = self._config.get("port")
            _s["topic"] = self._config.get("topic")
            _s["tls"] = self._config.get("tls")
            _s["client_id"] = self._config.get("client_id")
        return _s

    def is_running(self) -> bool:
        with self._lock:
            return bool(self._status["running"])

    # ---------- STEP 9 — Diagnose (auto-discovery) ----------

    def get_diagnose(self) -> Dict[str, Any]:
        """Ritorna diagnostica completa per troubleshooting MQTT.

        Include:
          - config (mascherato) + status runtime
          - subscribed_topics (cosa è effettivamente sottoscritto)
          - top_roots: root topic più visti (msh/EU_868/IT, msh/EU_868/IT/2/...)
          - top_senders: nodi MQTT che stanno pubblicando (fromId)
          - recent_topics: ultimi N topic visti (sample)
          - suggestions: warning euristici (es. no wildcard, broker diverso dai roots)
        """
        with self._lock:
            _cfg = dict(self._config)
            if _cfg.get("password"):
                _cfg["password"] = "***"
            _st = dict(self._status)
            _sub = list(self._subscribed_topics)
            _top_roots = [
                {"root": _r, "count": _c}
                for _r, _c in self._root_counter.most_common(20)
            ]
            _top_senders = [
                {"id": _s, "count": _c}
                for _s, _c in self._sender_counter.most_common(20)
            ]
            _recent = list(self._recent_topics)[-20:]
            _raw_topic = _cfg.get("topic") or ""

        _sugg: List[str] = []
        # Suggerimento 1: topic senza wildcard
        if _raw_topic and "#" not in _raw_topic and "+" not in _raw_topic:
            _sugg.append("topic_no_wildcard")
        # Suggerimento 2: messaggi ricevuti zero ma connected
        if _st.get("connected") and _st.get("msgs_received", 0) == 0:
            _sugg.append("connected_no_messages")
        # Suggerimento 3: parse errori dominanti vs ok
        _ok = int(_st.get("msgs_parse_ok", 0) or 0)
        _err = int(_st.get("msgs_parse_err", 0) or 0)
        _nev = int(_st.get("msgs_not_envelope", 0) or 0)
        if (_err + _nev) > _ok and (_err + _nev) > 5:
            _sugg.append("mostly_not_envelope")
        # Suggerimento 4: root dominante non presente nei topic subscribed
        if _top_roots and _sub:
            _first_root = _top_roots[0]["root"]
            _match = any(_first_root in _t for _t in _sub)
            if not _match:
                _sugg.append("root_mismatch_subscribe")
        # Suggerimento 5: paho/protobuf mancanti
        if not _PAHO_OK:
            _sugg.append("paho_missing")
        if not _PB_OK:
            _sugg.append("protobuf_missing")

        return {
            "ok": True,
            "config": _cfg,
            "status": _st,
            "subscribed_topics": _sub,
            "top_roots": _top_roots,
            "top_senders": _top_senders,
            "recent_topics": _recent,
            "suggestions": _sugg,
            "tracking_limits": {
                "roots_max": self._TRACK_ROOTS_MAX,
                "senders_max": self._TRACK_SENDERS_MAX,
                "recent_window": self._TRACK_RECENT_WINDOW,
            },
        }

    # ---------- Lifecycle ----------

    def start(self) -> Dict[str, Any]:
        """Avvia connessione MQTT in background thread."""
        if not _PAHO_OK:
            return {"ok": False, "error": "paho_mqtt_not_installed"}
        if not _PB_OK:
            return {"ok": False, "error": "meshtastic_protobuf_not_installed"}

        with self._lock:
            if self._status["running"]:
                return {"ok": False, "error": "already_running"}
            _broker = self._config.get("broker")
            if not _broker:
                return {"ok": False, "error": "broker_not_configured"}
            try:
                _client = _mqtt.Client(client_id=self._config["client_id"],
                                       clean_session=True)
            except Exception as _e:
                return {"ok": False, "error": "client_init_fail",
                        "detail": str(_e)[:160]}

            _u = self._config.get("username")
            _p = self._config.get("password")
            if _u:
                try:
                    _client.username_pw_set(_u, _p or "")
                except Exception:
                    pass

            if self._config.get("tls"):
                try:
                    _client.tls_set()
                except Exception as _e:
                    return {"ok": False, "error": "tls_setup_fail",
                            "detail": str(_e)[:160]}

            _client.on_connect = self._on_connect
            _client.on_disconnect = self._on_disconnect
            _client.on_message = self._on_message

            try:
                _client.connect_async(_broker, int(self._config["port"]), 60)
                _client.loop_start()
                self._thread_started = True
            except Exception as _e:
                self._status["last_error"] = str(_e)[:180]
                try:
                    _client.loop_stop()
                except Exception:
                    pass
                return {"ok": False, "error": "connect_fail",
                        "detail": str(_e)[:160]}

            self._client = _client
            self._status["running"] = True
            self._status["started_at"] = int(time.time())
            self._status["last_error"] = None
            self._status["msgs_received"] = 0
            self._status["msgs_parse_ok"] = 0
            self._status["msgs_parse_err"] = 0
            self._status["msgs_not_envelope"] = 0
            # STEP 9 — reset tracking auto-discovery
            self._subscribed_topics = []
            self._root_counter = Counter()
            self._sender_counter = Counter()
            self._recent_topics.clear()
        return {"ok": True, "status": self.get_status()}

    def stop(self) -> Dict[str, Any]:
        with self._lock:
            _client = self._client
            if not self._status["running"] and _client is None:
                return {"ok": False, "error": "not_running"}
            self._status["running"] = False
            self._status["connected"] = False
            self._client = None
        if _client is not None:
            try:
                _client.disconnect()
            except Exception:
                pass
            try:
                _client.loop_stop()
            except Exception:
                pass
        return {"ok": True}

    # ---------- Callbacks paho ----------

    def _on_connect(self, client, userdata, flags, rc):
        try:
            # STEP 9 — espandi topic (virgola-separato + auto-wildcard)
            _raw = self._config.get("topic") or "msh/#"
            _topics = _expand_topics(_raw)
            if rc == 0:
                with self._lock:
                    self._status["connected"] = True
                    self._status["last_error"] = None
                    self._subscribed_topics = list(_topics)
                # subscribe a TUTTI i topic espansi
                for _t in _topics:
                    try:
                        client.subscribe(_t, qos=0)
                    except Exception as _e:
                        with self._lock:
                            self._status["last_error"] = (
                                f"subscribe '{_t}': {str(_e)[:100]}")
            else:
                with self._lock:
                    self._status["connected"] = False
                    self._status["last_error"] = f"connect_rc={rc}"
        except Exception as _e:
            with self._lock:
                self._status["last_error"] = (
                    f"on_connect: {str(_e)[:120]}")

    def _on_disconnect(self, client, userdata, rc):
        with self._lock:
            self._status["connected"] = False
            if rc != 0 and not self._status.get("last_error"):
                self._status["last_error"] = f"disconnect_rc={rc}"

    def _on_message(self, client, userdata, msg):
        """Entry-point: parse envelope + feed monitor pipeline."""
        _topic = msg.topic if msg else ""
        with self._lock:
            self._status["msgs_received"] += 1
            self._status["last_msg_ts"] = int(time.time())
            self._status["last_topic"] = _topic
            # STEP 9 — tracking root topic (bounded)
            _root = _root_of(_topic, depth=3)
            if _root:
                self._root_counter[_root] += 1
                # Cap memoria: se troppo grande, mantieni solo top-N
                if len(self._root_counter) > self._TRACK_ROOTS_MAX * 2:
                    _keep = dict(self._root_counter.most_common(self._TRACK_ROOTS_MAX))
                    self._root_counter = Counter(_keep)
            self._recent_topics.append(_topic)
        try:
            _pkt = parse_service_envelope(msg.payload)
            if _pkt is None:
                with self._lock:
                    self._status["msgs_not_envelope"] += 1
                return
            with self._lock:
                self._status["msgs_parse_ok"] += 1
                # STEP 9 — tracking sender
                _sid = _pkt.get("fromId") or ""
                if _sid:
                    self._sender_counter[_sid] += 1
                    if len(self._sender_counter) > self._TRACK_SENDERS_MAX * 2:
                        _keep = dict(self._sender_counter.most_common(self._TRACK_SENDERS_MAX))
                        self._sender_counter = Counter(_keep)
            self._dispatch_packet(_pkt)
        except Exception as _e:
            with self._lock:
                self._status["msgs_parse_err"] += 1
                self._status["last_error"] = (
                    f"on_message: {str(_e)[:120]}")

    # ---------- Dispatch to monitor ----------

    def _dispatch_packet(self, packet_dict: Dict[str, Any]):
        """Invia packet dict nella pipeline monitor (_on_receive)."""
        if not _MON_OK or _monitor is None:
            return
        try:
            _iface = _resolve_interface()
            _monitor._on_receive(packet=packet_dict, interface=_iface)
        except Exception as _e:
            with self._lock:
                self._status["last_error"] = (
                    f"dispatch: {str(_e)[:120]}")

    # ---------- Test helper ----------

    def inject_envelope_bytes(self, data: bytes, topic: str = "msh/test"):
        """Testing helper: simula ricezione MQTT senza broker reale."""
        _pkt = parse_service_envelope(data)
        with self._lock:
            self._status["msgs_received"] += 1
            self._status["last_topic"] = topic
            self._status["last_msg_ts"] = int(time.time())
            if _pkt is None:
                self._status["msgs_not_envelope"] += 1
                return {"ok": False, "error": "parse_fail"}
            self._status["msgs_parse_ok"] += 1
        self._dispatch_packet(_pkt)
        return {"ok": True, "packet_id": _pkt.get("id"),
                "from": _pkt.get("fromId")}


# Singleton istance
_BRIDGE = MqttBridge()


def get_bridge() -> MqttBridge:
    return _BRIDGE
