# ══════════════════════════════════════════════════════════════════════════════
# MESHTASTIC CRYPTO — AES-256-CTR decrypt per pacchetti MeshPacket
# ══════════════════════════════════════════════════════════════════════════════
# Meshtastic usa AES-256-CTR (o AES-128-CTR se la PSK è 16 byte) con nonce
# derivato da packet_id + from_node del header MeshPacket.
#
# Nonce Meshtastic (16 byte totali):
#   offset 0..7  : packet_num (uint64 LE)     (normalmente solo i primi 4 byte
#                  sono usati, i restanti 4 sono 0 perché PacketID è u32)
#   offset 8..11 : from_node (uint32 LE)
#   offset 12..15: counter block (sempre 0)
#
# Reference C++ (firmware/src/mesh/CryptoEngine.cpp):
#   memcpy(nonce, &packetNum, sizeof(packetNum));   // 8 bytes
#   memcpy(nonce+8, &fromNode, sizeof(fromNode));   // 4 bytes
#   memset(nonce+12, 0, 4);                         // zero-padding
#
# Le PSK note:
#   - "AQ==" (base64 = 0x01)  → espansa alla defaultpsk (16 byte) → AES-128
#   - 16 byte                  → AES-128-CTR
#   - 32 byte                  → AES-256-CTR
#
# © 2026 MANGOLINK — Meshtastic Italia Network App
# ══════════════════════════════════════════════════════════════════════════════

from __future__ import annotations
import base64
import binascii
from typing import List, Optional, Tuple


# Default PSK Meshtastic (16 byte = AES-128)
# Sorgente: firmware/src/mesh/CryptoEngine.cpp → defaultpsk
DEFAULT_PSK = bytes([
    0xd4, 0xf1, 0xbb, 0x3a, 0x20, 0x29, 0x07, 0x59,
    0xf0, 0xbc, 0xff, 0xab, 0xcf, 0x4e, 0x69, 0x01,
])


def normalize_psk(raw: str) -> Optional[bytes]:
    """Converte una PSK da stringa (base64 o hex) ai bytes da usare per AES.

    Gestisce:
      - base64 standard (es. 'AQ==' → 0x01)
      - hex raw con/senza '0x' (es. 'd4f1bb3a...')
      - byte singolo 0x01 → espande a DEFAULT_PSK
      - 16 byte → AES-128
      - 32 byte → AES-256
      - < 16 byte ma > 1 → scala dalla DEFAULT_PSK incrementando l'ultimo byte
                          (comportamento Meshtastic per psk=N dove N in 2..10)
    """
    if not raw:
        return None
    s = raw.strip()
    data: Optional[bytes] = None
    # Prefisso '0x' o solo hex characters → tratta SEMPRE come hex (priorità)
    s_low = s.lower()
    hx_candidate = s_low[2:] if s_low.startswith("0x") else s_low
    hx_candidate = hx_candidate.replace(" ", "").replace(":", "")
    if hx_candidate and all(c in "0123456789abcdef" for c in hx_candidate) and len(hx_candidate) % 2 == 0 and s_low.startswith("0x"):
        try:
            data = binascii.unhexlify(hx_candidate)
        except Exception:
            data = None
    if data is None:
        # Tentativo base64 (caso tipico: chiavi Meshtastic in base64)
        try:
            data = base64.b64decode(s, validate=True)
        except Exception:
            data = None
    if data is None:
        # Fallback finale: hex senza prefisso (solo se stringa pura hex)
        try:
            hx = s.replace(" ", "").replace(":", "").lower()
            if hx.startswith("0x"):
                hx = hx[2:]
            data = binascii.unhexlify(hx)
        except Exception:
            return None
    if not data:
        return None
    # Un byte singolo → default PSK (con eventuale scaling)
    if len(data) == 1:
        n = data[0]
        if n == 0:
            # PSK disattivata
            return None
        if n == 1:
            return DEFAULT_PSK
        # PSK 2..10: default + (n-1) sul byte 15 (compatibilità Meshtastic)
        modified = bytearray(DEFAULT_PSK)
        modified[-1] = (modified[-1] + (n - 1)) & 0xFF
        return bytes(modified)
    # Lunghezze canoniche accettate
    if len(data) in (16, 32):
        return data
    # Altre lunghezze: accettiamo 24 (AES-192) e padding a 32
    if len(data) == 24:
        return data
    if len(data) < 16:
        # Pad con zeri fino a 16
        return data + b"\x00" * (16 - len(data))
    if len(data) < 32:
        return data + b"\x00" * (32 - len(data))
    # Tronca a 32
    return data[:32]


def build_nonce(packet_id: int, from_node: int) -> bytes:
    """Costruisce il nonce 16-byte come fa il firmware Meshtastic."""
    try:
        pid = int(packet_id or 0) & 0xFFFFFFFFFFFFFFFF  # uint64
        fnode = int(from_node or 0) & 0xFFFFFFFF        # uint32
    except Exception:
        pid = 0
        fnode = 0
    nonce = bytearray(16)
    nonce[0:8] = pid.to_bytes(8, "little")
    nonce[8:12] = fnode.to_bytes(4, "little")
    # nonce[12:16] già a zero
    return bytes(nonce)


def try_decrypt(encrypted_hex_or_bytes, packet_id: int, from_node: int,
                psk_b64_or_hex: str) -> Optional[bytes]:
    """Prova a decifrare un payload Meshtastic.

    Ritorna i bytes decifrati (potenzialmente un protobuf Data serialized)
    oppure None se la PSK non è valida o la libreria cryptography manca.
    NON valida il protobuf: spetta al chiamante (fw_fingerprint o monitor)
    verificare che il risultato sia un protobuf Data valido.
    """
    try:
        from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
    except ImportError:
        return None
    # Normalizza input — accetta bytes, hex string, o base64 string.
    # BUG FIX 2026-04-20: il monitor a volte popola `encrypted_hex` con base64
    # (pacchetti MQTT) invece di hex. unhexlify falliva silenziosamente su ogni
    # PSK → decrypt_err 100% anche con PSK corrette. Fallback robusto a base64.
    if isinstance(encrypted_hex_or_bytes, (bytes, bytearray)):
        ct = bytes(encrypted_hex_or_bytes)
    else:
        _s = str(encrypted_hex_or_bytes or "").strip()
        if not _s:
            return None
        ct = None
        # Primo tentativo: hex (caso RF tipico, bytes→hexlify)
        try:
            ct = binascii.unhexlify(_s)
        except Exception:
            ct = None
        # Fallback: base64 (caso MQTT, stringa arrivata già come base64)
        if ct is None:
            try:
                import base64 as _b64
                ct = _b64.b64decode(_s, validate=False)
            except Exception:
                ct = None
        if ct is None:
            return None
    if not ct:
        return None
    key = normalize_psk(psk_b64_or_hex)
    if not key:
        return None
    nonce = build_nonce(packet_id, from_node)
    try:
        cipher = Cipher(algorithms.AES(key), modes.CTR(nonce))
        return cipher.decryptor().update(ct)
    except Exception:
        return None


def validate_decrypted(decrypted: bytes) -> Tuple[bool, Optional[int], Optional[bytes]]:
    """Prova a parsare il risultato come protobuf 'Data' Meshtastic.

    Un protobuf Data valido inizia solitamente con:
      - field 1 (portnum, varint)
      - field 2 (payload, bytes)

    Ritorna (valid, portnum, payload_bytes).
    Valid = True se il primo campo è un portnum noto (1..72) e la struttura
    proto base parsa senza eccezioni.
    """
    if not decrypted or len(decrypted) < 2:
        return False, None, None
    try:
        # Import meshtastic protobuf (già nel requirements)
        from meshtastic import mesh_pb2  # type: ignore
        data = mesh_pb2.Data()
        data.ParseFromString(decrypted)
        pn = int(data.portnum) if data.portnum is not None else None
        # Accettiamo portnum in range conosciuto (0..255) e almeno un campo valido
        if pn is None or pn < 0 or pn > 255:
            return False, None, None
        payload_bytes = bytes(data.payload) if data.payload else b""
        # Euristica di validità: se il portnum è UNKNOWN_APP (0) e non c'è payload
        # è quasi sicuramente spazzatura (PSK sbagliata)
        if pn == 0 and not payload_bytes:
            return False, None, None
        return True, pn, payload_bytes
    except Exception:
        return False, None, None


def compute_channel_hash(name: str, psk_bytes: bytes) -> int:
    """Calcola hash8 canale Meshtastic: XOR(name_utf8) XOR XOR(psk_bytes).

    Usato per disambiguare PSK con stessa chiave AES ma channel_name diversi.
    Identica all'omonima in monitor.py — duplicata qui per evitare import ciclico.
    """
    _h = 0
    try:
        for _c in (name or "").encode("utf-8"):
            _h ^= _c
        for _b in (psk_bytes or b""):
            _h ^= (_b & 0xFF)
    except Exception:
        return 0
    return _h & 0xFF


def try_all_psk_detailed(encrypted_hex_or_bytes, packet_id: int, from_node: int,
                         psk_list: List[dict],
                         packet_channel_hash: Optional[int] = None) -> dict:
    """STEP 8 — Brute-force con feedback dettagliato (a prescindere dal canale).

    Itera TUTTE le PSK abilitate ignorando channel_hash/channel_idx. Raccoglie
    diagnostica per-pacchetto (numero tentativi, ragioni dei fallimenti,
    elenco label provate) utile per UI/analyst.

    Ritorna sempre un dict:
        {
            'matched':          <match_dict or None>,
            'tried':            int,   # PSK effettivamente provate
            'skipped_disabled': int,   # PSK disabilitate saltate
            'skipped_empty':    int,   # PSK senza psk_b64 saltate
            'reasons':          {str: int},   # breakdown motivi failure
            'tried_labels':     [str, ...],
            'matched_label':    str or None,
        }

    Note:
      - Il loop si ferma al primo match valido.
      - Nessun filtro su channel_hash: funziona anche cross-rete / collisioni.
      - Backward-compat: try_all_psk() resta come wrapper (match o None).
    """
    result = {
        "matched": None,
        "tried": 0,
        "skipped_disabled": 0,
        "skipped_empty": 0,
        "reasons": {},
        "tried_labels": [],
        "matched_label": None,
    }
    if not psk_list:
        return result

    def _bump(reason_key: str) -> None:
        result["reasons"][reason_key] = result["reasons"].get(reason_key, 0) + 1

    for psk in psk_list:
        if not psk.get("enabled", 1):
            result["skipped_disabled"] += 1
            continue
        raw = psk.get("psk_b64") or ""
        if not raw:
            result["skipped_empty"] += 1
            continue
        result["tried"] += 1
        _label = psk.get("label") or "?"
        result["tried_labels"].append(_label)
        dec = try_decrypt(encrypted_hex_or_bytes, packet_id, from_node, raw)
        if not dec:
            _bump("decrypt_err")
            continue
        ok, pn, payload = validate_decrypted(dec)
        if not ok:
            if pn is None:
                _bump("bad_proto")
            elif pn == 0:
                _bump("zero_portnum")
            else:
                _bump("invalid_data")
            continue
        # Primo match valido — preparo dict, ma applico disambiguazione FASE 14
        # se packet_channel_hash fornito e match.channel_name non corrisponde all'hash.
        _matched_psk = psk
        if packet_channel_hash is not None and psk.get("channel_name"):
            try:
                _matched_b64 = psk.get("psk_b64") or ""
                _matched_psk_bytes = normalize_psk(_matched_b64) if _matched_b64 else None
                _matched_h8 = compute_channel_hash(
                    psk.get("channel_name"), _matched_psk_bytes or b""
                ) if _matched_psk_bytes else None
                if _matched_h8 != int(packet_channel_hash) & 0xFF:
                    # FASE 14: il primo match non corrisponde all'hash8 del pacchetto.
                    # Cerco tra le PSK con stessa psk_b64 quella col channel_name che match.
                    _target_h8 = int(packet_channel_hash) & 0xFF
                    for _alt in psk_list:
                        if not _alt.get("enabled", 1):
                            continue
                        if (_alt.get("psk_b64") or "") != _matched_b64:
                            continue
                        if not _alt.get("channel_name"):
                            continue
                        try:
                            _alt_h8 = compute_channel_hash(
                                _alt.get("channel_name"), _matched_psk_bytes
                            )
                            if _alt_h8 == _target_h8:
                                _matched_psk = _alt
                                break
                        except Exception:
                            continue
            except Exception:
                pass

        result["matched"] = {
            "psk_id": _matched_psk.get("id"),
            "label": _matched_psk.get("label"),
            "kind": _matched_psk.get("kind"),
            "channel_name": _matched_psk.get("channel_name"),  # FASE 14: vero canale
            "psk_b64": _matched_psk.get("psk_b64"),  # FASE 17: per verifica hash8 downstream
            "portnum": pn,
            "payload_bytes": payload,
            "full_decrypted": dec,
        }
        result["matched_label"] = _matched_psk.get("label")
        return result
    return result


def try_all_psk(encrypted_hex_or_bytes, packet_id: int, from_node: int,
                psk_list: List[dict],
                packet_channel_hash: Optional[int] = None) -> Optional[dict]:
    """Prova tutte le PSK in `psk_list` finché una decifra correttamente.

    Wrapper backward-compat su try_all_psk_detailed().
    Ritorna {'psk_id', 'label', 'kind', 'channel_name', 'portnum', 'payload_bytes'}
    o None.

    FASE 14 (2026-05-05): se packet_channel_hash fornito, applica disambiguazione
    quando il primo match e' tra PSK condivise (stessa AES key, nomi diversi).
    """
    detailed = try_all_psk_detailed(
        encrypted_hex_or_bytes, packet_id, from_node, psk_list,
        packet_channel_hash=packet_channel_hash,
    )
    return detailed.get("matched")


# ══════════════════════════════════════════════════════════════════════════════
# PSK PUBBLICHE DEFAULT — precaricate al primo avvio
# ══════════════════════════════════════════════════════════════════════════════
# PSK pubbliche ben note (Primary default Meshtastic + canale italiano "LongFast")
# L'utente può disabilitarle o aggiungerne di proprie tramite UI.

DEFAULT_PUBLIC_PSKS = [
    # Simple-byte PSK 0x01 (defaultpsk intera) — canale primario Meshtastic pubblico
    {
        "label": "Meshtastic Default (simple-byte 1)",
        "psk_b64": "AQ==",
        "kind": "public",
        "channel_name": "LongFast",
        "notes": "Canale primario Meshtastic (defaultpsk 16B, AES-128).",
    },
    # Simple-byte PSK 0x02..0x0A — canali secondari firmware (defaultpsk + n-1 byte 15)
    # Firmware Meshtastic auto-espande qualunque PSK 1 byte (valore N, 2..10)
    # a DEFAULT_PSK con l'ultimo byte incrementato di N-1. Questo crea 10 canali
    # "secondari" universalmente presenti su tutte le installazioni Meshtastic
    # pubbliche che non hanno sovrascritto la PSK del channel 1..10.
    {
        "label": "Meshtastic simple-byte 2",
        "psk_b64": "Ag==", "kind": "public", "channel_name": "default-2",
        "notes": "Canale secondario 2 (simple-byte 0x02).",
    },
    {
        "label": "Meshtastic simple-byte 3",
        "psk_b64": "Aw==", "kind": "public", "channel_name": "default-3",
        "notes": "Canale secondario 3 (simple-byte 0x03).",
    },
    {
        "label": "Meshtastic simple-byte 4",
        "psk_b64": "BA==", "kind": "public", "channel_name": "default-4",
        "notes": "Canale secondario 4 (simple-byte 0x04).",
    },
    {
        "label": "Meshtastic simple-byte 5",
        "psk_b64": "BQ==", "kind": "public", "channel_name": "default-5",
        "notes": "Canale secondario 5 (simple-byte 0x05).",
    },
    {
        "label": "Meshtastic simple-byte 6",
        "psk_b64": "Bg==", "kind": "public", "channel_name": "default-6",
        "notes": "Canale secondario 6 (simple-byte 0x06).",
    },
    {
        "label": "Meshtastic simple-byte 7",
        "psk_b64": "Bw==", "kind": "public", "channel_name": "default-7",
        "notes": "Canale secondario 7 (simple-byte 0x07).",
    },
    {
        "label": "Meshtastic simple-byte 8",
        "psk_b64": "CA==", "kind": "public", "channel_name": "default-8",
        "notes": "Canale secondario 8 (simple-byte 0x08).",
    },
    {
        "label": "Meshtastic simple-byte 9",
        "psk_b64": "CQ==", "kind": "public", "channel_name": "default-9",
        "notes": "Canale secondario 9 (simple-byte 0x09).",
    },
    {
        "label": "Meshtastic simple-byte 10",
        "psk_b64": "Cg==", "kind": "public", "channel_name": "default-10",
        "notes": "Canale secondario 10 (simple-byte 0x0A).",
    },
]


# ══════════════════════════════════════════════════════════════════════════════
# PKI DECRYPT (X25519 + HKDF-SHA256 + AES-256-CCM)
# ══════════════════════════════════════════════════════════════════════════════
# Meshtastic PKI (Direct Messages / ADMIN / ATAK privato):
#   - Sorgente e destinatario hanno una coppia X25519 (pub_key 32B / priv_key 32B)
#   - ECDH: shared = X25519(priv_local, pub_remote) → 32 byte
#   - Nonce PKI (13 byte):
#       offset 0..7  : packet_num (uint64 LE)
#       offset 8..11 : from_node (uint32 LE)
#       offset 12    : extra_byte (0x00)
#   - AES-256-CCM con AAD vuota, tag_length=8
#
# Reference C++ (firmware/src/mesh/CryptoEngine.cpp → encryptCurve25519)

def _hkdf_sha256_32(ikm: bytes, info: bytes = b"", salt: bytes = b"") -> bytes:
    """HKDF-SHA256 che deriva una chiave a 32 byte. Meshtastic usa direttamente
    la chiave condivisa ECDH (X25519) come chiave AES, senza HKDF.
    Questa funzione è fornita come utility opzionale per varianti future."""
    try:
        from cryptography.hazmat.primitives.kdf.hkdf import HKDF
        from cryptography.hazmat.primitives import hashes
        return HKDF(algorithm=hashes.SHA256(), length=32, salt=salt, info=info).derive(ikm)
    except Exception:
        return b""


def build_pki_nonce(packet_id: int, from_node: int, extra: int = 0) -> bytes:
    """Nonce 13-byte per AES-256-CCM PKI."""
    try:
        pid = int(packet_id or 0) & 0xFFFFFFFFFFFFFFFF
        fnode = int(from_node or 0) & 0xFFFFFFFF
    except Exception:
        pid = 0
        fnode = 0
    nonce = bytearray(13)
    nonce[0:8] = pid.to_bytes(8, "little")
    nonce[8:12] = fnode.to_bytes(4, "little")
    nonce[12] = int(extra) & 0xFF
    return bytes(nonce)


def derive_shared_key_x25519(my_priv_hex: str, their_pub_hex: str) -> Optional[bytes]:
    """Deriva la chiave condivisa X25519 (ECDH) come fa il firmware."""
    try:
        from cryptography.hazmat.primitives.asymmetric import x25519
        priv_raw = binascii.unhexlify(my_priv_hex.strip().replace(":", "").replace(" ", ""))
        pub_raw = binascii.unhexlify(their_pub_hex.strip().replace(":", "").replace(" ", ""))
        if len(priv_raw) != 32 or len(pub_raw) != 32:
            return None
        priv = x25519.X25519PrivateKey.from_private_bytes(priv_raw)
        pub = x25519.X25519PublicKey.from_public_bytes(pub_raw)
        shared = priv.exchange(pub)
        return shared  # 32 bytes
    except Exception:
        return None


def decrypt_pki(encrypted, packet_id: int, from_node: int,
                my_priv_hex: str, their_pub_hex: str,
                tag_length: int = 8) -> Optional[bytes]:
    """Decripta un payload PKI Meshtastic (AES-256-CCM, ECDH X25519)."""
    try:
        from cryptography.hazmat.primitives.ciphers.aead import AESCCM
    except ImportError:
        return None
    if isinstance(encrypted, (bytes, bytearray)):
        ct = bytes(encrypted)
    else:
        try:
            ct = binascii.unhexlify(encrypted)
        except Exception:
            return None
    if not ct or len(ct) < (tag_length + 1):
        return None
    shared = derive_shared_key_x25519(my_priv_hex, their_pub_hex)
    if not shared:
        return None
    nonce = build_pki_nonce(packet_id, from_node)
    # AES-CCM vuole nonce 7..13 byte. Meshtastic usa 13.
    for tlen in (tag_length, 8, 16, 4):
        try:
            aes = AESCCM(shared, tag_length=tlen)
            return aes.decrypt(nonce, ct, None)
        except Exception:
            continue
    return None


# ══════════════════════════════════════════════════════════════════════════════
# PORTNUM PAYLOAD PARSER — 23 protobuf types (ADMIN/ATAK/TELEMETRY/…)
# ══════════════════════════════════════════════════════════════════════════════
# Dispatcher che prende (portnum, payload_bytes) e ritorna un dict con i campi
# decodificati. Usa meshtastic.protobuf.* + protobuf MessageToDict.
#
# Supporta tutti i portnum Meshtastic standard:
#   1 TEXT_MESSAGE_APP  → str UTF-8
#   3 POSITION_APP      → mesh_pb2.Position
#   4 NODEINFO_APP      → mesh_pb2.User
#   5 ROUTING_APP       → mesh_pb2.Routing
#   6 ADMIN_APP         → admin_pb2.AdminMessage
#   7 TEXT_MESSAGE_COMPRESSED_APP → Unishox2 (placeholder, raw hex)
#   8 WAYPOINT_APP      → mesh_pb2.Waypoint
#   10 DETECTION_SENSOR_APP → str UTF-8
#   11 ALERT_APP         → str UTF-8
#   32 REPLY_APP         → raw
#   34 PAXCOUNTER_APP    → paxcount_pb2.Paxcount
#   64 SERIAL_APP        → raw bytes
#   66 RANGE_TEST_APP    → str UTF-8
#   67 TELEMETRY_APP     → telemetry_pb2.Telemetry
#   70 TRACEROUTE_APP    → mesh_pb2.RouteDiscovery
#   71 NEIGHBORINFO_APP  → mesh_pb2.NeighborInfo
#   72 ATAK_PLUGIN       → atak_pb2.TAKPacket
#   73 MAP_REPORT_APP    → mqtt_pb2.MapReport
#   …altri: raw hex + tentativo generico

def _b2hex(v):
    if isinstance(v, (bytes, bytearray)):
        return v.hex()
    return v


def _msg_to_dict(msg):
    """Converte un protobuf message in dict (bytes → hex).
    Compatibile con protobuf v4 (MessageToDict moderno, preserva snake_case)."""
    try:
        from google.protobuf.json_format import MessageToDict
        # API moderna (protobuf>=4): niente including_default_value_fields
        d = MessageToDict(msg, preserving_proto_field_name=True,
                          use_integers_for_enums=False)
    except TypeError:
        try:
            from google.protobuf.json_format import MessageToDict
            d = MessageToDict(msg, preserving_proto_field_name=True)
        except Exception as e:
            d = {"_error_pb": str(e)}
    except Exception as e:
        d = {"_error_pb": str(e)}
    # Hex-ify eventuali oggetti bytes rimasti (MessageToDict li converte in base64)
    return d


def parse_portnum_payload(portnum, payload_bytes: bytes) -> dict:
    """Mega-dispatcher: ritorna {portnum_name, decoded_type, decoded, raw_hex, error}."""
    out = {
        "portnum": None,
        "portnum_name": None,
        "decoded_type": None,
        "decoded": None,
        "raw_hex": (payload_bytes.hex() if payload_bytes else ""),
        "raw_len": len(payload_bytes) if payload_bytes else 0,
        "error": None,
    }
    if payload_bytes is None:
        out["error"] = "payload_bytes is None"
        return out

    # Normalizza portnum: può essere int o stringa
    pn_int = None
    pn_name = None
    try:
        from meshtastic.protobuf import portnums_pb2
        if isinstance(portnum, int):
            pn_int = portnum
            try:
                pn_name = portnums_pb2.PortNum.Name(portnum)
            except Exception:
                pn_name = f"PORT_{portnum}"
        elif isinstance(portnum, str):
            pn_name = portnum
            try:
                pn_int = portnums_pb2.PortNum.Value(portnum)
            except Exception:
                pn_int = -1
        out["portnum"] = pn_int
        out["portnum_name"] = pn_name
    except Exception as e:
        out["error"] = f"portnum normalization: {e}"
        return out

    if not payload_bytes:
        out["decoded_type"] = "empty"
        out["decoded"] = None
        return out

    try:
        # TEXT_MESSAGE_APP (1)
        if pn_int == 1 or pn_name == "TEXT_MESSAGE_APP":
            try:
                txt = payload_bytes.decode("utf-8", errors="replace")
                out["decoded_type"] = "text"
                out["decoded"] = {"text": txt}
                return out
            except Exception as e:
                out["error"] = str(e); return out

        # POSITION_APP (3)
        if pn_int == 3 or pn_name == "POSITION_APP":
            from meshtastic.protobuf import mesh_pb2
            m = mesh_pb2.Position()
            m.ParseFromString(payload_bytes)
            d = _msg_to_dict(m)
            # Conversioni lat/lon i7 → float decimale
            if "latitude_i" in d:
                try: d["latitude"] = d["latitude_i"] * 1e-7
                except Exception: pass
            if "longitude_i" in d:
                try: d["longitude"] = d["longitude_i"] * 1e-7
                except Exception: pass
            out["decoded_type"] = "Position"
            out["decoded"] = d
            return out

        # NODEINFO_APP (4)
        if pn_int == 4 or pn_name == "NODEINFO_APP":
            from meshtastic.protobuf import mesh_pb2
            m = mesh_pb2.User()
            m.ParseFromString(payload_bytes)
            out["decoded_type"] = "User"
            out["decoded"] = _msg_to_dict(m)
            return out

        # ROUTING_APP (5)
        if pn_int == 5 or pn_name == "ROUTING_APP":
            from meshtastic.protobuf import mesh_pb2
            m = mesh_pb2.Routing()
            m.ParseFromString(payload_bytes)
            out["decoded_type"] = "Routing"
            out["decoded"] = _msg_to_dict(m)
            return out

        # ADMIN_APP (6) — TUTTI i campi admin visibili
        if pn_int == 6 or pn_name == "ADMIN_APP":
            from meshtastic.protobuf import admin_pb2
            m = admin_pb2.AdminMessage()
            m.ParseFromString(payload_bytes)
            out["decoded_type"] = "AdminMessage"
            out["decoded"] = _msg_to_dict(m)
            return out

        # TEXT_MESSAGE_COMPRESSED_APP (7) — Unishox2
        if pn_int == 7 or pn_name == "TEXT_MESSAGE_COMPRESSED_APP":
            # Prova a decomprimere con unishox2 se disponibile
            try:
                import unishox2  # type: ignore
                dec = unishox2.decompress(payload_bytes, len(payload_bytes) * 4 + 32)
                out["decoded_type"] = "text_unishox2"
                out["decoded"] = {"text": dec[0] if isinstance(dec, tuple) else dec}
                return out
            except Exception:
                out["decoded_type"] = "text_compressed_raw"
                out["decoded"] = {"hex": payload_bytes.hex()}
                return out

        # WAYPOINT_APP (8)
        if pn_int == 8 or pn_name == "WAYPOINT_APP":
            from meshtastic.protobuf import mesh_pb2
            m = mesh_pb2.Waypoint()
            m.ParseFromString(payload_bytes)
            d = _msg_to_dict(m)
            if "latitude_i" in d:
                try: d["latitude"] = d["latitude_i"] * 1e-7
                except Exception: pass
            if "longitude_i" in d:
                try: d["longitude"] = d["longitude_i"] * 1e-7
                except Exception: pass
            out["decoded_type"] = "Waypoint"
            out["decoded"] = d
            return out

        # DETECTION_SENSOR_APP (10) / ALERT_APP (11) / RANGE_TEST_APP (66) → testo
        if pn_int in (10, 11, 66):
            try:
                out["decoded_type"] = "text_sensor"
                out["decoded"] = {"text": payload_bytes.decode("utf-8", errors="replace")}
                return out
            except Exception:
                pass

        # KEY_VERIFICATION_APP (12)
        if pn_int == 12 or pn_name == "KEY_VERIFICATION_APP":
            out["decoded_type"] = "key_verification_raw"
            out["decoded"] = {"hex": payload_bytes.hex()}
            return out

        # PAXCOUNTER_APP (34)
        if pn_int == 34 or pn_name == "PAXCOUNTER_APP":
            from meshtastic.protobuf import paxcount_pb2
            m = paxcount_pb2.Paxcount()
            m.ParseFromString(payload_bytes)
            out["decoded_type"] = "Paxcount"
            out["decoded"] = _msg_to_dict(m)
            return out

        # STORE_FORWARD_APP (65)
        if pn_int == 65 or pn_name == "STORE_FORWARD_APP":
            from meshtastic.protobuf import storeforward_pb2
            m = storeforward_pb2.StoreAndForward()
            m.ParseFromString(payload_bytes)
            out["decoded_type"] = "StoreAndForward"
            out["decoded"] = _msg_to_dict(m)
            return out

        # TELEMETRY_APP (67)
        if pn_int == 67 or pn_name == "TELEMETRY_APP":
            from meshtastic.protobuf import telemetry_pb2
            m = telemetry_pb2.Telemetry()
            m.ParseFromString(payload_bytes)
            out["decoded_type"] = "Telemetry"
            out["decoded"] = _msg_to_dict(m)
            return out

        # TRACEROUTE_APP (70)
        if pn_int == 70 or pn_name == "TRACEROUTE_APP":
            from meshtastic.protobuf import mesh_pb2
            m = mesh_pb2.RouteDiscovery()
            m.ParseFromString(payload_bytes)
            out["decoded_type"] = "RouteDiscovery"
            out["decoded"] = _msg_to_dict(m)
            return out

        # NEIGHBORINFO_APP (71)
        if pn_int == 71 or pn_name == "NEIGHBORINFO_APP":
            from meshtastic.protobuf import mesh_pb2
            m = mesh_pb2.NeighborInfo()
            m.ParseFromString(payload_bytes)
            out["decoded_type"] = "NeighborInfo"
            out["decoded"] = _msg_to_dict(m)
            return out

        # ATAK_PLUGIN (72) — TUTTI i campi ATAK visibili
        if pn_int == 72 or pn_name == "ATAK_PLUGIN":
            from meshtastic.protobuf import atak_pb2
            m = atak_pb2.TAKPacket()
            m.ParseFromString(payload_bytes)
            out["decoded_type"] = "TAKPacket"
            out["decoded"] = _msg_to_dict(m)
            return out

        # MAP_REPORT_APP (73)
        if pn_int == 73 or pn_name == "MAP_REPORT_APP":
            from meshtastic.protobuf import mqtt_pb2
            m = mqtt_pb2.MapReport()
            m.ParseFromString(payload_bytes)
            out["decoded_type"] = "MapReport"
            out["decoded"] = _msg_to_dict(m)
            return out

        # REMOTE_HARDWARE_APP (2)
        if pn_int == 2 or pn_name == "REMOTE_HARDWARE_APP":
            from meshtastic.protobuf import remote_hardware_pb2
            m = remote_hardware_pb2.HardwareMessage()
            m.ParseFromString(payload_bytes)
            out["decoded_type"] = "HardwareMessage"
            out["decoded"] = _msg_to_dict(m)
            return out

        # Default: raw hex + tentativo testo UTF-8
        try:
            txt = payload_bytes.decode("utf-8")
            if all(c.isprintable() or c in "\n\r\t" for c in txt):
                out["decoded_type"] = "text_guess"
                out["decoded"] = {"text": txt}
                return out
        except Exception:
            pass
        out["decoded_type"] = "raw"
        out["decoded"] = {"hex": payload_bytes.hex()}
        return out

    except Exception as e:
        out["error"] = f"parse_portnum_payload({pn_name}): {e}"
        out["decoded_type"] = "parse_error"
        out["decoded"] = {"hex": payload_bytes.hex()}
        return out


# ══════════════════════════════════════════════════════════════════════════════
# CRYPTO AGENT — orchestratore che tenta TUTTE le strategie di decrypt
# ══════════════════════════════════════════════════════════════════════════════
# Input: packet_dict con {encrypted_hex, packet_id, from_node, to_node, portnum_hint,
#                         channel_idx, channel_hash, public_key_hex}
# Optional: psk_list (per canale), pki_list (privkey locali + pubkey remote)
# Output: {success, method, psk_matched, portnum, decoded_fields, cleartext_hex, attempts[]}

def crypto_agent_decrypt(packet: dict,
                         psk_list: Optional[List[dict]] = None,
                         pki_list: Optional[List[dict]] = None,
                         verbose: bool = True) -> dict:
    """Super-funzione Crypto Agent: prova TUTTE le strategie e ritorna tutto decifrato.

    psk_list: [{id,label,psk_b64,kind,enabled}, …]
    pki_list: [{label,my_priv_hex,their_pub_hex}, …]
    """
    result = {
        "success": False,
        "method": None,
        "matched": None,
        "portnum": packet.get("portnum_hint"),
        "portnum_decoded": None,
        "decoded_fields": None,
        "cleartext_hex": None,
        "attempts": [],
        "error": None,
    }

    enc = packet.get("encrypted_hex") or ""
    if not enc:
        result["error"] = "encrypted_hex missing"
        return result

    pid = packet.get("packet_id") or 0
    fn = packet.get("from_node") or 0
    portnum_hint = packet.get("portnum_hint")

    # ========== FASE 1: PSK (AES-CTR) ==========
    psks = list(psk_list or [])
    # Aggiungi fallback con PSK default se lista vuota
    if not psks:
        psks = [{"id": 0, "label": "Default AQ==", "psk_b64": "AQ==",
                 "kind": "public", "enabled": 1}]

    for psk in psks:
        if not psk.get("enabled", 1):
            continue
        raw = psk.get("psk_b64") or ""
        if not raw:
            continue
        dec = try_decrypt(enc, pid, fn, raw)
        att = {"method": "PSK", "label": psk.get("label"), "ok": False}
        if not dec:
            att["reason"] = "decrypt failed (key invalid)"
            result["attempts"].append(att)
            continue
        ok, pn, payload = validate_decrypted(dec)
        att["ok"] = bool(ok)
        att["portnum"] = pn
        if ok:
            parsed = parse_portnum_payload(pn, payload)
            result["success"] = True
            result["method"] = "PSK/AES-CTR"
            result["matched"] = {
                "psk_id": psk.get("id"),
                "psk_label": psk.get("label"),
                "psk_kind": psk.get("kind"),
            }
            result["portnum"] = pn
            result["portnum_decoded"] = parsed.get("portnum_name")
            result["decoded_fields"] = parsed
            result["cleartext_hex"] = dec.hex()
            if verbose:
                result["attempts"].append(att)
            return result
        result["attempts"].append(att)

    # ========== FASE 2: PKI (X25519 + AES-CCM) ==========
    pkis = list(pki_list or [])
    for pki in pkis:
        priv = pki.get("my_priv_hex") or ""
        pub = pki.get("their_pub_hex") or packet.get("public_key_hex") or ""
        if not priv or not pub:
            continue
        try:
            dec = decrypt_pki(enc, pid, fn, priv, pub)
        except Exception as e:
            result["attempts"].append({"method": "PKI", "label": pki.get("label"),
                                       "ok": False, "reason": str(e)})
            continue
        att = {"method": "PKI", "label": pki.get("label"), "ok": False}
        if not dec:
            att["reason"] = "pki decrypt failed"
            result["attempts"].append(att)
            continue
        ok, pn, payload = validate_decrypted(dec)
        att["ok"] = bool(ok)
        att["portnum"] = pn
        if ok:
            parsed = parse_portnum_payload(pn, payload)
            result["success"] = True
            result["method"] = "PKI/X25519+AES-CCM"
            result["matched"] = {"pki_label": pki.get("label")}
            result["portnum"] = pn
            result["portnum_decoded"] = parsed.get("portnum_name")
            result["decoded_fields"] = parsed
            result["cleartext_hex"] = dec.hex()
            result["attempts"].append(att)
            return result
        result["attempts"].append(att)

    # ========== FASE 3: parse raw se già in chiaro ==========
    # Alcuni pacchetti hanno il "encrypted_hex" in realtà già in chiaro (caso edge)
    try:
        raw = binascii.unhexlify(enc)
        ok, pn, payload = validate_decrypted(raw)
        if ok:
            parsed = parse_portnum_payload(pn, payload)
            result["success"] = True
            result["method"] = "cleartext"
            result["portnum"] = pn
            result["portnum_decoded"] = parsed.get("portnum_name")
            result["decoded_fields"] = parsed
            result["cleartext_hex"] = raw.hex()
            result["attempts"].append({"method": "raw_parse", "ok": True,
                                       "portnum": pn})
            return result
        result["attempts"].append({"method": "raw_parse", "ok": False,
                                   "reason": "not a valid protobuf Data"})
    except Exception as e:
        result["attempts"].append({"method": "raw_parse", "ok": False,
                                   "reason": str(e)})

    result["error"] = "Tutte le strategie di decrypt hanno fallito. Aggiungi PSK/PKI corretta."
    return result


if __name__ == "__main__":
    # Self-test
    print("DEFAULT PSK bytes:", DEFAULT_PSK.hex())
    print("Normalized 'AQ==':", normalize_psk("AQ==").hex() if normalize_psk("AQ==") else "None")
    print("Normalized '0x01':", normalize_psk("0x01").hex() if normalize_psk("0x01") else "None")
    n = build_nonce(0x1234ABCD, 0xDEADBEEF)
    print("Nonce(pid=0x1234ABCD, from=0xDEADBEEF):", n.hex())
    print("PKI nonce(same):", build_pki_nonce(0x1234ABCD, 0xDEADBEEF).hex())
    # parse_portnum_payload empty self-test
    r = parse_portnum_payload(1, b"hello world")
    print("parse TEXT:", r)
    # Crypto agent fake
    pkt = {"encrypted_hex": "", "packet_id": 0, "from_node": 0}
    ag = crypto_agent_decrypt(pkt)
    print("Agent empty:", ag["error"])
