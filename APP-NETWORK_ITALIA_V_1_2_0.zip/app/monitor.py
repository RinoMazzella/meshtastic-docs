# -*- coding: utf-8 -*-
"""
📡 Meshtastic Italia Network App v1.2.0 — Monitor Module
Modulo per il monitor real-time dei pacchetti mesh (PRO).

Architettura:
  - Un thread background mantiene SerialInterface + pubsub
  - Ogni pacchetto ricevuto viene analizzato, classificato (RF/MQTT)
    e inviato in un EventQueue per lo streaming SSE verso il browser
  - Aggregatore statistiche thread-safe (Lock) per le classifiche
  - USB esclusiva: quando il monitor è attivo, CLI/Config/Flash si bloccano
  - Zero dipendenze nuove: usa meshtastic + pyserial già in requirements.txt

© 2026 🌐🥭MANGOLINK🥭🌐 — Tutti i diritti riservati
"""

import os
import re
import json
import time
import queue
import base64
import threading
import datetime
import binascii
from collections import defaultdict, deque

# Moduli nostri (opzionali — il monitor gira anche senza di loro)
try:
    import monitor_db
    _DB_OK = True
except Exception:
    monitor_db = None
    _DB_OK = False

try:
    import fw_fingerprint
    _FP_OK = True
except Exception:
    fw_fingerprint = None
    _FP_OK = False

# Decompressione opzionale (Unishox2 usato da alcuni fork firmware per portnum 7)
try:
    import unishox2 as _unishox2  # pip install unishox2-py3
    _UNISHOX_OK = True
except Exception:
    _unishox2 = None
    _UNISHOX_OK = False

# Open Location Code (Plus Codes) — opzionale per conversione lat/lon
try:
    from openlocationcode import openlocationcode as _olc
    _OLC_OK = True
except Exception:
    _olc = None
    _OLC_OK = False

# Decrypt Meshtastic AES-CTR — opzionale (richiede cryptography già in requirements)
try:
    import meshtastic_crypto as _mcrypt
    _MCRYPT_OK = True
except Exception:
    _mcrypt = None
    _MCRYPT_OK = False

# ═══════════════════════════════════════════════════════════
# ENUM MAPS — decodifica numerica → stringa umana
# Riferimento: https://github.com/meshtastic/protobufs
# ═══════════════════════════════════════════════════════════

# PortNum completo (da portnums.proto) — include sia experimental che production
PORTNUM_MAP = {
    0: "UNKNOWN_APP", 1: "TEXT_MESSAGE_APP", 2: "REMOTE_HARDWARE_APP",
    3: "POSITION_APP", 4: "NODEINFO_APP", 5: "ROUTING_APP",
    6: "ADMIN_APP", 7: "TEXT_MESSAGE_COMPRESSED_APP", 8: "WAYPOINT_APP",
    9: "AUDIO_APP", 10: "DETECTION_SENSOR_APP", 11: "ALERT_APP",
    12: "KEY_VERIFICATION_APP", 13: "REMOTE_SHELL_APP",
    32: "REPLY_APP", 33: "IP_TUNNEL_APP", 34: "PAXCOUNTER_APP",
    35: "STORE_FORWARD_PLUSPLUS_APP", 36: "NODE_STATUS_APP",
    64: "SERIAL_APP", 65: "STORE_FORWARD_APP", 66: "RANGE_TEST_APP",
    67: "TELEMETRY_APP", 68: "ZPS_APP", 69: "SIMULATOR_APP",
    70: "TRACEROUTE_APP", 71: "NEIGHBORINFO_APP", 72: "ATAK_PLUGIN",
    73: "MAP_REPORT_APP", 74: "POWERSTRESS_APP", 75: "LORAWAN_BRIDGE",
    76: "RETICULUM_TUNNEL_APP", 77: "CAYENNE_APP", 78: "ATAK_PLUGIN_V2",
    112: "GROUPALARM_APP",
    256: "PRIVATE_APP", 257: "ATAK_FORWARDER", 511: "MAX",
}

# MeshPacket.Priority enum
PRIORITY_MAP = {
    0: "UNSET", 1: "MIN", 10: "BACKGROUND", 64: "DEFAULT",
    70: "RESPONSE", 100: "HIGH", 120: "ALERT", 127: "RELIABLE",
    200: "ACK", 255: "MAX",
}

# Routing error codes
ROUTING_ERROR_MAP = {
    0: "NONE", 1: "NO_ROUTE", 2: "GOT_NAK", 3: "TIMEOUT",
    4: "NO_INTERFACE", 5: "MAX_RETRANSMIT", 6: "NO_CHANNEL",
    7: "TOO_LARGE", 8: "NO_RESPONSE", 9: "DUTY_CYCLE_LIMIT",
    10: "BAD_REQUEST", 11: "NOT_AUTHORIZED", 12: "PKI_FAILED",
    13: "PKI_UNKNOWN_PUBKEY", 14: "ADMIN_BAD_SESSION_KEY",
    15: "ADMIN_PUBLIC_KEY_UNAUTHORIZED", 16: "RATE_LIMITED",
}

# Fix type GPS (Position.fix_type)
FIX_TYPE_MAP = {0: "NONE", 1: "2D", 2: "3D", 3: "DGPS", 4: "RTK"}

# Location source
LOCATION_SOURCE_MAP = {
    0: "LOC_UNSET", 1: "LOC_MANUAL", 2: "LOC_INTERNAL", 3: "LOC_EXTERNAL",
}

# Altitude source
ALTITUDE_SOURCE_MAP = {
    0: "ALT_UNSET", 1: "ALT_MANUAL", 2: "ALT_INTERNAL",
    3: "ALT_EXTERNAL", 4: "ALT_BAROMETRIC",
}

# Device role (User.role)
ROLE_MAP = {
    0: "CLIENT", 1: "CLIENT_MUTE", 2: "ROUTER", 3: "ROUTER_CLIENT",
    4: "REPEATER", 5: "TRACKER", 6: "SENSOR", 7: "TAK",
    8: "CLIENT_HIDDEN", 9: "LOST_AND_FOUND", 10: "TAK_TRACKER",
    11: "ROUTER_LATE",
}

# Store & Forward request/response enum
SF_RR_MAP = {
    0: "UNSET", 1: "ROUTER_ERROR", 2: "ROUTER_HEARTBEAT",
    3: "ROUTER_PING", 4: "ROUTER_PONG", 5: "ROUTER_BUSY",
    6: "ROUTER_HISTORY", 7: "ROUTER_STATS", 8: "ROUTER_TEXT_BROADCAST",
    9: "ROUTER_TEXT_DIRECT",
    64: "CLIENT_ERROR", 65: "CLIENT_HISTORY", 66: "CLIENT_STATS",
    67: "CLIENT_PING", 68: "CLIENT_PONG", 69: "CLIENT_ABORT",
}

# Remote hardware type
REMOTE_HW_TYPE_MAP = {
    0: "UNSET", 1: "WRITE_GPIOS", 2: "WATCH_GPIOS",
    3: "GPIOS_CHANGED", 4: "READ_GPIOS", 5: "READ_GPIOS_REPLY",
}

# Team colors (ATAK)
TEAM_MAP = {
    0: "UNSPECIFIED_COLOR", 1: "WHITE", 2: "YELLOW", 3: "ORANGE",
    4: "MAGENTA", 5: "RED", 6: "MAROON", 7: "PURPLE",
    8: "DARK_BLUE", 9: "BLUE", 10: "CYAN", 11: "TEAL",
    12: "GREEN", 13: "DARK_GREEN", 14: "BROWN",
}

# Detection sensor state (bool wrapped)
DETECTION_STATE_MAP = {False: "LOW", True: "HIGH", 0: "LOW", 1: "HIGH"}


# ═══════════════════════════════════════════════════════════
# CHANNEL REGISTRY — classificazione network neutra
#
# Mappa nomi di canale → bucket UI:
#   - "min"          → canali ufficiali Meshtastic Italia Network
#   - "mesh_italia"  → qualsiasi altro canale italiano riconosciuto
#   - "unknown"      → non nel registry (appare come "sconosciuto")
#
# Nota: l'app NON tenta di decifrare canali con PSK esterne — il firmware
# decide cosa passare. Questa tabella classifica i canali CHE VEDIAMO
# usando i loro nomi (interface.channel list) o index 0-7.
# ═══════════════════════════════════════════════════════════

CHANNEL_REGISTRY = {
    # Canali primari MIN (il nostro network)
    "ita-nord":    "min",
    "ita-centro":  "min",
    "ita-sud":     "min",
    "ita-help":    "min",
    "ita-test":    "min",
    "ita-shop":    "min",
    "italia":      "min",
    # Canali pubblici condivisi — trattati come MIN di default (primary)
    "mediumfast":  "min",
    # Altri canali italiani aggregati (bucket generico)
    "abruzzo":     "mesh_italia",
    "basilicata":  "mesh_italia",
    "calabria":    "mesh_italia",
    "campania":    "mesh_italia",
    "em-ro":       "mesh_italia",
    "friuli-vg":   "mesh_italia",
    "lazio":       "mesh_italia",
    "liguria":     "mesh_italia",
    "lombardia":   "mesh_italia",
    "marche":      "mesh_italia",
    "molise":      "mesh_italia",
    "piemonte":    "mesh_italia",
    "puglia":      "mesh_italia",
    "sardegna":    "mesh_italia",
    "sicilia":     "mesh_italia",
    "toscana":     "mesh_italia",
    "trentino-aa": "mesh_italia",
    "umbria":      "mesh_italia",
    "valle aosta": "mesh_italia",
    "veneto":      "mesh_italia",
    "c-ticino":    "mesh_italia",
    "san marino":  "mesh_italia",
    "test":        "mesh_italia",
    "newsfeed":    "mesh_italia",
    "onlybots":    "mesh_italia",
    "rrp":         "mesh_italia",
    # Canali fork community (nomi on-air protocollari)
    "darkmesh":    "mesh_italia",
    "darkmesh.7z": "mesh_italia",
}


def classify_network(channel_name, channel_idx=None):
    """Ritorna uno dei 3 bucket UI: min / mesh_italia / unknown.

    - Se il canale ha un nome riconosciuto nel registry → usa quello
    - Altrimenti, se channel_idx == 0 (primary di default) → assume 'min'
    - Altrimenti → 'unknown'
    """
    if channel_name:
        key = str(channel_name).strip().lower()
        hit = CHANNEL_REGISTRY.get(key)
        if hit:
            return hit
    if channel_idx == 0:
        return "min"  # primary channel (default MediumFast PSK AQ==)
    return "unknown"


# Plus Code regex — Open Location Code format (es. "8FPQ2234+PG")
_PLUS_CODE_RE = re.compile(r"\b([23456789CFGHJMPQRVWX]{4,8}\+[23456789CFGHJMPQRVWX]{2,3})\b")


def _extract_plus_code(text):
    """Se il testo contiene un Plus Code valido, ritorna (code, lat, lon) o None."""
    if not text or not isinstance(text, str):
        return None
    m = _PLUS_CODE_RE.search(text.upper())
    if not m:
        return None
    code = m.group(1)
    lat = lon = None
    if _OLC_OK:
        try:
            if _olc.isValid(code) and _olc.isFull(code):
                area = _olc.decode(code)
                lat = (area.latitudeLo + area.latitudeHi) / 2.0
                lon = (area.longitudeLo + area.longitudeHi) / 2.0
        except Exception:
            pass
    return {"code": code, "lat": lat, "lon": lon}


def _try_unishox_decode(hex_or_bytes):
    """Tenta decompressione Unishox2. Ritorna (text, ok)."""
    if not _UNISHOX_OK or not hex_or_bytes:
        return None, False
    try:
        if isinstance(hex_or_bytes, str):
            # Hex string
            data = binascii.unhexlify(hex_or_bytes)
        else:
            data = bytes(hex_or_bytes)
        # unishox2-py3 API: decompress(data, orig_size)
        # Se non sappiamo orig_size, tentiamo con buffer fino a 10x
        try:
            result = _unishox2.decompress(data, len(data) * 10)
        except TypeError:
            # API alternativa senza size hint
            result = _unishox2.decompress(data)
        if isinstance(result, tuple):
            result = result[0]
        if isinstance(result, bytes):
            result = result.decode("utf-8", errors="replace")
        return str(result), True
    except Exception:
        return None, False


def _enum_str(value, enum_map, default="UNKNOWN"):
    """Decodifica un valore enum (int o già string) in label umana."""
    if isinstance(value, str):
        return value  # già decodificato
    if isinstance(value, int):
        return enum_map.get(value, f"{default}_{value}")
    return default

# ═══════════════════════════════════════════════════════════
# STATO GLOBALE (thread-safe)
# ═══════════════════════════════════════════════════════════

_LOCK = threading.RLock()
_STATE = {
    "active": False,
    "port": None,
    "started_at": None,
    "packets_total": 0,
    "packets_rf": 0,
    "packets_mqtt": 0,
    "packets_text": 0,
    "packets_encrypted": 0,
    "last_error": None,
    "interface": None,       # meshtastic SerialInterface instance
    "thread": None,          # supervisor thread
    "my_node_num": None,
    "my_node_name": None,
}

# Ring buffer eventi (ultimi 500 pacchetti) — gli SSE client leggono da qui
_EVENTS = deque(maxlen=500)
_EVENT_SEQ = 0   # incrementale: usato da SSE per evitare duplicati

# STEP B — Buffer pacchetti cifrati non decifrati (rematch futuro)
# Contiene dict minimo: {packet_id, from_int, encrypted_hex, ts, rowid_db?}
_PKT_ENC_BUFFER = deque(maxlen=500)

# Coda di consegna per ogni client SSE connesso
_SSE_CLIENTS = []   # lista di queue.Queue

# Statistiche per nodo (chiavi = nodeId str)
_NODE_STATS = defaultdict(lambda: {
    "id": "",
    "long_name": "Unknown",
    "short_name": "????",
    "hw_model": "UNKNOWN",
    "rf_packets": 0,
    "mqtt_packets": 0,
    "text_msgs": 0,
    "positions": 0,
    "telemetry": 0,
    "nodeinfo": 0,
    "routing": 0,
    "traceroute": 0,
    "neighborinfo": 0,
    "waypoint": 0,
    "other": 0,
    "encrypted": 0,
    "total_hops": 0,           # somma hopLimit per media
    "hop_samples": 0,
    "spam_count": 0,           # NodeInfo < 60s
    "last_nodeinfo_ts": 0,
    "last_seen_ts": 0,
    "last_seen": "",
    "first_seen_ts": 0,
    "last_rssi": 0,
    "last_snr": 0,
    "best_rssi": -999,
    "best_snr": -999,
    "last_channel": 0,
    "last_coords": "",
    "avg_interval_s": 0.0,     # intervallo medio tra pacchetti (periodicità)
    "_prev_packet_ts": 0,
    "_intervals_sum": 0.0,
    "_intervals_n": 0,
})

# H3 — Cache metadata nodi (sticky attraverso pacchetti diversi)
# Aggiornata da NODEINFO_APP e MAP_REPORT_APP, iniettata in OGNI evt prima
# del push SSE: permette UI di mostrare is_licensed/stealth/firmware_version/
# region/modem_preset/hw_model/role anche su pacchetti TELEMETRY/POSITION/TEXT
# di un nodo che ha emesso una precedente NODEINFO.
_NODE_META = {}   # { sender_id_str: { is_licensed, is_stealth, is_unmessagable,
                  #                     macaddr, role, public_key_hex,
                  #                     firmware_version, region, modem_preset,
                  #                     hw_model, long_name, short_name,
                  #                     last_updated_ts } }

# ═══════════════════════════════════════════════════════════
# SOGLIE ALERT — Default MediumFast (come scelto da utente)
# ═══════════════════════════════════════════════════════════

# MediumFast preset:
#   BW 250 kHz, CR 4/7, SF 10 → data-rate ≈ 1400 bps
#   Airtime medio pacchetto ≈ 60 ms vs LongFast ≈ 196 ms
#   Più permissivo su airtime → NodeInfo più frequenti tollerate
THRESHOLDS_DEFAULT = {
    "preset": "MediumFast",
    "nodeinfo_min_interval_s": 300,   # NodeInfo spam se < 5 min (MediumFast è più permissivo)
    "ch_util_max_pct": 25.0,          # >25% = mesh degradata
    "airtime_max_pct": 10.0,          # EU_868 duty cycle hard-limit
    "rf_flood_per_min": 20,           # nodo che manda >20 pkt/min in RF
    "mqtt_flood_per_min": 30,         # nodo che manda >30 pkt/min in MQTT
    "hop_flood_threshold": 3,         # hopLimit iniziale max normale = 3
    "spam_count_alert": 3,            # alert dopo 3 episodi spam
    "weak_signal_rssi": -110,         # sotto questo = segnale pessimo
    "weak_signal_snr": -10.0,
}

_THRESHOLDS = dict(THRESHOLDS_DEFAULT)


def get_thresholds():
    """Ritorna le soglie attuali (copia per sicurezza)."""
    with _LOCK:
        return dict(_THRESHOLDS)


def set_thresholds(new_values):
    """Aggiorna le soglie. Accetta dict con subset di chiavi."""
    global _THRESHOLDS
    with _LOCK:
        for k, v in (new_values or {}).items():
            if k in THRESHOLDS_DEFAULT:
                _THRESHOLDS[k] = v
        return dict(_THRESHOLDS)


def reset_thresholds():
    """Ripristina i default MediumFast."""
    global _THRESHOLDS
    with _LOCK:
        _THRESHOLDS = dict(THRESHOLDS_DEFAULT)
        return dict(_THRESHOLDS)


# ═══════════════════════════════════════════════════════════
# FASE 4 — Preset FW standard per le soglie
# Ogni preset riflette la capacità teorica del modem LoRa:
#   LongFast  → airtime alto, NodeInfo frequenti tollerate meno
#   MediumFast → default, buon compromesso
#   ShortFast → airtime basso, più permissivo su flood
#   LongSlow  → bassissimo data-rate, molto permissivo
#   VeryLongSlow → ultra-slow, limite duty cycle critico
# ═══════════════════════════════════════════════════════════

FW_PRESETS = {
    "LongFast": {
        "preset": "LongFast",
        "nodeinfo_min_interval_s": 600,   # 10 min (data-rate basso)
        "ch_util_max_pct": 20.0,
        "airtime_max_pct": 8.0,
        "rf_flood_per_min": 10,
        "mqtt_flood_per_min": 20,
        "hop_flood_threshold": 3,
        "spam_count_alert": 3,
        "weak_signal_rssi": -115,
        "weak_signal_snr": -12.0,
    },
    "MediumFast": {
        "preset": "MediumFast",
        "nodeinfo_min_interval_s": 300,
        "ch_util_max_pct": 25.0,
        "airtime_max_pct": 10.0,
        "rf_flood_per_min": 20,
        "mqtt_flood_per_min": 30,
        "hop_flood_threshold": 3,
        "spam_count_alert": 3,
        "weak_signal_rssi": -110,
        "weak_signal_snr": -10.0,
    },
    "ShortFast": {
        "preset": "ShortFast",
        "nodeinfo_min_interval_s": 180,   # 3 min (data-rate alto)
        "ch_util_max_pct": 35.0,
        "airtime_max_pct": 15.0,
        "rf_flood_per_min": 40,
        "mqtt_flood_per_min": 60,
        "hop_flood_threshold": 3,
        "spam_count_alert": 5,
        "weak_signal_rssi": -105,
        "weak_signal_snr": -8.0,
    },
    "LongSlow": {
        "preset": "LongSlow",
        "nodeinfo_min_interval_s": 1800,  # 30 min (data-rate molto basso)
        "ch_util_max_pct": 15.0,
        "airtime_max_pct": 5.0,
        "rf_flood_per_min": 5,
        "mqtt_flood_per_min": 10,
        "hop_flood_threshold": 3,
        "spam_count_alert": 2,
        "weak_signal_rssi": -120,
        "weak_signal_snr": -15.0,
    },
    "VeryLongSlow": {
        "preset": "VeryLongSlow",
        "nodeinfo_min_interval_s": 3600,  # 1h
        "ch_util_max_pct": 10.0,
        "airtime_max_pct": 3.0,
        "rf_flood_per_min": 3,
        "mqtt_flood_per_min": 5,
        "hop_flood_threshold": 3,
        "spam_count_alert": 2,
        "weak_signal_rssi": -125,
        "weak_signal_snr": -18.0,
    },
}


def list_fw_presets():
    """Ritorna lista dei preset standard FW supportati."""
    return list(FW_PRESETS.keys())


def apply_fw_preset(preset_name):
    """Applica un preset FW standard alle soglie. Ritorna dict thresholds aggiornato.

    Args:
        preset_name: uno di FW_PRESETS.keys()

    Returns:
        (ok, result)  — ok=True se applicato, result=dict thresholds
                      — ok=False se preset ignoto, result=dict errore
    """
    global _THRESHOLDS
    if preset_name not in FW_PRESETS:
        return False, {
            "error": "unknown_preset",
            "valid_presets": list(FW_PRESETS.keys()),
        }
    with _LOCK:
        _THRESHOLDS = dict(FW_PRESETS[preset_name])
        return True, dict(_THRESHOLDS)


# ═══════════════════════════════════════════════════════════
# HELPERS
# ═══════════════════════════════════════════════════════════

def _now_ts():
    return time.time()

def _now_hms():
    return datetime.datetime.now().strftime("%H:%M:%S")

def _format_mac(node_id):
    """Crea un finto MAC-style ID dal nodeId (stile forense)"""
    try:
        nid = node_id if isinstance(node_id, int) else int(str(node_id).replace("!", ""), 16)
        hex_id = f"{nid:08x}"
        return ":".join(hex_id[i:i+2] for i in range(0, len(hex_id), 2)).upper()
    except Exception:
        return "00:00:00:00"


def _push_event(evt):
    """Accoda un evento (dict JSON-serializable) per gli SSE client."""
    global _EVENT_SEQ
    with _LOCK:
        _EVENT_SEQ += 1
        evt["seq"] = _EVENT_SEQ
        _EVENTS.append(evt)
        for q in list(_SSE_CLIENTS):
            try:
                q.put_nowait(evt)
            except queue.Full:
                pass  # client troppo lento, salta


def _broadcast_status(extra=None):
    """Invia uno status aggiornato ai client SSE."""
    with _LOCK:
        evt = {
            "type": "status",
            "ts": _now_ts(),
            "active": _STATE["active"],
            "port": _STATE["port"],
            "started_at": _STATE["started_at"],
            "packets_total": _STATE["packets_total"],
            "packets_rf": _STATE["packets_rf"],
            "packets_mqtt": _STATE["packets_mqtt"],
            "packets_text": _STATE["packets_text"],
            "packets_encrypted": _STATE["packets_encrypted"],
            "last_error": _STATE["last_error"],
            "my_node_num": _STATE["my_node_num"],
            "my_node_name": _STATE["my_node_name"],
        }
        if extra:
            evt.update(extra)
    _push_event(evt)


# ═══════════════════════════════════════════════════════════
# PACKET ANALYZER — estrae TUTTI i metadati + classifica RF/MQTT
# ═══════════════════════════════════════════════════════════

def _to_hex(b):
    """Helper: bytes → hex string (None-safe)."""
    if b is None:
        return None
    try:
        if isinstance(b, (bytes, bytearray)):
            return binascii.hexlify(bytes(b)).decode("ascii")
        if isinstance(b, str):
            # Potrebbe già essere base64 o hex; proviamo prima hex
            return b
        return str(b)
    except Exception:
        return None


def _to_int(v, default=None):
    try:
        return int(v)
    except Exception:
        return default


def _to_float(v, default=None):
    try:
        return float(v)
    except Exception:
        return default


def _format_node_id_str(val):
    """Formatta !abcd1234 da int o stringa."""
    if val is None:
        return None
    if isinstance(val, str):
        if val.startswith("!"):
            return val
        try:
            return "!" + f"{int(val):08x}"
        except Exception:
            return val
    try:
        return "!" + f"{int(val):08x}"
    except Exception:
        return str(val)


def _extract_telemetry_all(telem):
    """Estrae TUTTI i campi di tutte le 8 varianti telemetry (sparse)."""
    if not isinstance(telem, dict):
        return {}
    out = {"time": telem.get("time")}
    # DeviceMetrics
    dm = telem.get("deviceMetrics") or telem.get("device_metrics") or {}
    if isinstance(dm, dict) and dm:
        out["device"] = {
            "battery_level": dm.get("batteryLevel", dm.get("battery_level")),
            "voltage": dm.get("voltage"),
            "channel_utilization": dm.get("channelUtilization", dm.get("channel_utilization")),
            "air_util_tx": dm.get("airUtilTx", dm.get("air_util_tx")),
            "uptime_seconds": dm.get("uptimeSeconds", dm.get("uptime_seconds")),
        }
    # EnvironmentMetrics
    em = telem.get("environmentMetrics") or telem.get("environment_metrics") or {}
    if isinstance(em, dict) and em:
        out["environment"] = {
            "temperature": em.get("temperature"),
            "relative_humidity": em.get("relativeHumidity", em.get("relative_humidity")),
            "barometric_pressure": em.get("barometricPressure", em.get("barometric_pressure")),
            "gas_resistance": em.get("gasResistance", em.get("gas_resistance")),
            "iaq": em.get("iaq"),
            "lux": em.get("lux"),
            "white_lux": em.get("whiteLux", em.get("white_lux")),
            "ir_lux": em.get("irLux", em.get("ir_lux")),
            "uv_lux": em.get("uvLux", em.get("uv_lux")),
            "wind_direction": em.get("windDirection", em.get("wind_direction")),
            "wind_speed": em.get("windSpeed", em.get("wind_speed")),
            "wind_gust": em.get("windGust", em.get("wind_gust")),
            "wind_lull": em.get("windLull", em.get("wind_lull")),
            "weight": em.get("weight"),
            "rainfall_1h": em.get("rainfall1h", em.get("rainfall_1h")),
            "rainfall_24h": em.get("rainfall24h", em.get("rainfall_24h")),
            "soil_moisture": em.get("soilMoisture", em.get("soil_moisture")),
            "soil_temperature": em.get("soilTemperature", em.get("soil_temperature")),
            "radiation": em.get("radiation"),
            "distance": em.get("distance"),
            "voltage": em.get("voltage"),
            "current": em.get("current"),
        }
    # AirQualityMetrics
    aq = telem.get("airQualityMetrics") or telem.get("air_quality_metrics") or telem.get("airQuality") or {}
    if isinstance(aq, dict) and aq:
        out["air_quality"] = {
            "pm10_standard": aq.get("pm10Standard", aq.get("pm10_standard")),
            "pm25_standard": aq.get("pm25Standard", aq.get("pm25_standard")),
            "pm100_standard": aq.get("pm100Standard", aq.get("pm100_standard")),
            "pm10_environmental": aq.get("pm10Environmental", aq.get("pm10_environmental")),
            "pm25_environmental": aq.get("pm25Environmental", aq.get("pm25_environmental")),
            "pm100_environmental": aq.get("pm100Environmental", aq.get("pm100_environmental")),
            "particles_03um": aq.get("particles03um", aq.get("particles_03um")),
            "particles_05um": aq.get("particles05um", aq.get("particles_05um")),
            "particles_10um": aq.get("particles10um", aq.get("particles_10um")),
            "particles_25um": aq.get("particles25um", aq.get("particles_25um")),
            "particles_50um": aq.get("particles50um", aq.get("particles_50um")),
            "particles_100um": aq.get("particles100um", aq.get("particles_100um")),
            "co2": aq.get("co2"),
        }
    # PowerMetrics (8 canali possibili)
    pm = telem.get("powerMetrics") or telem.get("power_metrics") or telem.get("power") or {}
    if isinstance(pm, dict) and pm:
        power = {}
        for i in range(1, 9):
            cv = pm.get(f"ch{i}Voltage") or pm.get(f"ch{i}_voltage")
            ci = pm.get(f"ch{i}Current") or pm.get(f"ch{i}_current")
            if cv is not None:
                power[f"ch{i}_voltage"] = cv
            if ci is not None:
                power[f"ch{i}_current"] = ci
        if power:
            out["power"] = power
    # LocalStats (mesh health)
    ls = telem.get("localStats") or telem.get("local_stats") or {}
    if isinstance(ls, dict) and ls:
        out["local_stats"] = {
            "uptime_seconds": ls.get("uptimeSeconds", ls.get("uptime_seconds")),
            "channel_utilization": ls.get("channelUtilization", ls.get("channel_utilization")),
            "air_util_tx": ls.get("airUtilTx", ls.get("air_util_tx")),
            "num_packets_tx": ls.get("numPacketsTx", ls.get("num_packets_tx")),
            "num_packets_rx": ls.get("numPacketsRx", ls.get("num_packets_rx")),
            "num_packets_rx_bad": ls.get("numPacketsRxBad", ls.get("num_packets_rx_bad")),
            "num_online_nodes": ls.get("numOnlineNodes", ls.get("num_online_nodes")),
            "num_total_nodes": ls.get("numTotalNodes", ls.get("num_total_nodes")),
            "num_rx_dupe": ls.get("numRxDupe", ls.get("num_rx_dupe")),
            "num_tx_relay": ls.get("numTxRelay", ls.get("num_tx_relay")),
            "num_tx_relay_canceled": ls.get("numTxRelayCanceled", ls.get("num_tx_relay_canceled")),
            "heap_total_bytes": ls.get("heapTotalBytes", ls.get("heap_total_bytes")),
            "heap_free_bytes": ls.get("heapFreeBytes", ls.get("heap_free_bytes")),
        }
    # HealthMetrics (biometric)
    hm = telem.get("healthMetrics") or telem.get("health_metrics") or {}
    if isinstance(hm, dict) and hm:
        out["health"] = {
            "heart_bpm": hm.get("heartBpm", hm.get("heart_bpm")),
            "spO2": hm.get("spO2"),
            "temperature": hm.get("temperature"),
        }
    # HostMetrics (gateway linux)
    host = telem.get("hostMetrics") or telem.get("host_metrics") or {}
    if isinstance(host, dict) and host:
        out["host"] = {
            "uptime_seconds": host.get("uptimeSeconds", host.get("uptime_seconds")),
            "freemem_bytes": host.get("freememBytes", host.get("freemem_bytes")),
            "load1": host.get("load1"),
            "load5": host.get("load5"),
            "load15": host.get("load15"),
            "diskfree1_bytes": host.get("diskfree1Bytes", host.get("diskfree1_bytes")),
            "user_string": host.get("userString", host.get("user_string")),
        }
    # Rimuovi chiavi None-only
    return {k: v for k, v in out.items() if v is not None}


def _analyze_packet(packet, interface):
    """
    Analizza un pacchetto meshtastic ed estrae il 100% dei metadati disponibili.
    Copre TUTTI i portnum documentati in portnums.proto + tutti i campi
    MeshPacket di mesh.proto. Mantiene sempre `raw_hex` del payload decoded
    per analisi forense anche quando il parsing è riuscito.
    """
    try:
        # ═════ 1. TOP-LEVEL MeshPacket FIELDS ═════
        sender_raw = packet.get("fromId") or packet.get("from") or "Unknown"
        sender_id = _format_node_id_str(sender_raw) or str(sender_raw)

        rssi = _to_int(packet.get("rxRssi"), 0) or 0
        snr = _to_float(packet.get("rxSnr"), 0.0) or 0.0
        hop_limit = _to_int(packet.get("hopLimit"), 0) or 0
        hop_start = _to_int(packet.get("hopStart"), hop_limit)
        hops_away = packet.get("hopsAway")
        channel = _to_int(packet.get("channel"), 0) or 0
        priority_raw = packet.get("priority", 0)
        priority_str = _enum_str(priority_raw, PRIORITY_MAP, "PRIORITY")
        want_ack = bool(packet.get("wantAck", False))
        via_mqtt = packet.get("viaMqtt")
        pki_encrypted = bool(packet.get("pkiEncrypted", False))
        public_key_raw = packet.get("publicKey")
        public_key_hex = _to_hex(public_key_raw) if public_key_raw else None
        next_hop = packet.get("nextHop") or packet.get("next_hop")
        relay_node = packet.get("relayNode") or packet.get("relay_node")
        delayed = packet.get("delayed")
        tx_after = packet.get("txAfter") or packet.get("tx_after")
        packet_id = packet.get("id", "N/A")
        to_raw = packet.get("toId") or packet.get("to")
        to_id = _format_node_id_str(to_raw) if to_raw is not None else ""
        rx_time = packet.get("rxTime") or _now_ts()

        # Broadcast detection
        is_broadcast = (
            to_raw in (4294967295, 0xFFFFFFFF, "!ffffffff", "^all")
            or str(to_id).lower() == "!ffffffff"
        )

        # ═════ 2. RF vs MQTT CLASSIFICATION ═════
        # Source of truth: via_mqtt. Fallback: rssi==0 && snr==0 (firmware vecchi)
        if via_mqtt is True:
            is_mqtt = True
        elif via_mqtt is False:
            is_mqtt = False
        else:
            is_mqtt = (rssi == 0 and snr == 0.0)
        source = "mqtt" if is_mqtt else "rf"

        # ═════ 3. DECODED SUBDICT ═════
        decoded = packet.get("decoded", {}) or {}
        if not isinstance(decoded, dict):
            decoded = {}
        # portnum può arrivare come int o stringa
        portnum_raw = decoded.get("portnum", "UNKNOWN_APP")
        if isinstance(portnum_raw, int):
            portnum_str = PORTNUM_MAP.get(portnum_raw, f"PORT_{portnum_raw}")
        else:
            portnum_str = str(portnum_raw)
        portnum_int = None
        if isinstance(portnum_raw, int):
            portnum_int = portnum_raw
        else:
            # reverse lookup
            for k, v in PORTNUM_MAP.items():
                if v == portnum_str:
                    portnum_int = k
                    break

        # Decoded wrapper metadata (comuni)
        decoded_meta = {
            "bitfield": decoded.get("bitfield"),
            "want_response": decoded.get("wantResponse"),
            "dest": decoded.get("dest"),
            "source": decoded.get("source"),
            "request_id": decoded.get("requestId"),
            "reply_id": decoded.get("replyId"),
            "emoji": decoded.get("emoji"),
        }
        decoded_meta = {k: v for k, v in decoded_meta.items() if v is not None}

        # Raw payload hex (anche quando decoded OK — forense)
        raw_payload_hex = None
        raw_payload_len = 0
        raw = decoded.get("payload")
        if raw:
            if isinstance(raw, (bytes, bytearray)):
                raw_payload_hex = binascii.hexlify(bytes(raw)).decode("ascii")
                raw_payload_len = len(raw)
            elif isinstance(raw, str):
                raw_payload_hex = raw
                raw_payload_len = len(raw) // 2 if all(c in "0123456789abcdefABCDEF" for c in raw) else len(raw)

        # ═════ 4. ENCRYPTED (non-decodificato) ═════
        # BUG FIX 2026-04-20: `packet["encrypted"]` può arrivare come bytes (RF)
        # o come stringa base64 (MQTT). Prima il codice assumeva hex per le
        # stringhe, causando encrypted_len sbagliato e fail silenzioso nella
        # brute-force PSK (try_decrypt fa unhexlify). Ora normalizziamo a hex.
        encrypted_hex = None
        encrypted_len = 0
        if "encrypted" in packet and packet["encrypted"]:
            erw = packet["encrypted"]
            if isinstance(erw, (bytes, bytearray)):
                encrypted_hex = binascii.hexlify(bytes(erw)).decode("ascii")
                encrypted_len = len(erw)
            elif isinstance(erw, str):
                _s = erw.strip()
                _decoded = None
                # Primo tentativo: hex (se la stringa è puramente esadecimale)
                if _s and all(c in "0123456789abcdefABCDEF" for c in _s) and (len(_s) % 2 == 0):
                    try:
                        _decoded = binascii.unhexlify(_s)
                    except Exception:
                        _decoded = None
                # Fallback: base64 (caso MQTT)
                if _decoded is None and _s:
                    try:
                        import base64 as _b64
                        _decoded = _b64.b64decode(_s, validate=False)
                    except Exception:
                        _decoded = None
                if _decoded is not None and len(_decoded) > 0:
                    # Salva SEMPRE in formato hex per coerenza (encrypted_hex = hex)
                    encrypted_hex = binascii.hexlify(_decoded).decode("ascii")
                    encrypted_len = len(_decoded)
                else:
                    # Fallback last-resort: salva la stringa grezza (verrà gestita
                    # da try_decrypt che ora accetta hex/base64/bytes).
                    encrypted_hex = _s
                    encrypted_len = 0

        # ═════ 5. PAYLOAD PER PORTNUM (30+ tipi) ═════
        payload = {}

        if portnum_str == "TEXT_MESSAGE_APP":
            _text = decoded.get("text", "") or ""
            payload["text"] = _text
            # Plus Code detection (formato OLC compatto, es. "8FPQ2234+PG")
            _pc = _extract_plus_code(_text)
            if _pc:
                payload["plus_code"] = _pc

        elif portnum_str == "TEXT_MESSAGE_COMPRESSED_APP":
            # Payload compresso (usato da alcuni fork firmware). Tentiamo
            # decompressione Unishox2 se la lib è disponibile; altrimenti
            # esponiamo solo la flag "compressed" e la lunghezza raw.
            _txt_in_decoded = decoded.get("text", "")
            payload["compressed"] = True
            if _txt_in_decoded:
                # Alcuni firmware decodificano già lato device
                payload["text"] = _txt_in_decoded
            else:
                _dec, _ok = _try_unishox_decode(raw_payload_hex or raw)
                if _ok:
                    payload["text"] = _dec
                    payload["compressed_decoded"] = True
                else:
                    payload["text"] = ""
                    payload["compressed_decoded"] = False

        elif portnum_str == "POSITION_APP":
            pos = decoded.get("position", {}) or {}
            payload["latitude"] = pos.get("latitude")
            payload["longitude"] = pos.get("longitude")
            payload["latitude_i"] = pos.get("latitudeI")
            payload["longitude_i"] = pos.get("longitudeI")
            payload["altitude"] = pos.get("altitude")
            payload["altitude_hae"] = pos.get("altitudeHae")
            payload["altitude_geoidal_separation"] = pos.get("altitudeGeoidalSeparation")
            payload["sats_in_view"] = pos.get("satsInView")
            payload["pdop"] = pos.get("PDOP") or pos.get("pdop")
            payload["hdop"] = pos.get("HDOP") or pos.get("hdop")
            payload["vdop"] = pos.get("VDOP") or pos.get("vdop")
            payload["gps_accuracy"] = pos.get("gpsAccuracy")
            payload["ground_speed"] = pos.get("groundSpeed")
            payload["ground_track"] = pos.get("groundTrack")
            payload["fix_type"] = _enum_str(pos.get("fixType"), FIX_TYPE_MAP, "FIX")
            payload["fix_quality"] = pos.get("fixQuality")
            payload["precision_bits"] = pos.get("precisionBits")
            payload["location_source"] = _enum_str(pos.get("locationSource"), LOCATION_SOURCE_MAP, "LOC")
            payload["altitude_source"] = _enum_str(pos.get("altitudeSource"), ALTITUDE_SOURCE_MAP, "ALT")
            payload["timestamp"] = pos.get("timestamp") or pos.get("time")
            payload["seq_number"] = pos.get("seqNumber")

        elif portnum_str == "NODEINFO_APP":
            user = decoded.get("user", {}) or {}
            payload["id"] = user.get("id")
            payload["long_name"] = user.get("longName", "???")
            payload["short_name"] = user.get("shortName", "???")
            payload["macaddr"] = _to_hex(user.get("macaddr")) if user.get("macaddr") else None
            payload["hw_model"] = user.get("hwModel", "UNKNOWN")
            payload["role"] = _enum_str(user.get("role", "CLIENT"), ROLE_MAP, "ROLE")
            payload["is_licensed"] = bool(user.get("isLicensed", False))
            payload["is_stealth"] = bool(user.get("isStealth", False)) if "isStealth" in user else None
            pkey = user.get("publicKey")
            payload["public_key_hex"] = _to_hex(pkey) if pkey else None
            payload["has_public_key"] = bool(pkey)

        elif portnum_str == "ROUTING_APP":
            r = decoded.get("routing", {}) or {}
            payload["error_reason_code"] = r.get("errorReason")
            payload["error_reason"] = _enum_str(r.get("errorReason", 0), ROUTING_ERROR_MAP, "ERR")
            if "routeRequest" in r:
                payload["route_request"] = r["routeRequest"]
            if "routeReply" in r:
                payload["route_reply"] = r["routeReply"]

        elif portnum_str == "TRACEROUTE_APP":
            tr = decoded.get("traceroute", {}) or {}
            route = tr.get("route") or []
            route_back = tr.get("routeBack") or []
            # SNR scaling: valori raw sono int8 moltiplicati per 4
            snr_tow_raw = tr.get("snrTowards") or []
            snr_back_raw = tr.get("snrBack") or []
            payload["route"] = [_format_node_id_str(n) for n in route]
            payload["route_back"] = [_format_node_id_str(n) for n in route_back]
            payload["snr_towards_db"] = [
                (s / 4.0 if s != -128 else None) for s in snr_tow_raw
            ]
            payload["snr_back_db"] = [
                (s / 4.0 if s != -128 else None) for s in snr_back_raw
            ]
            payload["hops_count"] = len(route)

        elif portnum_str == "NEIGHBORINFO_APP":
            ni = decoded.get("neighborinfo", {}) or decoded.get("neighborInfo", {}) or {}
            payload["node_id"] = _format_node_id_str(ni.get("nodeId"))
            payload["last_sent_by_id"] = _format_node_id_str(ni.get("lastSentById"))
            payload["node_broadcast_interval_secs"] = ni.get("nodeBroadcastIntervalSecs")
            neighbors = []
            for n in (ni.get("neighbors") or []):
                snr_raw = n.get("snr")
                neighbors.append({
                    "node_id": _format_node_id_str(n.get("nodeId")),
                    # snr potrebbe arrivare già scalato (float) o raw (int/4)
                    "snr_db": snr_raw if isinstance(snr_raw, float) else (
                        (snr_raw / 4.0) if isinstance(snr_raw, int) and snr_raw != -128 else None
                    ),
                    "last_rx_time": n.get("lastRxTime"),
                    "node_broadcast_interval_secs": n.get("nodeBroadcastIntervalSecs"),
                })
            payload["neighbors"] = neighbors
            payload["neighbor_count"] = len(neighbors)

        elif portnum_str == "WAYPOINT_APP":
            wp = decoded.get("waypoint", {}) or {}
            payload["id"] = wp.get("id")
            lat_i = wp.get("latitudeI")
            lon_i = wp.get("longitudeI")
            payload["latitude"] = (lat_i / 1e7) if lat_i else None
            payload["longitude"] = (lon_i / 1e7) if lon_i else None
            payload["expire"] = wp.get("expire")
            payload["locked_to"] = _format_node_id_str(wp.get("lockedTo"))
            payload["name"] = wp.get("name", "")
            payload["description"] = wp.get("description", "")
            payload["icon"] = wp.get("icon")

        elif portnum_str == "TELEMETRY_APP":
            telem = decoded.get("telemetry", {}) or {}
            payload = _extract_telemetry_all(telem)
            payload["_source_port"] = decoded.get("source")
            # Identifica tipo variante principale
            variants_present = [k for k in ("device", "environment", "air_quality", "power", "local_stats", "health", "host") if k in payload]
            payload["variants"] = variants_present

        elif portnum_str == "MAP_REPORT_APP":
            mr = decoded.get("mapReport", {}) or decoded.get("map_report", {}) or {}
            payload["long_name"] = mr.get("longName")
            payload["short_name"] = mr.get("shortName")
            payload["role"] = _enum_str(mr.get("role"), ROLE_MAP, "ROLE")
            payload["hw_model"] = mr.get("hwModel")
            payload["firmware_version"] = mr.get("firmwareVersion")
            payload["region"] = mr.get("region")
            payload["modem_preset"] = mr.get("modemPreset")
            payload["has_default_channel"] = mr.get("hasDefaultChannel")
            lat_i = mr.get("latitudeI")
            lon_i = mr.get("longitudeI")
            payload["latitude"] = (lat_i / 1e7) if lat_i else None
            payload["longitude"] = (lon_i / 1e7) if lon_i else None
            payload["altitude"] = mr.get("altitude")
            payload["position_precision"] = mr.get("positionPrecision")
            payload["num_online_local_nodes"] = mr.get("numOnlineLocalNodes")

        elif portnum_str == "PAXCOUNTER_APP":
            pc = decoded.get("paxcounter", {}) or {}
            payload["wifi"] = pc.get("wifi", 0)
            payload["ble"] = pc.get("ble", 0)
            payload["uptime"] = pc.get("uptime", 0)

        elif portnum_str == "DETECTION_SENSOR_APP":
            ds = decoded.get("detectionSensor") or decoded.get("detection_sensor") or decoded
            payload["state"] = DETECTION_STATE_MAP.get(ds.get("state"), ds.get("state")) if isinstance(ds, dict) else None
            payload["name"] = ds.get("name", "") if isinstance(ds, dict) else ""
            payload["text"] = decoded.get("text", "")

        elif portnum_str == "RANGE_TEST_APP":
            rt = decoded.get("rangetest") or decoded.get("range_test") or {}
            payload["seq"] = rt.get("seq") if isinstance(rt, dict) else None
            payload["time"] = rt.get("time") if isinstance(rt, dict) else None
            payload["text"] = decoded.get("text", "")  # RangeTest spesso invia testo con seq

        elif portnum_str == "STORE_FORWARD_APP" or portnum_str == "STORE_FORWARD_PLUSPLUS_APP":
            sf = decoded.get("storeForward", {}) or decoded.get("store_forward", {}) or {}
            payload["rr"] = _enum_str(sf.get("rr"), SF_RR_MAP, "RR")
            payload["stats"] = sf.get("stats") or {}
            payload["history"] = _to_hex(sf.get("history")) if sf.get("history") else None
            payload["text"] = sf.get("text")

        elif portnum_str == "ADMIN_APP":
            am = decoded.get("adminMessage") or decoded.get("admin_message") or decoded.get("admin") or {}
            if isinstance(am, dict):
                payload["session_passkey_hex"] = _to_hex(am.get("sessionPasskey")) if am.get("sessionPasskey") else None
                # Identifica il variant type
                variant = None
                for k in am.keys():
                    if k not in ("sessionPasskey", "session_passkey"):
                        variant = k
                        break
                payload["variant"] = variant
            else:
                payload["admin_raw"] = str(am)[:200]

        elif portnum_str == "REMOTE_HARDWARE_APP":
            rh = decoded.get("remoteHardware") or decoded.get("remote_hardware") or {}
            payload["type"] = _enum_str(rh.get("type"), REMOTE_HW_TYPE_MAP, "HW")
            payload["gpio_mask"] = rh.get("gpioMask", rh.get("gpio_mask"))
            payload["gpio_value"] = rh.get("gpioValue", rh.get("gpio_value"))

        elif portnum_str == "SERIAL_APP":
            # Serial è binario puro
            payload["raw_hex"] = raw_payload_hex
            payload["size"] = raw_payload_len

        elif portnum_str == "AUDIO_APP":
            # Codec2: magic 0xC0 0xDE 0xC2 + byte marker
            payload["size"] = raw_payload_len
            if raw_payload_hex and len(raw_payload_hex) >= 8:
                magic = raw_payload_hex[:6].lower()
                payload["codec2_magic"] = magic == "c0dec2"
                if payload["codec2_magic"]:
                    payload["bitrate_marker"] = int(raw_payload_hex[6:8], 16)

        elif portnum_str == "REPLY_APP":
            payload["raw_hex"] = raw_payload_hex
            payload["size"] = raw_payload_len

        elif portnum_str == "IP_TUNNEL_APP":
            payload["raw_hex"] = raw_payload_hex
            payload["size"] = raw_payload_len
            # Parse IPv4 header se possibile
            if raw_payload_hex and len(raw_payload_hex) >= 40:
                try:
                    b = bytes.fromhex(raw_payload_hex)
                    version_ihl = b[0]
                    if (version_ihl >> 4) == 4:  # IPv4
                        payload["ip_version"] = 4
                        payload["ip_protocol"] = b[9]
                        payload["ip_src"] = ".".join(str(x) for x in b[12:16])
                        payload["ip_dst"] = ".".join(str(x) for x in b[16:20])
                except Exception:
                    pass

        elif portnum_str == "ALERT_APP":
            payload["text"] = decoded.get("text", "")
            payload["severity"] = decoded.get("severity")

        elif portnum_str == "KEY_VERIFICATION_APP":
            payload["raw_hex"] = raw_payload_hex
            payload["size"] = raw_payload_len

        elif portnum_str in ("ATAK_PLUGIN", "ATAK_PLUGIN_V2", "ATAK_FORWARDER"):
            # Binary CoT compressed / fountain coded
            payload["raw_hex"] = raw_payload_hex
            payload["size"] = raw_payload_len
            payload["format"] = "cot_binary"

        elif portnum_str == "PRIVATE_APP":
            payload["raw_hex"] = raw_payload_hex
            payload["size"] = raw_payload_len
            payload["note"] = "user-defined"

        elif portnum_str == "POWERSTRESS_APP":
            payload["raw_hex"] = raw_payload_hex
            payload["size"] = raw_payload_len

        elif portnum_str == "SIMULATOR_APP":
            payload["raw_hex"] = raw_payload_hex
            payload["size"] = raw_payload_len

        elif portnum_str in ("LORAWAN_BRIDGE", "RETICULUM_TUNNEL_APP", "CAYENNE_APP"):
            payload["raw_hex"] = raw_payload_hex
            payload["size"] = raw_payload_len

        else:
            # Portnum sconosciuto / nuovo — dump raw
            payload["raw_hex"] = raw_payload_hex
            payload["size"] = raw_payload_len

        # ═════ 6. RISOLVI IDENTITÀ SENDER DAL NODE-DB ═════
        long_name = sender_id
        short_name = "????"
        hw_model = "UNKNOWN"
        role_resolved = None
        try:
            node_key = sender_id
            if not node_key.startswith("!"):
                try:
                    node_key = "!" + f"{int(sender_id):08x}"
                except Exception:
                    pass
            node = None
            if hasattr(interface, "nodes") and isinstance(interface.nodes, dict):
                node = interface.nodes.get(node_key) or interface.nodes.get(sender_id)
            if node:
                user = node.get("user", {}) or {}
                long_name = user.get("longName", sender_id) or sender_id
                short_name = user.get("shortName", "????")
                hw_model = user.get("hwModel", "UNKNOWN")
                role_resolved = user.get("role")
        except Exception:
            pass

        # Se il pacchetto stesso è NODEINFO_APP, prendi dal payload corrente (più fresco)
        if portnum_str == "NODEINFO_APP":
            long_name = payload.get("long_name") or long_name
            short_name = payload.get("short_name") or short_name
            hw_model = payload.get("hw_model") or hw_model
            role_resolved = payload.get("role") or role_resolved

        # ═════ 6b. CHANNEL NAME RESOLUTION + NETWORK CLASSIFICATION ═════
        channel_name = None
        try:
            # Risolvi nome canale dal device (localConfig.channels[channel_idx])
            if hasattr(interface, "localNode") and interface.localNode:
                chs = getattr(interface.localNode, "channels", None)
                if chs and 0 <= channel < len(chs):
                    ch_obj = chs[channel]
                    # Formati diversi a seconda della versione meshtastic lib
                    settings = getattr(ch_obj, "settings", None) or ch_obj
                    name = getattr(settings, "name", None) or (
                        settings.get("name") if isinstance(settings, dict) else None
                    )
                    if name:
                        channel_name = str(name)
        except Exception:
            pass

        # FASE 9 (2026-05-05) — Set di nomi PRESET radio (NON sono canali validi).
        # Se channel_name combacia con un preset, viene considerato "non affidabile"
        # e sovrascritto da fonti più semantiche (PSK hash8 / PSK match dopo decrypt).
        _PRESET_NAMES = {
            "LongFast", "MediumFast", "ShortFast", "ShortTurbo",
            "ShortSlow", "MediumSlow", "LongModerate", "LongSlow", "VeryLongSlow",
        }

        # FASE 9 (2026-05-05) — Resolution chain riordinata:
        #   1) localNode.channels[idx]  (slot 0-7 USB autoritativo)
        #   2) PSK hash8 lookup         (catalogo Italia + custom — autoritativo per canale)
        #   3) channelId_env MQTT       (ULTIMO fallback, può contenere il nome del bridge)
        # In più: se Step 1 ha restituito un nome che è un preset (LongFast/MediumFast),
        # consideriamo non affidabile e proviamo Step 2 per upgrade.
        if not channel_name or channel_name in _PRESET_NAMES:
            if channel is not None:
                try:
                    _resolved = _psk_hash8_lookup(channel)
                    if _resolved and _resolved not in _PRESET_NAMES:
                        # PSK match valido — preferito a preset ambiguo
                        channel_name = _resolved
                    elif _resolved and not channel_name:
                        # Anche se è preset name, almeno popolato
                        channel_name = _resolved
                except Exception:
                    pass

        # ULTIMO fallback: ServiceEnvelope channelId (MQTT broker-side)
        # Usato solo se localNode + PSK hash8 non hanno risolto.
        if not channel_name:
            try:
                _env_nm = packet.get("channelId_env") or packet.get("channelId")
                if _env_nm and isinstance(_env_nm, str) and _env_nm.strip():
                    channel_name = _env_nm.strip()
            except Exception:
                pass

        # STEP 4 — Harvest hash8→name nella channel_map (silent, best-effort).
        # Non sovrascrive mai entry USB autoritative (vedi channel_map_harvest).
        try:
            if channel_name and channel is not None:
                monitor_db.channel_map_harvest(channel, channel_name)
        except Exception:
            pass

        network_bucket = classify_network(channel_name, channel)

        # ═════ 6c. FIRMWARE FINGERPRINT (euristica per-nodo, label neutri) ═════
        fw_type = "unknown"
        fw_flags = {}
        if _FP_OK and portnum_int is not None:
            try:
                from_int_fp = None
                try:
                    from_int_fp = int(str(sender_id).lstrip("!"), 16)
                except Exception:
                    from_int_fp = None
                if from_int_fp is not None:
                    fw_type, fw_flags = fw_fingerprint.observe(from_int_fp, portnum_int, ts=rx_time)
            except Exception:
                fw_type = "unknown"
                fw_flags = {}

        # ═════ 6bis. H3 — AGGIORNA _NODE_META (sticky per sender) ═════
        # Se questo è un NODEINFO/MAP_REPORT, salviamo i metadati "identità"
        # del nodo per iniettarli in TUTTI i prossimi pacchetti dello stesso sender.
        try:
            if portnum_str == "NODEINFO_APP":
                _m = _NODE_META.setdefault(sender_id, {})
                if payload.get("is_licensed") is not None: _m["is_licensed"] = payload.get("is_licensed")
                if payload.get("is_stealth") is not None: _m["is_stealth"] = payload.get("is_stealth")
                if payload.get("macaddr"): _m["macaddr"] = payload.get("macaddr")
                if payload.get("role"): _m["role"] = payload.get("role")
                if payload.get("hw_model"): _m["hw_model"] = payload.get("hw_model")
                if payload.get("public_key_hex"): _m["public_key_hex"] = payload.get("public_key_hex")
                if payload.get("long_name"): _m["long_name"] = payload.get("long_name")
                if payload.get("short_name"): _m["short_name"] = payload.get("short_name")
                _m["_updated_ts"] = rx_time
            elif portnum_str == "MAP_REPORT_APP":
                _m = _NODE_META.setdefault(sender_id, {})
                if payload.get("firmware_version"): _m["firmware_version"] = payload.get("firmware_version")
                if payload.get("region"): _m["region"] = payload.get("region")
                if payload.get("modem_preset"): _m["modem_preset"] = payload.get("modem_preset")
                if payload.get("role"): _m["role"] = payload.get("role")
                if payload.get("hw_model"): _m["hw_model"] = payload.get("hw_model")
                if payload.get("long_name"): _m["long_name"] = payload.get("long_name")
                if payload.get("short_name"): _m["short_name"] = payload.get("short_name")
                _m["_updated_ts"] = rx_time
        except Exception:
            pass

        # ═════ 6ter. H3 — INIETTA _NODE_META sticky in evt ═════
        # I campi "identità nodo" già visti nei NODEINFO/MAP_REPORT passati
        # devono comparire anche nei pacchetti successivi (TELEMETRY, POSITION,
        # TEXT…) dello stesso sender, così la UI può renderizzarli sempre.
        _meta_sticky = _NODE_META.get(sender_id) or {}
        _inj_is_licensed = _meta_sticky.get("is_licensed")
        _inj_is_stealth = _meta_sticky.get("is_stealth")
        _inj_macaddr = _meta_sticky.get("macaddr")
        _inj_firmware_version = _meta_sticky.get("firmware_version")
        _inj_region = _meta_sticky.get("region")
        _inj_modem_preset = _meta_sticky.get("modem_preset")
        _inj_public_key_sticky = _meta_sticky.get("public_key_hex")
        # role: preferisci quello appena risolto, altrimenti lo sticky
        _role_final = role_resolved or _meta_sticky.get("role")
        # hw_model: preferisci appena risolto, altrimenti sticky
        _hw_final = hw_model or _meta_sticky.get("hw_model")

        # ═════ STEP 5 — Harvest public_key per nodo (silent, best-effort) ═════
        # Popola node_pubkeys con la chiave X25519 osservata. UNIQUE(node, key)
        # garantisce che rotazioni chiave diventino righe separate (non overwrite).
        try:
            _final_pk = public_key_hex or _inj_public_key_sticky
            if _final_pk and sender_id:
                _src_tag = "mqtt" if source == "mqtt" else "rf"
                monitor_db.node_pubkey_harvest(sender_id, _final_pk, source=_src_tag)
        except Exception:
            pass

        # ═════ 7. OUTPUT ═════
        return {
            # Timestamps
            "ts": rx_time,
            "ts_hms": datetime.datetime.fromtimestamp(rx_time).strftime("%H:%M:%S"),
            # Classification
            "source": source,           # "rf" | "mqtt"
            "is_broadcast": is_broadcast,
            # Sender identity
            "sender_id": sender_id,
            "sender_mac": _format_mac(sender_id),
            "long_name": long_name,
            "short_name": short_name,
            "hw_model": _hw_final,
            "role": _role_final,
            # H3 — sticky node identity (propagati da NODEINFO/MAP_REPORT passati)
            "is_licensed": _inj_is_licensed,
            "is_stealth": _inj_is_stealth,
            "macaddr_full": _inj_macaddr,
            "firmware_version": _inj_firmware_version,
            "region": _inj_region,
            "modem_preset": _inj_modem_preset,
            # Destination
            "to_id": str(to_id) if to_id else "",
            # Packet ID & timing
            "packet_id": packet_id,
            # Radio metrics
            "rssi": rssi,
            "snr": snr,
            "channel": channel,
            # STEP C — Channel hash/index distinti
            # 'channel' dal protobuf Meshtastic è IL CHANNEL HASH (XOR hash(name)^hash(psk)),
            # NON l'indice 0-7. L'indice si ricava solo via lookup nella tabella canali locali.
            "channel_hash": channel,
            "channel_idx": channel if (0 <= channel <= 7) else None,
            # Hop
            "hop_limit": hop_limit,
            "hop_start": hop_start,
            "hops_away": hops_away,
            "hops_used": (hop_start - hop_limit) if (hop_start is not None and hop_limit is not None) else None,
            "next_hop": next_hop,
            "relay_node": relay_node,
            # Flags
            "priority": priority_str,
            "priority_num": priority_raw if isinstance(priority_raw, int) else None,
            "want_ack": want_ack,
            "via_mqtt": bool(via_mqtt) if via_mqtt is not None else None,
            "pki_encrypted": pki_encrypted,
            "public_key_hex": public_key_hex or _inj_public_key_sticky,
            "delayed": delayed,
            "tx_after": tx_after,
            # Decoded wrapper meta
            "decoded_meta": decoded_meta,
            # Payload
            "portnum": portnum_str,
            "portnum_num": portnum_int,
            "payload": payload,
            "raw_payload_hex": raw_payload_hex,
            "raw_payload_len": raw_payload_len,
            # Encrypted (quando non decodificabile)
            "encrypted_hex": encrypted_hex,
            "encrypted_len": encrypted_len,
            # Classificazione network (neutra: min / mesh_italia / unknown)
            "network": network_bucket,
            "channel_name": channel_name,
            # Firmware fingerprint (label neutri)
            "fw_type": fw_type,
            "fw_flags": fw_flags,
            # Flag compressione rapidi (per filtri UI)
            "is_compressed": portnum_str == "TEXT_MESSAGE_COMPRESSED_APP",
            # STEP 12 — Ghost Node Mode: rileva "decoded spazzatura" dal nodo USB.
            # Se il nodo tenta decrypt con una delle sue 8 PSK-slot ma il pacchetto
            # e' di un canale regionale non-slot (es. Campania), produce un
            # decoded={portnum:UNKNOWN_APP(0), payload:~random} che prima ci faceva
            # scartare is_encrypted=False -> brute-force catalogo mai eseguita ->
            # canali regionali mai leggibili. Ora rileviamo la spazzatura e
            # riflagghiamo is_encrypted=True per attivare STEP 8 brute-force su
            # tutto il catalogo PSK Italia (36 entries).
            "is_encrypted": bool(encrypted_hex) and (
                (not decoded)
                or (
                    # Ghost-node: decoded presente ma senza portnum utile
                    # e senza testo/payload leggibile -> spazzatura da PSK
                    # sbagliata del nodo -> retry brute-force.
                    (portnum_int is None or portnum_int == 0)
                    and not (isinstance(payload, dict) and payload.get("text"))
                )
            ),
        }
    except Exception as e:
        return {
            "ts": _now_ts(),
            "ts_hms": _now_hms(),
            "source": "error",
            "error": str(e),
            "portnum": "PARSE_ERROR",
            "network": "unknown",
            "fw_type": "unknown",
            "fw_flags": {},
        }


# ═══════════════════════════════════════════════════════════
# DB PERSISTENCE — hook che inserisce ogni evento in monitor_db
# ═══════════════════════════════════════════════════════════

def _persist_event(evt):
    """Inserisce il pacchetto nel DB 7gg + tabelle specializzate per portnum.

    H2 v2 — ora popola:
    - packets con le 22 nuove colonne (telemetry_json, position_*, decoded_meta_*,
      radio_control_*, raw_protobuf_b64, pki_encrypted, ecc.)
    - nodes con le 16 nuove colonne (macaddr, role, public_key_hex, region,
      firmware_version, modem_preset, last_battery/voltage/ch_util/tx_util/uptime)
    - topology (da NEIGHBORINFO_APP — una riga per vicino)
    - traceroutes (da TRACEROUTE_APP — path forward+back)
    - map_reports (da MAP_REPORT_APP — snapshot metadata nodo)
    - waypoints (da WAYPOINT_APP — POI condivisi)
    - storeforward_stats (da STORE_FORWARD_APP — heartbeat/history/stats)
    - node_metadata (da NODEINFO_APP/MAP_REPORT_APP — snapshot User.proto)

    Silent-fail totale: il monitor NON deve morire per un DB down.
    """
    if not _DB_OK or not monitor_db:
        return
    try:
        payload = evt.get("payload") or {}
        if not isinstance(payload, dict):
            payload = {}
        text = payload.get("text") if isinstance(payload, dict) else None
        sender_raw = evt.get("sender_id", "")
        try:
            from_int = int(str(sender_raw).lstrip("!"), 16) if sender_raw else None
        except Exception:
            from_int = None
        to_raw = evt.get("to_id", "")
        try:
            to_int = int(str(to_raw).lstrip("!"), 16) if to_raw else None
        except Exception:
            to_int = None

        ts_ms = int(evt.get("ts", time.time()) * 1000)
        portnum_str = evt.get("portnum") or ""

        # ═════ GPS dal payload (POSITION/WAYPOINT/MAP_REPORT) ═════
        _lat = payload.get("latitude")
        _lon = payload.get("longitude")
        _alt = payload.get("altitude")

        # ═════ Telemetry dict (solo per TELEMETRY_APP) ═════
        _telemetry_dict = None
        if portnum_str == "TELEMETRY_APP" and isinstance(payload, dict):
            # payload per telemetry contiene direttamente device/environment/air_quality/ecc.
            _telemetry_dict = {k: v for k, v in payload.items()
                               if k in ("device", "environment", "air_quality",
                                        "power", "local_stats", "health", "host")
                               and v is not None}
            if not _telemetry_dict:
                _telemetry_dict = None

        # ═════ Position quality dict (solo per POSITION_APP) ═════
        _pos_quality = None
        _pos_sats = None
        _pos_pdop = None
        if portnum_str == "POSITION_APP" and isinstance(payload, dict):
            _pos_quality = {
                k: v for k, v in payload.items()
                if k in ("sats_in_view", "pdop", "hdop", "vdop", "gps_accuracy",
                         "fix_type", "fix_quality", "precision_bits",
                         "location_source", "altitude_source", "altitude_hae",
                         "altitude_geoidal_separation", "ground_speed",
                         "ground_track", "timestamp", "seq_number")
                and v is not None
            } or None
            _pos_sats = payload.get("sats_in_view")
            _pos_pdop = payload.get("pdop")

        # ═════ Radio control dict ═════
        _radio_ctl = {
            k: v for k, v in {
                "next_hop": evt.get("next_hop"),
                "relay_node": evt.get("relay_node"),
                "hops_away": evt.get("hops_away"),
                "via_mqtt": evt.get("via_mqtt"),
                "want_ack": evt.get("want_ack"),
                "priority": evt.get("priority"),
                "priority_num": evt.get("priority_num"),
                "delayed": evt.get("delayed"),
                "tx_after": evt.get("tx_after"),
            }.items() if v is not None
        } or None

        # ═════ Decoded meta wrapper ═════
        _dmeta = evt.get("decoded_meta") or None
        if isinstance(_dmeta, dict) and not _dmeta:
            _dmeta = None

        # ═════ NODEINFO_APP — popola nodes.macaddr/role/is_licensed/public_key/ecc ═════
        _node_user = {}
        if portnum_str == "NODEINFO_APP" and isinstance(payload, dict):
            _node_user = {
                "macaddr": payload.get("macaddr"),
                "role": payload.get("role"),
                "is_licensed": payload.get("is_licensed"),
                "is_stealth": payload.get("is_stealth"),
                "public_key_hex": payload.get("public_key_hex"),
            }

        # ═════ MAP_REPORT_APP — popola firmware_version/region/modem_preset ═════
        _node_map = {}
        if portnum_str == "MAP_REPORT_APP" and isinstance(payload, dict):
            _node_map = {
                "firmware_version": payload.get("firmware_version"),
                "region": payload.get("region"),
                "modem_preset": payload.get("modem_preset"),
                "role": payload.get("role"),
            }

        # ═════ INSERT packets + upsert nodes ═════
        monitor_db.insert_packet({
            # Base
            "ts": ts_ms,
            "from_node": from_int,
            "to_node": to_int,
            "channel_idx": evt.get("channel_idx"),
            # FASE 15: channel_hash 8-bit (0-255) per disambiguazione PSK condivise
            "channel_hash": evt.get("channel_hash"),
            "channel_name": evt.get("channel_name"),
            "network": evt.get("network", "unknown"),
            "portnum": evt.get("portnum_num"),
            "port_name": portnum_str,
            "payload_text": text if isinstance(text, str) else None,
            "payload_len": evt.get("raw_payload_len"),
            "rssi": evt.get("rssi"),
            "snr": evt.get("snr"),
            "hop_start": evt.get("hop_start"),
            "hop_limit": evt.get("hop_limit"),
            "packet_id": evt.get("packet_id") if isinstance(evt.get("packet_id"), int) else None,
            "is_encrypted": evt.get("is_encrypted", False),
            "is_compressed": evt.get("is_compressed", False),
            "fw_type": evt.get("fw_type", "unknown"),
            "fw_flags": evt.get("fw_flags"),
            "source": evt.get("source", "rf"),
            "short_name": evt.get("short_name"),
            "long_name": evt.get("long_name"),
            "hw_model": evt.get("hw_model"),
            "stealth_suspect": (evt.get("fw_type") == "stealth"),
            "encrypted_hex": evt.get("encrypted_hex") if evt.get("is_encrypted") else None,
            "psk_match": evt.get("psk_match_label"),
            # H2 v2 — NUOVE COLONNE PACKETS
            "telemetry": _telemetry_dict,
            "position_quality": _pos_quality,
            "position_lat": _lat, "position_lon": _lon, "position_alt": _alt,
            "position_sats": _pos_sats, "position_pdop": _pos_pdop,
            "latitude": _lat, "longitude": _lon, "altitude": _alt,  # compat pre-H2
            "decoded_meta": _dmeta,
            "request_id": (_dmeta or {}).get("request_id"),
            "reply_id": (_dmeta or {}).get("reply_id"),
            "emoji": (_dmeta or {}).get("emoji"),
            "want_response": (_dmeta or {}).get("want_response"),
            "radio_control": _radio_ctl,
            "next_hop": evt.get("next_hop"),
            "relay_node": evt.get("relay_node"),
            "hops_away": evt.get("hops_away"),
            "via_mqtt": evt.get("via_mqtt"),
            "want_ack": evt.get("want_ack"),
            "priority_num": evt.get("priority_num"),
            "raw_protobuf_b64": evt.get("raw_packet_b64"),
            "public_key_hex": evt.get("public_key_hex") or _node_user.get("public_key_hex"),
            "pki_encrypted": evt.get("pki_encrypted"),
            # H2 v2 — NUOVE COLONNE NODES (upsert via insert_packet)
            "macaddr": _node_user.get("macaddr"),
            "role": _node_user.get("role") or _node_map.get("role") or evt.get("role"),
            "is_licensed": _node_user.get("is_licensed"),
            "is_stealth": _node_user.get("is_stealth"),
            "firmware_version": _node_map.get("firmware_version"),
            "region": _node_map.get("region"),
            "modem_preset": _node_map.get("modem_preset"),
        })

        # ═════════════════════════════════════════════════════════
        # H2 v2 — INSERT nelle 6 nuove tabelle (per portnum specifico)
        # ═════════════════════════════════════════════════════════

        # NEIGHBORINFO_APP → una riga in topology per OGNI vicino
        if portnum_str == "NEIGHBORINFO_APP":
            try:
                neighbors = payload.get("neighbors") or []
                for n in neighbors:
                    if not isinstance(n, dict):
                        continue
                    monitor_db.insert_topology({
                        "ts": ts_ms,
                        "node_id": from_int,
                        "neighbor_id": n.get("node_id"),
                        "snr": n.get("snr_db"),
                        "last_rx_time": n.get("last_rx_time"),
                        "node_broadcast_interval_secs": n.get("node_broadcast_interval_secs"),
                        "source": evt.get("source"),
                    })
            except Exception:
                pass

        # TRACEROUTE_APP → una riga in traceroutes con path forward+back
        elif portnum_str == "TRACEROUTE_APP":
            try:
                monitor_db.insert_traceroute({
                    "ts": ts_ms,
                    "from_node": from_int,
                    "to_node": to_int,
                    "route_forward": payload.get("route"),
                    "route_back": payload.get("route_back"),
                    "snr_forward": payload.get("snr_towards_db"),
                    "snr_back": payload.get("snr_back_db"),
                    "hop_count": payload.get("hops_count"),
                    "is_response": (evt.get("decoded_meta") or {}).get("reply_id") is not None,
                    "packet_id": evt.get("packet_id") if isinstance(evt.get("packet_id"), int) else None,
                    "source": evt.get("source"),
                })
            except Exception:
                pass

        # MAP_REPORT_APP → snapshot metadata broadcast
        elif portnum_str == "MAP_REPORT_APP":
            try:
                lat_i = payload.get("latitude_i")
                lon_i = payload.get("longitude_i")
                # Se _i non esistono, converti da latitude * 1e7
                if lat_i is None and payload.get("latitude") is not None:
                    try:
                        lat_i = int(float(payload.get("latitude")) * 1e7)
                    except Exception:
                        lat_i = None
                if lon_i is None and payload.get("longitude") is not None:
                    try:
                        lon_i = int(float(payload.get("longitude")) * 1e7)
                    except Exception:
                        lon_i = None
                monitor_db.insert_map_report({
                    "ts": ts_ms,
                    "node_id": from_int,
                    "long_name": payload.get("long_name"),
                    "short_name": payload.get("short_name"),
                    "role": payload.get("role"),
                    "hw_model": payload.get("hw_model"),
                    "firmware_version": payload.get("firmware_version"),
                    "region": payload.get("region"),
                    "modem_preset": payload.get("modem_preset"),
                    "has_default_channel": payload.get("has_default_channel"),
                    "latitude_i": lat_i,
                    "longitude_i": lon_i,
                    "altitude": payload.get("altitude"),
                    "position_precision": payload.get("position_precision"),
                    "num_online_local_nodes": payload.get("num_online_local_nodes"),
                    "has_opted_report_location": payload.get("has_opted_report_location"),
                    "source": evt.get("source"),
                })
                # MAP_REPORT è anche un ottimo node_metadata snapshot
                monitor_db.insert_node_metadata({
                    "ts": ts_ms,
                    "node_id": from_int,
                    "firmware_version": payload.get("firmware_version"),
                    "role": payload.get("role"),
                    "hw_model": payload.get("hw_model"),
                    "source": evt.get("source"),
                })
            except Exception:
                pass

        # WAYPOINT_APP → POI condiviso
        elif portnum_str == "WAYPOINT_APP":
            try:
                lat_i = payload.get("latitude_i")
                lon_i = payload.get("longitude_i")
                if lat_i is None and payload.get("latitude") is not None:
                    try:
                        lat_i = int(float(payload.get("latitude")) * 1e7)
                    except Exception:
                        lat_i = None
                if lon_i is None and payload.get("longitude") is not None:
                    try:
                        lon_i = int(float(payload.get("longitude")) * 1e7)
                    except Exception:
                        lon_i = None
                locked_to = payload.get("locked_to")
                monitor_db.insert_waypoint({
                    "ts": ts_ms,
                    "waypoint_id": payload.get("id"),
                    "from_node": from_int,
                    "latitude_i": lat_i,
                    "longitude_i": lon_i,
                    "expire": payload.get("expire"),
                    "locked_to": locked_to,
                    "name": payload.get("name"),
                    "description": payload.get("description"),
                    "icon": payload.get("icon"),
                    "source": evt.get("source"),
                })
            except Exception:
                pass

        # STORE_FORWARD_APP → heartbeat/history/stats
        elif portnum_str in ("STORE_FORWARD_APP", "STORE_FORWARD_PLUSPLUS_APP"):
            try:
                stats = payload.get("stats") if isinstance(payload.get("stats"), dict) else {}
                monitor_db.insert_storeforward_stats({
                    "ts": ts_ms,
                    "node_id": from_int,
                    "rr_type": payload.get("rr"),
                    "messages_total": stats.get("messages_total") or stats.get("messagesTotal"),
                    "messages_saved": stats.get("messages_saved") or stats.get("messagesSaved"),
                    "messages_max": stats.get("messages_max") or stats.get("messagesMax"),
                    "up_time": stats.get("up_time") or stats.get("upTime"),
                    "requests": stats.get("requests"),
                    "requests_history": stats.get("requests_history") or stats.get("requestsHistory"),
                    "heartbeat": stats.get("heartbeat"),
                    "return_max": stats.get("return_max") or stats.get("returnMax"),
                    "return_window": stats.get("return_window") or stats.get("returnWindow"),
                    "history_messages": stats.get("history_messages") or stats.get("historyMessages"),
                    "history_window": stats.get("history_window") or stats.get("historyWindow"),
                    "history_last_request": stats.get("history_last_request") or stats.get("historyLastRequest"),
                    "source": evt.get("source"),
                })
            except Exception:
                pass

        # NODEINFO_APP → snapshot User.proto → node_metadata
        elif portnum_str == "NODEINFO_APP":
            try:
                monitor_db.insert_node_metadata({
                    "ts": ts_ms,
                    "node_id": from_int,
                    "role": payload.get("role"),
                    "hw_model": payload.get("hw_model"),
                    "device_id_hex": payload.get("public_key_hex") and payload.get("public_key_hex")[:32],
                    "source": evt.get("source"),
                })
            except Exception:
                pass
    except Exception:
        pass


def _update_stats(evt):
    """Aggiorna le statistiche aggregate per nodo (thread-safe)."""
    with _LOCK:
        sid = evt.get("sender_id") or "Unknown"
        s = _NODE_STATS[sid]
        s["id"] = sid
        if evt.get("long_name"): s["long_name"] = evt["long_name"]
        if evt.get("short_name"): s["short_name"] = evt["short_name"]
        if evt.get("hw_model"): s["hw_model"] = evt["hw_model"]

        s["last_seen_ts"] = evt.get("ts", _now_ts())
        s["last_seen"] = evt.get("ts_hms", _now_hms())
        if not s["first_seen_ts"]:
            s["first_seen_ts"] = s["last_seen_ts"]
        s["last_channel"] = evt.get("channel", 0)

        # Periodicità
        if s["_prev_packet_ts"]:
            delta = s["last_seen_ts"] - s["_prev_packet_ts"]
            if 0 < delta < 3600:  # ignora outlier
                s["_intervals_sum"] += delta
                s["_intervals_n"] += 1
                s["avg_interval_s"] = s["_intervals_sum"] / s["_intervals_n"]
        s["_prev_packet_ts"] = s["last_seen_ts"]

        # Source
        if evt.get("source") == "mqtt":
            s["mqtt_packets"] += 1
            _STATE["packets_mqtt"] += 1
        else:
            s["rf_packets"] += 1
            _STATE["packets_rf"] += 1
            rssi = evt.get("rssi", 0)
            snr = evt.get("snr", 0)
            s["last_rssi"] = rssi
            s["last_snr"] = snr
            if rssi and rssi > s["best_rssi"]: s["best_rssi"] = rssi
            if snr and snr > s["best_snr"]: s["best_snr"] = snr

        # Hop
        hop_limit = evt.get("hop_limit", 0) or 0
        if hop_limit:
            s["total_hops"] += hop_limit
            s["hop_samples"] += 1

        # Portnum counter
        pn = evt.get("portnum", "UNKNOWN")
        if pn == "TEXT_MESSAGE_APP":
            s["text_msgs"] += 1
            _STATE["packets_text"] += 1
        elif pn == "POSITION_APP":
            pos = evt.get("payload", {})
            s["positions"] += 1
            lat, lon = pos.get("latitude"), pos.get("longitude")
            if lat and lon:
                s["last_coords"] = f"{lat:.5f},{lon:.5f}"
        elif pn == "TELEMETRY_APP":
            s["telemetry"] += 1
        elif pn == "NODEINFO_APP":
            s["nodeinfo"] += 1
            last = s["last_nodeinfo_ts"]
            if last > 0:
                dt = evt["ts"] - last
                if dt < _THRESHOLDS["nodeinfo_min_interval_s"]:
                    s["spam_count"] += 1
                    evt["spam_alert"] = {"type": "nodeinfo_flood", "delta_s": int(dt)}
            s["last_nodeinfo_ts"] = evt["ts"]
        elif pn == "ROUTING_APP":
            s["routing"] += 1
        elif pn == "TRACEROUTE_APP":
            s["traceroute"] += 1
        elif pn == "NEIGHBORINFO_APP":
            s["neighborinfo"] += 1
        elif pn == "WAYPOINT_APP":
            s["waypoint"] += 1
        else:
            s["other"] += 1

        # Encrypted
        if evt.get("encrypted_hex"):
            s["encrypted"] += 1
            _STATE["packets_encrypted"] += 1

        _STATE["packets_total"] += 1


# ═══════════════════════════════════════════════════════════
# CALLBACK pubsub — chiamato dal thread meshtastic quando arriva un pkt
# ═══════════════════════════════════════════════════════════

def _try_psk_decrypt(evt):
    """Tenta decifratura AES-CTR usando le PSK registrate in DB.

    Se la decifratura ha successo e il protobuf Data è valido:
      - evt['psk_match_id'], evt['psk_match_label'] → PSK matchata
      - evt['portnum_num'] → portnum decodificato
      - evt['portnum'] → nome portnum
      - evt['payload']['text'] → testo se TEXT_MESSAGE_APP
      - evt['payload']['decrypted_hex'] → hex completo payload
      - evt['is_encrypted'] → False (ora è leggibile)
    """
    # STEP 13 — Diagnostica SEMPRE popolata (visibility per UI).
    # Prima: se psks vuota o DB/crypto KO, uscivamo silenziosamente senza
    # decrypt_attempts -> la UI mostrava "Crypto Agent" vuoto senza capire
    # perche'. Ora popoliamo SEMPRE evt['decrypt_attempts']=0 +
    # evt['decrypt_skipped_reason'] con motivo preciso.
    if not _MCRYPT_OK:
        evt["decrypt_attempts"] = 0
        evt["decrypt_skipped_reason"] = "crypto_module_unavailable"
        return evt
    if not _DB_OK:
        evt["decrypt_attempts"] = 0
        evt["decrypt_skipped_reason"] = "db_unavailable"
        return evt
    enc_hex = evt.get("encrypted_hex")
    if not enc_hex:
        return evt
    # STEP 12 — Ghost Node Mode: esegui brute-force anche quando il nodo USB
    # pretende di aver "decodificato" il pacchetto ma il risultato e' spazzatura
    # (portnum=UNKNOWN_APP/0 + nessun testo). Questo copre il caso in cui
    # _analyze_packet non ha riflaggato is_encrypted (difesa in profondita').
    if not evt.get("is_encrypted"):
        _pn_evt = evt.get("portnum_num")
        _pn_unknown = (_pn_evt is None) or (int(_pn_evt) == 0)
        _pl_evt = evt.get("payload") or {}
        _has_text = isinstance(_pl_evt, dict) and bool(_pl_evt.get("text"))
        if not (_pn_unknown and not _has_text):
            # Decoded sembra autentico -> niente retry
            return evt
        # Ghost-node retry: proseguiamo con brute-force
    try:
        psks = monitor_db.psk_list(enabled_only=True) or []
    except Exception:
        psks = []
    if not psks:
        # STEP 13 — visibility: popoliamo i campi diagnostici invece di uscire
        # silenziosamente, cosi' la UI capisce che il catalog e' vuoto.
        evt["decrypt_attempts"] = 0
        evt["decrypt_skipped_reason"] = "no_psk_in_db"
        return evt
    # Calcola from_node come intero (il sender può essere "!xxxxxxxx" o numero)
    try:
        sid = evt.get("sender_id") or ""
        if isinstance(sid, str) and sid.startswith("!"):
            from_int = int(sid[1:], 16)
        else:
            from_int = int(sid) if sid else 0
    except Exception:
        from_int = 0
    packet_id = int(evt.get("packet_id") or 0)
    # STEP 8 — brute-force con feedback per-pacchetto (a prescindere dal canale)
    try:
        # FASE 14 (2026-05-05): passa packet_channel_hash per disambiguare PSK condivise
        _diag = _mcrypt.try_all_psk_detailed(
            enc_hex, packet_id, from_int, psks,
            packet_channel_hash=evt.get("channel_hash") or evt.get("channel_idx"),
        )
    except Exception:
        _diag = {"matched": None, "tried": 0, "reasons": {}, "tried_labels": []}
    # Popola SEMPRE i campi diagnostici (anche quando il match fallisce).
    # tried + reasons + tried_labels (cap 100 per non saturare SSE, sufficiente
    # per il catalogo Italia completo da 36 entries + PSK nodo + dizionario Hunter).
    evt["decrypt_attempts"] = int(_diag.get("tried") or 0)
    _reasons = _diag.get("reasons") or {}
    if _reasons:
        evt["decrypt_reasons"] = _reasons
    _tl = _diag.get("tried_labels") or []
    if _tl:
        evt["decrypt_tried_labels"] = _tl[:100]
    match = _diag.get("matched")
    if not match:
        # PSK non ha matchato; _on_receive bufferizza dopo PKI (H4.3-T3).
        # Diagnostica già popolata sopra (decrypt_attempts/decrypt_reasons).
        return evt
    # Match trovato — popola metadati
    evt["is_encrypted"] = False
    evt["psk_match_id"] = match.get("psk_id")
    evt["psk_match_label"] = match.get("label")
    evt["psk_match_kind"] = match.get("kind", "public")

    # FASE 9+17 (2026-05-05) — Override channel_name dopo decrypt PSK riuscito
    # FASE 17: prima di sovrascrivere channel_name, verifichiamo che il hash8 della
    # PSK matchata corrisponda all'hash8 del pacchetto. Se mismatch, significa che
    # il sender ha cifrato con la stessa AES key ma un nome canale diverso —
    # NON dobbiamo etichettare come "LongFast" un canale custom 0x35.
    _PRESET_NAMES_PSK = {
        "LongFast", "MediumFast", "ShortFast", "ShortTurbo",
        "ShortSlow", "MediumSlow", "LongModerate", "LongSlow", "VeryLongSlow",
    }
    _psk_cn = match.get("channel_name")
    _cur_cn = evt.get("channel_name")
    _pkt_hash = evt.get("channel_hash")
    if _pkt_hash is None:
        _pkt_hash = evt.get("channel_idx")

    # FASE 17: verifica hash8 match
    _hash_match = True  # default: assume corrisponda (backward-compat)
    if _pkt_hash is not None and _psk_cn:
        try:
            _matched_b64 = match.get("psk_b64") or ""
            if _matched_b64:
                _matched_norm = _mcrypt.normalize_psk(_matched_b64)
                if _matched_norm:
                    _calc_h8 = _mcrypt.compute_channel_hash(_psk_cn, _matched_norm)
                    if (int(_calc_h8) & 0xFF) != (int(_pkt_hash) & 0xFF):
                        _hash_match = False  # nome PSK non corrisponde a quello del sender
        except Exception:
            pass

    if _psk_cn and _hash_match and (not _cur_cn or _cur_cn in _PRESET_NAMES_PSK):
        evt["channel_name"] = _psk_cn
    elif not _hash_match and not _cur_cn:
        # FASE 17: nome PSK non affidabile → mantieni null (display mostrera' Ch{hash})
        evt["channel_name"] = None
        evt["channel_name_unverified"] = _psk_cn  # diagnostico
    pn = match.get("portnum")
    if pn is not None:
        try:
            evt["portnum_num"] = int(pn)
            evt["portnum"] = PORTNUM_MAP.get(int(pn), f"PORT_{int(pn)}")
        except Exception:
            pass
    # Popola payload decifrato
    payload_bytes = match.get("payload_bytes") or b""
    payload = evt.get("payload") or {}
    try:
        payload["decrypted_hex"] = payload_bytes.hex() if payload_bytes else ""
        payload["decrypted_len"] = len(payload_bytes)
        # Se è TEXT_MESSAGE_APP prova decoding UTF-8
        if evt.get("portnum_num") == 1 and payload_bytes:
            try:
                payload["text"] = payload_bytes.decode("utf-8", errors="replace")
            except Exception:
                pass
        # Se è TEXT_MESSAGE_COMPRESSED_APP prova Unishox
        elif evt.get("portnum_num") == 7 and payload_bytes and _UNISHOX_OK:
            try:
                payload["text"] = _unishox2.decompress(payload_bytes, len(payload_bytes) * 8)[0]
            except Exception:
                try:
                    payload["text"] = payload_bytes.decode("utf-8", errors="replace")
                except Exception:
                    pass
    except Exception:
        pass
    evt["payload"] = payload
    # Incrementa match counter (silent-fail)
    try:
        monitor_db.psk_bump_match(match.get("psk_id"))
    except Exception:
        pass
    return evt


def _try_pki_decrypt(evt):
    """H4.3-T3 — Tenta decifratura X25519+AES-CCM con chiavi PKI registrate.

    Viene chiamato dopo _try_psk_decrypt. Se il pacchetto è ancora cifrato e
    abbiamo chiavi PKI device-own abilitate, tentiamo la decifratura contro
    l'elenco dei peer conosciuti (prima con their_pub_hex specifico se noto,
    poi brute-force su nodes.public_key se disponibile via iface.nodes).

    Se la decifratura ha successo:
      - evt['pki_match_id'], evt['pki_match_label'] → entry matchata
      - evt['pki_match_peer']  → hex pub peer che ha decifrato
      - evt['portnum_num'], evt['portnum'], evt['payload']['text'] come PSK
      - evt['is_encrypted'] → False
      - pki_keys.match_count++ via pki_bump_match(id)

    Security: priv_hex non viene mai loggato / emesso in evento.
    """
    if not _MCRYPT_OK or not _DB_OK:
        return evt
    if not evt.get("is_encrypted"):
        return evt
    _enc_hex = evt.get("encrypted_hex")
    if not _enc_hex:
        return evt
    # Carica chiavi PKI abilitate
    try:
        _pkis = monitor_db.pki_list(enabled_only=True) or []
    except Exception:
        _pkis = []
    if not _pkis:
        return evt
    # Calcola from_node come intero
    try:
        _sid = evt.get("sender_id") or ""
        if isinstance(_sid, str) and _sid.startswith("!"):
            _from_int = int(_sid[1:], 16)
        else:
            _from_int = int(_sid) if _sid else 0
    except Exception:
        _from_int = 0
    _packet_id = int(evt.get("packet_id") or 0)

    # Ottieni pub-key del sender dai nodes dell'interface (se disponibili)
    _sender_pub_hex = None
    try:
        with _LOCK:
            _iface = _STATE.get("interface")
        if _iface is not None and hasattr(_iface, "nodes"):
            _sid_norm = evt.get("sender_id") or ""
            _node_entry = _iface.nodes.get(_sid_norm) if isinstance(_iface.nodes, dict) else None
            if _node_entry is None and _from_int:
                _node_entry = _iface.nodes.get(f"!{_from_int:08x}") if isinstance(_iface.nodes, dict) else None
            if _node_entry and isinstance(_node_entry, dict):
                _user = _node_entry.get("user") or {}
                _pk = _user.get("publicKey") or _user.get("public_key")
                if _pk:
                    try:
                        # publicKey può essere base64 o hex; tenta entrambi
                        import base64 as _b64
                        _raw = _b64.b64decode(_pk) if isinstance(_pk, str) and not all(c in "0123456789abcdefABCDEF" for c in _pk) else None
                        if _raw and len(_raw) == 32:
                            _sender_pub_hex = _raw.hex()
                        elif isinstance(_pk, str) and len(_pk) == 64:
                            _sender_pub_hex = _pk.lower()
                    except Exception:
                        pass
    except Exception:
        pass

    # Costruisce lista di tentativi: (pki_id, label, priv_hex, peer_hex)
    # Ordine: prima match esatto priv+peer (se nodes.public_key noto), poi brute
    _tries = []
    for _k in _pkis:
        _priv = _k.get("my_priv_hex")
        if not _priv:
            continue
        _label = _k.get("label") or f"pki#{_k.get('id')}"
        # Match esatto se abbiamo il pub del sender
        if _sender_pub_hex:
            _tries.append((_k.get("id"), _label, _priv, _sender_pub_hex))
        # Peer salvato nell'entry (peer-specific keypair)
        _peer_saved = _k.get("their_pub_hex")
        if _peer_saved and _peer_saved != _sender_pub_hex:
            _tries.append((_k.get("id"), _label, _priv, _peer_saved))

    if not _tries:
        return evt

    _decrypted = None
    _matched_id = None
    _matched_label = None
    _matched_peer = None
    for _pid, _lab, _priv, _peer in _tries:
        try:
            _out = _mcrypt.decrypt_pki(_enc_hex, _packet_id, _from_int, _priv, _peer)
        except Exception:
            _out = None
        if not _out:
            continue
        # Valida: i byte decifrati devono essere un Data protobuf valido
        try:
            _ok, _pn, _pb = _mcrypt.validate_decrypted(_out)
        except Exception:
            _ok, _pn, _pb = False, None, None
        if not _ok:
            continue
        _decrypted = {"portnum": _pn, "payload_bytes": _pb or b""}
        _matched_id = _pid
        _matched_label = _lab
        _matched_peer = _peer
        break

    if not _decrypted:
        return evt

    # Popola metadati decifrati (stesso pattern di _try_psk_decrypt)
    evt["is_encrypted"] = False
    evt["pki_match_id"] = _matched_id
    evt["pki_match_label"] = _matched_label
    evt["pki_match_peer"] = _matched_peer
    _pn = _decrypted.get("portnum")
    if _pn is not None:
        try:
            evt["portnum_num"] = int(_pn)
            evt["portnum"] = PORTNUM_MAP.get(int(_pn), f"PORT_{int(_pn)}")
        except Exception:
            pass
    _pb = _decrypted.get("payload_bytes") or b""
    _payload = evt.get("payload") or {}
    try:
        _payload["decrypted_hex"] = _pb.hex() if _pb else ""
        _payload["decrypted_len"] = len(_pb)
        if evt.get("portnum_num") == 1 and _pb:
            try:
                _payload["text"] = _pb.decode("utf-8", errors="replace")
            except Exception:
                pass
        elif evt.get("portnum_num") == 7 and _pb and _UNISHOX_OK:
            try:
                _payload["text"] = _unishox2.decompress(_pb, len(_pb) * 8)[0]
            except Exception:
                try:
                    _payload["text"] = _pb.decode("utf-8", errors="replace")
                except Exception:
                    pass
    except Exception:
        pass
    evt["payload"] = _payload
    # Incrementa match counter (silent-fail)
    try:
        monitor_db.pki_bump_match(_matched_id)
    except Exception:
        pass
    return evt


def _on_receive(packet=None, interface=None, **kwargs):
    try:
        if packet is None or interface is None:
            return
        evt = _analyze_packet(packet, interface)
        # Tentativo PSK decrypt prima di pushare
        evt = _try_psk_decrypt(evt)
        # Tentativo PKI decrypt se PSK non ha matchato (H4.3-T3)
        if evt.get("is_encrypted"):
            evt = _try_pki_decrypt(evt)
        # Se entrambi hanno fallito → bufferizza per rematch futuro (STEP B + PKI)
        if evt.get("is_encrypted") and evt.get("encrypted_hex"):
            try:
                _enc_hex_b = evt.get("encrypted_hex")
                _sid_b = evt.get("sender_id") or ""
                try:
                    if isinstance(_sid_b, str) and _sid_b.startswith("!"):
                        _from_int_b = int(_sid_b[1:], 16)
                    else:
                        _from_int_b = int(_sid_b) if _sid_b else 0
                except Exception:
                    _from_int_b = 0
                _PKT_ENC_BUFFER.append({
                    "packet_id": int(evt.get("packet_id") or 0),
                    "from_int": _from_int_b,
                    "encrypted_hex": _enc_hex_b,
                    "ts": evt.get("ts"),
                    "channel": evt.get("channel"),
                    "channel_name": evt.get("channel_name"),
                    "sender_id": _sid_b,
                })
            except Exception:
                pass
        # H2 v2 — Recovery 100%: serializza packet dict completo per futura re-parsing
        try:
            import base64 as _b64, json as _json
            # Rimuovi riferimenti non JSON-serializable (bytes → hex già fatto da _analyze)
            _raw_json = _json.dumps(packet, separators=(",", ":"), default=str)
            # Cap 8KB per packet (evita abuse su packet giganti MQTT)
            if len(_raw_json) <= 8192:
                evt["raw_packet_b64"] = _b64.b64encode(_raw_json.encode("utf-8")).decode("ascii")
        except Exception:
            pass
        _update_stats(evt)
        evt["type"] = "packet"
        _push_event(evt)
        # Persistenza DB 7gg (silent-fail)
        _persist_event(evt)
    except Exception as e:
        _push_event({
            "type": "error",
            "ts": _now_ts(),
            "ts_hms": _now_hms(),
            "error": f"on_receive: {e}",
        })


def _on_connection(interface=None, topic=None, **kwargs):
    """Callback pubsub per connection.established / lost."""
    try:
        ev = str(topic.getName() if topic else "unknown")
    except Exception:
        ev = "unknown"
    try:
        if interface is not None and hasattr(interface, "myInfo") and interface.myInfo:
            with _LOCK:
                _STATE["my_node_num"] = getattr(interface.myInfo, "my_node_num", None)
            # Tentiamo di recuperare il nome
            try:
                my_key = "!" + f"{_STATE['my_node_num']:08x}"
                node = interface.nodes.get(my_key) if hasattr(interface, "nodes") else None
                if node:
                    with _LOCK:
                        _STATE["my_node_name"] = node.get("user", {}).get("longName", "Local")
            except Exception:
                pass
    except Exception:
        pass
    _broadcast_status({"event": ev})


# ═══════════════════════════════════════════════════════════
# SUPERVISOR THREAD — mantiene la connessione seriale viva
# ═══════════════════════════════════════════════════════════

def _supervisor(port):
    """Thread: apre SerialInterface, sottoscrive pubsub, tiene in vita."""
    try:
        import meshtastic.serial_interface as _serial
        from pubsub import pub
    except ImportError as e:
        with _LOCK:
            _STATE["active"] = False
            _STATE["last_error"] = f"Libreria mancante: {e}"
        _broadcast_status()
        return

    try:
        iface = _serial.SerialInterface(devPath=port)
    except Exception as e:
        with _LOCK:
            _STATE["active"] = False
            _STATE["last_error"] = f"Connessione fallita: {e}"
        _broadcast_status()
        return

    with _LOCK:
        _STATE["interface"] = iface
        _STATE["active"] = True
        _STATE["port"] = port
        _STATE["started_at"] = _now_ts()
        _STATE["last_error"] = None

    try:
        pub.subscribe(_on_receive, "meshtastic.receive")
        pub.subscribe(_on_connection, "meshtastic.connection.established")
        pub.subscribe(_on_connection, "meshtastic.connection.lost")
    except Exception as e:
        with _LOCK:
            _STATE["last_error"] = f"Subscribe fallito: {e}"

    _broadcast_status({"event": "connected"})

    # Loop: rimane in vita finché _STATE["active"] è True
    while True:
        with _LOCK:
            active = _STATE["active"]
        if not active:
            break
        time.sleep(0.5)

    # Cleanup
    try:
        pub.unsubscribe(_on_receive, "meshtastic.receive")
        pub.unsubscribe(_on_connection, "meshtastic.connection.established")
        pub.unsubscribe(_on_connection, "meshtastic.connection.lost")
    except Exception:
        pass

    try:
        iface.close()
    except Exception:
        pass

    with _LOCK:
        _STATE["interface"] = None
        _STATE["port"] = None
        _STATE["started_at"] = None
    _broadcast_status({"event": "disconnected"})


# ═══════════════════════════════════════════════════════════
# API PUBBLICHE (chiamate da server.py)
# ═══════════════════════════════════════════════════════════

def is_active():
    """True se il monitor sta girando (USB occupato)."""
    with _LOCK:
        return bool(_STATE["active"])


# ═══════════════════════════════════════════════════════════
# STEP A — Lettura canali e PSK dal nodo USB
# Usa l'interfaccia già attiva del Monitor (niente race sul device).
# ═══════════════════════════════════════════════════════════

def _role_num_to_str(role_val):
    """Converte l'enum Channel.Role in stringa leggibile."""
    try:
        iv = int(role_val)
    except Exception:
        iv = None
    mapping = {0: "DISABLED", 1: "PRIMARY", 2: "SECONDARY"}
    if iv is not None and iv in mapping:
        return mapping[iv]
    # Alcune versioni espongono direttamente stringa
    s = str(role_val or "").upper()
    for k in mapping.values():
        if k in s:
            return k
    return "UNKNOWN"


# ──────────────────────────────────────────────────────────────────────
# FASE 2 (2026-05-05) — Cache hash8 -> channel_name dalle PSK abilitate
# ──────────────────────────────────────────────────────────────────────
# Quando un pacchetto arriva via radio LoRa con channel_idx (hash8) ma il nodo
# USB non ha quello slot configurato, il channel_name resta NULL. Costruiamo
# una cache lazy {hash8: channel_name} dalle PSK abilitate del catalogo Italia.
# La cache viene invalidata se il numero di PSK enabled cambia.
_PSK_HASH8_CACHE = {}     # {hash8: channel_name}
_PSK_HASH8_CACHE_LEN = -1  # numero PSK quando fu popolata; -1 = mai
_PSK_HASH8_CACHE_TS = 0    # ultimo refresh ms (per TTL)


def _psk_hash8_lookup(hash8):
    """Restituisce il channel_name associato a un hash8 cercando tra le PSK
    abilitate. Costruisce/aggiorna una cache in-memory.

    Cache TTL: 60s O quando il numero di PSK abilitate cambia.
    Collisioni hash8: vince la prima PSK enabled in ordine di id (deterministico).
    Ritorna None se nessuna PSK matcha.
    """
    global _PSK_HASH8_CACHE, _PSK_HASH8_CACHE_LEN, _PSK_HASH8_CACHE_TS
    try:
        import time as _time
        now_ms = int(_time.time() * 1000)
        # TTL 60s o cambio dimensione lista
        psks = monitor_db.psk_list(enabled_only=True) or []
        if (len(psks) != _PSK_HASH8_CACHE_LEN or
                now_ms - _PSK_HASH8_CACHE_TS > 60_000):
            _new = {}
            import base64 as _b64
            for _psk in psks:
                _name = _psk.get("channel_name")
                _b64s = _psk.get("psk_b64") or ""
                if not _name or not _b64s:
                    continue
                # Decodifica PSK
                try:
                    _bytes = _b64.b64decode(_b64s, validate=False)
                except Exception:
                    continue
                # Espansione default-byte (1..10) - allineata a meshtastic_crypto.normalize_psk
                if len(_bytes) == 1:
                    _n = _bytes[0]
                    if _n == 0:
                        continue
                    if _n == 1:
                        _bytes = bytes([0xd4, 0xf1, 0xbb, 0x3a, 0x20, 0x29, 0x07, 0x59,
                                       0xf0, 0xbc, 0xff, 0xab, 0xcf, 0x4e, 0x69, 0x01])
                    else:
                        _default = bytearray([0xd4, 0xf1, 0xbb, 0x3a, 0x20, 0x29, 0x07, 0x59,
                                             0xf0, 0xbc, 0xff, 0xab, 0xcf, 0x4e, 0x69, 0x01])
                        _default[-1] = (_default[-1] + (_n - 1)) & 0xFF
                        _bytes = bytes(_default)
                _h8 = compute_channel_hash(_name, _bytes)
                # Prima PSK con quel hash vince (ordine id ASC = deterministico)
                if _h8 not in _new:
                    _new[_h8] = _name
            _PSK_HASH8_CACHE = _new
            _PSK_HASH8_CACHE_LEN = len(psks)
            _PSK_HASH8_CACHE_TS = now_ms
        return _PSK_HASH8_CACHE.get(int(hash8) & 0xFF)
    except Exception:
        return None


def compute_channel_hash(name, psk_bytes):
    """Calcola hash8 canale Meshtastic: XOR(name_utf8) XOR XOR(psk_bytes).

    - name: str (utf-8) — nome canale (es. "LongFast", "MyChan")
    - psk_bytes: bytes — PSK decodificata (es. b"\x01" = default, o 16/32 bytes random)
    Ritorna int 0-255. Compatibile con la convenzione firmware Meshtastic.
    """
    _h = 0
    try:
        for _c in (name or "").encode("utf-8"):
            _h ^= _c
    except Exception:
        pass
    try:
        for _b in (psk_bytes or b""):
            _h ^= (_b & 0xFF)
    except Exception:
        pass
    return _h & 0xFF


def read_local_channels():
    """Legge i canali del nodo USB collegato via l'interfaccia attiva del Monitor.

    Ritorna {"ok": True, "channels": [...]} oppure {"ok": False, "error": "..."}.
    Ogni canale: {index, role, name, psk_b64, psk_len, default_psk}.
    """
    with _LOCK:
        iface = _STATE.get("interface")
        active = _STATE.get("active")
    if not active or iface is None:
        return {"ok": False, "error": "monitor_not_active"}
    try:
        localNode = getattr(iface, "localNode", None)
        if not localNode:
            return {"ok": False, "error": "no_local_node"}
        # Forza refresh config se disponibile (best-effort)
        try:
            if hasattr(localNode, "waitForConfig"):
                localNode.waitForConfig()
        except Exception:
            pass
        chs = getattr(localNode, "channels", None)
        if not chs:
            return {"ok": False, "error": "no_channels"}
        out = []
        for ch in chs:
            try:
                idx = int(getattr(ch, "index", -1))
            except Exception:
                idx = -1
            role_raw = getattr(ch, "role", None)
            role_str = _role_num_to_str(role_raw)
            settings = getattr(ch, "settings", None)
            if settings is None and isinstance(ch, dict):
                settings = ch.get("settings")
            name = ""
            psk_bytes = b""
            if settings is not None:
                try:
                    name = getattr(settings, "name", "") or ""
                    if not name and isinstance(settings, dict):
                        name = settings.get("name", "") or ""
                except Exception:
                    name = ""
                try:
                    psk_bytes = getattr(settings, "psk", b"") or b""
                    if not psk_bytes and isinstance(settings, dict):
                        psk_bytes = settings.get("psk", b"") or b""
                except Exception:
                    psk_bytes = b""
            # PSK in formato base64 (una sola-byte 0x01 → "AQ==" = default)
            try:
                psk_b64 = base64.b64encode(bytes(psk_bytes)).decode("ascii") if psk_bytes else ""
            except Exception:
                psk_b64 = ""
            default_psk = (psk_b64 == "AQ==")
            # hash8 = XOR(name_utf8) XOR XOR(psk_bytes) — standard Meshtastic firmware
            _nm = str(name) if name else ("PrimaryDefault" if (role_str == "PRIMARY" and default_psk) else f"ch{idx}")  # FASE 10: no preset name come fallback
            _hash8 = compute_channel_hash(_nm, psk_bytes or b"")
            # short_name derivato dal nome (max 4 char uppercase). Solo per display.
            _short = (_nm[:4].upper() if _nm else "")
            out.append({
                "index": idx,
                "role": role_str,
                "name": _nm,
                "short_name": _short,
                "psk_b64": psk_b64,
                "psk_len": len(psk_bytes) if psk_bytes else 0,
                "default_psk": default_psk,
                "hash8": _hash8,
            })
        return {"ok": True, "channels": out}
    except Exception as e:
        return {"ok": False, "error": f"read_fail: {e}"}


def sync_psks_from_node():
    """Legge canali dal nodo USB e upserta PSK nel DB.

    - DISABLED → skip
    - PRIMARY con PSK default (AQ==) → kind="public"
    - Tutte le altre PSK → kind="private" (chiave custom, protetta)
    - PSK vuota/mancante → skip
    - Label: sempre "Nodo: {name}" per distinguere dall'origine (catalogo vs nodo)

    Ritorna {"ok": True, "added": N, "updated": N, "unchanged": N, "skipped": N, "details": [...]}.
    """
    if not _DB_OK or monitor_db is None:
        return {"ok": False, "error": "db_not_available"}
    res = read_local_channels()
    if not res.get("ok"):
        return {"ok": False, "error": res.get("error", "read_failed")}
    added = updated = unchanged = skipped = 0
    details = []
    # Channel-map upsert (hash8 → name/short/idx) — sempre, anche se la PSK è vuota
    try:
        _map_slots = [
            {
                "hash8": int(_c.get("hash8", 0) or 0),
                "idx": int(_c.get("index", -1) or -1),
                "name": str(_c.get("name") or ""),
                "short_name": str(_c.get("short_name") or ""),
                "role": str(_c.get("role") or "UNKNOWN"),
                "psk_b64": str(_c.get("psk_b64") or ""),
                "default_psk": bool(_c.get("default_psk") or False),
            }
            for _c in res.get("channels", [])
            if _c.get("role") != "DISABLED"
        ]
        if hasattr(monitor_db, "channel_map_upsert"):
            monitor_db.channel_map_upsert(_map_slots)
    except Exception:
        pass  # non bloccare sync PSK se fallisce channel_map
    for ch in res.get("channels", []):
        role = ch.get("role", "UNKNOWN")
        name = (ch.get("name") or "").strip()
        psk_b64 = ch.get("psk_b64", "")
        if role == "DISABLED":
            skipped += 1
            details.append({"index": ch["index"], "action": "skip", "reason": "disabled"})
            continue
        if not psk_b64:
            skipped += 1
            details.append({"index": ch["index"], "action": "skip", "reason": "empty_psk"})
            continue
        # Label canale: preferisci il nome, altrimenti fallback per ruolo
        if not name:
            name = "PrimaryDefault" if role == "PRIMARY" and psk_b64 == "AQ==" else f"ch{ch['index']}"  # FASE 10: no preset name
        label = f"Nodo: {name}"
        kind = "public" if (psk_b64 == "AQ==" and role == "PRIMARY") else "private"
        notes = f"Importato dal nodo USB (role={role}, ch{ch['index']})"
        try:
            r = monitor_db.psk_add_or_update(
                label=label,
                psk_b64=psk_b64,
                kind=kind,
                channel_name=name,
                notes=notes,
            )
        except Exception as e:
            r = {"error": str(e)}
        if "added" in r:
            added += 1
            details.append({"index": ch["index"], "name": name, "action": "added", "kind": kind})
        elif "updated" in r:
            updated += 1
            details.append({"index": ch["index"], "name": name, "action": "updated", "kind": kind})
        elif "unchanged" in r:
            unchanged += 1
            details.append({"index": ch["index"], "name": name, "action": "unchanged", "kind": kind})
        else:
            skipped += 1
            details.append({"index": ch["index"], "name": name, "action": "error", "reason": r.get("error", "unknown")})
    return {
        "ok": True,
        "added": added,
        "updated": updated,
        "unchanged": unchanged,
        "skipped": skipped,
        "total": len(res.get("channels", [])),
        "details": details,
    }


def import_private_key_from_node():
    """H4.3-T2 — Legge la chiave privata X25519 dal nodo USB e la salva in pki_keys.

    Accede a iface.localNode.localConfig.security.private_key (32 bytes).
    Deriva automaticamente la public key associata.
    Salva in pki_keys con source='node_usb', is_device_own=1.

    Ritorna {
        "ok": True,
        "action": "added" | "unchanged",
        "id": <pki_id>,
        "my_priv_hex": <hex>,
        "my_pub_hex": <hex>,
        "label": <str>
    } oppure {"ok": False, "error": ...}.

    Sicurezza: la chiave privata non viene mai loggata in chiaro nei messaggi utente.
    """
    if not _DB_OK or monitor_db is None:
        return {"ok": False, "error": "db_not_available"}
    with _LOCK:
        _iface = _STATE.get("interface")
        _active = _STATE.get("active")
    if not _active or _iface is None:
        return {"ok": False, "error": "monitor_not_active"}
    try:
        _local_node = getattr(_iface, "localNode", None)
        if not _local_node:
            return {"ok": False, "error": "no_local_node"}
        # Best-effort refresh config
        try:
            if hasattr(_local_node, "waitForConfig"):
                _local_node.waitForConfig()
        except Exception:
            pass

        # localConfig può essere un messaggio protobuf (LocalConfig) o dict-like
        _local_cfg = getattr(_local_node, "localConfig", None)
        if _local_cfg is None:
            return {"ok": False, "error": "no_local_config"}

        # SecurityConfig (field 'security' nel LocalConfig)
        _sec = getattr(_local_cfg, "security", None)
        if _sec is None and isinstance(_local_cfg, dict):
            _sec = _local_cfg.get("security")
        if _sec is None:
            return {"ok": False, "error": "no_security_config"}

        # private_key: campo 2 di SecurityConfig (bytes 32B)
        _priv_bytes = getattr(_sec, "private_key", None)
        if _priv_bytes is None and isinstance(_sec, dict):
            _priv_bytes = _sec.get("private_key") or _sec.get("privateKey")
        if not _priv_bytes:
            return {"ok": False, "error": "no_private_key_on_node"}

        try:
            _priv_bytes = bytes(_priv_bytes)
        except Exception:
            return {"ok": False, "error": "priv_not_bytes"}

        if len(_priv_bytes) != 32:
            return {"ok": False, "error": "bad_priv_length",
                    "got": len(_priv_bytes), "expected": 32}

        _priv_hex = _priv_bytes.hex()

        # public_key associata (field 3) — opzionale, se non c'è la deriviamo
        _pub_bytes = getattr(_sec, "public_key", None)
        if _pub_bytes is None and isinstance(_sec, dict):
            _pub_bytes = _sec.get("public_key") or _sec.get("publicKey")
        _pub_hex = None
        if _pub_bytes:
            try:
                _pub_bytes = bytes(_pub_bytes)
                if len(_pub_bytes) == 32:
                    _pub_hex = _pub_bytes.hex()
            except Exception:
                _pub_hex = None

        # Etichetta: nome nodo proprio se disponibile
        _owner_name = None
        try:
            _my_info = getattr(_iface, "myInfo", None)
            if _my_info is not None:
                _my_num = getattr(_my_info, "my_node_num", None) or getattr(_my_info, "myNodeNum", None)
                _nodes_map = getattr(_iface, "nodes", None) or {}
                if _my_num and _nodes_map:
                    for _k, _v in _nodes_map.items():
                        _user = _v.get("user") if isinstance(_v, dict) else None
                        if _user and _v.get("num") == _my_num:
                            _owner_name = _user.get("longName") or _user.get("shortName")
                            break
        except Exception:
            _owner_name = None
        _label = f"Nodo USB ({_owner_name})" if _owner_name else "Nodo USB (device-own)"

        # Controlla se esiste già (UNIQUE priv,peer=NULL)
        _existing = monitor_db.pki_find_by_priv(_priv_hex, their_pub_hex=None)
        if _existing is not None:
            # Assicura flag device_own=1, enabled=1 e label aggiornata
            monitor_db.pki_update(_existing, label=_label, is_device_own=1, enabled=1)
            _row = monitor_db.pki_get(_existing)
            return {
                "ok": True,
                "action": "unchanged",
                "id": _existing,
                "my_priv_hex_preview": _priv_hex[:8] + "..." + _priv_hex[-4:],
                "my_pub_hex": (_row or {}).get("my_pub_hex") or _pub_hex,
                "label": _label,
            }

        # Aggiungi nuova entry
        _res = monitor_db.pki_add(
            label=_label,
            my_priv_hex=_priv_hex,
            my_pub_hex=_pub_hex,  # se None, pki_add lo deriva via cryptography
            their_pub_hex=None,
            source="node_usb",
            is_device_own=1,
            notes="Importato da USB (SecurityConfig.private_key)",
        )
        if _res.get("error"):
            return {"ok": False, "error": _res["error"], "detail": _res.get("detail") or _res.get("message")}
        return {
            "ok": True,
            "action": "added",
            "id": _res["id"],
            "my_priv_hex_preview": _priv_hex[:8] + "..." + _priv_hex[-4:],
            "my_pub_hex": _res.get("my_pub_hex") or _pub_hex,
            "label": _label,
        }
    except Exception as e:
        return {"ok": False, "error": "import_fail", "message": str(e)[:200]}


def discover_pki_pairings():
    """H4.3-T4 — Key Discovery agent.

    Scansiona iface.nodes e crea coppie (my_priv × their_pub) per ogni peer
    che espone user.publicKey. Usa solo le priv con is_device_own=1 come base.

    Ritorna {
        "ok": True,
        "device_own_priv_count": N,
        "nodes_scanned": M,
        "nodes_with_pub": K,
        "pairings_added": X,
        "pairings_existing": Y,
        "pairings_errors": Z,
        "details": [{node_id, their_pub_hex, action, pki_id}, ...]
    }
    oppure {"ok": False, "error": ...}

    Sicurezza: priv_hex mai logato; source='discovered' distingue le entry
    generate automaticamente; label include nome peer per leggibilità.
    """
    if not _DB_OK or monitor_db is None:
        return {"ok": False, "error": "db_not_available"}
    with _LOCK:
        _iface = _STATE.get("interface")
        _active = _STATE.get("active")
    if not _active or _iface is None:
        return {"ok": False, "error": "monitor_not_active"}

    # Priv device-own abilitate
    try:
        _priv_rows = monitor_db.pki_list(enabled_only=True, device_own_only=True) or []
    except Exception:
        _priv_rows = []
    if not _priv_rows:
        return {"ok": False, "error": "no_device_own_priv",
                "message": "Nessuna priv device-own: importa prima una chiave da USB."}

    _nodes = {}
    try:
        _nodes = getattr(_iface, "nodes", {}) or {}
    except Exception:
        _nodes = {}
    if not isinstance(_nodes, dict) or not _nodes:
        return {"ok": False, "error": "no_nodes_visible", "details": []}

    import base64 as _b64
    _pairings_added = 0
    _pairings_existing = 0
    _pairings_errors = 0
    _nodes_with_pub = 0
    _details = []

    for _node_id, _node in _nodes.items():
        if not isinstance(_node, dict):
            continue
        _user = _node.get("user") or {}
        _pk = _user.get("publicKey") or _user.get("public_key")
        if not _pk:
            continue
        _their_pub_hex = None
        try:
            if isinstance(_pk, str):
                # Tenta hex pulito (64 char) altrimenti base64
                _clean = _pk.strip()
                if len(_clean) == 64 and all(c in "0123456789abcdefABCDEF" for c in _clean):
                    _their_pub_hex = _clean.lower()
                else:
                    _raw = _b64.b64decode(_clean)
                    if len(_raw) == 32:
                        _their_pub_hex = _raw.hex()
            elif isinstance(_pk, (bytes, bytearray)):
                if len(_pk) == 32:
                    _their_pub_hex = bytes(_pk).hex()
        except Exception:
            _their_pub_hex = None
        if not _their_pub_hex:
            continue
        _nodes_with_pub += 1
        _peer_name = _user.get("longName") or _user.get("shortName") or _node_id

        for _priv_row in _priv_rows:
            _priv_hex = _priv_row.get("my_priv_hex")
            if not _priv_hex:
                continue
            # Skip self-pairing (my pub == peer pub)
            if _priv_row.get("my_pub_hex") and _priv_row["my_pub_hex"] == _their_pub_hex:
                continue
            # Controlla duplicati (UNIQUE priv+peer)
            try:
                _exists = monitor_db.pki_find_by_priv(_priv_hex, their_pub_hex=_their_pub_hex)
            except Exception:
                _exists = None
            if _exists is not None:
                _pairings_existing += 1
                _details.append({
                    "node_id": _node_id,
                    "peer_name": _peer_name,
                    "their_pub_hex": _their_pub_hex,
                    "action": "existing",
                    "pki_id": _exists,
                })
                continue
            # Aggiungi nuova entry
            _label = f"Discovered {_peer_name}"
            try:
                _res = monitor_db.pki_add(
                    label=_label,
                    my_priv_hex=_priv_hex,
                    my_pub_hex=_priv_row.get("my_pub_hex"),
                    their_pub_hex=_their_pub_hex,
                    source="discovered",
                    is_device_own=0,
                    notes=f"Auto-paired da iface.nodes ({_node_id})",
                )
            except Exception as _e:
                _pairings_errors += 1
                _details.append({
                    "node_id": _node_id,
                    "peer_name": _peer_name,
                    "their_pub_hex": _their_pub_hex,
                    "action": "error",
                    "error": str(_e)[:120],
                })
                continue
            if _res.get("error"):
                _pairings_errors += 1
                _details.append({
                    "node_id": _node_id,
                    "peer_name": _peer_name,
                    "their_pub_hex": _their_pub_hex,
                    "action": "error",
                    "error": _res["error"],
                })
            else:
                _pairings_added += 1
                _details.append({
                    "node_id": _node_id,
                    "peer_name": _peer_name,
                    "their_pub_hex": _their_pub_hex,
                    "action": "added",
                    "pki_id": _res.get("id"),
                })

    return {
        "ok": True,
        "device_own_priv_count": len(_priv_rows),
        "nodes_scanned": len(_nodes),
        "nodes_with_pub": _nodes_with_pub,
        "pairings_added": _pairings_added,
        "pairings_existing": _pairings_existing,
        "pairings_errors": _pairings_errors,
        "details": _details,
    }


def rematch_buffered_packets():
    """STEP B — Auto-decrypt agent.

    Ritenta la decifratura su pacchetti cifrati già ricevuti:
      - Buffer RAM (_PKT_ENC_BUFFER) → fino a 500 ultimi pacchetti
      - DB: packets con is_encrypted=1 e encrypted_hex NOT NULL negli ultimi 7d

    Per ogni match trovato:
      - Rimuove dal buffer RAM
      - Aggiorna la row DB (is_encrypted=0, port_name, portnum, payload_text, psk_match)
      - Incrementa match_count sulla PSK
      - Emette SSE event "packet_decoded" con dettagli
    Ritorna stats.
    """
    if not _MCRYPT_OK or not _DB_OK:
        return {"ok": False, "error": "crypto_or_db_missing"}
    try:
        psks = monitor_db.psk_list(enabled_only=True) or []
    except Exception:
        psks = []
    # H4.3-T3 — carica PKI abilitate per rematch
    try:
        _pkis = monitor_db.pki_list(enabled_only=True) or []
    except Exception:
        _pkis = []
    if not psks and not _pkis:
        return {"ok": False, "error": "no_keys_enabled",
                "buffer_size": len(_PKT_ENC_BUFFER)}

    ram_matched = 0
    ram_tried = 0
    db_matched = 0
    db_tried = 0
    _ram_pki_matched = 0
    emitted = []

    # ─── Rematch RAM buffer ───
    remaining = []
    with _LOCK:
        buffered = list(_PKT_ENC_BUFFER)
        _PKT_ENC_BUFFER.clear()
    for item in buffered:
        ram_tried += 1
        try:
            # FASE 14: passa channel_hash per disambiguazione PSK condivise
            _ph_buf = item.get("channel_hash") or item.get("channel_idx")
            try:
                _ph_buf = int(_ph_buf) if _ph_buf is not None else None
            except Exception:
                _ph_buf = None
            m = _mcrypt.try_all_psk(
                item.get("encrypted_hex", ""),
                int(item.get("packet_id") or 0),
                int(item.get("from_int") or 0),
                psks,
                packet_channel_hash=_ph_buf,
            ) if psks else None
        except Exception:
            m = None
        if m:
            ram_matched += 1
            pn = m.get("portnum")
            port_name = PORTNUM_MAP.get(int(pn), f"PORT_{pn}") if pn is not None else None
            text = None
            pb = m.get("payload_bytes") or b""
            try:
                if int(pn) == 1 and pb:
                    text = pb.decode("utf-8", errors="replace")
                elif int(pn) == 7 and pb and _UNISHOX_OK:
                    try:
                        text = _unishox2.decompress(pb, len(pb) * 8)[0]
                    except Exception:
                        text = pb.decode("utf-8", errors="replace")
            except Exception:
                pass
            evt = {
                "type": "packet_decoded",
                "packet_id": item.get("packet_id"),
                "sender_id": item.get("sender_id"),
                "channel": item.get("channel"),
                "channel_name": item.get("channel_name"),
                "ts": item.get("ts"),
                "psk_match_id": m.get("psk_id"),
                "psk_match_label": m.get("label"),
                "psk_match_kind": m.get("kind", "private"),
                "portnum_num": int(pn) if pn is not None else None,
                "portnum": port_name,
                "payload": {"text": text} if text else {},
            }
            emitted.append(evt)
            try:
                _push_event(evt)
            except Exception:
                pass
            try:
                monitor_db.psk_bump_match(m.get("psk_id"))
            except Exception:
                pass
            # Aggiorna anche la row DB se esiste (match per packet_id + from_node + ts vicino)
            try:
                monitor_db.rematch_update_packet(
                    packet_id=item.get("packet_id"),
                    from_int=item.get("from_int"),
                    port_name=port_name,
                    portnum=int(pn) if pn is not None else None,
                    payload_text=text,
                    psk_label=m.get("label"),
                )
            except Exception:
                pass
        else:
            # H4.3-T3 — tenta PKI con tutte le chiavi device-own+enabled
            _pki_ok = False
            for _pk in (_pkis or []):
                _priv = _pk.get("my_priv_hex")
                if not _priv:
                    continue
                # Peer-list: (peer-specific their_pub_hex se presente) + nessun peer (skip)
                _peers = []
                if _pk.get("their_pub_hex"):
                    _peers.append(_pk["their_pub_hex"])
                for _peer in _peers:
                    try:
                        _out = _mcrypt.decrypt_pki(
                            item.get("encrypted_hex", ""),
                            int(item.get("packet_id") or 0),
                            int(item.get("from_int") or 0),
                            _priv, _peer,
                        )
                    except Exception:
                        _out = None
                    if not _out:
                        continue
                    try:
                        _ok_v, _pn_v, _pb_v = _mcrypt.validate_decrypted(_out)
                    except Exception:
                        _ok_v, _pn_v, _pb_v = False, None, None
                    if not _ok_v:
                        continue
                    _text_v = None
                    try:
                        if int(_pn_v) == 1 and _pb_v:
                            _text_v = (_pb_v or b"").decode("utf-8", errors="replace")
                    except Exception:
                        pass
                    _port_name_v = PORTNUM_MAP.get(int(_pn_v), f"PORT_{_pn_v}") if _pn_v is not None else None
                    _evt = {
                        "type": "packet_decoded",
                        "packet_id": item.get("packet_id"),
                        "sender_id": item.get("sender_id"),
                        "channel": item.get("channel"),
                        "channel_name": item.get("channel_name"),
                        "ts": item.get("ts"),
                        "pki_match_id": _pk.get("id"),
                        "pki_match_label": _pk.get("label"),
                        "pki_match_peer": _peer,
                        "portnum_num": int(_pn_v) if _pn_v is not None else None,
                        "portnum": _port_name_v,
                        "payload": {"text": _text_v} if _text_v else {},
                    }
                    emitted.append(_evt)
                    try:
                        _push_event(_evt)
                    except Exception:
                        pass
                    try:
                        monitor_db.pki_bump_match(_pk.get("id"))
                    except Exception:
                        pass
                    try:
                        monitor_db.rematch_update_packet(
                            packet_id=item.get("packet_id"),
                            from_int=item.get("from_int"),
                            port_name=_port_name_v,
                            portnum=int(_pn_v) if _pn_v is not None else None,
                            payload_text=_text_v,
                            psk_label=f"PKI:{_pk.get('label','?')}",
                        )
                    except Exception:
                        pass
                    _pki_ok = True
                    _ram_pki_matched += 1
                    break
                if _pki_ok:
                    break
            if not _pki_ok:
                # Nessun match (PSK+PKI), rimetti in buffer
                remaining.append(item)
    with _LOCK:
        for it in remaining:
            _PKT_ENC_BUFFER.append(it)

    # ─── Rematch DB (ultimi 7gg, con encrypted_hex) ───
    try:
        db_res = monitor_db.rematch_db_packets(psks=psks, window_days=30, crypto_mod=_mcrypt)
        db_matched = db_res.get("matched", 0)
        db_tried = db_res.get("tried", 0)
    except Exception:
        db_matched = 0
        db_tried = 0

    return {
        "ok": True,
        "ram_tried": ram_tried,
        "ram_matched": ram_matched,
        "ram_pki_matched": _ram_pki_matched,
        "ram_buffer_remaining": len(remaining),
        "db_tried": db_tried,
        "db_matched": db_matched,
        "total_matched": ram_matched + _ram_pki_matched + db_matched,
    }


def get_enc_buffer_size():
    """Dimensione corrente buffer pacchetti cifrati (debug)."""
    return len(_PKT_ENC_BUFFER)


def hunter_run(window_days=30, limit=500):
    """Crypto Hunter — brute force su buffer RAM + DB con breakdown per-PSK.

    Combina RAM buffer + DB in un unico run. Ritorna statistiche dettagliate:
      - scanned_ram / decrypted_ram / scanned_db / decrypted_db
      - per_psk: [{psk_id, label, matches}]  (aggregato RAM+DB)
      - results: sample di 50 match (packet_id, psk_label, portnum, snippet)
      - psk_count, buffer_size
      - reasons: breakdown motivi fallimento (Task #66)
          - pki_encrypted      → PKI DM (PSK non serve), solo DB
          - zero_packetid      → packet_id=0 (MQTT relay strippa nonce)
          - zero_from          → from_node=0 (nonce incompleto)
          - decrypt_fail_all_psk → nessuna PSK testata ha matchato
    """
    out = {
        "ok": False,
        "scanned_ram": 0, "decrypted_ram": 0,
        "scanned_db": 0, "decrypted_db": 0,
        "total_scanned": 0, "total_decrypted": 0,
        "per_psk": [], "results": [],
        "psk_count": 0, "buffer_size": 0,
        "errors": 0,
        "reasons": {
            "pki_encrypted": 0,
            "zero_packetid": 0,
            "zero_from": 0,
            "decrypt_fail_all_psk": 0,
        },
    }
    if not _MCRYPT_OK or not _DB_OK:
        out["error"] = "crypto_or_db_missing"
        return out
    try:
        psks = monitor_db.psk_list(enabled_only=True) or []
    except Exception:
        psks = []
    out["psk_count"] = len(psks)
    out["buffer_size"] = len(_PKT_ENC_BUFFER)
    if not psks:
        out["error"] = "no_psk_enabled"
        return out

    per_psk_count = {}  # psk_id -> count
    psk_labels = {int(p.get("id") or 0): p.get("label") for p in psks}
    results_sample = []

    # ─── Phase 1: RAM buffer brute force ───
    remaining = []
    with _LOCK:
        buffered = list(_PKT_ENC_BUFFER)
        _PKT_ENC_BUFFER.clear()
    for item in buffered:
        out["scanned_ram"] += 1
        # Task #66 — breakdown motivi di fallimento (RAM)
        _pid_raw = int(item.get("packet_id") or 0)
        _from_raw = int(item.get("from_int") or 0)
        if _pid_raw == 0:
            out["reasons"]["zero_packetid"] += 1
            remaining.append(item)
            continue
        if _from_raw == 0:
            out["reasons"]["zero_from"] += 1
            remaining.append(item)
            continue
        try:
            # FASE 14: channel_hash per disambiguazione PSK condivise
            _ph_h = item.get("channel_hash") or item.get("channel_idx")
            try:
                _ph_h = int(_ph_h) if _ph_h is not None else None
            except Exception:
                _ph_h = None
            m = _mcrypt.try_all_psk(
                item.get("encrypted_hex", ""),
                _pid_raw,
                _from_raw,
                psks,
                packet_channel_hash=_ph_h,
            )
        except Exception:
            m = None
            out["errors"] += 1
        if not m:
            out["reasons"]["decrypt_fail_all_psk"] += 1
            remaining.append(item)
            continue
        out["decrypted_ram"] += 1
        pid = int(m.get("psk_id") or 0)
        per_psk_count[pid] = per_psk_count.get(pid, 0) + 1
        pn = m.get("portnum")
        port_name = (PORTNUM_MAP.get(int(pn), f"PORT_{pn}")
                     if pn is not None else None)
        pb = m.get("payload_bytes") or b""
        snippet = ""
        try:
            if pn is not None and int(pn) == 1 and pb:
                snippet = pb.decode("utf-8", errors="replace")[:80]
            elif pb:
                snippet = pb.hex()[:80]
        except Exception:
            pass
        if len(results_sample) < 50:
            results_sample.append({
                "source": "ram",
                "packet_id": item.get("packet_id"),
                "from_node": item.get("from_int"),
                "psk_id": pid,
                "psk_label": m.get("label"),
                "portnum": int(pn) if pn is not None else None,
                "port_name": port_name,
                "snippet": snippet,
            })
    # restore RAM buffer with unmatched packets
    with _LOCK:
        _PKT_ENC_BUFFER.extend(remaining)

    # ─── Phase 2: DB brute force ───
    try:
        db_res = monitor_db.hunter_scan_db(
            psks=psks, window_days=window_days,
            crypto_mod=_mcrypt, limit=int(limit),
            include_decrypted=False,
        )
        out["scanned_db"] = db_res.get("scanned", 0)
        out["decrypted_db"] = db_res.get("decrypted", 0)
        for row in db_res.get("per_psk", []) or []:
            pid = int(row.get("psk_id") or 0)
            per_psk_count[pid] = per_psk_count.get(pid, 0) + int(row.get("matches") or 0)
        # Append DB sample results
        for r in db_res.get("results", []) or []:
            if len(results_sample) < 50:
                r2 = dict(r)
                r2["source"] = "db"
                results_sample.append(r2)
        out["errors"] += int(db_res.get("errors") or 0)
        # Task #66 — aggrega i motivi DB nel totale
        _db_reasons = db_res.get("reasons", {}) or {}
        for _k in ("pki_encrypted", "zero_packetid", "zero_from",
                   "decrypt_fail_all_psk"):
            out["reasons"][_k] = (out["reasons"].get(_k, 0)
                                  + int(_db_reasons.get(_k, 0) or 0))
    except Exception as e:
        out["errors"] += 1
        out["error"] = f"db_scan_fail:{e}"

    # ─── Aggregate output ───
    out["total_scanned"] = out["scanned_ram"] + out["scanned_db"]
    out["total_decrypted"] = out["decrypted_ram"] + out["decrypted_db"]
    out["per_psk"] = [
        {"psk_id": pid, "label": psk_labels.get(pid, f"PSK#{pid}"),
         "matches": cnt}
        for pid, cnt in sorted(per_psk_count.items(),
                               key=lambda kv: kv[1], reverse=True)
    ]
    out["results"] = results_sample
    out["buffer_size"] = len(_PKT_ENC_BUFFER)
    out["ok"] = True
    return out


def start(port):
    """Avvia il monitor sulla porta specificata. Ritorna (ok, error)."""
    with _LOCK:
        if _STATE["active"]:
            return False, "already_active"
        if not port:
            return False, "no_port"
        # Reset contatori
        _STATE["packets_total"] = 0
        _STATE["packets_rf"] = 0
        _STATE["packets_mqtt"] = 0
        _STATE["packets_text"] = 0
        _STATE["packets_encrypted"] = 0
        _STATE["last_error"] = None
        _NODE_STATS.clear()
        _EVENTS.clear()

    # Init DB + reset fingerprint euristico
    if _DB_OK and monitor_db:
        try:
            monitor_db.init_db()
        except Exception as e:
            with _LOCK:
                _STATE["last_error"] = f"DB init: {e}"
    if _FP_OK and fw_fingerprint:
        try:
            fw_fingerprint.reset()
        except Exception:
            pass

    t = threading.Thread(target=_supervisor, args=(port,), daemon=True, name="MeshMonitor")
    with _LOCK:
        _STATE["thread"] = t
    t.start()

    # Attende fino a 3 secondi per vedere se la connessione è riuscita
    for _ in range(30):
        time.sleep(0.1)
        with _LOCK:
            if _STATE["active"] and _STATE["interface"] is not None:
                return True, None
            if _STATE["last_error"]:
                return False, _STATE["last_error"]
    return True, None  # Ancora in fase di init, ma il thread è partito


def stop():
    """Ferma il monitor e rilascia la porta."""
    with _LOCK:
        if not _STATE["active"]:
            return False, "not_active"
        _STATE["active"] = False
    # Il supervisor vedrà active=False e uscirà
    return True, None


def get_status():
    """Snapshot completo dello stato attuale."""
    with _LOCK:
        return {
            "active": _STATE["active"],
            "port": _STATE["port"],
            "started_at": _STATE["started_at"],
            "uptime_s": int(_now_ts() - _STATE["started_at"]) if _STATE["started_at"] else 0,
            "packets_total": _STATE["packets_total"],
            "packets_rf": _STATE["packets_rf"],
            "packets_mqtt": _STATE["packets_mqtt"],
            "packets_text": _STATE["packets_text"],
            "packets_encrypted": _STATE["packets_encrypted"],
            "unique_nodes": len(_NODE_STATS),
            "my_node_num": _STATE["my_node_num"],
            "my_node_name": _STATE["my_node_name"],
            "last_error": _STATE["last_error"],
            "thresholds": dict(_THRESHOLDS),
        }


def get_stats(top=20, sort_by="total"):
    """
    Ritorna la lista nodi con statistiche per le classifiche.
    sort_by: "total" | "rf" | "mqtt" | "spam" | "nodeinfo" | "text" | "recent"
    """
    with _LOCK:
        rows = []
        for sid, s in _NODE_STATS.items():
            total = s["rf_packets"] + s["mqtt_packets"]
            avg_hop = (s["total_hops"] / s["hop_samples"]) if s["hop_samples"] else 0
            rows.append({
                "id": sid,
                "mac": _format_mac(sid),
                "long_name": s["long_name"],
                "short_name": s["short_name"],
                "hw_model": s["hw_model"],
                "total": total,
                "rf": s["rf_packets"],
                "mqtt": s["mqtt_packets"],
                "text": s["text_msgs"],
                "pos": s["positions"],
                "telem": s["telemetry"],
                "nodeinfo": s["nodeinfo"],
                "routing": s["routing"],
                "traceroute": s["traceroute"],
                "neighborinfo": s["neighborinfo"],
                "waypoint": s["waypoint"],
                "other": s["other"],
                "encrypted": s["encrypted"],
                "spam": s["spam_count"],
                "avg_hop": round(avg_hop, 2),
                "avg_interval_s": round(s["avg_interval_s"], 1),
                "last_rssi": s["last_rssi"],
                "last_snr": s["last_snr"],
                "best_rssi": s["best_rssi"] if s["best_rssi"] > -999 else None,
                "best_snr": s["best_snr"] if s["best_snr"] > -999 else None,
                "channel": s["last_channel"],
                "last_seen": s["last_seen"],
                "last_seen_ts": s["last_seen_ts"],
                "first_seen_ts": s["first_seen_ts"],
                "last_coords": s["last_coords"],
            })

    # Sort
    key_map = {
        "total": lambda r: r["total"],
        "rf": lambda r: r["rf"],
        "mqtt": lambda r: r["mqtt"],
        "spam": lambda r: r["spam"],
        "nodeinfo": lambda r: r["nodeinfo"],
        "text": lambda r: r["text"],
        "recent": lambda r: r["last_seen_ts"],
    }
    keyfn = key_map.get(sort_by, key_map["total"])
    rows.sort(key=keyfn, reverse=True)
    return rows[:top]


# ═══════════════════════════════════════════════════════════
# SSE STREAM — gestione client
# ═══════════════════════════════════════════════════════════

def sse_stream_generator(last_event_id=0):
    """
    Generator Flask per stream SSE.
    Invia prima gli eventi storici (da last_event_id in poi) e poi live.
    Yield: stringhe SSE "event: xxx\ndata: {...}\n\n"
    """
    client_q = queue.Queue(maxsize=1000)
    with _LOCK:
        _SSE_CLIENTS.append(client_q)
        # Backfill: invia eventi recenti dopo last_event_id
        backfill = [e for e in _EVENTS if e.get("seq", 0) > last_event_id]

    try:
        # Heartbeat iniziale + backfill
        yield f": connected\n\n"
        for evt in backfill:
            yield _sse_format(evt)

        # Loop live
        while True:
            try:
                evt = client_q.get(timeout=15.0)
                yield _sse_format(evt)
            except queue.Empty:
                # Heartbeat per tenere viva la connessione
                yield f": ping {int(_now_ts())}\n\n"
            except GeneratorExit:
                break
    finally:
        with _LOCK:
            if client_q in _SSE_CLIENTS:
                _SSE_CLIENTS.remove(client_q)


def _sse_format(evt):
    """Formatta un dict in riga SSE."""
    try:
        data = json.dumps(evt, default=str, ensure_ascii=False)
    except Exception:
        data = json.dumps({"type": "error", "error": "serialize"})
    evt_type = evt.get("type", "packet")
    seq = evt.get("seq", 0)
    return f"id: {seq}\nevent: {evt_type}\ndata: {data}\n\n"
