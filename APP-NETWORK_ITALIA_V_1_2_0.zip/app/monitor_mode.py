# -*- coding: utf-8 -*-
"""
monitor_mode.py — Monitor Mode completo (estende tune_node)
════════════════════════════════════════════════════════════════════

STEP F1 — "Prendi possesso" del nodo USB collegato e configuralo per
massimizzare l'estrazione di metadati dalla rete mesh.

Due profili:
  - STOCK (firmware Meshtastic ufficiale): 8 parametri sicuri
  - MOD   (firmware fork/custom):         14 parametri estesi

Rilevamento profilo:
  - "auto": usa fw_fingerprint per classificare il nodo
  - "stock"/"mod": forzato manualmente dall'utente

Scheduler opt-in (checkbox OFF di default):
  - Riavvio automatico ogni N ore (default 6h)  → localNode.reboot()
  - Reset NodeDB ogni N giorni (default 7g)     → localNode.resetNodeDb()

Sicurezza:
  - Whitelist rigida: solo i path elencati sono modificabili
  - confirm=True richiesto per apply()/reboot_now()/reset_nodedb_now()
  - SOLO API Python meshtastic — MAI subprocess/shell
  - Scheduler daemon stoppabile via threading.Event

© 2026 MANGOLINK — tutti i diritti riservati.
"""

import threading
import time
import datetime

# Detection firmware (opzionale)
try:
    import fw_fingerprint as _fp
    _FP_OK = True
except Exception:
    _fp = None
    _FP_OK = False


# ═══════════════════════════════════════════════════════════
# PROFILI WHITELIST
# ═══════════════════════════════════════════════════════════

# Profilo STOCK — 8 parametri sicuri, compatibili con FW ufficiale Meshtastic
MONITOR_TARGETS_STOCK = {
    # LoRa — potenza TX massima legale EU
    "lora.tx_power": 30,
    # LoRa — accetta pacchetti ricevuti via MQTT
    "lora.ignore_mqtt": False,
    # Device — rebroadcast ALL (modalità default, ma forziamo in caso di regressione)
    # 0 = ALL, 1 = ALL_SKIP_DECODING, 2 = LOCAL_ONLY, 3 = CORE_PORTNUMS_ONLY
    "device.rebroadcast_mode": 0,
    # Device — NodeInfo broadcast ogni 3h (standard)
    "device.node_info_broadcast_secs": 10800,
    # MQTT — abilita ricezione/invio via gateway MQTT
    "mqtt.enabled": True,
    # Position — broadcast posizione ogni 15 min
    "position.position_broadcast_secs": 900,
    # Position — update GPS ogni 60s
    "position.gps_update_interval": 60,
    # Telemetry — device update ogni 10 min
    "telemetry.device_update_interval": 600,
}

# Profilo MOD — 14 parametri estesi, per FW fork/mod che supportano opzioni extra
MONITOR_TARGETS_MOD = dict(MONITOR_TARGETS_STOCK)
MONITOR_TARGETS_MOD.update({
    # MQTT — proxy verso client (se supportato)
    "mqtt.proxy_to_client_enabled": True,
    # Telemetry — environment (sensori ambientali) ogni 10 min
    "telemetry.environment_update_interval": 600,
    # Telemetry — power (batteria/alimentazione) ogni 10 min
    "telemetry.power_update_interval": 600,
    # NeighborInfo — mappa topologia mesh
    "neighbor_info.enabled": True,
    "neighbor_info.update_interval": 900,
    # Store & Forward — accumula messaggi per history
    "store_forward.enabled": True,
})

# Union di tutti i path consentiti (whitelist globale)
_ALLOWED_PATHS = set(MONITOR_TARGETS_MOD.keys())

# Path module-level (vanno su moduleConfig invece che localConfig)
_MODULE_LEVELS = {
    "mqtt", "telemetry", "serial", "store_forward", "neighbor_info",
    "ambient_lighting", "detection_sensor", "paxcounter",
    "external_notification",
}


# ═══════════════════════════════════════════════════════════
# LETTURA/SCRITTURA CONFIG (API Python meshtastic)
# ═══════════════════════════════════════════════════════════

def _is_module(path):
    return path.split(".")[0] in _MODULE_LEVELS


def _read_path(iface, path):
    """Legge valore config dal nodo. Path dot-notation.

    Esempio: 'lora.tx_power' → iface.localNode.localConfig.lora.tx_power
    """
    if path not in _ALLOWED_PATHS:
        return None
    try:
        localNode = getattr(iface, "localNode", None)
        if not localNode:
            return None
        root = getattr(localNode, "moduleConfig", None) if _is_module(path) \
            else getattr(localNode, "localConfig", None)
        if root is None:
            return None
        obj = root
        for p in path.split("."):
            obj = getattr(obj, p, None)
            if obj is None:
                return None
        return obj
    except Exception:
        return None


def _write_path(iface, path, value):
    """Scrive valore config via API meshtastic + writeConfig(section).

    Ritorna (ok: bool, msg: str).
    """
    if path not in _ALLOWED_PATHS:
        return False, "not_allowed"
    try:
        localNode = getattr(iface, "localNode", None)
        if not localNode:
            return False, "no_local_node"
        parts = path.split(".")
        module_level = parts[0]
        is_mod = _is_module(path)
        root = getattr(localNode, "moduleConfig", None) if is_mod \
            else getattr(localNode, "localConfig", None)
        if root is None:
            return False, "no_config_root"
        obj = root
        for p in parts[:-1]:
            obj = getattr(obj, p, None)
            if obj is None:
                return False, f"missing_sub:{p}"
        field = parts[-1]
        if not hasattr(obj, field):
            return False, f"unknown_field:{field}"
        # Type coerce sicura
        try:
            cur = getattr(obj, field)
            if isinstance(cur, bool) or (cur is None and isinstance(value, bool)):
                setattr(obj, field, bool(value))
            elif isinstance(cur, int) or (cur is None and isinstance(value, int)):
                setattr(obj, field, int(value))
            else:
                setattr(obj, field, value)
        except Exception as e:
            return False, f"set_fail:{e}"
        # Commit sezione
        try:
            localNode.writeConfig(module_level)
        except Exception as e:
            return False, f"write_fail:{e}"
        return True, "ok"
    except Exception as e:
        return False, f"exc:{e}"


# ═══════════════════════════════════════════════════════════
# FW DETECTION + PROFILE SELECTION
# ═══════════════════════════════════════════════════════════

def _detect_fw_profile(iface):
    """Detecta il profilo FW usando fw_fingerprint (se disponibile).

    Ritorna 'stock' o 'mod'. Fallback: 'stock' se detection fallisce.
    """
    if not _FP_OK or _fp is None:
        return "stock"
    try:
        # fw_fingerprint espone classify_node(node_dict) o simile
        # Usa best-effort: se non riesce, default stock
        if hasattr(_fp, "classify_interface"):
            res = _fp.classify_interface(iface)
            if isinstance(res, dict):
                kind = (res.get("kind") or res.get("classification") or "stock").lower()
                return "mod" if kind in ("mod", "fork", "custom") else "stock"
        return "stock"
    except Exception:
        return "stock"


def _get_targets(profile):
    """Ritorna i target dict in base al profilo."""
    p = (profile or "auto").lower()
    if p == "mod":
        return dict(MONITOR_TARGETS_MOD), "mod"
    if p == "stock":
        return dict(MONITOR_TARGETS_STOCK), "stock"
    # "auto": verrà risolto in preview()/apply() con detect
    return None, "auto"


# ═══════════════════════════════════════════════════════════
# PREVIEW / APPLY
# ═══════════════════════════════════════════════════════════

def preview(iface, profile="auto"):
    """Confronta stato attuale con target. Non modifica nulla.

    Ritorna: {ok, profile_used, current, target, diff, changes_needed}
    """
    tgt, prof_used = _get_targets(profile)
    if tgt is None:
        # auto
        prof_used = _detect_fw_profile(iface)
        tgt = dict(MONITOR_TARGETS_MOD) if prof_used == "mod" \
            else dict(MONITOR_TARGETS_STOCK)
    tgt = {k: v for k, v in tgt.items() if k in _ALLOWED_PATHS}
    current = {}
    diff = []
    for path, want in tgt.items():
        cur = _read_path(iface, path)
        current[path] = cur
        if cur != want:
            diff.append({"path": path, "current": cur, "target": want})
    return {
        "ok": True,
        "profile_used": prof_used,
        "profile_requested": profile,
        "current": current,
        "target": tgt,
        "diff": diff,
        "changes_needed": len(diff),
    }


def apply(iface, profile="auto", confirm=False):
    """Applica Monitor Mode al nodo. Richiede confirm=True.

    Ritorna: {ok, profile_used, applied, errors, new_state}
    """
    if not confirm:
        return {"ok": False, "error": "confirm_required",
                "message": "Il cambio parametri richiede confirm=true esplicito."}
    tgt, prof_used = _get_targets(profile)
    if tgt is None:
        prof_used = _detect_fw_profile(iface)
        tgt = dict(MONITOR_TARGETS_MOD) if prof_used == "mod" \
            else dict(MONITOR_TARGETS_STOCK)
    tgt = {k: v for k, v in tgt.items() if k in _ALLOWED_PATHS}
    applied = []
    errors = []
    for path, want in tgt.items():
        cur = _read_path(iface, path)
        if cur == want:
            applied.append({"path": path, "status": "unchanged", "value": cur})
            continue
        ok, msg = _write_path(iface, path, want)
        if ok:
            applied.append({"path": path, "status": "applied", "old": cur, "new": want})
        else:
            errors.append({"path": path, "error": msg})
    new_state = {p: _read_path(iface, p) for p in tgt.keys()}
    return {
        "ok": len(errors) == 0,
        "profile_used": prof_used,
        "profile_requested": profile,
        "applied": applied,
        "errors": errors,
        "new_state": new_state,
    }


# ═══════════════════════════════════════════════════════════
# ADMIN ACTIONS: reboot + reset NodeDB
# ═══════════════════════════════════════════════════════════

def reboot_now(iface, confirm=False):
    """Invia AdminMessage reboot al nodo collegato."""
    if not confirm:
        return {"ok": False, "error": "confirm_required"}
    try:
        localNode = getattr(iface, "localNode", None)
        if not localNode:
            return {"ok": False, "error": "no_local_node"}
        # API meshtastic: localNode.reboot(secs=10) oppure reboot()
        if hasattr(localNode, "reboot"):
            try:
                localNode.reboot(10)
            except TypeError:
                localNode.reboot()
            return {"ok": True, "action": "reboot", "ts": time.time()}
        return {"ok": False, "error": "reboot_method_missing"}
    except Exception as e:
        return {"ok": False, "error": "reboot_fail", "message": str(e)}


def reset_nodedb_now(iface, confirm=False):
    """Invia AdminMessage resetNodeDb al nodo collegato."""
    if not confirm:
        return {"ok": False, "error": "confirm_required"}
    try:
        localNode = getattr(iface, "localNode", None)
        if not localNode:
            return {"ok": False, "error": "no_local_node"}
        # API meshtastic: localNode.resetNodeDb() o resetNodes()
        for method_name in ("resetNodeDb", "resetNodes"):
            fn = getattr(localNode, method_name, None)
            if callable(fn):
                fn()
                return {"ok": True, "action": "reset_nodedb",
                        "method": method_name, "ts": time.time()}
        return {"ok": False, "error": "reset_method_missing"}
    except Exception as e:
        return {"ok": False, "error": "reset_fail", "message": str(e)}


# ═══════════════════════════════════════════════════════════
# SCHEDULER OPT-IN (threading.Timer daemon)
# ═══════════════════════════════════════════════════════════

_SCHED_LOCK = threading.Lock()
_SCHED_STATE = {
    "reboot_enabled": False,
    "reboot_interval_s": 6 * 3600,      # 6h
    "reboot_next_ts": None,
    "reboot_last_ts": None,
    "reboot_timer": None,

    "reset_enabled": False,
    "reset_interval_s": 7 * 24 * 3600,  # 7 giorni
    "reset_next_ts": None,
    "reset_last_ts": None,
    "reset_timer": None,

    "iface_getter": None,                # callable che restituisce iface
}


def _cancel_timer(key):
    t = _SCHED_STATE.get(key)
    if t is not None:
        try:
            t.cancel()
        except Exception:
            pass
    _SCHED_STATE[key] = None


def _schedule_reboot_timer():
    """Avvia/rinnova timer reboot. Chiamato sotto lock."""
    _cancel_timer("reboot_timer")
    interval = _SCHED_STATE["reboot_interval_s"]
    _SCHED_STATE["reboot_next_ts"] = time.time() + interval
    t = threading.Timer(interval, _fire_reboot)
    t.daemon = True
    _SCHED_STATE["reboot_timer"] = t
    t.start()


def _schedule_reset_timer():
    _cancel_timer("reset_timer")
    interval = _SCHED_STATE["reset_interval_s"]
    _SCHED_STATE["reset_next_ts"] = time.time() + interval
    t = threading.Timer(interval, _fire_reset)
    t.daemon = True
    _SCHED_STATE["reset_timer"] = t
    t.start()


def _fire_reboot():
    with _SCHED_LOCK:
        if not _SCHED_STATE["reboot_enabled"]:
            return
        getter = _SCHED_STATE.get("iface_getter")
        iface = None
        if callable(getter):
            try:
                iface = getter()
            except Exception:
                iface = None
        if iface is not None:
            try:
                reboot_now(iface, confirm=True)
                _SCHED_STATE["reboot_last_ts"] = time.time()
            except Exception:
                pass
        # Reschedule
        if _SCHED_STATE["reboot_enabled"]:
            _schedule_reboot_timer()


def _fire_reset():
    with _SCHED_LOCK:
        if not _SCHED_STATE["reset_enabled"]:
            return
        getter = _SCHED_STATE.get("iface_getter")
        iface = None
        if callable(getter):
            try:
                iface = getter()
            except Exception:
                iface = None
        if iface is not None:
            try:
                reset_nodedb_now(iface, confirm=True)
                _SCHED_STATE["reset_last_ts"] = time.time()
            except Exception:
                pass
        if _SCHED_STATE["reset_enabled"]:
            _schedule_reset_timer()


def set_iface_getter(getter):
    """Registra il callable che fornisce l'iface corrente (es. lambda: monitor._STATE.get('interface'))."""
    with _SCHED_LOCK:
        _SCHED_STATE["iface_getter"] = getter


def schedule_reboot(enabled=True, interval_hours=6):
    with _SCHED_LOCK:
        _SCHED_STATE["reboot_enabled"] = bool(enabled)
        _SCHED_STATE["reboot_interval_s"] = max(3600, int(interval_hours * 3600))
        if enabled:
            _schedule_reboot_timer()
        else:
            _cancel_timer("reboot_timer")
            _SCHED_STATE["reboot_next_ts"] = None
    return schedule_status()


def schedule_reset(enabled=True, interval_days=7):
    with _SCHED_LOCK:
        _SCHED_STATE["reset_enabled"] = bool(enabled)
        _SCHED_STATE["reset_interval_s"] = max(86400, int(interval_days * 86400))
        if enabled:
            _schedule_reset_timer()
        else:
            _cancel_timer("reset_timer")
            _SCHED_STATE["reset_next_ts"] = None
    return schedule_status()


def schedule_status():
    """Ritorna stato scheduler (per UI)."""
    with _SCHED_LOCK:
        now = time.time()
        def _fmt(ts):
            if not ts:
                return None
            return datetime.datetime.fromtimestamp(ts).isoformat(timespec="seconds")
        reboot_remaining = None
        if _SCHED_STATE["reboot_enabled"] and _SCHED_STATE["reboot_next_ts"]:
            reboot_remaining = max(0, int(_SCHED_STATE["reboot_next_ts"] - now))
        reset_remaining = None
        if _SCHED_STATE["reset_enabled"] and _SCHED_STATE["reset_next_ts"]:
            reset_remaining = max(0, int(_SCHED_STATE["reset_next_ts"] - now))
        return {
            "reboot": {
                "enabled": _SCHED_STATE["reboot_enabled"],
                "interval_s": _SCHED_STATE["reboot_interval_s"],
                "next_ts": _fmt(_SCHED_STATE["reboot_next_ts"]),
                "last_ts": _fmt(_SCHED_STATE["reboot_last_ts"]),
                "remaining_s": reboot_remaining,
            },
            "reset_nodedb": {
                "enabled": _SCHED_STATE["reset_enabled"],
                "interval_s": _SCHED_STATE["reset_interval_s"],
                "next_ts": _fmt(_SCHED_STATE["reset_next_ts"]),
                "last_ts": _fmt(_SCHED_STATE["reset_last_ts"]),
                "remaining_s": reset_remaining,
            },
        }


def schedule_stop_all():
    """Stop completo (usato in shutdown/test)."""
    with _SCHED_LOCK:
        _SCHED_STATE["reboot_enabled"] = False
        _SCHED_STATE["reset_enabled"] = False
        _cancel_timer("reboot_timer")
        _cancel_timer("reset_timer")
        _SCHED_STATE["reboot_next_ts"] = None
        _SCHED_STATE["reset_next_ts"] = None
    return {"ok": True}


# ═══════════════════════════════════════════════════════════
# NETWORK INFO — config attesa MIN / Mesh Italia
# ═══════════════════════════════════════════════════════════

NETWORK_EXPECTED = {
    "region": "EU_868",
    "modem_preset": "MEDIUM_FAST",
    "frequency_mhz": 869.525,
    "bandwidth_khz": 250,
    "spread_factor": 9,
    "coding_rate": "4/5",
    "bitrate_bps": 1758,
    "mqtt_root_topic": "msh/EU_868/IT",
    "channel_name_primary": "MediumFast",
}


def read_network_info(iface):
    """Legge la configurazione di rete attuale dal nodo e confronta con attesa.

    Ritorna: {expected, current, match: bool per riga}
    """
    current = {}
    # LoRa config
    lora = None
    try:
        lora = iface.localNode.localConfig.lora
    except Exception:
        lora = None
    if lora is not None:
        # region è un enum; la libreria a volte espone .Name()
        try:
            region_val = lora.region
            # Se è enum int → mappa via descriptor
            reg_name = None
            try:
                reg_name = lora.DESCRIPTOR.fields_by_name["region"].enum_type.values_by_number[int(region_val)].name
            except Exception:
                reg_name = str(region_val)
            current["region"] = reg_name
        except Exception:
            current["region"] = None
        try:
            preset_val = lora.modem_preset
            preset_name = None
            try:
                preset_name = lora.DESCRIPTOR.fields_by_name["modem_preset"].enum_type.values_by_number[int(preset_val)].name
            except Exception:
                preset_name = str(preset_val)
            current["modem_preset"] = preset_name
        except Exception:
            current["modem_preset"] = None
        try:
            current["tx_power"] = int(lora.tx_power)
        except Exception:
            current["tx_power"] = None
    # MQTT root topic
    try:
        mqtt = iface.localNode.moduleConfig.mqtt
        current["mqtt_root_topic"] = str(mqtt.root) if getattr(mqtt, "root", None) else ""
        current["mqtt_enabled"] = bool(mqtt.enabled)
    except Exception:
        current["mqtt_root_topic"] = None
        current["mqtt_enabled"] = None
    # Primary channel name
    try:
        ch0 = iface.localNode.getChannelByChannelIndex(0)
        current["channel_name_primary"] = str(ch0.settings.name) if ch0 and ch0.settings else ""
    except Exception:
        current["channel_name_primary"] = None
    # Match (solo su chiavi confrontabili)
    match = {}
    for k, v in NETWORK_EXPECTED.items():
        cur = current.get(k)
        if cur is None:
            match[k] = None
        elif isinstance(v, str) and isinstance(cur, str):
            match[k] = cur.upper() == v.upper() or cur.lower() == v.lower()
        else:
            match[k] = cur == v
    return {
        "ok": True,
        "expected": dict(NETWORK_EXPECTED),
        "current": current,
        "match": match,
    }
