# -*- coding: utf-8 -*-
"""
📡 Meshtastic Italia Network App v1.1.0 — Server Flask
API REST + Sistema Licenze Ed25519 + MOD Firmware + localhost:5555
© 2026 🌐🥭MANGOLINK🥭🌐 — Tutti i diritti riservati
"""

import os
import json
from flask import Flask, render_template, jsonify, request, send_from_directory
try:
    from flask_cors import CORS
except ImportError:
    CORS = None

from app.system_utils import (
    detect_os, get_os_info, list_serial_ports,
    check_driver_installed, check_python_info, open_url
)
from app.config_generator import (
    generate_auto_config, generate_cli_commands,
    generate_qr_code, validate_params, get_script_completo,
    generate_channel_url
)
from app.network_params import (
    NETWORK_CONFIG, CHANNELS, AUTOCONFIG_URL, DEVICE_ROLES,
    MODEM_PRESETS, DRIVER_LINKS, SUPPORTED_DEVICES, LINKS,
    FIRMWARE_INFO, BOOTLOADER_METHODS, DEPRECATED_ROLES
)
from app.license_manager import (
    generate_fingerprint, get_license_info, reload_license, get_license_path,
    diagnose_license, reset_license_cache
)
from app import monitor as mesh_monitor
monitor = mesh_monitor  # alias: permette uso diretto nelle API PSK/tune
try:
    from app import tune_node as _tune
except Exception:
    _tune = None
try:
    from app import monitor_analyst as _analyst
except Exception:
    _analyst = None
try:
    from app import monitor_mode as _mmode
except Exception:
    _mmode = None
# Registra getter iface per scheduler opt-in (reboot/reset nodeDB)
if _mmode is not None:
    try:
        _mmode.set_iface_getter(lambda: mesh_monitor._STATE.get("interface"))
    except Exception:
        pass

# Monitor DB layer (optional — falls back gracefully if missing)
try:
    from app import monitor_db as mdb
    _MDB_AVAILABLE = True
except Exception as _e_mdb:
    mdb = None
    _MDB_AVAILABLE = False

APP_VERSION = "1.2.0"

# ═══════════════════════════════════════════════════════════
# INIZIALIZZAZIONE APP
# ═══════════════════════════════════════════════════════════

# Path base = stessa cartella di server.py (struttura flat)
_base_dir = os.path.dirname(os.path.abspath(__file__))

app = Flask(
    __name__,
    static_folder=_base_dir,
    static_url_path='/static',
    template_folder=_base_dir
)
app.config['SECRET_KEY'] = os.urandom(32).hex()  # Random per sessione (localhost only)
if CORS:
    CORS(app)

# ═══════════════════════════════════════════════════════════
# PAGINA PRINCIPALE
# ═══════════════════════════════════════════════════════════

@app.route('/')
def index():
    """Serve la pagina HTML principale"""
    return render_template('index.html')

# ═══════════════════════════════════════════════════════════
# API SISTEMA
# ═══════════════════════════════════════════════════════════

@app.route('/api/system/info', methods=['GET'])
def api_system_info():
    """Info complete sul sistema: OS, Python, pip, meshtastic CLI"""
    return jsonify({
        "os": get_os_info(),
        "python": check_python_info(),
        "drivers": check_driver_installed(),
    })

@app.route('/api/system/ports', methods=['GET'])
def api_system_ports():
    """Lista porte seriali USB disponibili"""
    return jsonify({"ports": list_serial_ports()})

@app.route('/api/system/drivers', methods=['GET'])
def api_system_drivers():
    """Check driver USB installati + link download"""
    return jsonify({
        "installed": check_driver_installed(),
        "download_links": DRIVER_LINKS,
    })

@app.route('/api/deps/check', methods=['GET'])
def api_deps_check():
    """Verifica TUTTE le dipendenze Python richieste dall'app"""
    import sys
    deps = [
        {"module": "flask",        "pip": "flask",        "label": "Flask (web server)",        "required": True},
        {"module": "flask_cors",   "pip": "flask-cors",   "label": "Flask-CORS",                "required": True},
        {"module": "serial",       "pip": "pyserial",     "label": "PySerial (USB)",             "required": True},
        {"module": "meshtastic",   "pip": "meshtastic",   "label": "Meshtastic CLI + API",       "required": True},
        {"module": "cryptography", "pip": "cryptography", "label": "Cryptography (licenze)",     "required": True},
        {"module": "qrcode",       "pip": "qrcode[pil]",  "label": "QR Code",                    "required": True},
        {"module": "PIL",          "pip": "Pillow",       "label": "Pillow (immagini)",           "required": True},
        {"module": "esptool",      "pip": "esptool",      "label": "ESPTool (flash ESP32)",       "required": False},
    ]
    results = []
    for dep in deps:
        try:
            mod = __import__(dep["module"])
            version = getattr(mod, '__version__', getattr(mod, 'VERSION', '?'))
            results.append({**dep, "installed": True, "version": str(version)})
        except ImportError:
            results.append({**dep, "installed": False, "version": None})

    # Info Python + pip
    py_version = f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"
    pip_ok = False
    pip_version = None
    try:
        r = subprocess.run([sys.executable, '-m', 'pip', '--version'],
                           capture_output=True, text=True, timeout=10,
                           encoding='utf-8', errors='replace')
        if r.returncode == 0:
            pip_ok = True
            pip_version = (r.stdout or '').split(' ')[1] if r.stdout else '?'
    except Exception:
        pass

    all_required_ok = all(d["installed"] for d in results if d["required"])
    missing_required = [d for d in results if d["required"] and not d["installed"]]

    return jsonify({
        "python_version": py_version,
        "python_path": sys.executable,
        "pip_available": pip_ok,
        "pip_version": pip_version,
        "all_ok": all_required_ok,
        "missing_count": len(missing_required),
        "deps": results,
    })

@app.route('/api/deps/install', methods=['POST'])
def api_deps_install():
    """Installa TUTTE le dipendenze mancanti o un pacchetto specifico"""
    import sys
    data = request.get_json() or {}
    package = data.get("package", "")  # Pacchetto singolo, oppure vuoto = tutti

    ALLOWED = {"meshtastic", "flask", "flask-cors", "pyserial", "cryptography",
               "qrcode", "qrcode[pil]", "Pillow", "esptool", ""}
    if package and package not in ALLOWED:
        return jsonify({"success": False, "error": f"Pacchetto non consentito: {package}"}), 403

    import platform as _plat
    env = {**os.environ, 'PYTHONIOENCODING': 'utf-8'}
    base_kwargs = dict(
        capture_output=True, text=True,
        timeout=300,
        env=env,
        encoding='utf-8',
        errors='replace'
    )
    if _plat.system() == 'Windows':
        base_kwargs['creationflags'] = getattr(subprocess, 'CREATE_NO_WINDOW', 0)

    if package:
        # Installa singolo pacchetto
        packages = [package]
    else:
        # Installa tutti i mancanti da requirements.txt
        req_file = os.path.join(os.path.dirname(__file__), "requirements.txt")
        if os.path.exists(req_file):
            packages = ["-r", req_file]
        else:
            packages = ["flask", "flask-cors", "pyserial", "meshtastic",
                        "cryptography", "qrcode[pil]", "Pillow"]

    results = []
    try:
        # Tentativo 1: installazione normale
        cmd = [sys.executable, '-m', 'pip', 'install', '--upgrade'] + packages
        result = subprocess.run(cmd, **base_kwargs)
        stdout = (result.stdout or '').strip()
        stderr = (result.stderr or '').strip()

        if result.returncode == 0:
            return jsonify({
                "success": True,
                "stdout": stdout,
                "stderr": stderr,
                "method": "standard",
            })

        # Tentativo 2: con --user
        cmd_user = [sys.executable, '-m', 'pip', 'install', '--user', '--upgrade'] + packages
        result2 = subprocess.run(cmd_user, **base_kwargs)
        stdout2 = (result2.stdout or '').strip()
        stderr2 = (result2.stderr or '').strip()

        if result2.returncode == 0:
            return jsonify({
                "success": True,
                "stdout": stdout2,
                "stderr": stderr2,
                "method": "--user",
            })

        return jsonify({
            "success": False,
            "error": stderr or stderr2 or stdout or stdout2 or "Installazione fallita senza dettagli",
            "stdout": stdout or stdout2,
            "stderr": stderr or stderr2,
        })
    except subprocess.TimeoutExpired:
        return jsonify({"success": False, "error": "Timeout (300s) — connessione molto lenta"}), 504
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500

@app.route('/api/system/open-url', methods=['POST'])
def api_system_open_url():
    """Apre un URL nel browser dell'utente"""
    data = request.get_json()
    url = data.get("url", "")
    if url:
        success = open_url(url)
        return jsonify({"success": success, "url": url})
    return jsonify({"success": False, "error": "URL mancante"}), 400

@app.route('/api/system/exec', methods=['POST'])
def api_system_exec():
    """Esegue un comando di sistema con output REALE e timing"""
    import time as _time
    data = request.get_json() or {}
    cmd = data.get("command", "").strip()
    if not cmd:
        return jsonify({"error": "Comando vuoto"}), 400
    
    # Blocca comandi distruttivi
    blocked = ['rm -rf /', 'format c:', 'mkfs', ':(){', 'dd if=', '> /dev/sd', 
               'shutdown', 'halt', 'init 0', 'del /f /s /q c:\\',
               'curl | sh', 'curl |sh', 'curl|sh', 'curl|bash',
               'wget -O- |', 'wget -O-|', 'wget|sh', 'wget|bash',
               'python -c "import os', "python -c 'import os",
               'powershell -enc', 'powershell -e ', 'powershell -command',
               'eval ', 'exec(', '| bash', '|bash',
               'chmod 777 /', 'chown root', 'passwd',
               'netcat ', 'nc -l', 'ncat ',
               'rm -rf ~', 'rm -rf $HOME',
               'sudo rm -rf', 'reboot', 'kill -9 1', 'kill -9 -1',
               'pkill -9', 'killall ',
               'iptables -F', 'iptables --flush',
               'systemctl disable', 'systemctl mask',
               '>/dev/sda', '>/dev/nvme',
               'base64 -d|', 'base64 -d |',
               'xargs rm', 'find / -delete',
               'mkfs.ext', 'wipefs',
               'crontab -r', 'at -d']
    for b in blocked:
        if b.lower() in cmd.lower():
            return jsonify({"error": f"Comando bloccato per sicurezza: {b}", "success": False})
    
    try:
        import subprocess, platform, shutil
        env = os.environ.copy()
        env['PYTHONIOENCODING'] = 'utf-8'
        
        system = platform.system().lower()
        start_time = _time.time()
        
        # Pattern "cleanup" — comandi che possono avere exit code != 0 ma sono OK
        partial_ok_patterns = [
            'silentlycontinue', 'erroraction', '2>/dev/null', '2>&1',
            'remove-item', 'clear-recyclebin', 'cleanmgr',
            'rm -rf /tmp', 'rm -rf /private/var', 'rm -rf ~/library/caches',
            'rm -rf ~/library/logs', 'rm -rf ~/.cache',
            'apt autoremove', 'apt autoclean', 'apt clean',
            'journalctl --vacuum', 'pip cache purge', 'brew cleanup',
        ]
        is_partial_ok = any(p in cmd.lower() for p in partial_ok_patterns)
        
        if system == 'windows':
            cmd_clean = cmd.replace('sudo ', '')
            
            # Per comandi Remove-Item: mostra COSA è stato effettivamente cancellato
            if 'remove-item' in cmd_clean.lower() and 'silentlycontinue' in cmd_clean.lower():
                # Wrap: conta file prima, esegui, conta dopo, mostra differenza
                ps_script = f"""
$ErrorActionPreference = 'SilentlyContinue'
$target = {_extract_ps_path(cmd_clean)}
if (Test-Path $target) {{
    $before = (Get-ChildItem $target -Recurse -Force -ErrorAction SilentlyContinue | Measure-Object).Count
    $sizeBefore = (Get-ChildItem $target -Recurse -Force -ErrorAction SilentlyContinue | Measure-Object -Property Length -Sum -ErrorAction SilentlyContinue).Sum
    {cmd_clean}
    $after = (Get-ChildItem $target -Recurse -Force -ErrorAction SilentlyContinue | Measure-Object).Count
    $deleted = $before - $after
    $sizeFreed = $sizeBefore - (Get-ChildItem $target -Recurse -Force -ErrorAction SilentlyContinue | Measure-Object -Property Length -Sum -ErrorAction SilentlyContinue).Sum
    $sizeMB = [math]::Round($sizeFreed / 1MB, 2)
    Write-Output "Eliminati: $deleted file/cartelle | Liberati: $($sizeMB) MB"
    Write-Output "Rimanenti: $after (bloccati da programmi attivi)"
}} else {{
    Write-Output "Cartella vuota o non trovata"
}}
exit 0
"""
                cmd_final = ps_script
            elif is_partial_ok:
                # Altri comandi cleanup: esegui normalmente, ignora errori
                cmd_final = f'{cmd_clean}; if ($?) {{ Write-Output "OK" }} else {{ Write-Output "Completato con avvisi" }}; exit 0'
            else:
                cmd_final = cmd_clean
            
            ps = shutil.which('powershell') or shutil.which('pwsh') or 'powershell'
            result = subprocess.run(
                [ps, '-NoProfile', '-Command', cmd_final],
                capture_output=True, text=True, timeout=60, env=env,
                encoding='utf-8', errors='replace'
            )
        elif system == 'darwin':
            result = subprocess.run(
                ['/bin/bash', '-c', cmd],
                capture_output=True, text=True, timeout=60, env=env,
                encoding='utf-8', errors='replace'
            )
        else:
            result = subprocess.run(
                ['/bin/bash', '-c', cmd],
                capture_output=True, text=True, timeout=60, env=env,
                encoding='utf-8', errors='replace'
            )
        
        elapsed = round(_time.time() - start_time, 2)
        stdout = (result.stdout or '').strip()
        stderr = (result.stderr or '').strip()
        
        # Rileva se serve admin
        needs_admin = False
        admin_kw = ['access denied', 'permission denied', 'not recognized',
                    'operation not permitted', 'requires elevation', 
                    'must be run as administrator', 'permesso negato',
                    'accesso negato', 'privilegi insufficienti']
        combined = (stdout + ' ' + stderr).lower()
        for kw in admin_kw:
            if kw in combined:
                needs_admin = True
                break
        
        # Aggiungi timing all'output
        timing = f"⏱️ {elapsed}s"
        
        if result.returncode == 0:
            display = f"{stdout}\n{timing}" if stdout else f"✅ Eseguito | {timing}"
            return jsonify({"success": True, "stdout": display, "stderr": stderr, "elapsed": elapsed})
        elif is_partial_ok and not needs_admin:
            display = f"{stdout}\n{timing}" if stdout else f"⚠️ Completato parzialmente | {timing}"
            return jsonify({
                "success": True, "partial": True,
                "stdout": display, "stderr": stderr, "elapsed": elapsed
            })
        else:
            return jsonify({
                "success": False,
                "error": stderr or stdout or f"Errore (codice {result.returncode})",
                "stdout": stdout, "stderr": stderr, "needs_admin": needs_admin,
                "elapsed": elapsed
            })
    except subprocess.TimeoutExpired:
        return jsonify({"error": "Timeout (60s)", "success": False})
    except Exception as e:
        return jsonify({"error": str(e), "success": False})

def _extract_ps_path(cmd):
    """Estrae il path da un comando Remove-Item di PowerShell"""
    import re
    m = re.search(r'-Path\s+"([^"]+)"', cmd) or re.search(r'-Path\s+(\S+)', cmd)
    if m:
        path = m.group(1).rstrip('\\*').rstrip('/*')
        return f'"{path}"'
    return '"$env:TEMP"'

# ═══════════════════════════════════════════════════════════
# API LICENZA
# ═══════════════════════════════════════════════════════════

@app.route('/api/license/status', methods=['GET'])
def api_license_status():
    """Stato completo della licenza + stato Setup Doctor (v1.1.3+)"""
    info = get_license_info()
    info["app_version"] = APP_VERSION
    # v1.1.3+: includi stato Setup Doctor per banner UI
    try:
        from app.setup_doctor import get_doctor_state
        doctor = get_doctor_state()
        if doctor:
            info["doctor"] = {
                "stable": doctor.get("stable"),
                "mac_is_random": doctor.get("mac_is_random"),
                "unstable_components": doctor.get("unstable_components", []),
                "remedies": doctor.get("remedies", []),
                "fp_anchored": doctor.get("fp_anchored"),
                "system": doctor.get("system", {}),
                "last_check": doctor.get("timestamp"),
            }
    except Exception:
        pass
    return jsonify(info)


# ═══════════════════════════════════════════════════════════
# API SETUP DOCTOR (v1.1.3+) — Health check fingerprint hardware
# ═══════════════════════════════════════════════════════════

@app.route('/api/system/health-check', methods=['GET'])
def api_system_health_check():
    """Ritorna lo stato corrente del Setup Doctor (senza rieseguire il test)."""
    try:
        from app.setup_doctor import get_doctor_state
        state = get_doctor_state()
        if state is None:
            return jsonify({"available": False, "message": "Doctor non ancora eseguito"})
        return jsonify({"available": True, "state": state})
    except Exception as e:
        return jsonify({"available": False, "error": str(e)}), 500


@app.route('/api/system/doctor/run', methods=['POST'])
def api_system_doctor_run():
    """Forza una nuova esecuzione del Setup Doctor (10 letture FP).
    Usato dal bottone 'Rifai verifica' nella UI."""
    try:
        from app.setup_doctor import run_first_boot_check
        result = run_first_boot_check(force=True)
        return jsonify({"success": True, "state": result})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


@app.route('/api/system/doctor/clear-anchor', methods=['POST'])
def api_system_doctor_clear_anchor():
    """Cancella l'anchor del fingerprint (es. cambio HW volontario).
    Al prossimo Doctor verrà ricalcolato dall'hardware corrente."""
    try:
        from app.setup_doctor import clear_anchor
        ok = clear_anchor()
        return jsonify({"success": ok})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500

@app.route('/api/license/fingerprint', methods=['GET'])
def api_license_fingerprint():
    """Ritorna il fingerprint hardware del PC"""
    fp = generate_fingerprint()
    return jsonify({"fingerprint": fp})

@app.route('/api/license/reload', methods=['POST'])
def api_license_reload():
    """Ricarica la licenza (dopo che l'utente ha messo il file)"""
    info = reload_license()
    info["app_version"] = APP_VERSION
    return jsonify(info)

@app.route('/api/license/open-folder', methods=['POST'])
def api_license_open_folder():
    """Apre la cartella dell'app nel file manager"""
    app_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    return jsonify({"success": open_url(app_dir), "path": app_dir})

@app.route('/api/license/diagnose', methods=['GET'])
def api_license_diagnose():
    """Diagnostica step-by-step del processo di attivazione licenza"""
    try:
        report = diagnose_license()
        report["app_version"] = APP_VERSION
        return jsonify(report)
    except Exception as e:
        return jsonify({
            "error": str(e),
            "steps": [{"id": "exception", "ok": False, "label": "Errore diagnostica", "detail": str(e)}],
            "summary": "error"
        }), 500

@app.route('/api/license/reset-cache', methods=['POST'])
def api_license_reset_cache():
    """Resetta cache anti-tampering e revoca per forzare verifica pulita"""
    try:
        result = reset_license_cache()
        return jsonify(result)
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/api/license/force-revoke-check', methods=['POST'])
def api_license_force_revoke_check():
    """★ Forza un check di revoca immediato: cancella cache → ri-verifica online → ritorna stato"""
    try:
        # 1. Cancella cache per forzare verifica online
        # ★ FIX v1.2.0: usa get_cache_path() dal license_manager (path corretto = app/.license_cache_v2)
        from app.license_manager import get_cache_path, reset_license_cache
        cache_path = get_cache_path()
        _cache_existed = os.path.exists(cache_path)
        if _cache_existed:
            try:
                os.remove(cache_path)
                print(f"  [FORCE-REVOKE] Cache cancellata: {cache_path}")
            except OSError as _e:
                print(f"  [FORCE-REVOKE] ⚠ Errore cancellazione cache: {_e}")
        else:
            print(f"  [FORCE-REVOKE] Nessuna cache da cancellare ({cache_path})")

        # 2. Verifica pulita (senza cache → forza check remoto + locale revoked.json)
        info = get_license_info()
        info["app_version"] = APP_VERSION
        info["force_checked"] = True
        info["cache_cleared"] = _cache_existed
        info["check_time"] = __import__('datetime').datetime.now().isoformat()
        print(f"  [FORCE-REVOKE] Risultato: status={info.get('status')}, online_verified={info.get('online_verified')}")
        return jsonify(info)
    except Exception as e:
        print(f"  [FORCE-REVOKE] ❌ Errore: {e}")
        return jsonify({"error": str(e)}), 500

# ═══════════════════════════════════════════════════════════
# API CONFIGURAZIONE
# ═══════════════════════════════════════════════════════════

@app.route('/api/config/auto', methods=['GET'])
def api_config_auto():
    """Configurazione automatica: URL + comandi + canali"""
    return jsonify(generate_auto_config())

@app.route('/api/config/commands', methods=['POST'])
def api_config_commands():
    """Genera comandi CLI dai parametri scelti dall'utente"""
    params = request.get_json() or {}
    commands = generate_cli_commands(params)
    validation = validate_params(params)
    script = get_script_completo(params)
    return jsonify({
        "commands": commands,
        "validation": validation,
        "script": script,
    })

@app.route('/api/config/validate', methods=['POST'])
def api_config_validate():
    """Valida i parametri senza generare comandi"""
    params = request.get_json() or {}
    return jsonify(validate_params(params))

@app.route('/api/config/qrcode', methods=['POST'])
def api_config_qrcode():
    """Genera QR code PNG (base64) per configurazione canali.
    Se riceve custom_channels, genera URL protobuf dinamico.
    Altrimenti usa AUTOCONFIG_URL standard."""
    data = request.get_json() or {}

    # Se l'utente ha canali personalizzati, genera URL dinamico
    custom_channels = data.get("custom_channels")
    if custom_channels:
        dynamic_url = generate_channel_url(data)
        if dynamic_url:
            url = dynamic_url
        else:
            url = data.get("url", AUTOCONFIG_URL)
    else:
        url = data.get("url", AUTOCONFIG_URL)

    qr_base64 = generate_qr_code(url)
    if qr_base64:
        return jsonify({"qr_code": qr_base64, "url": url})
    # Non crash: ritorna ok con flag per far usare il fallback JS
    return jsonify({"qr_code": None, "url": url, "fallback": True})

# ═══════════════════════════════════════════════════════════
# API NETWORK (parametri, canali, link)
# ═══════════════════════════════════════════════════════════

@app.route('/api/network/params', methods=['GET'])
def api_network_params():
    """Tutti i parametri ufficiali del network"""
    return jsonify(NETWORK_CONFIG)

@app.route('/api/network/channels', methods=['GET'])
def api_network_channels():
    """Lista canali ufficiali"""
    return jsonify({"channels": CHANNELS, "autoconfig_url": AUTOCONFIG_URL})

@app.route('/api/network/links', methods=['GET'])
def api_network_links():
    """Tutti i link ufficiali organizzati per categoria"""
    return jsonify(LINKS)

@app.route('/api/network/roles', methods=['GET'])
def api_network_roles():
    """Tutti i 12 ruoli con descrizioni complete"""
    return jsonify({
        "roles": DEVICE_ROLES,
        "deprecated": DEPRECATED_ROLES,
    })

@app.route('/api/network/presets', methods=['GET'])
def api_network_presets():
    """Tutti i preset modem disponibili"""
    return jsonify(MODEM_PRESETS)

@app.route('/api/network/devices', methods=['GET'])
def api_network_devices():
    """Database dispositivi supportati"""
    return jsonify({"devices": SUPPORTED_DEVICES})

@app.route('/api/network/firmware', methods=['GET'])
def api_network_firmware():
    """Info firmware + bootloader"""
    return jsonify({
        "firmware": FIRMWARE_INFO,
        "bootloader": BOOTLOADER_METHODS,
    })

# ═══════════════════════════════════════════════════════════
# API DATI (params info, comandi CLI, guide)
# ═══════════════════════════════════════════════════════════

@app.route('/api/data/<filename>', methods=['GET'])
def api_data_file(filename):
    """Serve file JSON dalla cartella data/ (o stessa cartella se flat)"""
    # Prova prima data/ come sottocartella, poi stessa cartella (flat)
    data_dir = os.path.join(_base_dir, 'data')
    safe_name = os.path.basename(filename)
    if not safe_name.endswith('.json'):
        safe_name += '.json'
    filepath = os.path.join(data_dir, safe_name)
    if not os.path.exists(filepath):
        filepath = os.path.join(_base_dir, safe_name)
    if os.path.exists(filepath):
        with open(filepath, 'r', encoding='utf-8') as f:
            return jsonify(json.load(f))
    return jsonify({"error": f"File {safe_name} non trovato"}), 404

# ═══════════════════════════════════════════════════════════
# API MOD — Operazioni avanzate firmware
# ═══════════════════════════════════════════════════════════

@app.route('/api/mod/import-config', methods=['POST'])
def api_mod_import_config():
    """Importa configurazione YAML sul dispositivo via --configure"""
    # Mutex USB esclusivo: se Monitor attivo, blocca
    _busy = _monitor_busy_response()
    if _busy is not None:
        return _busy
    import tempfile
    data = request.get_json() or {}
    yaml_content = data.get("yaml_content", "")
    if not yaml_content:
        return jsonify({"success": False, "error": "Contenuto YAML vuoto"})
    
    try:
        # Salva YAML in file temporaneo
        fd, tmp_path = tempfile.mkstemp(suffix='.yaml', prefix='mesh_config_')
        with os.fdopen(fd, 'w', encoding='utf-8') as f:
            f.write(yaml_content)
        
        # Esegui meshtastic --configure
        cli_path = _find_meshtastic_cli()
        if not cli_path:
            os.unlink(tmp_path)
            return jsonify({"success": False, "error": "meshtastic CLI non trovato"})
        
        import subprocess
        result = subprocess.run(
            [cli_path, '--configure', tmp_path],
            capture_output=True, text=True, timeout=120,
            env={**os.environ, 'PYTHONIOENCODING': 'utf-8'}
        )
        
        # Cleanup
        try:
            os.unlink(tmp_path)
        except:
            pass
        
        if result.returncode == 0:
            return jsonify({
                "success": True,
                "message": f"Configurazione importata con successo!\n{result.stdout}",
                "stdout": result.stdout
            })
        else:
            return jsonify({
                "success": False,
                "error": f"Errore import: {result.stderr or result.stdout}",
                "stdout": result.stdout,
                "stderr": result.stderr
            })
    except subprocess.TimeoutExpired:
        return jsonify({"success": False, "error": "Timeout (120s) — dispositivo non risponde"})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)})

# ═══════════════════════════════════════════════════════════
# API CLI — Esecuzione comandi Meshtastic reali
# ═══════════════════════════════════════════════════════════

import subprocess
import shutil
import shlex

def _find_meshtastic_cli():
    """Trova il percorso del CLI meshtastic, cross-platform"""
    path = shutil.which("meshtastic")
    if path:
        return path
    # Fallback Windows: cerca nel Python Scripts
    import sys
    scripts_dir = os.path.join(os.path.dirname(sys.executable), "Scripts")
    win_path = os.path.join(scripts_dir, "meshtastic.exe")
    if os.path.exists(win_path):
        return win_path
    # Fallback Linux/Mac: cerca in ~/.local/bin
    local_path = os.path.expanduser("~/.local/bin/meshtastic")
    if os.path.exists(local_path):
        return local_path
    return None

@app.route('/api/cli/execute', methods=['POST'])
def api_cli_execute():
    """Esegue un comando meshtastic CLI con porta opzionale"""
    # Mutex USB esclusivo: se Monitor attivo, blocca
    _busy = _monitor_busy_response()
    if _busy is not None:
        return _busy
    data = request.get_json() or {}
    command = data.get("command", "").strip()
    port = data.get("port", "").strip()  # Porta USB selezionata dall'utente
    
    # Whitelist comandi sicuri
    SAFE_COMMANDS = [
        "--info", "--nodes", "--get all", "--export-config",
        "--version", "--noproto", "--ble-scan",
        "--factory-reset", "--reboot", "--reset-nodedb",
        "--listen", "--qr",
    ]
    SAFE_PREFIXES = [
        "--set ", "--set-owner", "--set-ham", "--ch-set", "--ch-set-url",
        "--setlat", "--setlon", "--setalt", "--sendtext",
        "--port ", "--get ", "--remove-position",
        "--configure ", "--dest ", "--ch-index",
    ]
    
    if not command:
        return jsonify({"error": "Comando vuoto"}), 400
    
    # Verifica che il comando sia sicuro
    is_safe = any(command == s or command.startswith(s) for s in SAFE_COMMANDS)
    if not is_safe:
        is_safe = any(command.startswith(p) for p in SAFE_PREFIXES)
    if not is_safe:
        return jsonify({"error": f"Comando non permesso: {command}"}), 403
    
    # Verifica CLI installato
    cli_path = _find_meshtastic_cli()
    if not cli_path:
        return jsonify({
            "error": "Meshtastic CLI non trovato! Installa con: pip install meshtastic",
            "install_command": "pip install --upgrade meshtastic"
        }), 404
    
    # Costruisci il comando — porta + comando
    try:
        cmd_parts = shlex.split(command)
    except ValueError:
        cmd_parts = command.split()
    
    # Prependi --port se specificata E il comando non ha già --port
    args = [cli_path]
    if port and '--port' not in command:
        args += ['--port', port]
    args += cmd_parts
    
    import time as _time
    start = _time.time()
    
    # Comandi pesanti che richiedono più tempo (200 nodi = ~60s)
    heavy_cmds = ['--export-config', '--nodes', '--info', '--get all', '--listen']
    timeout_secs = 90 if any(h in command for h in heavy_cmds) else 30
    
    try:
        # CRITICO su Windows: forzare encoding UTF-8 con errors=replace
        # Senza questo, nomi nodi con emoji (👮🌐🥭⚡) crashano con cp1252
        import platform as _plat
        env = {**os.environ, 'PYTHONIOENCODING': 'utf-8'}
        
        if _plat.system() == 'Windows':
            # Windows: usa CREATE_NO_WINDOW + encoding esplicito
            result = subprocess.run(
                args,
                capture_output=True, text=True,
                timeout=timeout_secs,
                env=env,
                encoding='utf-8',
                errors='replace',
                creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0)
            )
        else:
            result = subprocess.run(
                args,
                capture_output=True, text=True,
                timeout=timeout_secs,
                env=env,
                encoding='utf-8',
                errors='replace'
            )
        
        elapsed = round(_time.time() - start, 2)
        full_cmd = f"meshtastic {'--port '+port+' ' if port else ''}{command}"
        
        # None-safe: stdout/stderr possono essere None
        stdout = (result.stdout or '').strip()
        stderr = (result.stderr or '').strip()
        
        return jsonify({
            "command": full_cmd,
            "port": port or "auto-detect",
            "stdout": f"{stdout}\n⏱️ {elapsed}s" if stdout else f"(nessun output) ⏱️ {elapsed}s",
            "stderr": stderr,
            "returncode": result.returncode,
            "success": result.returncode == 0,
            "elapsed": elapsed,
        })
    except subprocess.TimeoutExpired:
        elapsed = round(_time.time() - start, 2)
        return jsonify({"error": f"Timeout ({timeout_secs}s). Il nodo ha molti dati — riprova o usa un comando più leggero.", "elapsed": elapsed}), 504
    except UnicodeDecodeError as e:
        # Fallback per encoding issues residui
        return jsonify({"error": f"Errore encoding: {str(e)}. Prova a riavviare l'app.", "success": False}), 500
    except Exception as e:
        return jsonify({"error": f"Errore: {str(e)}"}), 500

@app.route('/api/cli/check', methods=['GET'])
def api_cli_check():
    """Verifica se meshtastic CLI è installato"""
    cli_path = _find_meshtastic_cli()
    if cli_path:
        try:
            result = subprocess.run(
                [cli_path, "--version"],
                capture_output=True, text=True, timeout=5,
                env={**os.environ, 'PYTHONIOENCODING': 'utf-8'},
                encoding='utf-8', errors='replace'
            )
            stdout = (result.stdout or '').strip()
            stderr = (result.stderr or '').strip()
            return jsonify({
                "installed": True,
                "path": cli_path,
                "version": stdout or stderr or "trovato",
            })
        except Exception:
            return jsonify({"installed": True, "path": cli_path, "version": "trovato"})
    return jsonify({
        "installed": False,
        "install_command": "pip install --upgrade meshtastic",
    })

@app.route('/api/cli/install', methods=['POST'])
def api_cli_install():
    """Installa o aggiorna meshtastic CLI via pip (stesso Python dell'app)"""
    import sys

    python_exe = sys.executable
    if not python_exe:
        return jsonify({"success": False, "error": "Python interpreter non trovato"}), 500

    data = request.get_json() or {}
    package = data.get("package", "meshtastic")  # Supporta installazione di qualsiasi pacchetto
    # Whitelist pacchetti consentiti (sicurezza)
    ALLOWED = {"meshtastic", "flask", "flask-cors", "pyserial", "cryptography",
               "qrcode", "qrcode[pil]", "Pillow", "esptool"}
    if package not in ALLOWED:
        return jsonify({"success": False, "error": f"Pacchetto non consentito: {package}"}), 403

    import platform as _plat
    env = {**os.environ, 'PYTHONIOENCODING': 'utf-8'}
    base_kwargs = dict(
        capture_output=True, text=True,
        timeout=180,
        env=env,
        encoding='utf-8',
        errors='replace'
    )
    if _plat.system() == 'Windows':
        base_kwargs['creationflags'] = getattr(subprocess, 'CREATE_NO_WINDOW', 0)

    # ── Verifica che pip sia disponibile ──────────────────────
    try:
        subprocess.run([python_exe, '-m', 'pip', '--version'],
                       capture_output=True, timeout=10)
    except Exception:
        # pip non trovato — prova ensurepip
        try:
            subprocess.run([python_exe, '-m', 'ensurepip', '--upgrade'],
                           capture_output=True, timeout=60)
        except Exception:
            return jsonify({
                "success": False,
                "error": "pip non trovato e impossibile installarlo. Esegui: python -m ensurepip --upgrade"
            })

    # ── Tentativo 1: installazione normale ────────────────────
    cmd_args = [python_exe, '-m', 'pip', 'install', '--upgrade', package]
    try:
        result = subprocess.run(cmd_args, **base_kwargs)
        stdout = (result.stdout or '').strip()
        stderr = (result.stderr or '').strip()

        if result.returncode == 0:
            cli_path = _find_meshtastic_cli() if package == 'meshtastic' else None
            return jsonify({
                "success": True,
                "installed_now": True,
                "stdout": stdout,
                "stderr": stderr,
                "cli_path": cli_path or "",
            })

        # ── Tentativo 2: con --user (no permessi admin) ──────
        cmd_user = [python_exe, '-m', 'pip', 'install', '--user', '--upgrade', package]
        result2 = subprocess.run(cmd_user, **base_kwargs)
        stdout2 = (result2.stdout or '').strip()
        stderr2 = (result2.stderr or '').strip()

        if result2.returncode == 0:
            cli_path = _find_meshtastic_cli() if package == 'meshtastic' else None
            return jsonify({
                "success": True,
                "installed_now": True,
                "stdout": stdout2,
                "stderr": stderr2,
                "method": "--user",
                "cli_path": cli_path or "",
            })

        # Entrambi i tentativi falliti — restituisci errore dettagliato
        combined_err = stderr or stderr2 or stdout or stdout2 or "pip ha restituito errore senza dettagli"
        return jsonify({
            "success": False,
            "error": combined_err,
            "stdout": stdout or stdout2,
            "stderr": stderr or stderr2,
            "returncode": result.returncode,
        })

    except subprocess.TimeoutExpired:
        return jsonify({"success": False, "error": "Timeout (180s) — connessione lenta, riprova"}), 504
    except Exception as e:
        return jsonify({"success": False, "error": f"Errore: {str(e)}"}), 500

@app.route('/api/cli/exec', methods=['POST'])
def api_cli_exec():
    """Esegue un comando meshtastic CLI — endpoint MOD (accetta formato args)"""
    # Mutex USB esclusivo: se Monitor attivo, blocca
    _busy = _monitor_busy_response()
    if _busy is not None:
        return _busy
    data = request.get_json() or {}
    args_str = data.get("args", "").strip()
    timeout_req = data.get("timeout", 60)
    
    if not args_str:
        return jsonify({"error": "Argomenti vuoti", "not_found": False}), 400
    
    cli_path = _find_meshtastic_cli()
    if not cli_path:
        return jsonify({
            "not_found": True,
            "error": "Meshtastic CLI non trovato! Installa con: pip install meshtastic",
        })
    
    # Costruisci comando
    try:
        cmd_parts = shlex.split(args_str)
    except ValueError:
        cmd_parts = args_str.split()
    
    args = [cli_path]
    # Aggiungi porta se selezionata e non già presente
    port = data.get("port", "")
    if not port:
        # Cerca nell'header o nei cookie — non c'è, usa dalla request
        pass
    if port and '--port' not in args_str:
        args += ['--port', port]
    args += cmd_parts
    
    import time as _time
    import platform as _plat
    start = _time.time()
    timeout_secs = min(max(int(timeout_req), 10), 300)  # 10-300 secondi
    
    try:
        env = {**os.environ, 'PYTHONIOENCODING': 'utf-8'}
        
        if _plat.system() == 'Windows':
            result = subprocess.run(
                args, capture_output=True, text=True,
                timeout=timeout_secs, env=env,
                encoding='utf-8', errors='replace',
                creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0)
            )
        else:
            result = subprocess.run(
                args, capture_output=True, text=True,
                timeout=timeout_secs, env=env,
                encoding='utf-8', errors='replace'
            )
        
        elapsed = round(_time.time() - start, 2)
        stdout = (result.stdout or '').strip()
        stderr = (result.stderr or '').strip()
        
        return jsonify({
            "stdout": f"{stdout}\n⏱️ {elapsed}s" if stdout else f"(nessun output) ⏱️ {elapsed}s",
            "stderr": stderr,
            "returncode": result.returncode,
            "success": result.returncode == 0,
            "elapsed": elapsed,
        })
    except subprocess.TimeoutExpired:
        return jsonify({"error": f"Timeout ({timeout_secs}s)", "stdout": "", "stderr": ""})
    except Exception as e:
        return jsonify({"error": str(e), "stdout": "", "stderr": ""})

# ═══════════════════════════════════════════════════════════
# 🩺 AUTO-DIAGNOSI & RECOVERY — Controllo compatibilità versioni
# ═══════════════════════════════════════════════════════════

# Versioni Python supportate (testate e funzionanti con meshtastic)
_PYTHON_MIN = (3, 9)
_PYTHON_MAX_TESTED = (3, 14)  # 3.14 funzionante con meshtastic CLI 2.7.x

# Versioni raccomandate per dipendenze critiche
_RECOMMENDED_VERSIONS = {
    "meshtastic": {"min": "2.3.0", "max_tested": "2.7.99", "recommended": "2.5.2"},
    "protobuf":   {"min": "4.21.0", "max_tested": "5.99.0", "recommended": ""},
    "pyserial":   {"min": "3.5",   "max_tested": "3.99", "recommended": ""},
    "cryptography": {"min": "3.4", "max_tested": "46.99", "recommended": ""},
    "flask":      {"min": "2.0",   "max_tested": "3.99", "recommended": ""},
}

def _parse_version(v_str):
    """Converte '2.3.1' → (2,3,1) per confronto"""
    try:
        parts = v_str.replace('rc','.',).replace('a','.',).replace('b','.',).split('.')
        return tuple(int(x) for x in parts[:3] if x.isdigit())
    except Exception:
        return (0,)

def _version_in_range(version_str, min_v, max_v):
    """Verifica se una versione è nel range accettabile"""
    v = _parse_version(version_str)
    vmin = _parse_version(min_v) if min_v else (0,)
    vmax = _parse_version(max_v) if max_v else (99, 99, 99)
    return vmin <= v <= vmax

# ── SMART ERROR PARSER — riconosce Traceback e suggerisce fix ──

_ERROR_PATTERNS = [
    {
        "pattern": r"ModuleNotFoundError: No module named '(\w+)'",
        "type": "missing_module",
        "title_it": "Modulo Python mancante",
        "title_en": "Missing Python module",
        "fix_type": "install_package",
    },
    {
        "pattern": r"ImportError: cannot import name '(\w+)' from '(\w+)'",
        "type": "import_error",
        "title_it": "Versione incompatibile",
        "title_en": "Incompatible version",
        "fix_type": "upgrade_package",
    },
    {
        "pattern": r"TypeError:.*unexpected keyword argument",
        "type": "api_mismatch",
        "title_it": "API incompatibile — versione libreria errata",
        "title_en": "Incompatible API — wrong library version",
        "fix_type": "reinstall_package",
    },
    {
        "pattern": r"google\.protobuf|protobuf",
        "type": "protobuf_error",
        "title_it": "Errore protobuf — versione incompatibile",
        "title_en": "Protobuf error — incompatible version",
        "fix_type": "fix_protobuf",
    },
    {
        "pattern": r"serial\.serialutil\.SerialException|could not open port|PermissionError.*serial|Access is denied",
        "type": "serial_error",
        "title_it": "Errore porta seriale",
        "title_en": "Serial port error",
        "fix_type": "serial_fix",
    },
    {
        "pattern": r"serial\.tools\.list_ports|No module named 'serial'",
        "type": "missing_serial",
        "title_it": "PySerial mancante",
        "title_en": "PySerial missing",
        "fix_type": "install_package",
    },
    {
        "pattern": r"FileNotFoundError.*meshtastic|meshtastic.*not found|No such file or directory.*meshtastic",
        "type": "cli_not_found",
        "title_it": "Meshtastic CLI non trovato",
        "title_en": "Meshtastic CLI not found",
        "fix_type": "install_package",
    },
    {
        "pattern": r"TimeoutError|timed out|Timeout waiting",
        "type": "timeout_error",
        "title_it": "Timeout comunicazione dispositivo",
        "title_en": "Device communication timeout",
        "fix_type": "device_fix",
    },
    {
        "pattern": r"Exception.*mesh_interface|mesh_interface.*Exception|common\(\)",
        "type": "mesh_interface_crash",
        "title_it": "Crash interfaccia Meshtastic — versione Python/libreria incompatibile",
        "title_en": "Meshtastic interface crash — incompatible Python/library version",
        "fix_type": "reinstall_meshtastic",
    },
    {
        "pattern": r"DeprecationWarning|SyntaxWarning.*invalid escape",
        "type": "deprecation_warning",
        "title_it": "Avvisi deprecazione — versione Python troppo nuova",
        "title_en": "Deprecation warnings — Python version too new",
        "fix_type": "check_python_version",
    },
    {
        "pattern": r"OSError.*WinError|OSError \[Errno|WindowsError",
        "type": "os_error",
        "title_it": "Errore di sistema operativo",
        "title_en": "Operating system error",
        "fix_type": "os_fix",
    },
    {
        "pattern": r"pip.*externally-managed|externally-managed-environment",
        "type": "pip_managed",
        "title_it": "Ambiente Python gestito dal sistema",
        "title_en": "System-managed Python environment",
        "fix_type": "pip_user_install",
    },
]

# Mappa moduli Python → pacchetti pip
_MODULE_TO_PIP = {
    "meshtastic": "meshtastic",
    "serial": "pyserial",
    "google.protobuf": "protobuf",
    "google": "protobuf",
    "protobuf": "protobuf",
    "yaml": "pyyaml",
    "PIL": "Pillow",
    "cryptography": "cryptography",
    "flask": "flask",
    "flask_cors": "flask-cors",
    "qrcode": "qrcode[pil]",
    "esptool": "esptool",
    "tabulate": "tabulate",
    "pypubsub": "pypubsub",
    "bleak": "bleak",
    "dotmap": "dotmap",
    "pexpect": "pexpect",
    "packaging": "packaging",
    "requests": "requests",
    "print_color": "print-color",
}

def _analyze_error(error_text):
    """Analizza un testo errore e ritorna diagnosi + fix suggeriti"""
    import re
    if not error_text:
        return None

    results = []
    for pattern_info in _ERROR_PATTERNS:
        match = re.search(pattern_info["pattern"], error_text, re.IGNORECASE | re.DOTALL)
        if match:
            diagnosis = {
                "type": pattern_info["type"],
                "title_it": pattern_info["title_it"],
                "title_en": pattern_info["title_en"],
                "fix_type": pattern_info["fix_type"],
                "match": match.group(0)[:200],
                "groups": list(match.groups()) if match.groups() else [],
            }

            # Genera fix specifici basati sul tipo
            if pattern_info["fix_type"] == "install_package":
                module_name = match.group(1) if match.lastindex else "meshtastic"
                pip_pkg = _MODULE_TO_PIP.get(module_name, module_name)
                diagnosis["fix_command"] = f"pip install --upgrade {pip_pkg}"
                diagnosis["fix_package"] = pip_pkg
                diagnosis["fix_action"] = "install"

            elif pattern_info["fix_type"] == "upgrade_package":
                module_name = match.group(2) if match.lastindex and match.lastindex >= 2 else "meshtastic"
                pip_pkg = _MODULE_TO_PIP.get(module_name, module_name)
                diagnosis["fix_command"] = f"pip install --upgrade {pip_pkg}"
                diagnosis["fix_package"] = pip_pkg
                diagnosis["fix_action"] = "upgrade"

            elif pattern_info["fix_type"] in ("reinstall_package", "reinstall_meshtastic"):
                diagnosis["fix_command"] = "pip install --force-reinstall meshtastic"
                diagnosis["fix_package"] = "meshtastic"
                diagnosis["fix_action"] = "reinstall"

            elif pattern_info["fix_type"] == "fix_protobuf":
                diagnosis["fix_command"] = "pip install --upgrade protobuf meshtastic"
                diagnosis["fix_package"] = "protobuf"
                diagnosis["fix_action"] = "upgrade"

            elif pattern_info["fix_type"] == "serial_fix":
                diagnosis["fix_action"] = "serial_troubleshoot"
                diagnosis["fix_steps"] = [
                    "Verifica cavo USB (dati, non solo ricarica)",
                    "Riavvia il dispositivo",
                    "Chiudi altri programmi che usano la porta",
                    "Installa driver CP210x o CH340",
                    "Linux: sudo usermod -a -G dialout $USER",
                ]

            elif pattern_info["fix_type"] == "device_fix":
                diagnosis["fix_action"] = "device_troubleshoot"
                diagnosis["fix_steps"] = [
                    "Riavvia il dispositivo Meshtastic",
                    "Prova un altro cavo USB",
                    "Reset NodeDB: meshtastic --reset-nodedb",
                    "Verifica porta USB selezionata",
                ]

            elif pattern_info["fix_type"] == "check_python_version":
                import sys
                diagnosis["fix_action"] = "python_version_warning"
                diagnosis["python_version"] = f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"

            elif pattern_info["fix_type"] == "pip_user_install":
                diagnosis["fix_command"] = "pip install --user --upgrade meshtastic"
                diagnosis["fix_package"] = "meshtastic"
                diagnosis["fix_action"] = "install_user"

            elif pattern_info["fix_type"] == "os_fix":
                diagnosis["fix_action"] = "os_troubleshoot"
                diagnosis["fix_steps"] = [
                    "Riavvia l'app come amministratore",
                    "Controlla permessi sulla cartella app",
                    "Verifica antivirus non blocchi l'accesso",
                ]

            results.append(diagnosis)

    return results if results else None


@app.route('/api/deps/diagnose', methods=['GET'])
def api_deps_diagnose():
    """Diagnosi COMPLETA: versioni Python, compatibilità librerie, driver USB, stato CLI"""
    import sys
    import re

    issues = []       # Problemi trovati
    warnings = []     # Avvisi non bloccanti
    info = []         # Info generali

    # ── 1. CHECK VERSIONE PYTHON ──────────────────────────────
    py_v = sys.version_info
    py_str = f"{py_v.major}.{py_v.minor}.{py_v.micro}"
    py_ok = True

    if py_v < _PYTHON_MIN:
        issues.append({
            "area": "python",
            "severity": "critical",
            "title": f"Python {py_str} troppo vecchio",
            "detail": f"Serve Python {_PYTHON_MIN[0]}.{_PYTHON_MIN[1]}+. Versione attuale: {py_str}",
            "fix_action": "upgrade_python",
            "fix_url": "https://www.python.org/downloads/",
        })
        py_ok = False
    elif (py_v.major, py_v.minor) > _PYTHON_MAX_TESTED:
        issues.append({
            "area": "python",
            "severity": "high",
            "title": f"Python {py_str} non ancora supportato da meshtastic",
            "detail": f"Python {py_str} potrebbe non essere compatibile con meshtastic CLI. Versione raccomandata: 3.11 o 3.12",
            "fix_action": "downgrade_python",
            "fix_url": "https://www.python.org/downloads/release/python-3120/",
        })

    info.append({"label": "Python", "value": py_str, "path": sys.executable, "ok": py_ok})

    # ── 2. CHECK VERSIONI LIBRERIE ────────────────────────────
    deps_status = []
    for dep_name, constraints in _RECOMMENDED_VERSIONS.items():
        try:
            if dep_name == "pyserial":
                mod = __import__("serial")
            elif dep_name == "protobuf":
                mod = __import__("google.protobuf")
                # __import__ restituisce il pacchetto top-level 'google',
                # quindi navighiamo al sotto-modulo corretto
                import importlib
                mod = importlib.import_module("google.protobuf")
            else:
                mod = __import__(dep_name)
            version = getattr(mod, '__version__', getattr(mod, 'VERSION', None))
            if version:
                version = str(version)
                in_range = _version_in_range(version, constraints["min"], constraints["max_tested"])
                dep_info = {"name": dep_name, "installed": True, "version": version, "ok": in_range}
                if not in_range:
                    if _parse_version(version) < _parse_version(constraints["min"]):
                        issues.append({
                            "area": "library",
                            "severity": "high",
                            "title": f"{dep_name} {version} troppo vecchio",
                            "detail": f"Versione minima richiesta: {constraints['min']}",
                            "fix_action": "upgrade",
                            "fix_package": _MODULE_TO_PIP.get(dep_name, dep_name),
                            "fix_command": f"pip install --upgrade {_MODULE_TO_PIP.get(dep_name, dep_name)}",
                        })
                    else:
                        warnings.append({
                            "area": "library",
                            "severity": "medium",
                            "title": f"{dep_name} {version} non testato",
                            "detail": f"Versione non verificata — potrebbe funzionare ma non è garantito",
                            "fix_action": "reinstall",
                            "fix_package": _MODULE_TO_PIP.get(dep_name, dep_name),
                        })
                deps_status.append(dep_info)
            else:
                deps_status.append({"name": dep_name, "installed": True, "version": "?", "ok": True})
        except ImportError:
            deps_status.append({"name": dep_name, "installed": False, "version": None, "ok": False})
            pip_pkg = _MODULE_TO_PIP.get(dep_name, dep_name)
            issues.append({
                "area": "library",
                "severity": "critical",
                "title": f"{dep_name} non installato",
                "detail": f"Libreria mancante: {dep_name}",
                "fix_action": "install",
                "fix_package": pip_pkg,
                "fix_command": f"pip install {pip_pkg}",
            })

    # ── 3. CHECK MESHTASTIC CLI — versione e funzionamento ────
    cli_path = _find_meshtastic_cli()
    cli_ok = False
    cli_version = None
    cli_error = None

    if cli_path:
        try:
            import platform as _plat
            env = {**os.environ, 'PYTHONIOENCODING': 'utf-8'}
            kwargs = dict(capture_output=True, text=True, timeout=10,
                         env=env, encoding='utf-8', errors='replace')
            if _plat.system() == 'Windows':
                kwargs['creationflags'] = getattr(subprocess, 'CREATE_NO_WINDOW', 0)

            result = subprocess.run([cli_path, "--version"], **kwargs)
            stdout = (result.stdout or '').strip()
            stderr = (result.stderr or '').strip()

            if result.returncode == 0:
                # Estrai versione da output
                ver_match = re.search(r'(\d+\.\d+\.\d+)', stdout or stderr)
                cli_version = ver_match.group(1) if ver_match else (stdout or stderr)
                cli_ok = True

                # Verifica compatibilità versione CLI
                if ver_match:
                    mesh_constraints = _RECOMMENDED_VERSIONS.get("meshtastic", {})
                    if not _version_in_range(ver_match.group(1),
                                             mesh_constraints.get("min", "2.0.0"),
                                             mesh_constraints.get("max_tested", "9.9.9")):
                        warnings.append({
                            "area": "cli",
                            "severity": "medium",
                            "title": f"Meshtastic CLI {ver_match.group(1)} — versione non testata",
                            "detail": "Potrebbe avere incompatibilità",
                            "fix_action": "reinstall",
                            "fix_package": "meshtastic",
                            "fix_command": "pip install --force-reinstall meshtastic",
                        })
            else:
                # CLI trovato ma errore all'esecuzione
                cli_error = stderr or stdout
                error_analysis = _analyze_error(cli_error)
                if error_analysis:
                    for diag in error_analysis:
                        issues.append({
                            "area": "cli",
                            "severity": "critical",
                            "title": diag["title_it"],
                            "detail": diag.get("match", "")[:200],
                            "fix_action": diag.get("fix_action", "reinstall"),
                            "fix_package": diag.get("fix_package", "meshtastic"),
                            "fix_command": diag.get("fix_command", "pip install --force-reinstall meshtastic"),
                        })
                else:
                    issues.append({
                        "area": "cli",
                        "severity": "critical",
                        "title": "Meshtastic CLI errore all'avvio",
                        "detail": (cli_error or "errore sconosciuto")[:300],
                        "fix_action": "reinstall",
                        "fix_package": "meshtastic",
                        "fix_command": "pip install --force-reinstall meshtastic",
                    })
        except subprocess.TimeoutExpired:
            cli_error = "Timeout (10s) verificando CLI"
            issues.append({
                "area": "cli",
                "severity": "high",
                "title": "Timeout verifica CLI",
                "detail": "meshtastic --version non risponde in 10 secondi",
                "fix_action": "reinstall",
                "fix_package": "meshtastic",
            })
        except Exception as e:
            cli_error = str(e)
    else:
        issues.append({
            "area": "cli",
            "severity": "critical",
            "title": "Meshtastic CLI non installato",
            "detail": "Il comando meshtastic non è stato trovato nel sistema",
            "fix_action": "install",
            "fix_package": "meshtastic",
            "fix_command": "pip install meshtastic",
        })

    info.append({"label": "Meshtastic CLI", "value": cli_version or "non trovato",
                 "path": cli_path or "", "ok": cli_ok, "error": cli_error})

    # ── 4. CHECK DRIVER USB ───────────────────────────────────
    driver_info = check_driver_installed()
    ports = list_serial_ports()
    info.append({"label": "Porte USB", "value": f"{len(ports)} trovate", "ok": len(ports) > 0})

    # ── 5. CHECK pip ──────────────────────────────────────────
    pip_ok = False
    pip_version = None
    try:
        r = subprocess.run([sys.executable, '-m', 'pip', '--version'],
                          capture_output=True, text=True, timeout=10,
                          encoding='utf-8', errors='replace')
        if r.returncode == 0:
            pip_ok = True
            pip_version = (r.stdout or '').split(' ')[1] if r.stdout else '?'
    except Exception:
        pass
    info.append({"label": "pip", "value": pip_version or "non trovato", "ok": pip_ok})

    # ── SCORE complessivo ─────────────────────────────────────
    critical_count = sum(1 for i in issues if i.get("severity") == "critical")
    high_count = sum(1 for i in issues if i.get("severity") == "high")
    score = 100 - (critical_count * 30) - (high_count * 15) - (len(warnings) * 5)
    score = max(0, min(100, score))

    status = "ok" if score >= 80 else ("warning" if score >= 50 else "critical")

    return jsonify({
        "status": status,
        "score": score,
        "issues": issues,
        "warnings": warnings,
        "info": info,
        "deps": deps_status,
        "python_version": py_str,
        "python_path": sys.executable,
        "cli_version": cli_version,
        "cli_path": cli_path,
        "cli_ok": cli_ok,
        "ports_count": len(ports),
        "pip_ok": pip_ok,
        "pip_version": pip_version,
    })


@app.route('/api/deps/fix', methods=['POST'])
def api_deps_fix():
    """Fix mirato: installa/aggiorna/reinstalla un pacchetto specifico con versione"""
    import sys
    data = request.get_json() or {}
    action = data.get("action", "install")     # install | upgrade | reinstall | uninstall_reinstall
    package = data.get("package", "meshtastic")
    version = data.get("version", "")          # Versione specifica opzionale

    ALLOWED = {"meshtastic", "flask", "flask-cors", "pyserial", "cryptography",
               "qrcode", "qrcode[pil]", "Pillow", "esptool", "protobuf",
               "pypubsub", "dotmap", "pexpect", "tabulate", "bleak",
               "packaging", "requests", "print-color", "pyyaml"}
    if package not in ALLOWED:
        return jsonify({"success": False, "error": f"Pacchetto non consentito: {package}"}), 403

    import platform as _plat
    env = {**os.environ, 'PYTHONIOENCODING': 'utf-8'}
    base_kwargs = dict(capture_output=True, text=True, timeout=300,
                      env=env, encoding='utf-8', errors='replace')
    if _plat.system() == 'Windows':
        base_kwargs['creationflags'] = getattr(subprocess, 'CREATE_NO_WINDOW', 0)

    steps = []
    success = False

    try:
        # Step 1: Se reinstall → prima disinstalla
        if action in ("reinstall", "uninstall_reinstall"):
            cmd_uninstall = [sys.executable, '-m', 'pip', 'uninstall', '-y', package]
            r = subprocess.run(cmd_uninstall, **base_kwargs)
            steps.append({
                "step": "uninstall",
                "command": ' '.join(cmd_uninstall),
                "success": r.returncode == 0,
                "output": ((r.stdout or '') + '\n' + (r.stderr or '')).strip()[:500],
            })

        # Step 2: Installa (con versione specifica se indicata)
        pkg_spec = f"{package}=={version}" if version else package
        cmd_install = [sys.executable, '-m', 'pip', 'install', '--upgrade', pkg_spec]
        if action == "reinstall":
            cmd_install = [sys.executable, '-m', 'pip', 'install', '--force-reinstall', pkg_spec]

        r = subprocess.run(cmd_install, **base_kwargs)
        stdout = (r.stdout or '').strip()
        stderr = (r.stderr or '').strip()

        if r.returncode == 0:
            success = True
            steps.append({
                "step": "install",
                "command": ' '.join(cmd_install),
                "success": True,
                "output": stdout[:500],
            })
        else:
            # Fallback --user
            cmd_user = cmd_install + ['--user'] if '--user' not in cmd_install else cmd_install
            cmd_user = [sys.executable, '-m', 'pip', 'install', '--user', '--upgrade', pkg_spec]
            r2 = subprocess.run(cmd_user, **base_kwargs)
            if r2.returncode == 0:
                success = True
                steps.append({
                    "step": "install_user",
                    "command": ' '.join(cmd_user),
                    "success": True,
                    "output": (r2.stdout or '').strip()[:500],
                })
            else:
                steps.append({
                    "step": "install_failed",
                    "command": ' '.join(cmd_install),
                    "success": False,
                    "output": (stderr or (r2.stderr or '') or "Installazione fallita")[:500],
                })

        # Step 3: Verifica post-install
        if success and package == "meshtastic":
            cli_path = _find_meshtastic_cli()
            if cli_path:
                try:
                    vr = subprocess.run([cli_path, "--version"],
                                       capture_output=True, text=True, timeout=10,
                                       encoding='utf-8', errors='replace')
                    steps.append({
                        "step": "verify",
                        "success": vr.returncode == 0,
                        "output": ((vr.stdout or '') + ' ' + (vr.stderr or '')).strip()[:200],
                    })
                except Exception:
                    pass

        return jsonify({
            "success": success,
            "action": action,
            "package": package,
            "version": version or "latest",
            "steps": steps,
        })

    except subprocess.TimeoutExpired:
        return jsonify({"success": False, "error": "Timeout (300s)", "steps": steps}), 504
    except Exception as e:
        return jsonify({"success": False, "error": str(e), "steps": steps}), 500


@app.route('/api/error/analyze', methods=['POST'])
def api_error_analyze():
    """Analizza un testo errore (Traceback) e suggerisce fix"""
    data = request.get_json() or {}
    error_text = data.get("error", "")

    if not error_text:
        return jsonify({"diagnoses": [], "message": "Nessun errore fornito"})

    diagnoses = _analyze_error(error_text)
    if diagnoses:
        return jsonify({
            "found": True,
            "diagnoses": diagnoses,
            "count": len(diagnoses),
        })
    else:
        return jsonify({
            "found": False,
            "diagnoses": [],
            "message": "Errore non riconosciuto — controlla manualmente",
        })


# ═══════════════════════════════════════════════════════════
# 📡 API MONITOR (PRO) — Scanner real-time pacchetti mesh
# ═══════════════════════════════════════════════════════════

def _require_pro():
    """Helper: verifica che la licenza sia PRO o PRO_MOD. Ritorna (ok, resp_tuple)."""
    try:
        lic = get_license_info() or {}
    except Exception as e:
        return False, (jsonify({"success": False, "error": f"license_check_failed: {e}"}), 500)
    status = (lic.get("status") or "").lower()
    if status in ("pro", "pro_mod"):
        return True, None
    return False, (jsonify({
        "success": False,
        "error": "requires_pro",
        "license_status": status,
        "message": "La sezione Monitor richiede una licenza PRO o PRO+MOD."
    }), 403)


def _monitor_busy_response():
    """Helper: se il Monitor è attivo, ritorna una Response 409 che blocca l'uso USB.
    Altrimenti ritorna None. La porta USB è esclusiva: Monitor vs CLI/Config/Flash.
    """
    try:
        if mesh_monitor.is_active():
            return jsonify({
                "success": False,
                "error": "monitor_active",
                "code": "USB_BUSY",
                "message": "Il Monitor è attivo e occupa la porta USB in modo esclusivo. Ferma il Monitor per usare CLI/Config/Flash."
            }), 409
    except Exception:
        # Se mesh_monitor non è accessibile, non bloccare
        return None
    return None


@app.route('/api/monitor/ports', methods=['GET'])
def api_monitor_ports():
    """Lista porte USB disponibili (alias di /api/system/ports per chiarezza)."""
    return jsonify({"ports": list_serial_ports(), "monitor_active": mesh_monitor.is_active()})


@app.route('/api/monitor/status', methods=['GET'])
def api_monitor_status():
    """Stato attuale del monitor (attivo/inattivo, contatori, soglie)."""
    return jsonify(mesh_monitor.get_status())


@app.route('/api/monitor/start', methods=['POST'])
def api_monitor_start():
    """Avvia il monitor su una porta. Richiede licenza PRO."""
    ok_pro, err_resp = _require_pro()
    if not ok_pro:
        return err_resp
    data = request.get_json(silent=True) or {}
    port = (data.get("port") or "").strip()
    if not port:
        return jsonify({"success": False, "error": "missing_port"}), 400
    # Whitelist base del nome porta (niente caratteri shell)
    if any(c in port for c in [';', '&', '|', '`', '$', '<', '>', '\n']):
        return jsonify({"success": False, "error": "invalid_port"}), 400
    ok, err = mesh_monitor.start(port)
    if not ok:
        return jsonify({"success": False, "error": err or "start_failed"}), 400
    return jsonify({"success": True, "port": port, "status": mesh_monitor.get_status()})


@app.route('/api/monitor/stop', methods=['POST'])
def api_monitor_stop():
    """Ferma il monitor e rilascia la porta USB."""
    ok_pro, err_resp = _require_pro()
    if not ok_pro:
        return err_resp
    ok, err = mesh_monitor.stop()
    if not ok:
        return jsonify({"success": False, "error": err or "stop_failed"}), 400
    return jsonify({"success": True})


@app.route('/api/monitor/stats', methods=['GET'])
def api_monitor_stats():
    """Classifiche nodi. Query: ?sort=total|rf|mqtt|spam|nodeinfo|text|recent&top=20"""
    ok_pro, err_resp = _require_pro()
    if not ok_pro:
        return err_resp
    sort_by = request.args.get("sort", "total")
    try:
        top = int(request.args.get("top", "20"))
        top = max(1, min(100, top))
    except Exception:
        top = 20
    return jsonify({
        "rows": mesh_monitor.get_stats(top=top, sort_by=sort_by),
        "status": mesh_monitor.get_status(),
    })


@app.route('/api/monitor/thresholds', methods=['GET', 'POST'])
def api_monitor_thresholds():
    """GET: soglie attuali. POST: aggiorna (body JSON con subset chiavi)."""
    ok_pro, err_resp = _require_pro()
    if not ok_pro:
        return err_resp
    if request.method == 'POST':
        data = request.get_json(silent=True) or {}
        if data.get("reset"):
            return jsonify(mesh_monitor.reset_thresholds())
        return jsonify(mesh_monitor.set_thresholds(data))
    return jsonify(mesh_monitor.get_thresholds())


@app.route('/api/monitor/thresholds/presets', methods=['GET'])
def api_monitor_thresholds_presets():
    """FASE 4 — Lista preset FW standard disponibili (LongFast/MediumFast/
    ShortFast/LongSlow/VeryLongSlow) con i rispettivi valori soglia.
    PRO-gated: l'enum è esposto solo a utenti PRO (no fingerprinting)."""
    ok_pro, err_resp = _require_pro()
    if not ok_pro:
        return err_resp
    return jsonify({
        "presets": list(mesh_monitor.FW_PRESETS.keys()),
        "values": {k: dict(v) for k, v in mesh_monitor.FW_PRESETS.items()},
        "active": mesh_monitor.get_thresholds().get("preset", "MediumFast"),
    })


@app.route('/api/monitor/thresholds/apply-preset', methods=['POST'])
def api_monitor_thresholds_apply_preset():
    """FASE 4 — Applica un preset FW standard. Body: {"preset": "LongFast"}."""
    ok_pro, err_resp = _require_pro()
    if not ok_pro:
        return err_resp
    data = request.get_json(silent=True) or {}
    preset = (data.get("preset") or "").strip()
    if not preset:
        return jsonify({"success": False, "error": "missing_preset"}), 400
    ok, result = mesh_monitor.apply_fw_preset(preset)
    if not ok:
        return jsonify({"success": False, **result}), 400
    return jsonify({"success": True, "thresholds": result})


@app.route('/api/monitor/stream', methods=['GET'])
def api_monitor_stream():
    """Stream SSE real-time dei pacchetti. Richiede licenza PRO."""
    ok_pro, err_resp = _require_pro()
    if not ok_pro:
        return err_resp
    from flask import Response
    try:
        last_id = int(request.headers.get("Last-Event-ID", "0"))
    except Exception:
        last_id = 0
    resp = Response(
        mesh_monitor.sse_stream_generator(last_event_id=last_id),
        mimetype='text/event-stream'
    )
    resp.headers['Cache-Control'] = 'no-cache'
    resp.headers['X-Accel-Buffering'] = 'no'
    resp.headers['Connection'] = 'keep-alive'
    return resp


# ═══════════════════════════════════════════════════════════
# 📊 API MONITOR STATISTICHE 7 GIORNI (PRO) — Leaderboard, timeline, export
# ═══════════════════════════════════════════════════════════

# Enrichment cache (5 min) — mai esporre il nome della fonte all'utente
_ENRICH_CACHE = {}          # node_id (str) → (ts, payload_dict)
_ENRICH_CACHE_TTL = 300     # 5 minuti
_ENRICH_LOCK = __import__('threading').Lock()

# Aggregator background thread (singleton, lazy start)
_AGG_STATE = {
    "thread": None,
    "started": False,
    "last_cleanup_ts": 0,
    "last_stats_ts": 0,
    "last_vacuum_ts": 0,
    "last_error": None,
}
_AGG_LOCK = __import__('threading').Lock()


def _aggregator_loop():
    """Background loop: pulizia oraria, stats daily, vacuum settimanale.
    Silent-fail su qualsiasi eccezione per non killare il server."""
    import time as _t
    while True:
        try:
            now = _t.time()
            # Cleanup + stats_daily ogni ora
            if now - _AGG_STATE["last_cleanup_ts"] >= 3600:
                try:
                    if _MDB_AVAILABLE:
                        mdb.cleanup_old()
                    _AGG_STATE["last_cleanup_ts"] = now
                except Exception as e:
                    _AGG_STATE["last_error"] = f"cleanup: {e}"
            if now - _AGG_STATE["last_stats_ts"] >= 3600:
                try:
                    if _MDB_AVAILABLE:
                        mdb.recompute_stats_daily()
                    _AGG_STATE["last_stats_ts"] = now
                except Exception as e:
                    _AGG_STATE["last_error"] = f"stats: {e}"
            # Vacuum ogni 7 giorni
            if now - _AGG_STATE["last_vacuum_ts"] >= 604800:
                try:
                    if _MDB_AVAILABLE:
                        mdb.vacuum()
                    _AGG_STATE["last_vacuum_ts"] = now
                except Exception as e:
                    _AGG_STATE["last_error"] = f"vacuum: {e}"
        except Exception as e:
            _AGG_STATE["last_error"] = f"loop: {e}"
        _t.sleep(60)  # wake-up ogni minuto per check cadenze


def _auto_seed_italia_psk_if_needed():
    """STEP 10 + STEP 13 — Auto-seed catalogo PSK Italia al primo avvio + self-healing.

    STEP 13 (2026-04-20): il gate non e' piu' solo "VoxLibera presente". Ora
    conta quante label del catalog sono effettivamente nel DB. Se count < expected
    riseed (upsert e' idempotente). Cosi' se l'utente aveva un catalog parziale
    o se il JSON viene aggiornato con nuove entry, la differenza viene recuperata.

    Ritorno (salvato anche in _AGG_STATE["italia_seed"]):
      {
        "expected": 36, "in_db_before": N, "in_db_after": N,
        "added": N, "updated": N, "unchanged": N, "errors": N,
        "skipped_reason": "ok|no_catalog|db_unavailable|load_error",
        "ts": ISO
      }
    Eventuali errori vengono loggati ma NON bloccano lo start dell'aggregator.
    """
    from datetime import datetime as _dt
    _stat = {
        "expected": 0, "in_db_before": 0, "in_db_after": 0,
        "added": 0, "updated": 0, "unchanged": 0, "errors": 0,
        "skipped_reason": None, "ts": _dt.utcnow().isoformat() + "Z",
    }
    if not _MDB_AVAILABLE:
        _stat["skipped_reason"] = "db_unavailable"
        try:
            _AGG_STATE["italia_seed"] = _stat
        except Exception:
            pass
        return _stat
    import json as _json
    import os as _os
    _cat_path = _os.path.join(_base_dir, 'psk_catalog_italia.json')
    if not _os.path.isfile(_cat_path):
        _stat["skipped_reason"] = "no_catalog"
        try:
            _AGG_STATE["italia_seed"] = _stat
        except Exception:
            pass
        return _stat
    try:
        with open(_cat_path, 'r', encoding='utf-8') as _f:
            _cat = _json.load(_f)
    except Exception as _e:
        _stat["skipped_reason"] = "load_error"
        _stat["error"] = str(_e)
        try:
            _AGG_STATE["italia_seed"] = _stat
        except Exception:
            pass
        return _stat
    _entries = _cat.get('entries') or []
    if not isinstance(_entries, list) or not _entries:
        _stat["skipped_reason"] = "no_catalog"
        try:
            _AGG_STATE["italia_seed"] = _stat
        except Exception:
            pass
        return _stat
    _stat["expected"] = len(_entries)
    # Count labels del catalog che sono gia' nel DB
    try:
        _db_labels = set()
        for _r in (mdb.psk_list() or []):
            _lbl = str(_r.get('label', '')).strip()
            if _lbl:
                _db_labels.add(_lbl)
    except Exception:
        _db_labels = set()
    _cat_labels = [str(_e.get('label') or '').strip() for _e in _entries if _e.get('label')]
    _present = sum(1 for _l in _cat_labels if _l in _db_labels)
    _stat["in_db_before"] = _present
    # Self-healing: se mancano entry OPPURE se sentinel VoxLibera assente, riseed
    _has_vox = 'VoxLibera' in _db_labels
    _needs_seed = (_present < _stat["expected"]) or (not _has_vox)
    if not _needs_seed:
        _stat["skipped_reason"] = "ok"
        _stat["in_db_after"] = _present
        try:
            _AGG_STATE["italia_seed"] = _stat
        except Exception:
            pass
        return _stat
    # Upsert di tutte le entries (idempotente)
    for _e in _entries:
        try:
            _label = str(_e.get('label') or '').strip()
            _psk = str(_e.get('psk_b64') or '').strip()
            if not _label or not _psk:
                _stat["errors"] += 1
                continue
            _res = mdb.psk_add_or_update(
                label=_label,
                psk_b64=_psk,
                kind=_e.get('kind') or 'private',
                channel_name=_e.get('channel_name'),
                notes=_e.get('notes'),
            ) or {}
            if 'added' in _res:
                _stat["added"] += 1
            elif 'updated' in _res:
                _stat["updated"] += 1
            elif 'unchanged' in _res:
                _stat["unchanged"] += 1
            elif 'error' in _res:
                _stat["errors"] += 1
        except Exception:
            _stat["errors"] += 1
            continue
    # Count finale
    try:
        _db_labels = set()
        for _r in (mdb.psk_list() or []):
            _lbl = str(_r.get('label', '')).strip()
            if _lbl:
                _db_labels.add(_lbl)
        _stat["in_db_after"] = sum(1 for _l in _cat_labels if _l in _db_labels)
    except Exception:
        _stat["in_db_after"] = _present
    _stat["skipped_reason"] = "ok"
    try:
        _AGG_STATE["italia_seed"] = _stat
        # Backward-compat: mantieni anche la vecchia chiave per audit
        _AGG_STATE["italia_seed_added"] = _stat["added"]
    except Exception:
        pass
    return _stat


def _ensure_aggregator_started():
    """Avvia il thread aggregator la prima volta che serve (idempotente)."""
    if not _MDB_AVAILABLE:
        return
    with _AGG_LOCK:
        if _AGG_STATE["started"]:
            return
        try:
            mdb.init_db()
        except Exception as e:
            _AGG_STATE["last_error"] = f"init_db: {e}"
            return
        # STEP 10 — Auto-seed catalogo PSK Italia al primo avvio (idempotente)
        try:
            _auto_seed_italia_psk_if_needed()
        except Exception:
            pass

        # FASE 11 (2026-05-05) — Auto-rematch one-shot al primo avvio post-fix
        # Quando il codice viene aggiornato con FASI 1-10, i pacchetti gia' nel DB
        # hanno channel_name potenzialmente sbagliato (era LongFast/MediumFast
        # invece del vero canale Italia). Eseguiamo un rematch one-shot per
        # retro-fixare i pacchetti pre-fix. Idempotente via flag in meta.
        try:
            _rematch_flag = "auto_rematch_v113_fix9_done"
            if not mdb.get_meta(_rematch_flag):
                try:
                    import monitor as _mon
                    if hasattr(_mon, "rematch_buffered_packets"):
                        _res = _mon.rematch_buffered_packets()
                        try:
                            import sys as _sys
                            _sys.stderr.write(
                                f"[server] Auto-rematch one-shot completato: {_res}\n"
                            )
                        except Exception:
                            pass
                    mdb.set_meta(_rematch_flag, "1")
                except Exception as _e:
                    _AGG_STATE["last_error"] = f"auto_rematch_startup: {_e}"
                    # Non settare il flag: ritenta al prossimo avvio
        except Exception:
            pass

        import threading as _th
        t = _th.Thread(target=_aggregator_loop, name="monitor-aggregator", daemon=True)
        t.start()
        _AGG_STATE["thread"] = t
        _AGG_STATE["started"] = True


def _mdb_guard():
    """Ritorna una Response 503 se il DB layer non è disponibile, altrimenti None."""
    if not _MDB_AVAILABLE:
        return jsonify({
            "success": False,
            "error": "mdb_unavailable",
            "message": "Il modulo monitor_db non è disponibile."
        }), 503
    return None


def _parse_filters_from_args():
    """Costruisce il dict `filters` per monitor_db._build_where() dai query params.
    I valori non validi vengono semplicemente ignorati (whitelist lato DB)."""
    filters = {}
    net = (request.args.get("network") or "").strip().lower()
    if net and net != "all":
        filters["network"] = net
    fw = (request.args.get("fw") or "").strip().lower()
    if fw and fw != "all":
        filters["fw_type"] = fw
    ch = (request.args.get("channel") or "").strip()
    if ch:
        filters["channel"] = ch
    pn = request.args.get("portnum")
    if pn is not None:
        try:
            filters["portnum"] = int(pn)
        except Exception:
            pass
    node = (request.args.get("node_id") or "").strip()
    if node:
        filters["node_id"] = node
    return filters


@app.route('/api/monitor/stats/leaderboard', methods=['GET'])
def api_monitor_leaderboard():
    """Classifica 7 giorni. Query:
    ?type=top_nodes|top_channels|top_portnums|by_network|by_firmware|
          best_signal|new_nodes|silent_nodes|compressed_nodes|hourly_heatmap
    &window=1h|6h|24h|3d|7d|30d (default 7d)
    &network=all|min|mesh_italia|unknown (default all)
    &fw=all|stock|fork_a|fork_b|stealth|builder|unknown (default all)
    &limit=20 (1..100)
    """
    ok_pro, err_resp = _require_pro()
    if not ok_pro:
        return err_resp
    guard = _mdb_guard()
    if guard:
        return guard
    _ensure_aggregator_started()

    kind = (request.args.get("type") or "top_nodes").strip().lower()
    window = (request.args.get("window") or "7d").strip().lower()
    filters = _parse_filters_from_args()
    try:
        limit = max(1, min(100, int(request.args.get("limit", "20"))))
    except Exception:
        limit = 20

    # Validazione enum (fail fast; la funzione interna ritornerebbe [])
    if kind not in mdb.LEADERBOARD_TYPES:
        return jsonify({"success": False, "error": "bad_type",
                        "allowed": sorted(list(mdb.LEADERBOARD_TYPES))}), 400
    if window not in mdb.WINDOW_MAP:
        return jsonify({"success": False, "error": "bad_window",
                        "allowed": sorted(list(mdb.WINDOW_MAP.keys()))}), 400

    try:
        rows = mdb.query_leaderboard(kind=kind, window=window,
                                     filters=filters, limit=limit)
        return jsonify({
            "success": True,
            "type": kind,
            "window": window,
            "filters": filters,
            "rows": rows,
        })
    except Exception as e:
        return jsonify({"success": False, "error": "internal", "message": str(e)}), 500


@app.route('/api/monitor/stats/timeline', methods=['GET'])
def api_monitor_timeline():
    """Timeline buckettata (default 1h) per heatmap/grafico.
    Query:
    ?window=1h|6h|24h|3d|7d|30d (default 7d)
    &bucket=5m|15m|1h|6h|1d (default 1h)
    &network=all|min|mesh_italia|unknown
    &fw=all|stock|fork_a|fork_b|stealth|builder|unknown
    """
    ok_pro, err_resp = _require_pro()
    if not ok_pro:
        return err_resp
    guard = _mdb_guard()
    if guard:
        return guard
    _ensure_aggregator_started()

    window = (request.args.get("window") or "7d").strip().lower()
    bucket = (request.args.get("bucket") or "1h").strip().lower()
    filters = _parse_filters_from_args()

    if window not in mdb.WINDOW_MAP:
        return jsonify({"success": False, "error": "bad_window"}), 400

    try:
        series = mdb.query_timeline(window=window, bucket=bucket, filters=filters)
        return jsonify({"success": True, "window": window, "bucket": bucket,
                        "filters": filters, "series": series})
    except Exception as e:
        return jsonify({"success": False, "error": "internal", "message": str(e)}), 500


@app.route('/api/monitor/stats/export', methods=['GET'])
def api_monitor_export():
    """Export leaderboard in CSV/JSON/MD.
    Query: stessi filtri di /leaderboard + &format=csv|json|md
    """
    ok_pro, err_resp = _require_pro()
    if not ok_pro:
        return err_resp
    guard = _mdb_guard()
    if guard:
        return guard
    _ensure_aggregator_started()

    kind = (request.args.get("type") or "top_nodes").strip().lower()
    window = (request.args.get("window") or "7d").strip().lower()
    fmt = (request.args.get("format") or "csv").strip().lower()
    filters = _parse_filters_from_args()
    try:
        limit = max(1, min(500, int(request.args.get("limit", "100"))))
    except Exception:
        limit = 100

    if kind not in mdb.LEADERBOARD_TYPES:
        return jsonify({"success": False, "error": "bad_type"}), 400
    if window not in mdb.WINDOW_MAP:
        return jsonify({"success": False, "error": "bad_window"}), 400
    if fmt not in mdb.EXPORT_FORMATS:
        return jsonify({"success": False, "error": "bad_format"}), 400

    try:
        body, mime, filename = mdb.export_leaderboard(kind=kind, fmt=fmt,
                                                     window=window,
                                                     filters=filters,
                                                     limit=limit)
        from flask import Response
        resp = Response(body, mimetype=mime)
        resp.headers['Content-Disposition'] = f'attachment; filename="{filename}"'
        return resp
    except ValueError as e:
        return jsonify({"success": False, "error": "bad_request", "message": str(e)}), 400
    except Exception as e:
        return jsonify({"success": False, "error": "internal", "message": str(e)}), 500


@app.route('/api/monitor/db/info', methods=['GET'])
def api_monitor_db_info():
    """Info DB: path, size, total rows, oldest/newest, retention giorni."""
    ok_pro, err_resp = _require_pro()
    if not ok_pro:
        return err_resp
    guard = _mdb_guard()
    if guard:
        return guard
    _ensure_aggregator_started()
    try:
        info = mdb.db_info()
        info["aggregator"] = {
            "started": _AGG_STATE["started"],
            "last_cleanup_ts": _AGG_STATE["last_cleanup_ts"],
            "last_stats_ts": _AGG_STATE["last_stats_ts"],
            "last_vacuum_ts": _AGG_STATE["last_vacuum_ts"],
            "last_error": _AGG_STATE["last_error"],
        }
        return jsonify({"success": True, "info": info})
    except Exception as e:
        return jsonify({"success": False, "error": "internal", "message": str(e)}), 500


@app.route('/api/monitor/db/purge', methods=['POST'])
def api_monitor_db_purge():
    """Purge dati DB. Body JSON: {"confirm": true, "scope": "all|older_than_7d"}
    Richiede PRO."""
    ok_pro, err_resp = _require_pro()
    if not ok_pro:
        return err_resp
    guard = _mdb_guard()
    if guard:
        return guard
    _ensure_aggregator_started()
    data = request.get_json(silent=True) or {}
    if not data.get("confirm"):
        return jsonify({"success": False, "error": "confirm_required"}), 400
    scope = (data.get("scope") or "older_than_retention").strip().lower()
    try:
        if scope == "all":
            mdb.purge_all()
            result = {"mode": "all"}
        else:
            deleted = mdb.cleanup_old()
            result = {"mode": "older_than_retention",
                      "deleted_packets": deleted[0] if isinstance(deleted, tuple) else 0,
                      "deleted_nodes": deleted[1] if isinstance(deleted, tuple) else 0}
        return jsonify({"success": True, "scope": scope, "result": result})
    except ValueError as e:
        return jsonify({"success": False, "error": "bad_request", "message": str(e)}), 400
    except Exception as e:
        return jsonify({"success": False, "error": "internal", "message": str(e)}), 500


@app.route('/api/monitor/enrich', methods=['GET'])
def api_monitor_enrich():
    """Arricchimento opzionale metadati nodo (directory nodi esterna).
    Query: ?node_id=! o numerico
    Cache in-memory 5 min. Mai esporre la fonte all'utente.
    Ritorna dati generici: long_name, short_name, position_approx (se disponibili).
    """
    ok_pro, err_resp = _require_pro()
    if not ok_pro:
        return err_resp
    node_id = (request.args.get("node_id") or "").strip()
    if not node_id or len(node_id) > 32:
        return jsonify({"success": False, "error": "bad_node_id"}), 400
    # Whitelist semplice
    if not all(c.isalnum() or c in "!:-_" for c in node_id):
        return jsonify({"success": False, "error": "invalid_node_id"}), 400

    import time as _t
    now = _t.time()
    with _ENRICH_LOCK:
        cached = _ENRICH_CACHE.get(node_id)
        if cached and (now - cached[0]) < _ENRICH_CACHE_TTL:
            return jsonify({"success": True, "cached": True, "data": cached[1]})

    # Se abilitato nei flag, tenta enrichment. Altrimenti ritorna vuoto.
    if _MDB_AVAILABLE:
        try:
            if not mdb.get_flag("enrich_online", default=True):
                return jsonify({"success": True, "cached": False, "data": {}})
        except Exception:
            pass

    # Fetch "directory nodi" — mai esporre la fonte
    data = {}
    try:
        import urllib.request
        import urllib.error
        import socket
        # Endpoint generico: lookup nodo per id (hex senza !)
        nid = node_id.lstrip("!")
        url = f"https://loraitalia.it/api/node/{nid}"
        req = urllib.request.Request(url, headers={
            "User-Agent": "MeshtasticItaliaNetwork/1.2.0",
            "Accept": "application/json",
        })
        try:
            with urllib.request.urlopen(req, timeout=3.0) as r:
                raw = r.read().decode("utf-8", errors="ignore")
                j = json.loads(raw)
                # Estrai solo campi "sicuri" da esporre, senza citare la fonte
                data = {
                    "long_name": j.get("long_name") or j.get("longName") or "",
                    "short_name": j.get("short_name") or j.get("shortName") or "",
                    "hw_model": j.get("hw_model") or j.get("hwModel") or "",
                    "position_approx": j.get("position") or {},
                }
        except (urllib.error.URLError, socket.timeout, json.JSONDecodeError):
            data = {}
    except Exception:
        data = {}

    with _ENRICH_LOCK:
        _ENRICH_CACHE[node_id] = (now, data)
        # Pulizia entries stantie
        if len(_ENRICH_CACHE) > 500:
            stale = [k for k, (ts, _) in _ENRICH_CACHE.items() if (now - ts) >= _ENRICH_CACHE_TTL]
            for k in stale:
                _ENRICH_CACHE.pop(k, None)

    return jsonify({"success": True, "cached": False, "data": data})


@app.route('/api/monitor/settings', methods=['GET', 'POST'])
def api_monitor_settings():
    """Impostazioni Monitor persistite in DB (tabella meta):
    - save_text (bool): salva testo messaggi in chiaro (PSK note) — default True
    - save_payload (bool): salva raw payload hex dei pacchetti crittati — default False
    - enrich_online (bool): abilita enrichment online — default True
    - retention_days (int 1..30): giorni di memoria — default 7
    """
    ok_pro, err_resp = _require_pro()
    if not ok_pro:
        return err_resp
    guard = _mdb_guard()
    if guard:
        return guard
    _ensure_aggregator_started()

    if request.method == 'POST':
        data = request.get_json(silent=True) or {}
        try:
            updated = {}
            for key in ("save_text", "save_payload", "enrich_online"):
                if key in data:
                    mdb.set_flag(key, bool(data[key]))
                    updated[key] = bool(data[key])
            if "retention_days" in data:
                try:
                    rd = int(data["retention_days"])
                    rd = mdb.set_retention_days(rd)
                    updated["retention_days"] = rd
                except Exception:
                    pass
            return jsonify({"success": True, "updated": updated})
        except Exception as e:
            return jsonify({"success": False, "error": "internal", "message": str(e)}), 500

    # GET
    try:
        settings = {
            "save_text": mdb.get_flag("save_text", default=True),
            "save_payload": mdb.get_flag("save_payload", default=False),
            "enrich_online": mdb.get_flag("enrich_online", default=True),
            "retention_days": mdb.get_retention_days(),
        }
        return jsonify({"success": True, "settings": settings})
    except Exception as e:
        return jsonify({"success": False, "error": "internal", "message": str(e)}), 500


# ═══════════════════════════════════════════════════════════
# MONITOR — HISTORY + NODE PROFILE + PSK MANAGER
# ═══════════════════════════════════════════════════════════

@app.route('/api/monitor/history', methods=['GET'])
def api_monitor_history():
    """Ritorna pacchetti storici (ultimi N dal DB 7gg).

    Query params:
      - limit: int (default 500, max 5000)
      - window: str (default '7d'): 1h, 6h, 24h, 3d, 7d
      - portnum: int opzionale (filtro)
      - network: str opzionale ('min', 'mesh_italia', 'unknown')
      - fw_type: str opzionale ('stock','fork_a','fork_b','stealth','builder','unknown')
    """
    ok_pro, err_resp = _require_pro()
    if not ok_pro:
        return err_resp
    guard = _mdb_guard()
    if guard:
        return guard
    _ensure_aggregator_started()
    try:
        limit = int(request.args.get('limit', 500))
        limit = max(1, min(5000, limit))
        window = request.args.get('window', '7d')
        portnum = request.args.get('portnum')  # string (port_name)
        network = request.args.get('network')
        fw_type = request.args.get('fw_type')
        rows = mdb.history_packets(
            limit=limit, window=window, portnum=portnum,
            network=network, fw_type=fw_type,
        )
        return jsonify({"success": True, "count": len(rows), "packets": rows, "window": window})
    except Exception as e:
        return jsonify({"success": False, "error": "internal", "message": str(e)}), 500


@app.route('/api/monitor/node/<node_id>', methods=['GET'])
def api_monitor_node_profile(node_id):
    """Scheda tecnica completa di un nodo.

    Query params:
      - window: str (default '7d')
    """
    ok_pro, err_resp = _require_pro()
    if not ok_pro:
        return err_resp
    guard = _mdb_guard()
    if guard:
        return guard
    _ensure_aggregator_started()
    try:
        window = request.args.get('window', '7d')
        profile = mdb.node_profile(node_id, window=window)
        if not profile:
            return jsonify({"success": False, "error": "not_found", "message": "Nodo non trovato"}), 404
        return jsonify({"success": True, "profile": profile})
    except Exception as e:
        return jsonify({"success": False, "error": "internal", "message": str(e)}), 500


# ══════════════════════════════════════════════════════════════════
# H3 v2 — HUB MONITOR SCANNER: lista nodi + ricerca FTS5 + sub-risorse
# ══════════════════════════════════════════════════════════════════

@app.route('/api/monitor/nodes', methods=['GET'])
def api_monitor_nodes_list():
    """Lista completa nodi con tutti i 37 metadati v2.

    Query params:
      - limit: int (default 500, max 5000)
      - window: str (default '7d')
      - network: str opz. ('min','mesh_italia','unknown')
      - fw_type: str opz.
      - role: str opz. (ROUTER, CLIENT, ...)
    """
    ok_pro, err_resp = _require_pro()
    if not ok_pro:
        return err_resp
    guard = _mdb_guard()
    if guard:
        return guard
    _ensure_aggregator_started()
    try:
        limit = int(request.args.get('limit', 500))
        window = request.args.get('window', '7d')
        network = request.args.get('network') or None
        fw_type = request.args.get('fw_type') or None
        role = request.args.get('role') or None
        rows = mdb.list_nodes(
            limit=limit, window=window,
            network=network, fw_type=fw_type, role=role,
        )
        return jsonify({"success": True, "count": len(rows), "nodes": rows, "window": window})
    except Exception as e:
        return jsonify({"success": False, "error": "internal", "message": str(e)}), 500


@app.route('/api/monitor/search', methods=['GET'])
def api_monitor_search():
    """Ricerca globale FTS5 (fallback LIKE) su payload + port + canale + nomi.

    Query params:
      - q: str (min 1, max 200)
      - limit: int (default 200, max 1000)
      - window: str (default '7d')
    """
    ok_pro, err_resp = _require_pro()
    if not ok_pro:
        return err_resp
    guard = _mdb_guard()
    if guard:
        return guard
    _ensure_aggregator_started()
    try:
        q = (request.args.get('q') or '').strip()
        if not q:
            return jsonify({"success": True, "count": 0, "results": [], "query": ""})
        limit = int(request.args.get('limit', 200))
        window = request.args.get('window', '7d')
        rows = mdb.search_fts(q, limit=limit, window=window)
        return jsonify({"success": True, "count": len(rows), "results": rows, "query": q, "window": window})
    except Exception as e:
        return jsonify({"success": False, "error": "internal", "message": str(e)}), 500


@app.route('/api/monitor/node/<node_id>/neighbors', methods=['GET'])
def api_monitor_node_neighbors(node_id):
    """Lista vicini rilevati da NEIGHBORINFO per questo nodo."""
    ok_pro, err_resp = _require_pro()
    if not ok_pro:
        return err_resp
    guard = _mdb_guard()
    if guard:
        return guard
    try:
        window = request.args.get('window', '7d')
        limit = int(request.args.get('limit', 500))
        rows = mdb.list_topology(limit=limit, window=window, node_id=node_id)
        return jsonify({"success": True, "count": len(rows), "neighbors": rows})
    except Exception as e:
        return jsonify({"success": False, "error": "internal", "message": str(e)}), 500


@app.route('/api/monitor/node/<node_id>/traceroutes', methods=['GET'])
def api_monitor_node_traceroutes(node_id):
    """Traceroute recenti in cui questo nodo è from o to."""
    ok_pro, err_resp = _require_pro()
    if not ok_pro:
        return err_resp
    guard = _mdb_guard()
    if guard:
        return guard
    try:
        window = request.args.get('window', '7d')
        limit = int(request.args.get('limit', 100))
        rows_f = mdb.list_traceroutes(limit=limit, window=window, from_node=node_id)
        rows_t = mdb.list_traceroutes(limit=limit, window=window, to_node=node_id)
        # Merge + dedup per packet_id
        seen = set()
        merged = []
        for r in rows_f + rows_t:
            pid = r.get("packet_id")
            key = (pid, r.get("ts"))
            if key in seen:
                continue
            seen.add(key)
            merged.append(r)
        merged.sort(key=lambda x: x.get("ts", 0), reverse=True)
        return jsonify({"success": True, "count": len(merged), "traceroutes": merged[:limit]})
    except Exception as e:
        return jsonify({"success": False, "error": "internal", "message": str(e)}), 500


@app.route('/api/monitor/node/<node_id>/map_reports', methods=['GET'])
def api_monitor_node_map_reports(node_id):
    """Snapshot MAP_REPORT emessi da questo nodo."""
    ok_pro, err_resp = _require_pro()
    if not ok_pro:
        return err_resp
    guard = _mdb_guard()
    if guard:
        return guard
    try:
        window = request.args.get('window', '7d')
        limit = int(request.args.get('limit', 100))
        rows = mdb.list_map_reports(limit=limit, window=window, node_id=node_id)
        return jsonify({"success": True, "count": len(rows), "map_reports": rows})
    except Exception as e:
        return jsonify({"success": False, "error": "internal", "message": str(e)}), 500


@app.route('/api/monitor/node/<node_id>/waypoints', methods=['GET'])
def api_monitor_node_waypoints(node_id):
    """Waypoint creati da questo nodo (finestra configurabile)."""
    ok_pro, err_resp = _require_pro()
    if not ok_pro:
        return err_resp
    guard = _mdb_guard()
    if guard:
        return guard
    try:
        nid = None
        try:
            nid = int(node_id, 16) if isinstance(node_id, str) and node_id.lower().startswith('!') else int(node_id, 16) if isinstance(node_id, str) and len(node_id) == 8 else int(node_id)
        except Exception:
            nid = None
        # list_waypoints non filtra per from_node → filtriamo qui
        all_wps = mdb.list_waypoints(limit=2000, window=request.args.get('window', '7d'))
        rows = [w for w in all_wps if w.get('from_node') == nid] if nid is not None else []
        limit = int(request.args.get('limit', 100))
        return jsonify({"success": True, "count": len(rows), "waypoints": rows[:limit]})
    except Exception as e:
        return jsonify({"success": False, "error": "internal", "message": str(e)}), 500


@app.route('/api/monitor/node/<node_id>/telemetry', methods=['GET'])
def api_monitor_node_telemetry(node_id):
    """Serie storica telemetria (DeviceMetrics/Environment/PowerMetrics) parsata.

    Ritorna [{ts, telemetry:{...}, rssi, snr, source}, ...] ordinato per ts DESC.
    """
    ok_pro, err_resp = _require_pro()
    if not ok_pro:
        return err_resp
    guard = _mdb_guard()
    if guard:
        return guard
    try:
        window = request.args.get('window', '7d')
        limit = max(1, min(int(request.args.get('limit', 200)), 1000))
        import sqlite3, json as _json
        nid = None
        try:
            if isinstance(node_id, str):
                s = node_id.strip()
                if s.startswith('!'):
                    nid = int(s[1:], 16)
                elif len(s) == 8 and all(c in '0123456789abcdefABCDEF' for c in s):
                    nid = int(s, 16)
                else:
                    nid = int(s)
            else:
                nid = int(node_id)
        except Exception:
            nid = None
        if nid is None:
            return jsonify({"success": False, "error": "bad_node_id"}), 400
        # Direct SQL via monitor_db helpers
        conn = mdb._connect()
        try:
            win_ms = mdb.WINDOW_MAP.get(window, mdb.WINDOW_MAP["7d"])
            cutoff = mdb._now_ms() - win_ms
            rows = conn.execute(
                "SELECT ts, telemetry_json, rssi, snr, source FROM packets "
                "WHERE from_node=? AND port_name='TELEMETRY_APP' AND telemetry_json IS NOT NULL "
                "AND ts>=? ORDER BY ts DESC LIMIT ?",
                (nid, cutoff, limit),
            ).fetchall()
            out = []
            for r in rows:
                d = dict(r)
                try:
                    d["telemetry"] = _json.loads(d.pop("telemetry_json")) if d.get("telemetry_json") else None
                except Exception:
                    d["telemetry"] = None
                    d.pop("telemetry_json", None)
                out.append(d)
            return jsonify({"success": True, "count": len(out), "telemetry": out})
        finally:
            conn.close()
    except Exception as e:
        return jsonify({"success": False, "error": "internal", "message": str(e)}), 500


@app.route('/api/monitor/node/<node_id>/metadata', methods=['GET'])
def api_monitor_node_metadata(node_id):
    """Storico snapshot metadata (firmware/role/flags) di un nodo."""
    ok_pro, err_resp = _require_pro()
    if not ok_pro:
        return err_resp
    guard = _mdb_guard()
    if guard:
        return guard
    try:
        limit = int(request.args.get('limit', 20))
        rows = mdb.list_node_metadata(node_id, limit=limit)
        return jsonify({"success": True, "count": len(rows), "metadata": rows})
    except Exception as e:
        return jsonify({"success": False, "error": "internal", "message": str(e)}), 500


@app.route('/api/monitor/node/<node_id>/storeforward', methods=['GET'])
def api_monitor_node_storeforward(node_id):
    """Storico Store&Forward stats per questo nodo (gateway SF)."""
    ok_pro, err_resp = _require_pro()
    if not ok_pro:
        return err_resp
    guard = _mdb_guard()
    if guard:
        return guard
    try:
        window = request.args.get('window', '7d')
        limit = int(request.args.get('limit', 50))
        rows = mdb.list_storeforward_stats(limit=limit, window=window, node_id=node_id)
        return jsonify({"success": True, "count": len(rows), "storeforward": rows})
    except Exception as e:
        return jsonify({"success": False, "error": "internal", "message": str(e)}), 500


@app.route('/api/monitor/psk', methods=['GET', 'POST'])
def api_monitor_psk():
    """CRUD PSK.
    GET  → lista tutte le PSK
    POST → aggiunge PSK (body: {label, psk_b64, kind, channel_name?, notes?})
    """
    ok_pro, err_resp = _require_pro()
    if not ok_pro:
        return err_resp
    guard = _mdb_guard()
    if guard:
        return guard
    _ensure_aggregator_started()
    if request.method == 'GET':
        try:
            # FASE 16c (2026-05-05): query param ?with_pkt_count=1 arricchisce con
            # il count pacchetti per channel_name (totale + finestra ultimi 7d).
            _wpc = request.args.get('with_pkt_count', '0').lower() in ('1', 'true', 'yes')
            _wd = request.args.get('window_days', type=int) or 7
            rows = mdb.psk_list(enabled_only=False, with_pkt_count=_wpc, window_days=_wd)
            return jsonify({"success": True, "count": len(rows), "keys": rows})
        except Exception as e:
            return jsonify({"success": False, "error": "internal", "message": str(e)}), 500
    # POST
    try:
        data = request.get_json(silent=True) or {}
        label = (data.get("label") or "").strip()
        psk_b64 = (data.get("psk_b64") or "").strip()
        if not label or not psk_b64:
            return jsonify({"success": False, "error": "bad_request", "message": "label e psk_b64 obbligatori"}), 400
        kind = (data.get("kind") or "public").strip()
        if kind not in ("public", "private"):
            return jsonify({"success": False, "error": "bad_request", "message": "kind deve essere 'public' o 'private'"}), 400
        channel_name = (data.get("channel_name") or "").strip() or None
        notes = (data.get("notes") or "").strip() or None
        res = mdb.psk_add(label=label, psk_b64=psk_b64, kind=kind,
                          channel_name=channel_name, notes=notes) or {}
        if "error" in res:
            return jsonify({"success": False, "error": res.get("error"),
                            "message": res.get("message", "")}), 400
        return jsonify({"success": True, "id": res.get("id")})
    except Exception as e:
        return jsonify({"success": False, "error": "internal", "message": str(e)}), 500


@app.route('/api/monitor/psk/<int:psk_id>', methods=['PUT', 'DELETE'])
def api_monitor_psk_one(psk_id):
    """Update/Delete PSK by id."""
    ok_pro, err_resp = _require_pro()
    if not ok_pro:
        return err_resp
    guard = _mdb_guard()
    if guard:
        return guard
    _ensure_aggregator_started()
    if request.method == 'DELETE':
        try:
            mdb.psk_delete(psk_id)
            return jsonify({"success": True, "deleted": psk_id})
        except Exception as e:
            return jsonify({"success": False, "error": "internal", "message": str(e)}), 500
    # PUT
    try:
        data = request.get_json(silent=True) or {}
        allowed = {}
        for k in ("label", "psk_b64", "channel_name", "kind", "enabled", "notes"):
            if k in data:
                allowed[k] = data[k]
        if "kind" in allowed and allowed["kind"] not in ("public", "private"):
            return jsonify({"success": False, "error": "bad_request", "message": "kind deve essere 'public' o 'private'"}), 400
        if "enabled" in allowed:
            allowed["enabled"] = 1 if bool(allowed["enabled"]) else 0
        mdb.psk_update(psk_id, **allowed)
        return jsonify({"success": True, "updated": psk_id, "fields": list(allowed.keys())})
    except Exception as e:
        return jsonify({"success": False, "error": "internal", "message": str(e)}), 500


@app.route('/api/monitor/psk/rematch', methods=['POST'])
def api_monitor_psk_rematch():
    """STEP B — Forza rematch delle PSK sui pacchetti cifrati bufferizzati + DB 7gg.

    Chiamato dopo ogni import/modifica di chiavi, o manualmente dall'utente tramite
    pulsante 🔄 Riprocessa con nuove chiavi.
    """
    ok_pro, err_resp = _require_pro()
    if not ok_pro:
        return err_resp
    guard = _mdb_guard()
    if guard:
        return guard
    _ensure_aggregator_started()
    try:
        res = monitor.rematch_buffered_packets()
    except Exception as e:
        return jsonify({"success": False, "error": "rematch_fail", "message": str(e)}), 500
    if not res or not res.get("ok"):
        return jsonify({
            "success": False,
            "error": (res or {}).get("error", "unknown"),
            "buffer_size": monitor.get_enc_buffer_size() if hasattr(monitor, "get_enc_buffer_size") else 0,
        }), 400
    return jsonify({
        "success": True,
        "ram_tried": res.get("ram_tried", 0),
        "ram_matched": res.get("ram_matched", 0),
        "ram_buffer_remaining": res.get("ram_buffer_remaining", 0),
        "db_tried": res.get("db_tried", 0),
        "db_matched": res.get("db_matched", 0),
        "total_matched": res.get("total_matched", 0),
    })


@app.route('/api/monitor/psk/sync-from-node', methods=['POST'])
def api_monitor_psk_sync_from_node():
    """Importa tutte le PSK dal nodo USB collegato (richiede Monitor attivo).

    Upsert per label 'Nodo: {channel_name}':
      - PRIMARY+AQ== → kind=public
      - SECONDARY / custom → kind=private
    Ritorna counters: added / updated / unchanged / skipped / total + details.
    """
    ok_pro, err_resp = _require_pro()
    if not ok_pro:
        return err_resp
    guard = _mdb_guard()
    if guard:
        return guard
    _ensure_aggregator_started()
    # Verifica monitor attivo
    try:
        if not monitor or not monitor.is_active():
            return jsonify({
                "success": False,
                "error": "monitor_not_active",
                "message": "Il Monitor deve essere attivo per leggere le chiavi dal nodo."
            }), 409
    except Exception:
        return jsonify({"success": False, "error": "monitor_unavailable"}), 500
    try:
        res = monitor.sync_psks_from_node()
    except Exception as e:
        return jsonify({"success": False, "error": "sync_fail", "message": str(e)}), 500
    if not res or not res.get("ok"):
        return jsonify({
            "success": False,
            "error": (res or {}).get("error", "unknown"),
            "message": (res or {}).get("error", "")
        }), 400
    # Auto-rematch se abbiamo aggiunto o aggiornato chiavi
    rematch_info = None
    if (res.get("added", 0) + res.get("updated", 0)) > 0:
        try:
            rematch_info = monitor.rematch_buffered_packets()
        except Exception:
            rematch_info = None
    return jsonify({
        "success": True,
        "added": res.get("added", 0),
        "updated": res.get("updated", 0),
        "unchanged": res.get("unchanged", 0),
        "skipped": res.get("skipped", 0),
        "total": res.get("total", 0),
        "details": res.get("details", []),
        "rematch": rematch_info,
    })


# ═══════════════════════════════════════════════════════════
# STEP 10 — PSK Italia seed (auto-associa catalogo 33 canali)
# ═══════════════════════════════════════════════════════════

@app.route('/api/monitor/psk/seed/italia', methods=['POST'])
def api_monitor_psk_seed_italia():
    """STEP 10 — Seed catalogo PSK Italia (33 canali, 11 chiavi uniche).

    Legge psk_catalog_italia.json dalla directory app/ e per ogni entry chiama
    mdb.psk_add_or_update(). Ritorna counters aggregati. Dopo il seed, se sono
    state aggiunte/aggiornate chiavi, invoca auto-rematch sui pacchetti bufferizzati.

    Usato dal pulsante "🇮🇹 Carica 33 canali Italia" + da auto-seed all'avvio.
    """
    ok_pro, err_resp = _require_pro()
    if not ok_pro:
        return err_resp
    guard = _mdb_guard()
    if guard:
        return guard
    import json as _json
    import os as _os
    _cat_path = _os.path.join(_base_dir, 'psk_catalog_italia.json')
    if not _os.path.isfile(_cat_path):
        return jsonify({
            "success": False,
            "error": "catalog_missing",
            "message": "psk_catalog_italia.json non trovato in app/"
        }), 404
    try:
        with open(_cat_path, 'r', encoding='utf-8') as _f:
            _cat = _json.load(_f)
    except Exception as e:
        return jsonify({
            "success": False,
            "error": "catalog_parse_fail",
            "message": str(e)
        }), 500
    _entries = _cat.get('entries') or []
    if not isinstance(_entries, list) or not _entries:
        return jsonify({
            "success": False,
            "error": "catalog_empty",
            "message": "Catalogo vuoto o malformato"
        }), 400
    _added = 0
    _updated = 0
    _unchanged = 0
    _errors = 0
    _err_list = []
    for _e in _entries:
        try:
            _label = str(_e.get('label') or '').strip()
            _psk = str(_e.get('psk_b64') or '').strip()
            if not _label or not _psk:
                _errors += 1
                _err_list.append({"label": _label, "error": "missing_field"})
                continue
            _res = mdb.psk_add_or_update(
                label=_label,
                psk_b64=_psk,
                kind=_e.get('kind') or 'public',
                channel_name=_e.get('channel_name'),
                notes=_e.get('notes'),
            ) or {}
            if 'added' in _res:
                _added += 1
            elif 'updated' in _res:
                _updated += 1
            elif 'unchanged' in _res:
                _unchanged += 1
            else:
                _errors += 1
                _err_list.append({"label": _label, "error": _res.get('error', 'unknown')})
        except Exception as _ex:
            _errors += 1
            _err_list.append({"label": _e.get('label', '?'), "error": str(_ex)})
    # Auto-rematch se qualcosa è cambiato
    _rematch = None
    if (_added + _updated) > 0:
        try:
            _ensure_aggregator_started()
            _rematch = monitor.rematch_buffered_packets()
        except Exception:
            _rematch = None
    return jsonify({
        "success": True,
        "total": len(_entries),
        "added": _added,
        "updated": _updated,
        "unchanged": _unchanged,
        "errors": _errors,
        "error_details": _err_list[:20],
        "rematch": _rematch,
        "catalog_version": _cat.get('version'),
        "catalog_updated": _cat.get('updated'),
    })


@app.route('/api/monitor/crypto/diagnose', methods=['GET'])
def api_monitor_crypto_diagnose():
    """STEP 13 — Diagnostica completa stato crypto (PSK catalog + flusso).

    Ritorna:
      {
        "success": true,
        "psk_total": N,             # PSK totali in DB
        "psk_enabled": N,           # PSK attive (usate dal brute-force)
        "psk_italia_coverage": {    # Copertura catalog Italia
            "expected": 36,
            "in_db": N,
            "missing": [label1, label2, ...]
        },
        "italia_seed": {...},       # Ultimo risultato auto-seed (da _AGG_STATE)
        "monitor_running": bool,    # Aggregator attivo
        "catalog_path_exists": bool,
        "catalog_version": str | null,
        "flow_check": {
            "crypto_module": bool,  # _MCRYPT_OK equivalente
            "db_available": bool
        }
      }
    Se psk_enabled=0 -> il brute-force NON parte, canali regionali non leggibili.
    Usa il bottone 'Seed Italia' per ripopolare.
    """
    ok_pro, err_resp = _require_pro()
    if not ok_pro:
        return err_resp
    import json as _json
    import os as _os
    _out = {
        "success": True,
        "psk_total": 0,
        "psk_enabled": 0,
        "psk_italia_coverage": {"expected": 0, "in_db": 0, "missing": []},
        "italia_seed": None,
        "monitor_running": False,
        "catalog_path_exists": False,
        "catalog_version": None,
        "flow_check": {"crypto_module": False, "db_available": _MDB_AVAILABLE},
    }
    # Monitor running?
    try:
        _out["monitor_running"] = bool(_AGG_STATE.get("started"))
        _out["italia_seed"] = _AGG_STATE.get("italia_seed")
    except Exception:
        pass
    # PSK counts
    if _MDB_AVAILABLE:
        try:
            _all = mdb.psk_list() or []
            _out["psk_total"] = len(_all)
            _out["psk_enabled"] = sum(1 for _r in _all if int(_r.get("enabled") or 0) == 1)
            _db_labels = set(str(_r.get("label", "")).strip() for _r in _all)
        except Exception as _e:
            _out["psk_list_error"] = str(_e)
            _db_labels = set()
    else:
        _db_labels = set()
    # Catalog coverage
    _cat_path = _os.path.join(_base_dir, 'psk_catalog_italia.json')
    _out["catalog_path_exists"] = _os.path.isfile(_cat_path)
    if _out["catalog_path_exists"]:
        try:
            with open(_cat_path, 'r', encoding='utf-8') as _f:
                _cat = _json.load(_f)
            _entries = _cat.get('entries') or []
            _cat_labels = [str(_e.get('label') or '').strip()
                           for _e in _entries if _e.get('label')]
            _out["catalog_version"] = _cat.get("version")
            _out["psk_italia_coverage"]["expected"] = len(_cat_labels)
            _in_db = [_l for _l in _cat_labels if _l in _db_labels]
            _missing = [_l for _l in _cat_labels if _l not in _db_labels]
            _out["psk_italia_coverage"]["in_db"] = len(_in_db)
            _out["psk_italia_coverage"]["missing"] = _missing[:50]
        except Exception as _e:
            _out["catalog_read_error"] = str(_e)
    # Crypto module check
    try:
        from meshtastic_crypto import try_all_psk_detailed as _fn  # noqa
        _out["flow_check"]["crypto_module"] = True
    except Exception:
        _out["flow_check"]["crypto_module"] = False
    return jsonify(_out)


# ═══════════════════════════════════════════════════════════
# STEP 2 Hunter — Channel slots (read + sync + map)
# ═══════════════════════════════════════════════════════════

@app.route('/api/monitor/channels', methods=['GET'])
def api_monitor_channels():
    """Ritorna lo snapshot corrente dei canali del nodo.

    Query:
      ?live=1 → forza re-read dal nodo USB (richiede Monitor attivo)
      default → ritorna snapshot DB (channel_map) senza toccare USB
    Response: {
        "success": true,
        "channels": [ {idx, name, short_name, role, psk_b64, default_psk, hash8, updated_ts?}, ... ],
        "source": "db" | "live",
        "total": N
    }
    """
    ok_pro, err_resp = _require_pro()
    if not ok_pro:
        return err_resp
    guard = _mdb_guard()
    if guard:
        return guard
    _live = (request.args.get("live", "0") == "1")
    if _live:
        if not monitor or not monitor.is_active():
            return jsonify({
                "success": False,
                "error": "monitor_not_active",
                "message": "Il Monitor deve essere attivo per leggere dai canali USB."
            }), 409
        try:
            _res = monitor.read_local_channels()
        except Exception as e:
            return jsonify({"success": False, "error": "read_fail", "message": str(e)}), 500
        if not _res.get("ok"):
            return jsonify({"success": False, "error": _res.get("error", "unknown")}), 400
        return jsonify({
            "success": True,
            "channels": _res.get("channels", []),
            "source": "live",
            "total": len(_res.get("channels", [])),
        })
    # Default: snapshot DB
    try:
        _rows = monitor_db.channel_map_all() if hasattr(monitor_db, "channel_map_all") else []
    except Exception:
        _rows = []
    return jsonify({
        "success": True,
        "channels": _rows,
        "source": "db",
        "total": len(_rows),
    })


@app.route('/api/monitor/channels/sync', methods=['POST'])
def api_monitor_channels_sync():
    """Legge gli 8 slot LR dal nodo USB, upserta channel_map + PSK catalog.

    Richiede Monitor attivo. Auto-rematch se sono state aggiunte/aggiornate PSK.
    Response:
      {success, channels, map_written, psk_added, psk_updated, psk_unchanged,
       psk_skipped, rematch: {...}}
    """
    ok_pro, err_resp = _require_pro()
    if not ok_pro:
        return err_resp
    guard = _mdb_guard()
    if guard:
        return guard
    _ensure_aggregator_started()
    if not monitor or not monitor.is_active():
        return jsonify({
            "success": False,
            "error": "monitor_not_active",
            "message": "Il Monitor deve essere attivo per sincronizzare i canali."
        }), 409
    # sync_psks_from_node già fa channel_map_upsert + PSK upsert
    try:
        _sync = monitor.sync_psks_from_node()
    except Exception as e:
        return jsonify({"success": False, "error": "sync_fail", "message": str(e)}), 500
    if not _sync or not _sync.get("ok"):
        return jsonify({
            "success": False,
            "error": (_sync or {}).get("error", "unknown"),
        }), 400
    # Leggi canali con hash8 per response
    try:
        _live = monitor.read_local_channels()
    except Exception:
        _live = {"ok": False, "channels": []}
    _channels = _live.get("channels", []) if _live.get("ok") else []
    # Auto-rematch se ci sono state aggiunte/aggiornamenti
    _rematch = None
    if (_sync.get("added", 0) + _sync.get("updated", 0)) > 0:
        try:
            _rematch = monitor.rematch_buffered_packets()
        except Exception:
            _rematch = None
    # Conta righe scritte in channel_map
    try:
        _map_total = len(monitor_db.channel_map_all()) if hasattr(monitor_db, "channel_map_all") else 0
    except Exception:
        _map_total = 0
    return jsonify({
        "success": True,
        "channels": _channels,
        "map_written": _map_total,
        "psk_added": _sync.get("added", 0),
        "psk_updated": _sync.get("updated", 0),
        "psk_unchanged": _sync.get("unchanged", 0),
        "psk_skipped": _sync.get("skipped", 0),
        "total": _sync.get("total", 0),
        "rematch": _rematch,
    })


# ═══════════════════════════════════════════════════════════
# STEP 5 Hunter — PKI Public-Key Harvester
# ═══════════════════════════════════════════════════════════

@app.route('/api/monitor/pubkeys', methods=['GET'])
def api_monitor_pubkeys():
    """Ritorna le chiavi pubbliche X25519 osservate in rete.

    Query:
      ?limit=200  → max righe (default 200, cap 1000)
    Response: {
        "success": true,
        "stats": {"unique_nodes": N, "unique_keys": M, "total_rows": T},
        "pubkeys": [
            {node_id, node_num, public_key_hex, first_seen_ts,
             last_seen_ts, seen_count, source}, ...
        ]
    }
    """
    ok_pro, err_resp = _require_pro()
    if not ok_pro:
        return err_resp
    guard = _mdb_guard()
    if guard:
        return guard
    try:
        _limit = int(request.args.get("limit", "200"))
    except Exception:
        _limit = 200
    try:
        _stats = monitor_db.node_pubkey_count() if hasattr(monitor_db, "node_pubkey_count") else {}
    except Exception:
        _stats = {"unique_nodes": 0, "unique_keys": 0, "total_rows": 0}
    try:
        _rows = monitor_db.node_pubkeys_list(_limit) if hasattr(monitor_db, "node_pubkeys_list") else []
    except Exception:
        _rows = []
    return jsonify({
        "success": True,
        "stats": _stats,
        "pubkeys": _rows,
    })


# ═══════════════════════════════════════════════════════════
# H4.3-T1/T2 — PKI KEYSTORE (CRUD pki_keys + import X25519 da USB)
# ═══════════════════════════════════════════════════════════

def _pki_row_safe(row):
    """Ritorna copia della row con priv_hex mascherato per uso API.

    Sicurezza: mai esporre priv completa via JSON. Preview: primi 8 + ultimi 4.
    """
    if not row:
        return row
    _safe = dict(row)
    _priv = _safe.get("my_priv_hex") or ""
    if _priv and len(_priv) >= 16:
        _safe["my_priv_hex_preview"] = _priv[:8] + "..." + _priv[-4:]
    else:
        _safe["my_priv_hex_preview"] = "(short)"
    _safe["my_priv_hex"] = None  # no leak
    return _safe


@app.route('/api/monitor/pki', methods=['GET', 'POST'])
def api_monitor_pki():
    """CRUD PKI keys (X25519 keypair).

    GET  → lista tutte le PKI keys (priv masked). Query: ?enabled_only=1&device_own_only=1
    POST → aggiunge chiave (body: {label, my_priv_hex, their_pub_hex?, my_pub_hex?, source?, is_device_own?, notes?})
    """
    ok_pro, err_resp = _require_pro()
    if not ok_pro:
        return err_resp
    guard = _mdb_guard()
    if guard:
        return guard
    _ensure_aggregator_started()
    if request.method == 'GET':
        try:
            _enabled = request.args.get("enabled_only", "0") in ("1", "true", "True")
            _device_own = request.args.get("device_own_only", "0") in ("1", "true", "True")
            _rows = mdb.pki_list(enabled_only=_enabled, device_own_only=_device_own)
            _safe_rows = [_pki_row_safe(r) for r in _rows]
            return jsonify({"success": True, "count": len(_safe_rows), "keys": _safe_rows})
        except Exception as e:
            return jsonify({"success": False, "error": "internal", "message": str(e)}), 500
    # POST
    try:
        _data = request.get_json(silent=True) or {}
        _label = (_data.get("label") or "").strip()
        _priv = (_data.get("my_priv_hex") or "").strip()
        if not _label or not _priv:
            return jsonify({"success": False, "error": "bad_request",
                            "message": "label e my_priv_hex obbligatori"}), 400
        _their = (_data.get("their_pub_hex") or "").strip() or None
        _mypub = (_data.get("my_pub_hex") or "").strip() or None
        _src = (_data.get("source") or "manual").strip()
        _dev_own = 1 if bool(_data.get("is_device_own")) else 0
        _notes = (_data.get("notes") or "").strip() or None
        _res = mdb.pki_add(
            label=_label, my_priv_hex=_priv, their_pub_hex=_their,
            my_pub_hex=_mypub, source=_src, is_device_own=_dev_own, notes=_notes,
        ) or {}
        if "error" in _res:
            return jsonify({"success": False, "error": _res.get("error"),
                            "message": _res.get("message", ""),
                            "detail": _res.get("detail", ""),
                            "allowed": _res.get("allowed")}), 400
        return jsonify({"success": True, "id": _res.get("id"),
                        "my_pub_hex": _res.get("my_pub_hex")})
    except Exception as e:
        return jsonify({"success": False, "error": "internal", "message": str(e)}), 500


@app.route('/api/monitor/pki/<int:pki_id>', methods=['PATCH', 'DELETE'])
def api_monitor_pki_one(pki_id):
    """Update/Delete PKI key by id.

    PATCH body: {label?, their_pub_hex?, enabled?, notes?, is_device_own?}
    """
    ok_pro, err_resp = _require_pro()
    if not ok_pro:
        return err_resp
    guard = _mdb_guard()
    if guard:
        return guard
    _ensure_aggregator_started()
    if request.method == 'DELETE':
        try:
            _res = mdb.pki_delete(pki_id) or {}
            if "error" in _res:
                return jsonify({"success": False, "error": _res.get("error")}), 404
            return jsonify({"success": True, "deleted": pki_id})
        except Exception as e:
            return jsonify({"success": False, "error": "internal", "message": str(e)}), 500
    # PATCH
    try:
        _data = request.get_json(silent=True) or {}
        _allowed = {}
        for _k in ("label", "their_pub_hex", "enabled", "notes", "is_device_own"):
            if _k in _data:
                _allowed[_k] = _data[_k]
        if "enabled" in _allowed:
            _allowed["enabled"] = 1 if bool(_allowed["enabled"]) else 0
        if "is_device_own" in _allowed:
            _allowed["is_device_own"] = 1 if bool(_allowed["is_device_own"]) else 0
        _res = mdb.pki_update(pki_id, **_allowed) or {}
        if "error" in _res:
            return jsonify({"success": False, "error": _res.get("error"),
                            "allowed": _res.get("allowed")}), 400
        return jsonify({"success": True, "updated": pki_id, "fields": list(_allowed.keys())})
    except Exception as e:
        return jsonify({"success": False, "error": "internal", "message": str(e)}), 500


@app.route('/api/monitor/pki/import-from-node', methods=['POST'])
def api_monitor_pki_import_from_node():
    """H4.3-T2 — Importa la private key X25519 dal nodo USB collegato.

    Richiede Monitor attivo. Legge SecurityConfig.private_key (32B),
    deriva la public key, salva in pki_keys con source='node_usb' is_device_own=1.
    """
    ok_pro, err_resp = _require_pro()
    if not ok_pro:
        return err_resp
    guard = _mdb_guard()
    if guard:
        return guard
    _ensure_aggregator_started()
    try:
        if not monitor or not monitor.is_active():
            return jsonify({
                "success": False,
                "error": "monitor_not_active",
                "message": "Il Monitor deve essere attivo per leggere la chiave dal nodo."
            }), 409
    except Exception:
        return jsonify({"success": False, "error": "monitor_unavailable"}), 500
    try:
        _res = monitor.import_private_key_from_node()
    except Exception as e:
        return jsonify({"success": False, "error": "import_fail", "message": str(e)[:200]}), 500
    if not _res or not _res.get("ok"):
        return jsonify({
            "success": False,
            "error": (_res or {}).get("error", "unknown"),
            "detail": (_res or {}).get("detail", ""),
            "message": (_res or {}).get("message", ""),
        }), 400
    return jsonify({
        "success": True,
        "action": _res.get("action"),        # "added" | "unchanged"
        "id": _res.get("id"),
        "my_priv_hex_preview": _res.get("my_priv_hex_preview"),  # 8+4 char mask
        "my_pub_hex": _res.get("my_pub_hex"),
        "label": _res.get("label"),
    })


@app.route('/api/monitor/packet/trace/<int:packet_id>', methods=['GET'])
def api_monitor_packet_trace(packet_id):
    """H4.3-T5 — Path Tracer.

    Ricostruisce il percorso di un packet_id: departure, transit, arrival,
    decrypt_status, hops_used, gateways, traceroute.
    """
    ok_pro, err_resp = _require_pro()
    if not ok_pro:
        return err_resp
    guard = _mdb_guard()
    if guard:
        return guard
    try:
        from path_tracer import trace_packet
    except Exception as e:
        return jsonify({"success": False, "error": "path_tracer_missing",
                        "detail": str(e)[:120]}), 500
    try:
        _res = trace_packet(int(packet_id))
    except Exception as e:
        return jsonify({"success": False, "error": "trace_fail",
                        "message": str(e)[:200]}), 500
    if not _res or not _res.get("ok"):
        return jsonify({
            "success": False,
            "error": (_res or {}).get("error", "unknown"),
            "detail": (_res or {}).get("detail", ""),
        }), 404 if (_res or {}).get("error") == "bad_packet_id" else 400
    _res["success"] = True
    return jsonify(_res)


@app.route('/api/monitor/packet/recent_ids', methods=['GET'])
def api_monitor_packet_recent_ids():
    """H4.3-T5 — Lista packet_id recenti (per dropdown UI trace)."""
    ok_pro, err_resp = _require_pro()
    if not ok_pro:
        return err_resp
    guard = _mdb_guard()
    if guard:
        return guard
    try:
        from path_tracer import recent_packet_ids
    except Exception as e:
        return jsonify({"success": False, "error": "path_tracer_missing",
                        "detail": str(e)[:120]}), 500
    try:
        _limit = int(request.args.get("limit", 50))
    except Exception:
        _limit = 50
    _enc_only = request.args.get("encrypted_only", "0") in ("1", "true", "True")
    try:
        _ids = recent_packet_ids(limit=_limit, encrypted_only=_enc_only)
    except Exception as e:
        return jsonify({"success": False, "error": "recent_fail",
                        "message": str(e)[:200]}), 500
    return jsonify({"success": True, "count": len(_ids), "packet_ids": _ids})


@app.route('/api/monitor/pki/discover', methods=['POST'])
def api_monitor_pki_discover():
    """H4.3-T4 — Key Discovery agent.

    Scansiona iface.nodes × priv device-own e crea coppie 'discovered' in pki_keys.
    Richiede Monitor attivo + almeno 1 priv device-own abilitata.
    """
    ok_pro, err_resp = _require_pro()
    if not ok_pro:
        return err_resp
    guard = _mdb_guard()
    if guard:
        return guard
    _ensure_aggregator_started()
    try:
        if not monitor or not monitor.is_active():
            return jsonify({
                "success": False,
                "error": "monitor_not_active",
                "message": "Il Monitor deve essere attivo per leggere i nodi."
            }), 409
    except Exception:
        return jsonify({"success": False, "error": "monitor_unavailable"}), 500
    try:
        _res = monitor.discover_pki_pairings()
    except Exception as e:
        return jsonify({"success": False, "error": "discover_fail",
                        "message": str(e)[:200]}), 500
    if not _res or not _res.get("ok"):
        return jsonify({
            "success": False,
            "error": (_res or {}).get("error", "unknown"),
            "message": (_res or {}).get("message", ""),
            "details": (_res or {}).get("details", []),
        }), 400
    return jsonify({
        "success": True,
        "device_own_priv_count": _res.get("device_own_priv_count", 0),
        "nodes_scanned": _res.get("nodes_scanned", 0),
        "nodes_with_pub": _res.get("nodes_with_pub", 0),
        "pairings_added": _res.get("pairings_added", 0),
        "pairings_existing": _res.get("pairings_existing", 0),
        "pairings_errors": _res.get("pairings_errors", 0),
        "details": _res.get("details", []),
    })


# ═══════════════════════════════════════════════════════════
# H4.3-T6 — MQTT BRIDGE (paho-mqtt → ServiceEnvelope → pipeline)
# ═══════════════════════════════════════════════════════════

@app.route('/api/monitor/mqtt/config', methods=['GET'])
def api_monitor_mqtt_config_get():
    """H4.3-T6 — Legge configurazione corrente MQTT bridge (password mascherata)."""
    ok_pro, err_resp = _require_pro()
    if not ok_pro:
        return err_resp
    try:
        from mqtt_bridge import get_bridge
    except Exception as e:
        return jsonify({"success": False, "error": "mqtt_bridge_missing",
                        "detail": str(e)[:120]}), 500
    try:
        _cfg = get_bridge().get_config(mask_password=True)
    except Exception as e:
        return jsonify({"success": False, "error": "config_fail",
                        "message": str(e)[:200]}), 500
    return jsonify({"success": True, "config": _cfg})


@app.route('/api/monitor/mqtt/config', methods=['POST'])
def api_monitor_mqtt_config_set():
    """H4.3-T6 — Aggiorna configurazione MQTT bridge.

    Body JSON: broker, port, topic, username, password, tls, client_id
    (tutti optional — vengono aggiornati solo i campi presenti).
    """
    ok_pro, err_resp = _require_pro()
    if not ok_pro:
        return err_resp
    try:
        body = request.get_json(force=True, silent=True) or {}
    except Exception:
        return jsonify({"success": False, "error": "invalid_json"}), 400
    try:
        from mqtt_bridge import get_bridge
    except Exception as e:
        return jsonify({"success": False, "error": "mqtt_bridge_missing",
                        "detail": str(e)[:120]}), 500
    try:
        _cfg = get_bridge().set_config(body)
    except Exception as e:
        return jsonify({"success": False, "error": "config_fail",
                        "message": str(e)[:200]}), 500
    return jsonify({"success": True, "config": _cfg})


@app.route('/api/monitor/mqtt/start', methods=['POST'])
def api_monitor_mqtt_start():
    """H4.3-T6 — Avvia connessione MQTT bridge."""
    ok_pro, err_resp = _require_pro()
    if not ok_pro:
        return err_resp
    guard = _mdb_guard()
    if guard:
        return guard
    try:
        from mqtt_bridge import get_bridge
    except Exception as e:
        return jsonify({"success": False, "error": "mqtt_bridge_missing",
                        "detail": str(e)[:120]}), 500
    try:
        _res = get_bridge().start()
    except Exception as e:
        return jsonify({"success": False, "error": "start_fail",
                        "message": str(e)[:200]}), 500
    if not _res.get("ok"):
        _err = _res.get("error", "unknown")
        _code = 409 if _err == "already_running" else 400
        return jsonify({"success": False, "error": _err,
                        "detail": _res.get("detail", "")}), _code
    return jsonify({"success": True, "status": _res.get("status", {})})


@app.route('/api/monitor/mqtt/stop', methods=['POST'])
def api_monitor_mqtt_stop():
    """H4.3-T6 — Ferma connessione MQTT bridge."""
    ok_pro, err_resp = _require_pro()
    if not ok_pro:
        return err_resp
    try:
        from mqtt_bridge import get_bridge
    except Exception as e:
        return jsonify({"success": False, "error": "mqtt_bridge_missing",
                        "detail": str(e)[:120]}), 500
    try:
        _res = get_bridge().stop()
    except Exception as e:
        return jsonify({"success": False, "error": "stop_fail",
                        "message": str(e)[:200]}), 500
    if not _res.get("ok"):
        return jsonify({"success": False,
                        "error": _res.get("error", "unknown")}), 409
    return jsonify({"success": True})


@app.route('/api/monitor/mqtt/status', methods=['GET'])
def api_monitor_mqtt_status():
    """H4.3-T6 — Stato bridge MQTT (connected, msgs_received, last_error)."""
    ok_pro, err_resp = _require_pro()
    if not ok_pro:
        return err_resp
    try:
        from mqtt_bridge import get_bridge
    except Exception as e:
        return jsonify({"success": False, "error": "mqtt_bridge_missing",
                        "detail": str(e)[:120]}), 500
    try:
        _st = get_bridge().get_status()
    except Exception as e:
        return jsonify({"success": False, "error": "status_fail",
                        "message": str(e)[:200]}), 500
    return jsonify({"success": True, "status": _st})


@app.route('/api/monitor/mqtt/diagnose', methods=['GET'])
def api_monitor_mqtt_diagnose():
    """STEP 9 — Diagnostica auto-discovery MQTT.

    Ritorna subscribed_topics + top_roots + top_senders + suggestions.
    Permette a Rino di capire perché non vede messaggi di altri nodi:
      - quali root topic sta pubblicando il broker
      - quali sender sono visibili
      - se il subscribe include wildcard o è troppo stretto
    """
    ok_pro, err_resp = _require_pro()
    if not ok_pro:
        return err_resp
    try:
        from mqtt_bridge import get_bridge
    except Exception as e:
        return jsonify({"success": False, "error": "mqtt_bridge_missing",
                        "detail": str(e)[:120]}), 500
    try:
        _diag = get_bridge().get_diagnose()
    except Exception as e:
        return jsonify({"success": False, "error": "diagnose_fail",
                        "message": str(e)[:200]}), 500
    return jsonify({"success": True, "diagnose": _diag})


# ═══════════════════════════════════════════════════════════
# H4.3-T8 — TOOL-SUITE INDEX & STATUS (consolidamento REST)
# ═══════════════════════════════════════════════════════════

_H43_TOOLS_INDEX = [
    # T1 — PKI keystore CRUD
    {"method": "GET",    "path": "/api/monitor/pki",
     "task": "T1", "name": "pki_list",
     "desc": "Lista chiavi PKI registrate (priv_hex mascherato)"},
    {"method": "POST",   "path": "/api/monitor/pki",
     "task": "T1", "name": "pki_add",
     "desc": "Aggiungi coppia chiavi PKI manualmente"},
    {"method": "PATCH",  "path": "/api/monitor/pki/<id>",
     "task": "T1", "name": "pki_update",
     "desc": "Aggiorna label/enabled di una entry PKI"},
    {"method": "DELETE", "path": "/api/monitor/pki/<id>",
     "task": "T1", "name": "pki_delete",
     "desc": "Rimuovi entry PKI dal keystore"},
    # T2 — Import private key da nodo USB
    {"method": "POST",   "path": "/api/monitor/pki/import-from-node",
     "task": "T2", "name": "pki_import_node",
     "desc": "Importa priv key X25519 dal nodo Meshtastic collegato via USB"},
    # T4 — Key discovery agent
    {"method": "POST",   "path": "/api/monitor/pki/discover",
     "task": "T4", "name": "pki_discover",
     "desc": "Auto-pairing priv device-own × nodes.publicKey da iface.nodes"},
    # T5 — Path tracer
    {"method": "GET",    "path": "/api/monitor/packet/trace/<packet_id>",
     "task": "T5", "name": "packet_trace",
     "desc": "Traccia percorso packet_id: departure/transit/arrival/gateways"},
    {"method": "GET",    "path": "/api/monitor/packet/recent_ids",
     "task": "T5", "name": "packet_recent_ids",
     "desc": "Lista packet_id recenti per dropdown UI"},
    # T6 — MQTT bridge
    {"method": "GET",    "path": "/api/monitor/mqtt/config",
     "task": "T6", "name": "mqtt_config_get",
     "desc": "Legge config MQTT bridge (password mascherata)"},
    {"method": "POST",   "path": "/api/monitor/mqtt/config",
     "task": "T6", "name": "mqtt_config_set",
     "desc": "Aggiorna broker/port/topic/user/pw/tls"},
    {"method": "POST",   "path": "/api/monitor/mqtt/start",
     "task": "T6", "name": "mqtt_start",
     "desc": "Avvia connessione MQTT → pipeline monitor"},
    {"method": "POST",   "path": "/api/monitor/mqtt/stop",
     "task": "T6", "name": "mqtt_stop",
     "desc": "Ferma bridge MQTT"},
    {"method": "GET",    "path": "/api/monitor/mqtt/status",
     "task": "T6", "name": "mqtt_status",
     "desc": "Stato bridge (connected, msgs_received, last_error)"},
    {"method": "GET",    "path": "/api/monitor/mqtt/diagnose",
     "task": "STEP9", "name": "mqtt_diagnose",
     "desc": "STEP 9 — Auto-discovery: root topics + sender + suggestions"},
    # H4.2 — Crypto agent (decrypt frontend)
    {"method": "POST",   "path": "/api/monitor/crypto/decrypt",
     "task": "H4.2", "name": "crypto_decrypt",
     "desc": "Decripta payload con PSK o PKI via API (frontend-driven)"},
    # Crypto Hunter — brute force catalogo PSK
    {"method": "POST",   "path": "/api/monitor/crypto/hunter",
     "task": "HUNTER", "name": "crypto_hunter",
     "desc": "Brute force: ruota tutte le PSK del DB su buffer RAM + DB 7g con breakdown per chiave"},
    # Tools index & status (T8)
    {"method": "GET",    "path": "/api/monitor/tools/index",
     "task": "T8", "name": "tools_index",
     "desc": "Lista completa endpoint crypto tool-suite"},
    {"method": "GET",    "path": "/api/monitor/tools/status",
     "task": "T8", "name": "tools_status",
     "desc": "Stato consolidato: pki_count, psk_count, mqtt, monitor"},
]


@app.route('/api/monitor/tools/index', methods=['GET'])
def api_monitor_tools_index():
    """H4.3-T8 — Elenco completo endpoint crypto tool-suite (no auth)."""
    return jsonify({
        "success": True,
        "count": len(_H43_TOOLS_INDEX),
        "tools": _H43_TOOLS_INDEX,
        "sprint": "H4.3",
        "version": "v1.2.0",
    })


@app.route('/api/monitor/tools/status', methods=['GET'])
def api_monitor_tools_status():
    """H4.3-T8 — Stato consolidato crypto tool-suite.

    Singolo roundtrip per UI: aggrega counters PKI/PSK, monitor, MQTT bridge.
    """
    ok_pro, err_resp = _require_pro()
    if not ok_pro:
        return err_resp
    _out = {
        "success": True,
        "db_ok": False,
        "monitor_active": False,
        "pki_count": 0,
        "pki_device_own_count": 0,
        "psk_count": 0,
        "buffer_size": 0,
        "mqtt": {"running": False, "connected": False,
                 "paho_available": False, "pb_available": False},
        "crypto_ok": False,
    }
    # DB + PKI + PSK counters
    try:
        import monitor_db
        _out["db_ok"] = True
        try:
            _pkis = monitor_db.pki_list(enabled_only=False) or []
            _out["pki_count"] = len(_pkis)
            _out["pki_device_own_count"] = sum(
                1 for k in _pkis if k.get("is_device_own"))
        except Exception:
            pass
        try:
            _psks = monitor_db.psk_list(enabled_only=False) or []
            _out["psk_count"] = len(_psks)
        except Exception:
            pass
    except Exception:
        pass
    # Monitor state
    try:
        if monitor is not None:
            _out["monitor_active"] = bool(monitor.is_active())
            try:
                _out["buffer_size"] = len(monitor._PKT_ENC_BUFFER)
            except Exception:
                pass
            try:
                _out["crypto_ok"] = bool(getattr(monitor, "_MCRYPT_OK", False))
            except Exception:
                pass
    except Exception:
        pass
    # MQTT bridge
    try:
        from mqtt_bridge import get_bridge
        _st = get_bridge().get_status()
        _out["mqtt"] = {
            "running": _st.get("running", False),
            "connected": _st.get("connected", False),
            "paho_available": _st.get("paho_available", False),
            "pb_available": _st.get("pb_available", False),
            "msgs_received": _st.get("msgs_received", 0),
            "msgs_parse_ok": _st.get("msgs_parse_ok", 0),
            "broker": _st.get("broker"),
            "topic": _st.get("topic"),
            "last_error": _st.get("last_error"),
        }
    except Exception:
        pass
    return jsonify(_out)


# ═══════════════════════════════════════════════════════════
# H4.2 — CRYPTO AGENT (decrypt frontend-driven: PSK + PKI + portnum parser)
# ═══════════════════════════════════════════════════════════

@app.route('/api/monitor/crypto/decrypt', methods=['POST'])
def api_monitor_crypto_decrypt():
    """Decripta un payload Meshtastic con una strategia specifica.

    Body JSON:
      - encrypted_hex (str, required)
      - packet_id (int, required)
      - from_node (int, required)
      - method: 'psk' | 'pki' | 'auto' (default 'auto')
      - psk_b64 (str) — per method=psk
      - my_priv_hex (str) — per method=pki
      - their_pub_hex (str) — per method=pki
      - portnum_hint (int|str, optional)
    """
    ok_pro, err_resp = _require_pro()
    if not ok_pro:
        return err_resp
    try:
        body = request.get_json(force=True, silent=True) or {}
    except Exception:
        return jsonify({"success": False, "error": "invalid_json"}), 400

    enc = body.get("encrypted_hex") or ""
    pid = int(body.get("packet_id") or 0)
    fn = int(body.get("from_node") or 0)
    method = (body.get("method") or "auto").lower()
    portnum_hint = body.get("portnum_hint")
    if not enc:
        return jsonify({"success": False, "error": "missing_encrypted_hex"}), 400

    try:
        from meshtastic_crypto import (try_decrypt, decrypt_pki,
                                       validate_decrypted, parse_portnum_payload)
    except Exception as e:
        return jsonify({"success": False, "error": "crypto_module_missing",
                        "detail": str(e)}), 500

    dec = None
    method_used = None
    if method in ("psk", "auto"):
        psk_b64 = body.get("psk_b64") or "AQ=="
        dec = try_decrypt(enc, pid, fn, psk_b64)
        if dec:
            ok, pn, payload = validate_decrypted(dec)
            if ok:
                parsed = parse_portnum_payload(pn, payload)
                return jsonify({
                    "success": True,
                    "method": "psk",
                    "psk_b64": psk_b64,
                    "cleartext_hex": dec.hex(),
                    "portnum": pn,
                    "parsed": parsed,
                })
    if method in ("pki", "auto"):
        priv = body.get("my_priv_hex") or ""
        pub = body.get("their_pub_hex") or ""
        if priv and pub:
            try:
                dec = decrypt_pki(enc, pid, fn, priv, pub)
                if dec:
                    ok, pn, payload = validate_decrypted(dec)
                    if ok:
                        parsed = parse_portnum_payload(pn, payload)
                        return jsonify({
                            "success": True,
                            "method": "pki",
                            "cleartext_hex": dec.hex(),
                            "portnum": pn,
                            "parsed": parsed,
                        })
            except Exception as e:
                return jsonify({"success": False, "error": "pki_fail",
                                "detail": str(e)}), 500
    return jsonify({"success": False, "error": "decrypt_failed",
                    "message": "La chiave fornita non decripta il pacchetto."}), 200


@app.route('/api/monitor/crypto/agent', methods=['POST'])
def api_monitor_crypto_agent():
    """Crypto Agent: prova TUTTE le chiavi (PSK del DB + PKI fornite) e ritorna
    tutti i campi decifrati + parse protobuf completo (ADMIN/ATAK/tutti i portnum).

    Body JSON: packet_dict (vedi crypto_agent_decrypt)
      - encrypted_hex, packet_id, from_node, to_node, portnum_hint, channel_idx,
        public_key_hex
      - pki_list (opt): [{label,my_priv_hex,their_pub_hex}, …]
    """
    ok_pro, err_resp = _require_pro()
    if not ok_pro:
        return err_resp
    try:
        body = request.get_json(force=True, silent=True) or {}
    except Exception:
        return jsonify({"success": False, "error": "invalid_json"}), 400
    try:
        from meshtastic_crypto import crypto_agent_decrypt
    except Exception as e:
        return jsonify({"success": False, "error": "crypto_module_missing",
                        "detail": str(e)}), 500
    # Carica TUTTE le PSK abilitate dal DB monitor
    psk_list = []
    try:
        if monitor_db:
            for k in monitor_db.psk_list_all() or []:
                if k.get("enabled", 1):
                    psk_list.append({
                        "id": k.get("id"),
                        "label": k.get("label") or "?",
                        "psk_b64": k.get("psk_b64") or "",
                        "kind": k.get("kind") or "public",
                        "enabled": 1,
                    })
    except Exception:
        psk_list = []
    pki_list = body.get("pki_list") or []
    result = crypto_agent_decrypt(body, psk_list=psk_list, pki_list=pki_list, verbose=True)
    return jsonify(result)


# ═══════════════════════════════════════════════════════════
# CRYPTO HUNTER — Brute force rotation catalogo PSK su buffer RAM + DB
# ═══════════════════════════════════════════════════════════

@app.route('/api/monitor/crypto/hunter', methods=['POST'])
def api_monitor_crypto_hunter():
    """Crypto Hunter — ruota tutte le PSK abilitate sul buffer RAM + DB 7g.

    Body JSON (opzionale):
      - window_days (int, default 7)   finestra temporale DB
      - limit (int, default 500)       max pacchetti DB da scorrere

    Ritorna (vedi monitor.hunter_run):
      {success, scanned_ram, decrypted_ram, scanned_db, decrypted_db,
       total_scanned, total_decrypted, psk_count, per_psk, results, errors}
    """
    ok_pro, err_resp = _require_pro()
    if not ok_pro:
        return err_resp
    guard = _mdb_guard()
    if guard:
        return guard
    _ensure_aggregator_started()
    body = request.get_json(silent=True) or {}
    try:
        window_days = int(body.get("window_days", 7))
        if window_days < 1: window_days = 1
        if window_days > 30: window_days = 30
    except Exception:
        window_days = 7
    try:
        limit = int(body.get("limit", 500))
        if limit < 10: limit = 10
        if limit > 5000: limit = 5000
    except Exception:
        limit = 500
    try:
        res = monitor.hunter_run(window_days=window_days, limit=limit)
    except Exception as e:
        return jsonify({"success": False, "error": "hunter_fail",
                        "message": str(e)}), 500
    if not res or not res.get("ok"):
        return jsonify({
            "success": False,
            "error": (res or {}).get("error", "unknown"),
            "psk_count": (res or {}).get("psk_count", 0),
            "buffer_size": (res or {}).get("buffer_size", 0),
        }), 400
    out = dict(res)
    out["success"] = True
    return jsonify(out)


# ═══════════════════════════════════════════════════════════
# STEP D — AUTO-TUNE NODE (preview + apply con conferma esplicita)
# ═══════════════════════════════════════════════════════════

@app.route('/api/monitor/tune/preview', methods=['GET'])
def api_monitor_tune_preview():
    """Confronta la configurazione attuale del nodo USB con i target Monitor.

    Ritorna 'current', 'target', 'diff' — nessuna modifica applicata.
    """
    ok_pro, err_resp = _require_pro()
    if not ok_pro:
        return err_resp
    if not _tune:
        return jsonify({"success": False, "error": "tune_module_missing"}), 500
    if not monitor or not monitor.is_active():
        return jsonify({"success": False, "error": "monitor_not_active",
                        "message": "Il Monitor deve essere attivo per leggere i parametri del nodo."}), 409
    try:
        iface = monitor._STATE.get("interface")
    except Exception:
        iface = None
    if iface is None:
        return jsonify({"success": False, "error": "no_interface"}), 500
    try:
        res = _tune.preview(iface)
    except Exception as e:
        return jsonify({"success": False, "error": "preview_fail", "message": str(e)}), 500
    return jsonify({"success": True, **res})


@app.route('/api/monitor/tune/apply', methods=['POST'])
def api_monitor_tune_apply():
    """Applica la tuning al nodo USB. Richiede body JSON {"confirm": true}.

    Ritorna 'applied', 'errors', 'new_state'.
    """
    ok_pro, err_resp = _require_pro()
    if not ok_pro:
        return err_resp
    if not _tune:
        return jsonify({"success": False, "error": "tune_module_missing"}), 500
    if not monitor or not monitor.is_active():
        return jsonify({"success": False, "error": "monitor_not_active"}), 409
    data = request.get_json(silent=True) or {}
    if not data.get("confirm"):
        return jsonify({"success": False, "error": "confirm_required",
                        "message": "Serve 'confirm': true esplicito per applicare le modifiche."}), 400
    try:
        iface = monitor._STATE.get("interface")
    except Exception:
        iface = None
    if iface is None:
        return jsonify({"success": False, "error": "no_interface"}), 500
    try:
        res = _tune.apply(iface, confirm=True)
    except Exception as e:
        return jsonify({"success": False, "error": "apply_fail", "message": str(e)}), 500
    return jsonify({"success": res.get("ok", False), **res})


# ═══════════════════════════════════════════════════════════
# STEP F — MONITOR MODE (profili esteso stock/mod + scheduler opt-in)
# ═══════════════════════════════════════════════════════════

def _require_monitor_active():
    """Helper: verifica monitor attivo + ritorna iface. (ok, iface_or_error_response)"""
    if not monitor or not monitor.is_active():
        return False, (jsonify({"success": False, "error": "monitor_not_active",
                                "message": "Il Monitor deve essere attivo."}), 409)
    try:
        iface = monitor._STATE.get("interface")
    except Exception:
        iface = None
    if iface is None:
        return False, (jsonify({"success": False, "error": "no_interface"}), 500)
    return True, iface


@app.route('/api/monitor/mode/preview', methods=['GET', 'POST'])
def api_monitor_mode_preview():
    """Preview Monitor Mode: confronta stato attuale con target del profilo.

    Body (opzionale): {"profile": "auto|stock|mod"}
    """
    ok_pro, err_resp = _require_pro()
    if not ok_pro:
        return err_resp
    if not _mmode:
        return jsonify({"success": False, "error": "mode_module_missing"}), 500
    ok, iface_or_err = _require_monitor_active()
    if not ok:
        return iface_or_err
    iface = iface_or_err
    data = request.get_json(silent=True) or {}
    profile = (data.get("profile") or request.args.get("profile") or "auto").lower()
    if profile not in ("auto", "stock", "mod"):
        return jsonify({"success": False, "error": "invalid_profile"}), 400
    try:
        res = _mmode.preview(iface, profile=profile)
    except Exception as e:
        return jsonify({"success": False, "error": "preview_fail", "message": str(e)}), 500
    return jsonify({"success": True, **res})


@app.route('/api/monitor/mode/apply', methods=['POST'])
def api_monitor_mode_apply():
    """Applica Monitor Mode al nodo. Body: {"profile": "...", "confirm": true}."""
    ok_pro, err_resp = _require_pro()
    if not ok_pro:
        return err_resp
    if not _mmode:
        return jsonify({"success": False, "error": "mode_module_missing"}), 500
    data = request.get_json(silent=True) or {}
    if not data.get("confirm"):
        return jsonify({"success": False, "error": "confirm_required",
                        "message": "Serve 'confirm': true esplicito."}), 400
    ok, iface_or_err = _require_monitor_active()
    if not ok:
        return iface_or_err
    iface = iface_or_err
    profile = (data.get("profile") or "auto").lower()
    if profile not in ("auto", "stock", "mod"):
        return jsonify({"success": False, "error": "invalid_profile"}), 400
    try:
        res = _mmode.apply(iface, profile=profile, confirm=True)
    except Exception as e:
        return jsonify({"success": False, "error": "apply_fail", "message": str(e)}), 500
    return jsonify({"success": res.get("ok", False), **res})


@app.route('/api/monitor/mode/reboot-now', methods=['POST'])
def api_monitor_mode_reboot_now():
    """Reboot immediato del nodo USB collegato. Body: {"confirm": true}."""
    ok_pro, err_resp = _require_pro()
    if not ok_pro:
        return err_resp
    if not _mmode:
        return jsonify({"success": False, "error": "mode_module_missing"}), 500
    data = request.get_json(silent=True) or {}
    if not data.get("confirm"):
        return jsonify({"success": False, "error": "confirm_required"}), 400
    ok, iface_or_err = _require_monitor_active()
    if not ok:
        return iface_or_err
    try:
        res = _mmode.reboot_now(iface_or_err, confirm=True)
    except Exception as e:
        return jsonify({"success": False, "error": "reboot_fail", "message": str(e)}), 500
    return jsonify({"success": res.get("ok", False), **res})


@app.route('/api/monitor/mode/reset-nodedb-now', methods=['POST'])
def api_monitor_mode_reset_nodedb_now():
    """Reset NodeDB immediato del nodo USB collegato. Body: {"confirm": true}."""
    ok_pro, err_resp = _require_pro()
    if not ok_pro:
        return err_resp
    if not _mmode:
        return jsonify({"success": False, "error": "mode_module_missing"}), 500
    data = request.get_json(silent=True) or {}
    if not data.get("confirm"):
        return jsonify({"success": False, "error": "confirm_required"}), 400
    ok, iface_or_err = _require_monitor_active()
    if not ok:
        return iface_or_err
    try:
        res = _mmode.reset_nodedb_now(iface_or_err, confirm=True)
    except Exception as e:
        return jsonify({"success": False, "error": "reset_fail", "message": str(e)}), 500
    return jsonify({"success": res.get("ok", False), **res})


@app.route('/api/monitor/mode/schedule', methods=['GET', 'POST'])
def api_monitor_mode_schedule():
    """GET: stato scheduler. POST: abilita/disabilita.

    Body POST: {"reboot_enabled": bool, "reboot_hours": int,
                "reset_enabled": bool, "reset_days": int}
    """
    ok_pro, err_resp = _require_pro()
    if not ok_pro:
        return err_resp
    if not _mmode:
        return jsonify({"success": False, "error": "mode_module_missing"}), 500
    if request.method == 'GET':
        return jsonify({"success": True, **_mmode.schedule_status()})
    data = request.get_json(silent=True) or {}
    try:
        if "reboot_enabled" in data:
            hrs = int(data.get("reboot_hours", 6))
            hrs = max(1, min(hrs, 168))  # 1h..7gg
            _mmode.schedule_reboot(enabled=bool(data["reboot_enabled"]),
                                   interval_hours=hrs)
        if "reset_enabled" in data:
            days = int(data.get("reset_days", 7))
            days = max(1, min(days, 90))  # 1g..90g
            _mmode.schedule_reset(enabled=bool(data["reset_enabled"]),
                                  interval_days=days)
    except Exception as e:
        return jsonify({"success": False, "error": "schedule_fail", "message": str(e)}), 500
    return jsonify({"success": True, **_mmode.schedule_status()})


@app.route('/api/monitor/mode/status', methods=['GET'])
def api_monitor_mode_status():
    """Stato completo Monitor Mode (scheduler + FW profile detected)."""
    ok_pro, err_resp = _require_pro()
    if not ok_pro:
        return err_resp
    if not _mmode:
        return jsonify({"success": False, "error": "mode_module_missing"}), 500
    out = {"success": True, "scheduler": _mmode.schedule_status()}
    ok, iface_or_err = _require_monitor_active()
    if ok:
        try:
            out["profile_auto"] = _mmode._detect_fw_profile(iface_or_err)
        except Exception:
            out["profile_auto"] = "stock"
    else:
        out["profile_auto"] = None
    return jsonify(out)


@app.route('/api/monitor/network/info', methods=['GET'])
def api_monitor_network_info():
    """Legge la configurazione di rete attuale del nodo e la confronta con l'attesa MIN / Mesh Italia."""
    ok_pro, err_resp = _require_pro()
    if not ok_pro:
        return err_resp
    if not _mmode:
        return jsonify({"success": False, "error": "mode_module_missing"}), 500
    ok, iface_or_err = _require_monitor_active()
    if not ok:
        return iface_or_err
    try:
        res = _mmode.read_network_info(iface_or_err)
    except Exception as e:
        return jsonify({"success": False, "error": "net_info_fail", "message": str(e)}), 500
    return jsonify({"success": True, **res})


@app.route('/api/monitor/nodes/gps', methods=['GET'])
def api_monitor_nodes_gps():
    """Lista nodi con coordinate GPS viste negli ultimi N ore (default 24h).

    Legge da monitor_db. Ritorna: [{node_id, name, lat, lon, snr, last_seen_iso}]
    """
    ok_pro, err_resp = _require_pro()
    if not ok_pro:
        return err_resp
    if not _MDB_AVAILABLE or mdb is None:
        return jsonify({"success": False, "error": "db_unavailable"}), 500
    try:
        hours = int(request.args.get("hours", 24))
        hours = max(1, min(hours, 168))
    except Exception:
        hours = 24
    try:
        nodes = mdb.list_gps_nodes(hours=hours) if hasattr(mdb, "list_gps_nodes") else []
    except Exception as e:
        return jsonify({"success": False, "error": "db_query_fail", "message": str(e)}), 500
    return jsonify({"success": True, "hours": hours, "count": len(nodes), "nodes": nodes})


# ═══════════════════════════════════════════════════════════
# STEP E — ANALYST AGENT (insights periodici su finestra 1h)
# ═══════════════════════════════════════════════════════════

@app.route('/api/monitor/analyst/insights', methods=['GET'])
def api_monitor_analyst_insights():
    """Ritorna gli insights correnti dell'Analyst Agent.

    Il thread analyst viene avviato automaticamente al primo accesso se
    non già attivo. Richiede PRO.

    FASE 6 (2026-05-05) — querystring opzionale:
        ?window_s=3600|21600|86400  (default 3600 = 1h)
        ?top_n=10                    (default 3, max 50)
        ?rank_by=packets|rssi_avg|snr_avg|hops|recency
    Se forniti, fa force_refresh con quei parametri.
    """
    ok_pro, err_resp = _require_pro()
    if not ok_pro:
        return err_resp
    if not _analyst:
        return jsonify({"success": False, "error": "analyst_module_missing"}), 500
    try:
        # Parse parametri opzionali — validation lato monitor_analyst
        _ws = request.args.get("window_s", type=int)
        _tn = request.args.get("top_n", type=int)
        _rb = request.args.get("rank_by", type=str) or "packets"
        if not _analyst.is_running():
            _analyst.start()
            _analyst.force_refresh(window_s=_ws, top_n=_tn, rank_by=_rb)
        elif _ws or _tn or (_rb and _rb != "packets"):
            # Force refresh on-demand se parametri custom forniti
            _analyst.force_refresh(window_s=_ws, top_n=_tn, rank_by=_rb)
        data = _analyst.get_insights()
    except Exception as e:
        return jsonify({"success": False, "error": "analyst_fail", "message": str(e)}), 500
    return jsonify({"success": True, **data})


@app.route('/api/monitor/analyst/refresh', methods=['POST'])
def api_monitor_analyst_refresh():
    """Forza un refresh immediato degli insights. Richiede PRO.

    FASE 6 (2026-05-05) — accetta JSON body opzionale o querystring:
        {"window_s":..., "top_n":..., "rank_by":"packets|rssi_avg|snr_avg|hops|recency"}
    """
    ok_pro, err_resp = _require_pro()
    if not ok_pro:
        return err_resp
    if not _analyst:
        return jsonify({"success": False, "error": "analyst_module_missing"}), 500
    try:
        # Body JSON o querystring
        _data = request.get_json(silent=True) or {}
        _ws = _data.get("window_s") or request.args.get("window_s", type=int)
        _tn = _data.get("top_n") or request.args.get("top_n", type=int)
        _rb = _data.get("rank_by") or request.args.get("rank_by", type=str) or "packets"
        res = _analyst.force_refresh(window_s=_ws, top_n=_tn, rank_by=_rb)
    except Exception as e:
        return jsonify({"success": False, "error": "refresh_fail", "message": str(e)}), 500
    return jsonify({"success": bool(res.get("ok")), **res})


@app.route('/api/monitor/analyst/stop', methods=['POST'])
def api_monitor_analyst_stop():
    """Ferma il thread analyst. Richiede PRO."""
    ok_pro, err_resp = _require_pro()
    if not ok_pro:
        return err_resp
    if not _analyst:
        return jsonify({"success": False, "error": "analyst_module_missing"}), 500
    try:
        res = _analyst.stop()
    except Exception as e:
        return jsonify({"success": False, "error": "stop_fail", "message": str(e)}), 500
    return jsonify({"success": bool(res.get("ok")), **res})


# ═══════════════════════════════════════════════════════════
# H4.4 — ADMIN CONTROL SUITE (30 AdminMessage wrapper)
# ═══════════════════════════════════════════════════════════

try:
    import admin_control as _admin_ctrl
    _ADMIN_OK = True
except Exception as _ac_e:
    _admin_ctrl = None
    _ADMIN_OK = False


_H44_ADMIN_INDEX = [
    {"method": "POST", "path": "/api/admin/execute",
     "task": "H4.4", "name": "admin_execute",
     "desc": "Dispatch dinamico: body {name, args} → admin_control.cmd_<name>"},
    {"method": "GET",  "path": "/api/admin/tools/index",
     "task": "H4.4", "name": "admin_index",
     "desc": "Catalogo 30 comandi AdminMessage + family/destructive flags"},
    {"method": "GET",  "path": "/api/admin/tools/status",
     "task": "H4.4", "name": "admin_status",
     "desc": "Stato readiness admin suite: iface/node/pki/destructive_count"},
]


def _admin_get_iface():
    """Recupera iface dal monitor. Ritorna None se non attivo."""
    try:
        if monitor is not None and monitor.is_active():
            return monitor._STATE.get("interface")
    except Exception:
        pass
    return None


@app.route('/api/admin/tools/index', methods=['GET'])
def api_admin_tools_index():
    """H4.4 — Lista catalogo 30 comandi Admin Control Suite (no auth).

    Pubblico come /api/monitor/tools/index → serve per UI che mostra
    i comandi disponibili, documentazione API, onboarding.
    """
    if not _ADMIN_OK:
        return jsonify({"success": False, "error": "admin_module_missing",
                        "count": 0, "commands": []}), 500
    # Arricchisci catalogo con info di supporto per UI
    cmds = []
    for c in _admin_ctrl.COMMAND_CATALOG:
        cmds.append({
            "name": c["name"],
            "family": c["family"],
            "destructive": bool(c["destructive"]),
            "desc": c["desc"],
        })
    return jsonify({
        "success": True,
        "sprint": "H4.4",
        "version": "v1.2.0",
        "count": len(cmds),
        "families": sorted(set(c["family"] for c in cmds)),
        "config_types": list(_admin_ctrl.CONFIG_TYPES),
        "module_config_types": list(_admin_ctrl.MODULE_CONFIG_TYPES),
        "channel_roles": list(_admin_ctrl.CHANNEL_ROLES),
        "commands": cmds,
        "endpoints": _H44_ADMIN_INDEX,
    })


@app.route('/api/admin/tools/status', methods=['GET'])
def api_admin_tools_status():
    """H4.4 — Stato readiness Admin Control Suite (PRO required)."""
    ok_pro, err_resp = _require_pro()
    if not ok_pro:
        return err_resp
    if not _ADMIN_OK:
        return jsonify({"success": False, "error": "admin_module_missing"}), 500
    iface = _admin_get_iface()
    has_iface = iface is not None
    has_node = bool(getattr(iface, "localNode", None)) if has_iface else False
    # Conteggio ops per famiglia
    by_family = {}
    destructive = 0
    for c in _admin_ctrl.COMMAND_CATALOG:
        by_family[c["family"]] = by_family.get(c["family"], 0) + 1
        if c["destructive"]:
            destructive += 1
    return jsonify({
        "success": True,
        "ready": bool(has_iface and has_node),
        "has_interface": has_iface,
        "has_local_node": has_node,
        "total_commands": len(_admin_ctrl.COMMAND_CATALOG),
        "destructive_commands": destructive,
        "commands_by_family": by_family,
        "monitor_active": bool(monitor and monitor.is_active()),
    })


@app.route('/api/admin/execute', methods=['POST'])
def api_admin_execute():
    """H4.4 — Dispatcher generico per i 30 comandi Admin Control Suite.

    Body JSON:
      { "name": "<command_name>", "args": { ... } }

    Esempio:
      { "name": "reboot", "args": { "seconds": 10, "confirm": true } }

    PRO gate + audit log obbligatori. Le ops distruttive richiedono
    `args.confirm = true` — controllo replicato lato admin_control.py.
    """
    ok_pro, err_resp = _require_pro()
    if not ok_pro:
        return err_resp
    if not _ADMIN_OK:
        return jsonify({"success": False, "error": "admin_module_missing"}), 500
    try:
        body = request.get_json(force=True, silent=True) or {}
    except Exception:
        return jsonify({"success": False, "error": "invalid_json"}), 400

    name = (body.get("name") or "").strip()
    args = body.get("args") or {}
    if not name:
        return jsonify({"success": False, "error": "missing_name"}), 400
    if not isinstance(args, dict):
        return jsonify({"success": False, "error": "args_not_dict"}), 400

    fn = _admin_ctrl.COMMAND_DISPATCH.get(name)
    if fn is None:
        return jsonify({"success": False, "error": "unknown_command",
                        "name": name,
                        "allowed": list(_admin_ctrl.COMMAND_DISPATCH)}), 404

    iface = _admin_get_iface()
    # Non fallire subito se iface None: admin_control gestisce internamente
    # il guard e ritorna {"error": "no_interface"} — più chiaro per debug UI
    try:
        result = fn(iface, **args)
    except TypeError as e:
        return jsonify({"success": False, "error": "bad_args",
                        "message": str(e), "name": name}), 400
    except Exception as e:
        return jsonify({"success": False, "error": "command_exception",
                        "message": str(e), "name": name}), 500

    # Audit log (best-effort, non blocca la risposta)
    try:
        import monitor_db
        if hasattr(monitor_db, "admin_audit_log"):
            monitor_db.admin_audit_log(
                command=name,
                args={k: v for k, v in args.items() if k != "confirm"},
                ok=bool(result.get("ok")),
                error=result.get("error"),
            )
    except Exception:
        pass

    status_code = 200 if result.get("ok") else 400
    return jsonify({"success": bool(result.get("ok")),
                    "name": name, **result}), status_code


# ═══════════════════════════════════════════════════════════
# GESTIONE ERRORI
# ═══════════════════════════════════════════════════════════

@app.errorhandler(404)
def not_found(e):
    return jsonify({"error": "Endpoint non trovato"}), 404

@app.errorhandler(500)
def server_error(e):
    return jsonify({"error": "Errore interno del server"}), 500


def create_app(port=5555):
    """Crea e ritorna l'app Flask configurata"""
    app.config['PORT'] = port
    return app
