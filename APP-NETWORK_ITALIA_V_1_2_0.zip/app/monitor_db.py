# -*- coding: utf-8 -*-
"""
📊 Meshtastic Italia Network App v1.2.0 — Monitor Database Layer
Persistenza SQLite 7 giorni con leaderboard, timeline, export CSV/JSON/MD.

Design:
  - SQLite nel profilo utente (cross-platform), stdlib only
  - Retention rolling 7 giorni, cleanup orario automatico
  - 3 tabelle: packets (record pacchetto), nodes (aggregato per nodo), stats_daily
  - Thread-safe via connection-per-call + WAL mode
  - Query leaderboard + timeline + export (CSV/JSON/MD)
  - Branding UI neutro: solo "MIN" è nominabile; ogni altro traffico
    italiano ricade nel bucket generico "mesh_italia"

© 2026 🌐🥭MANGOLINK🥭🌐 — Tutti i diritti riservati
"""

import os
import sys
import json
import time
import sqlite3
import threading
import datetime
import io
import csv

# ═══════════════════════════════════════════════════════════
# CONFIG
# ═══════════════════════════════════════════════════════════

DB_FILENAME = "monitor.db"
SCHEMA_VERSION = 2  # v2 (H1): packets 23→45 cols, nodes 22→38, 6 new tables, FTS5
DEFAULT_RETENTION_DAYS = 7
MAX_RETENTION_DAYS = 30
MIN_RETENTION_DAYS = 1
STATS_DAILY_RETENTION_DAYS = 30  # aggregati conservati oltre i raw
LEADERBOARD_DEFAULT_LIMIT = 20

# Finestre temporali valide per query (in secondi)
WINDOW_MAP = {
    "1h": 3600,
    "6h": 6 * 3600,
    "24h": 86400,
    "3d": 3 * 86400,
    "7d": 7 * 86400,
    "30d": 30 * 86400,
}

# Tipi leaderboard supportati (enum rigido — usato per validazione API)
LEADERBOARD_TYPES = {
    "top_nodes",          # Top nodi per packet count
    "top_channels",       # Top canali per traffico
    "top_portnums",       # Top PortNum
    "by_network",         # Distribuzione network (MIN/mesh_italia/unknown)
    "by_firmware",        # Distribuzione firmware fingerprint
    "best_signal",        # Top nodi per avg_rssi/snr
    "new_nodes",          # Nodi nuovi ultimi N
    "silent_nodes",       # Nodi visti ma silenti >24h
    "compressed_nodes",   # Nodi che usano portnum 7 (indicator fork)
    "hourly_heatmap",     # Traffico per ora giorno su finestra
}

EXPORT_FORMATS = {"csv", "json", "md"}

# Lock globale solo per init schema e purge (query normali usano conn/thread)
_SCHEMA_LOCK = threading.RLock()

# Singleton path resolution (una volta sola)
_DB_PATH_CACHE = None


# ═══════════════════════════════════════════════════════════
# PATH & CONNESSIONE
# ═══════════════════════════════════════════════════════════

def _app_data_dir():
    """Ritorna la directory user-profile cross-platform per DB persistente.
    Win: %APPDATA%\\Meshtastic Italia Network
    Mac: ~/Library/Application Support/Meshtastic Italia Network
    Linux/other: ~/.config/meshtastic-italia-network
    """
    app = "Meshtastic Italia Network"
    if sys.platform.startswith("win"):
        base = os.environ.get("APPDATA") or os.path.expanduser("~")
        return os.path.join(base, app)
    if sys.platform == "darwin":
        return os.path.join(os.path.expanduser("~"), "Library", "Application Support", app)
    base = os.environ.get("XDG_CONFIG_HOME") or os.path.join(os.path.expanduser("~"), ".config")
    return os.path.join(base, "meshtastic-italia-network")


def get_db_path():
    """Path assoluto del DB (crea directory se mancante, idempotente)."""
    global _DB_PATH_CACHE
    if _DB_PATH_CACHE:
        return _DB_PATH_CACHE
    d = _app_data_dir()
    try:
        os.makedirs(d, exist_ok=True)
    except Exception:
        # Fallback: accanto al modulo (ultima risorsa)
        d = os.path.dirname(os.path.abspath(__file__))
    _DB_PATH_CACHE = os.path.join(d, DB_FILENAME)
    return _DB_PATH_CACHE


def _connect():
    """Apre connessione con WAL + foreign keys + timeout decente.
    Ogni chiamata ritorna una nuova connessione (sqlite3 non è thread-safe su conn condivise)."""
    path = get_db_path()
    conn = sqlite3.connect(path, timeout=10.0, isolation_level=None)
    conn.row_factory = sqlite3.Row
    try:
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA synchronous=NORMAL")
        conn.execute("PRAGMA foreign_keys=ON")
    except Exception:
        pass
    return conn


# ═══════════════════════════════════════════════════════════
# SCHEMA
# ═══════════════════════════════════════════════════════════

_SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS meta (
    k TEXT PRIMARY KEY,
    v TEXT
);

CREATE TABLE IF NOT EXISTS packets (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ts INTEGER NOT NULL,
    from_node INTEGER NOT NULL,
    to_node INTEGER,
    channel_idx INTEGER,
    channel_hash INTEGER,
    channel_name TEXT,
    psk_match TEXT,
    network TEXT NOT NULL DEFAULT 'unknown',
    portnum INTEGER,
    port_name TEXT,
    payload_text TEXT,
    payload_len INTEGER,
    rssi INTEGER,
    snr REAL,
    hop_start INTEGER,
    hop_limit INTEGER,
    packet_id INTEGER,
    is_encrypted INTEGER NOT NULL DEFAULT 0,
    is_compressed INTEGER NOT NULL DEFAULT 0,
    fw_type TEXT,
    fw_flags TEXT,
    source TEXT
);

CREATE INDEX IF NOT EXISTS idx_packets_ts ON packets(ts DESC);
CREATE INDEX IF NOT EXISTS idx_packets_from ON packets(from_node, ts DESC);
CREATE INDEX IF NOT EXISTS idx_packets_channel ON packets(channel_name, ts DESC);
CREATE INDEX IF NOT EXISTS idx_packets_network ON packets(network, ts DESC);
CREATE INDEX IF NOT EXISTS idx_packets_portnum ON packets(portnum, ts DESC);
CREATE INDEX IF NOT EXISTS idx_packets_fw ON packets(fw_type, ts DESC);

CREATE TABLE IF NOT EXISTS nodes (
    node_id INTEGER PRIMARY KEY,
    node_hex TEXT,
    short_name TEXT,
    long_name TEXT,
    hw_model TEXT,
    first_seen INTEGER,
    last_seen INTEGER,
    network TEXT NOT NULL DEFAULT 'unknown',
    fw_type TEXT,
    fw_flags TEXT,
    total_packets INTEGER NOT NULL DEFAULT 0,
    rssi_sum REAL NOT NULL DEFAULT 0,
    rssi_n INTEGER NOT NULL DEFAULT 0,
    snr_sum REAL NOT NULL DEFAULT 0,
    snr_n INTEGER NOT NULL DEFAULT 0,
    stealth_suspect INTEGER NOT NULL DEFAULT 0,
    used_compression INTEGER NOT NULL DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_nodes_last_seen ON nodes(last_seen DESC);
CREATE INDEX IF NOT EXISTS idx_nodes_network ON nodes(network);

CREATE TABLE IF NOT EXISTS stats_daily (
    date TEXT PRIMARY KEY,
    total_packets INTEGER NOT NULL DEFAULT 0,
    unique_nodes INTEGER NOT NULL DEFAULT 0,
    by_network TEXT,
    by_firmware TEXT,
    by_portnum TEXT,
    by_channel TEXT,
    by_hour TEXT,
    updated_ts INTEGER
);

CREATE TABLE IF NOT EXISTS psk_keys (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    label TEXT NOT NULL,
    channel_name TEXT,
    psk_b64 TEXT NOT NULL,
    kind TEXT NOT NULL DEFAULT 'public',
    enabled INTEGER NOT NULL DEFAULT 1,
    match_count INTEGER NOT NULL DEFAULT 0,
    last_match_ts INTEGER,
    created_ts INTEGER NOT NULL,
    notes TEXT
);
CREATE INDEX IF NOT EXISTS idx_psk_enabled ON psk_keys(enabled);

-- ─────────────────────────────────────────────────────────────
-- STEP 2 Hunter — Channel map (hash8 → name/short/idx/psk)
-- Alimentata da sync_psks_from_node(). Usata per risolvere
-- channel_hash → nome canale nel terminale monitor.
-- ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS channel_map (
    hash8 INTEGER PRIMARY KEY,
    idx INTEGER,
    name TEXT,
    short_name TEXT,
    role TEXT,
    psk_b64 TEXT,
    default_psk INTEGER NOT NULL DEFAULT 0,
    updated_ts INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_channel_map_idx ON channel_map(idx);

-- ─────────────────────────────────────────────────────────────
-- H4.3-T1 — Tabella PKI X25519 (chiavi per decrypt DM PKI)
-- ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS pki_keys (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    label TEXT NOT NULL,
    my_priv_hex TEXT NOT NULL,
    my_pub_hex TEXT,
    their_pub_hex TEXT,
    source TEXT NOT NULL DEFAULT 'manual',
    is_device_own INTEGER NOT NULL DEFAULT 0,
    enabled INTEGER NOT NULL DEFAULT 1,
    match_count INTEGER NOT NULL DEFAULT 0,
    last_match_ts INTEGER,
    created_ts INTEGER NOT NULL,
    notes TEXT,
    UNIQUE(my_priv_hex, their_pub_hex)
);
CREATE INDEX IF NOT EXISTS idx_pki_enabled ON pki_keys(enabled);
CREATE INDEX IF NOT EXISTS idx_pki_device_own ON pki_keys(is_device_own, enabled);

-- ─────────────────────────────────────────────────────────────
-- STEP 5 — node_pubkeys: catalogo chiavi pubbliche osservate
-- Ogni nodo può avere più (node_id, pubkey) se ruota la chiave.
-- UNIQUE(node_id, public_key_hex) garantisce idempotenza harvest.
-- ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS node_pubkeys (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    node_id TEXT NOT NULL,
    node_num INTEGER,
    public_key_hex TEXT NOT NULL,
    first_seen_ts INTEGER NOT NULL,
    last_seen_ts INTEGER NOT NULL,
    seen_count INTEGER NOT NULL DEFAULT 1,
    source TEXT DEFAULT 'rf',
    UNIQUE(node_id, public_key_hex)
);
CREATE INDEX IF NOT EXISTS idx_node_pubkeys_node ON node_pubkeys(node_id);
CREATE INDEX IF NOT EXISTS idx_node_pubkeys_last ON node_pubkeys(last_seen_ts DESC);

-- ─────────────────────────────────────────────────────────────
-- H1 v2 — 6 nuove tabelle per metadata coverage 100%
-- ─────────────────────────────────────────────────────────────

-- Topology: edge mittente↔vicino (NEIGHBORINFO_APP)
CREATE TABLE IF NOT EXISTS topology (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ts INTEGER NOT NULL,
    node_id INTEGER NOT NULL,
    neighbor_id INTEGER NOT NULL,
    snr REAL,
    last_rx_time INTEGER,
    node_broadcast_interval_secs INTEGER,
    source TEXT
);
CREATE INDEX IF NOT EXISTS idx_topology_ts ON topology(ts DESC);
CREATE INDEX IF NOT EXISTS idx_topology_node ON topology(node_id, ts DESC);
CREATE INDEX IF NOT EXISTS idx_topology_neighbor ON topology(neighbor_id, ts DESC);
CREATE INDEX IF NOT EXISTS idx_topology_edge ON topology(node_id, neighbor_id, ts DESC);

-- Traceroutes: path completo multi-hop (TRACEROUTE_APP)
CREATE TABLE IF NOT EXISTS traceroutes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ts INTEGER NOT NULL,
    from_node INTEGER NOT NULL,
    to_node INTEGER NOT NULL,
    route_forward_json TEXT,
    route_back_json TEXT,
    snr_forward_json TEXT,
    snr_back_json TEXT,
    hop_count INTEGER,
    is_response INTEGER DEFAULT 0,
    packet_id INTEGER,
    source TEXT
);
CREATE INDEX IF NOT EXISTS idx_traceroutes_ts ON traceroutes(ts DESC);
CREATE INDEX IF NOT EXISTS idx_traceroutes_from ON traceroutes(from_node, ts DESC);
CREATE INDEX IF NOT EXISTS idx_traceroutes_to ON traceroutes(to_node, ts DESC);

-- Map reports: metadata broadcast nodi (MAP_REPORT_APP)
CREATE TABLE IF NOT EXISTS map_reports (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ts INTEGER NOT NULL,
    node_id INTEGER NOT NULL,
    long_name TEXT,
    short_name TEXT,
    role INTEGER,
    hw_model INTEGER,
    firmware_version TEXT,
    region INTEGER,
    modem_preset INTEGER,
    has_default_channel INTEGER,
    latitude_i INTEGER,
    longitude_i INTEGER,
    altitude INTEGER,
    position_precision INTEGER,
    num_online_local_nodes INTEGER,
    has_opted_report_location INTEGER,
    source TEXT
);
CREATE INDEX IF NOT EXISTS idx_map_reports_ts ON map_reports(ts DESC);
CREATE INDEX IF NOT EXISTS idx_map_reports_node ON map_reports(node_id, ts DESC);

-- Waypoints: POI condivisi in rete (WAYPOINT_APP)
CREATE TABLE IF NOT EXISTS waypoints (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ts INTEGER NOT NULL,
    waypoint_id INTEGER NOT NULL,
    from_node INTEGER NOT NULL,
    latitude_i INTEGER,
    longitude_i INTEGER,
    expire INTEGER,
    locked_to INTEGER,
    name TEXT,
    description TEXT,
    icon INTEGER,
    source TEXT
);
CREATE INDEX IF NOT EXISTS idx_waypoints_ts ON waypoints(ts DESC);
CREATE INDEX IF NOT EXISTS idx_waypoints_id ON waypoints(waypoint_id, ts DESC);
CREATE INDEX IF NOT EXISTS idx_waypoints_from ON waypoints(from_node, ts DESC);

-- Store&Forward stats: storico heartbeat/history/stats dei router S&F
CREATE TABLE IF NOT EXISTS storeforward_stats (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ts INTEGER NOT NULL,
    node_id INTEGER NOT NULL,
    rr_type INTEGER,
    messages_total INTEGER,
    messages_saved INTEGER,
    messages_max INTEGER,
    up_time INTEGER,
    requests INTEGER,
    requests_history INTEGER,
    heartbeat INTEGER,
    return_max INTEGER,
    return_window INTEGER,
    history_messages INTEGER,
    history_window INTEGER,
    history_last_request INTEGER,
    source TEXT
);
CREATE INDEX IF NOT EXISTS idx_sf_stats_ts ON storeforward_stats(ts DESC);
CREATE INDEX IF NOT EXISTS idx_sf_stats_node ON storeforward_stats(node_id, ts DESC);

-- Node metadata: snapshot MyNodeInfo + DeviceMetadata (valori al tempo t)
CREATE TABLE IF NOT EXISTS node_metadata (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ts INTEGER NOT NULL,
    node_id INTEGER NOT NULL,
    firmware_version TEXT,
    device_state_version INTEGER,
    canShutdown INTEGER,
    hasWifi INTEGER,
    hasBluetooth INTEGER,
    hasEthernet INTEGER,
    role INTEGER,
    position_flags INTEGER,
    hw_model INTEGER,
    hasRemoteHardware INTEGER,
    hasPKC INTEGER,
    excluded_modules INTEGER,
    reboot_count INTEGER,
    min_app_version INTEGER,
    pio_env TEXT,
    device_id_hex TEXT,
    source TEXT
);
CREATE INDEX IF NOT EXISTS idx_nodemeta_ts ON node_metadata(ts DESC);
CREATE INDEX IF NOT EXISTS idx_nodemeta_node ON node_metadata(node_id, ts DESC);
"""


def init_db():
    """Crea schema se mancante e registra versione. Idempotente."""
    with _SCHEMA_LOCK:
        conn = _connect()
        try:
            conn.executescript(_SCHEMA_SQL)
            conn.execute(
                "INSERT OR IGNORE INTO meta(k,v) VALUES(?,?)",
                ("schema_version", str(SCHEMA_VERSION)),
            )
            conn.execute(
                "INSERT OR IGNORE INTO meta(k,v) VALUES(?,?)",
                ("created_ts", str(int(time.time() * 1000))),
            )
            # Migrazione colonna encrypted_hex (STEP B rematch)
            try:
                cols = conn.execute("PRAGMA table_info(packets)").fetchall()
                names = {c["name"] for c in cols}
                if "encrypted_hex" not in names:
                    conn.execute("ALTER TABLE packets ADD COLUMN encrypted_hex TEXT")
                # FASE 15 (2026-05-05): channel_hash 8-bit per disambiguazione PSK condivise.
                # channel_idx era limitato a 0-7 (slot USB), channel_hash copre 0-255.
                if "channel_hash" not in names:
                    conn.execute("ALTER TABLE packets ADD COLUMN channel_hash INTEGER")
                    # Backfill iniziale: per pacchetti pre-FASE-15 usa channel_idx
                    conn.execute(
                        "UPDATE packets SET channel_hash = channel_idx "
                        "WHERE channel_hash IS NULL AND channel_idx IS NOT NULL"
                    )
                    try:
                        conn.execute(
                            "CREATE INDEX IF NOT EXISTS idx_packets_chash "
                            "ON packets(channel_hash, ts DESC)"
                        )
                    except Exception:
                        pass
            except Exception:
                pass
            # Migrazione colonne GPS su nodes (STEP F4 — lista nodi con posizione)
            try:
                cols = conn.execute("PRAGMA table_info(nodes)").fetchall()
                names = {c["name"] for c in cols}
                if "latitude" not in names:
                    conn.execute("ALTER TABLE nodes ADD COLUMN latitude REAL")
                if "longitude" not in names:
                    conn.execute("ALTER TABLE nodes ADD COLUMN longitude REAL")
                if "altitude" not in names:
                    conn.execute("ALTER TABLE nodes ADD COLUMN altitude INTEGER")
                if "pos_ts" not in names:
                    conn.execute("ALTER TABLE nodes ADD COLUMN pos_ts INTEGER")
                conn.execute("CREATE INDEX IF NOT EXISTS idx_nodes_pos_ts ON nodes(pos_ts DESC)")
            except Exception:
                pass

            # ═════════════════════════════════════════════════════════
            # H1 v2 — Migrazione 22 colonne packets + 16 colonne nodes
            # Target: coverage 100% metadata (311 campi hot-data)
            # ═════════════════════════════════════════════════════════

            # --- packets: 22 nuove colonne ---
            try:
                cols = conn.execute("PRAGMA table_info(packets)").fetchall()
                names = {c["name"] for c in cols}
                _packet_new_cols = [
                    # Telemetry (1 JSON blob → variant + tutti i sub-field)
                    ("telemetry_json", "TEXT"),
                    # Position quality + scalar denormalized per index
                    ("position_quality_json", "TEXT"),
                    ("position_lat", "REAL"),
                    ("position_lon", "REAL"),
                    ("position_alt", "INTEGER"),
                    ("position_sats", "INTEGER"),
                    ("position_pdop", "REAL"),
                    # Decoded Data meta (7 campi Meshtastic Data)
                    ("decoded_meta_json", "TEXT"),
                    ("request_id", "INTEGER"),
                    ("reply_id", "INTEGER"),
                    ("emoji", "INTEGER"),
                    ("want_response", "INTEGER"),
                    # Radio control (5 campi MeshPacket routing)
                    ("radio_control_json", "TEXT"),
                    ("next_hop", "INTEGER"),
                    ("relay_node", "INTEGER"),
                    ("hops_away", "INTEGER"),
                    ("via_mqtt", "INTEGER DEFAULT 0"),
                    ("want_ack", "INTEGER DEFAULT 0"),
                    ("priority", "INTEGER"),
                    # 100% recovery guarantee: protobuf bytes b64
                    ("raw_protobuf_b64", "TEXT"),
                    # Firmware fingerprint extra
                    ("public_key_hex", "TEXT"),
                    ("pki_encrypted", "INTEGER DEFAULT 0"),
                ]
                for col_name, col_type in _packet_new_cols:
                    if col_name not in names:
                        conn.execute(f"ALTER TABLE packets ADD COLUMN {col_name} {col_type}")
                conn.execute("CREATE INDEX IF NOT EXISTS idx_packets_position ON packets(position_lat, position_lon)")
                conn.execute("CREATE INDEX IF NOT EXISTS idx_packets_reply ON packets(reply_id)")
                conn.execute("CREATE INDEX IF NOT EXISTS idx_packets_request ON packets(request_id)")
                conn.execute("CREATE INDEX IF NOT EXISTS idx_packets_via_mqtt ON packets(via_mqtt, ts DESC)")
            except Exception as e:
                try:
                    sys.stderr.write(f"[monitor_db] migration packets v2 warn: {e}\n")
                except Exception:
                    pass

            # --- nodes: 16 nuove colonne ---
            try:
                cols = conn.execute("PRAGMA table_info(nodes)").fetchall()
                names = {c["name"] for c in cols}
                _nodes_new_cols = [
                    # User extras (5 campi User.proto)
                    ("macaddr", "TEXT"),
                    ("role", "TEXT"),
                    ("is_licensed", "INTEGER DEFAULT 0"),
                    ("is_stealth", "INTEGER DEFAULT 0"),
                    ("is_unmessagable", "INTEGER DEFAULT 0"),
                    ("public_key_hex", "TEXT"),
                    # MyNodeInfo + DeviceMetadata snapshot
                    ("firmware_version", "TEXT"),
                    ("region", "TEXT"),
                    ("modem_preset", "TEXT"),
                    ("hops_away", "INTEGER"),
                    ("via_mqtt_last", "INTEGER DEFAULT 0"),
                    # Telemetry live snapshot
                    ("last_battery", "INTEGER"),
                    ("last_voltage", "REAL"),
                    ("last_ch_util", "REAL"),
                    ("last_tx_util", "REAL"),
                    ("last_uptime", "INTEGER"),
                ]
                for col_name, col_type in _nodes_new_cols:
                    if col_name not in names:
                        conn.execute(f"ALTER TABLE nodes ADD COLUMN {col_name} {col_type}")
                conn.execute("CREATE INDEX IF NOT EXISTS idx_nodes_role ON nodes(role)")
                conn.execute("CREATE INDEX IF NOT EXISTS idx_nodes_region ON nodes(region)")
                conn.execute("CREATE INDEX IF NOT EXISTS idx_nodes_preset ON nodes(modem_preset)")
            except Exception as e:
                try:
                    sys.stderr.write(f"[monitor_db] migration nodes v2 warn: {e}\n")
                except Exception:
                    pass

            # --- FTS5 packets_fts (ricerca globale Hub Monitor Scanner) ---
            # Guarded: SQLite può non avere FTS5 compilato. In quel caso,
            # la search_fts() fallback su LIKE su payload_text/short_name/long_name.
            try:
                conn.execute(
                    "CREATE VIRTUAL TABLE IF NOT EXISTS packets_fts USING fts5("
                    "payload_text, port_name, channel_name, "
                    "short_name UNINDEXED, long_name UNINDEXED, "
                    "from_hex UNINDEXED, "
                    "content='', "
                    "tokenize='unicode61 remove_diacritics 2'"
                    ")"
                )
                set_meta("fts5_available", "1")
            except Exception as e:
                # FTS5 non disponibile → marcato per fallback in search_fts()
                try:
                    set_meta("fts5_available", "0")
                    sys.stderr.write(f"[monitor_db] FTS5 non disponibile (fallback LIKE): {e}\n")
                except Exception:
                    pass

            # Bump schema_version in meta
            try:
                conn.execute(
                    "INSERT INTO meta(k,v) VALUES(?,?) "
                    "ON CONFLICT(k) DO UPDATE SET v=excluded.v",
                    ("schema_version", str(SCHEMA_VERSION)),
                )
            except Exception:
                pass

            # Seed PSK pubbliche di default (solo al primo avvio)
            try:
                _seed_default_psks(conn)
            except Exception:
                pass

            # Seed catalogo PSK Italia (36 canali, 9 PSK uniche) — idempotente per label
            # Auto-load al primo avvio per dare copertura immediata sui canali italiani
            # noti (VoxLibera, RRP, SOS-Abruzzo, Newsfeed regionali, Mesh Mod, ecc.).
            try:
                _seed_italia_catalog(conn)
            except Exception:
                pass

            # FASE 7 (2026-05-05) — UNIQUE INDEX su psk_keys.label per evitare
            # duplicati da double-click "Aggiungi PSK" o sync concorrenti.
            # Idempotente: se trova duplicati, mantiene la riga con id minimo
            # (la prima inserita) e rimuove le altre.
            try:
                # Pulizia duplicati pre-esistenti (mantieni id MIN per ogni label)
                conn.execute(
                    "DELETE FROM psk_keys WHERE id NOT IN ("
                    "  SELECT MIN(id) FROM psk_keys GROUP BY label"
                    ")"
                )
                # Indice UNIQUE — IF NOT EXISTS rende l'op idempotente
                conn.execute(
                    "CREATE UNIQUE INDEX IF NOT EXISTS "
                    "idx_psk_keys_label_unique ON psk_keys(label)"
                )
            except Exception as _e:
                try:
                    sys.stderr.write(f"[monitor_db] PSK UNIQUE index skip: {_e}\n")
                except Exception:
                    pass
        finally:
            conn.close()


def _seed_default_psks(conn):
    """Precarica PSK pubbliche note.

    Idempotente per label: ogni PSK in DEFAULT_PUBLIC_PSKS viene inserita SOLO
    se non esiste già una row con quella label. Questo permette di aggiungere
    nuove PSK al catalogo nelle versioni successive dell'app senza toccare
    PSK custom o disabilitate dall'utente.
    """
    try:
        # Import lazy per evitare dipendenza circolare
        try:
            import meshtastic_crypto as _mc
            defaults = getattr(_mc, "DEFAULT_PUBLIC_PSKS", [])
        except Exception:
            defaults = [{
                "label": "Meshtastic Default (AQ==)",
                "psk_b64": "AQ==",
                "kind": "public",
                "channel_name": "LongFast",
                "notes": "Canale primario Meshtastic pubblico.",
            }]
        now_ts = int(time.time() * 1000)
        for p in defaults:
            label = p.get("label", "Unknown")
            # Check if this label already exists (upsert by label)
            existing = conn.execute(
                "SELECT id FROM psk_keys WHERE label=? LIMIT 1", (label,)
            ).fetchone()
            if existing:
                continue  # già presente, non toccare
            conn.execute(
                "INSERT INTO psk_keys(label, psk_b64, kind, channel_name, enabled, match_count, created_ts, notes) "
                "VALUES(?,?,?,?,1,0,?,?)",
                (
                    label,
                    p.get("psk_b64", ""),
                    p.get("kind", "public"),
                    p.get("channel_name"),
                    now_ts,
                    p.get("notes"),
                ),
            )
    except Exception:
        pass


def _seed_italia_catalog(conn):
    """Precarica catalogo PSK Italia da psk_catalog_italia.json al primo avvio.

    Idempotente per label: ogni entry viene inserita SOLO se non esiste già una
    row con quella label (rispetta modifiche utente o disabilitazioni). Stesso
    pattern di _seed_default_psks().

    Il file psk_catalog_italia.json deve trovarsi accanto a monitor_db.py (in
    app/). Se assente o malformato, il seed fallisce silenziosamente (non blocca
    l'avvio dell'app).

    Schema atteso:
        {"version": "...", "entries": [
            {"label": "...", "psk_b64": "...", "kind": "...",
             "channel_name": "...", "notes": "..."}, ...
        ]}
    """
    try:
        import json as _json
        _cat_path = os.path.join(
            os.path.dirname(os.path.abspath(__file__)),
            "psk_catalog_italia.json",
        )
        if not os.path.isfile(_cat_path):
            return
        with open(_cat_path, "r", encoding="utf-8") as _f:
            _cat = _json.load(_f)
        _entries = _cat.get("entries") or []
        if not isinstance(_entries, list) or not _entries:
            return
        now_ts = int(time.time() * 1000)
        _added = 0
        _skipped = 0
        for _e in _entries:
            try:
                _label = str(_e.get("label") or "").strip()
                _psk = str(_e.get("psk_b64") or "").strip()
                if not _label or not _psk:
                    continue
                # Check idempotenza per label
                _existing = conn.execute(
                    "SELECT id FROM psk_keys WHERE label=? LIMIT 1", (_label,)
                ).fetchone()
                if _existing:
                    _skipped += 1
                    continue
                _kind = str(_e.get("kind") or "private").lower()
                if _kind not in ("public", "private"):
                    _kind = "private"
                _channel_name = _e.get("channel_name")
                _notes = _e.get("notes") or ""
                conn.execute(
                    "INSERT INTO psk_keys(label, psk_b64, kind, channel_name, "
                    "enabled, match_count, created_ts, notes) "
                    "VALUES(?,?,?,?,1,0,?,?)",
                    (_label[:80], _psk[:200], _kind,
                     (_channel_name[:60] if _channel_name else None),
                     now_ts, _notes[:200]),
                )
                _added += 1
            except Exception:
                continue
        if _added > 0:
            try:
                sys.stderr.write(
                    f"[monitor_db] Seeded {_added} PSK Italia "
                    f"(skipped {_skipped} already-present)\n"
                )
            except Exception:
                pass
    except Exception as e:
        try:
            sys.stderr.write(f"[monitor_db] _seed_italia_catalog failed: {e}\n")
        except Exception:
            pass


def get_meta(key, default=None):
    conn = _connect()
    try:
        row = conn.execute("SELECT v FROM meta WHERE k=?", (key,)).fetchone()
        return row["v"] if row else default
    finally:
        conn.close()


def set_meta(key, value):
    conn = _connect()
    try:
        conn.execute(
            "INSERT INTO meta(k,v) VALUES(?,?) "
            "ON CONFLICT(k) DO UPDATE SET v=excluded.v",
            (key, str(value)),
        )
    finally:
        conn.close()


# ═══════════════════════════════════════════════════════════
# HELPERS
# ═══════════════════════════════════════════════════════════

def _now_ms():
    return int(time.time() * 1000)


def _node_int(v):
    """Converte !abcd1234 o int/str in intero NodeNum."""
    if v is None:
        return None
    if isinstance(v, int):
        return v
    s = str(v).strip()
    if not s:
        return None
    if s.startswith("!"):
        try:
            return int(s[1:], 16)
        except Exception:
            return None
    # Tenta decimale, poi hex
    try:
        return int(s)
    except Exception:
        try:
            return int(s, 16)
        except Exception:
            return None


def _node_hex(n):
    if n is None:
        return None
    try:
        return "!" + f"{int(n):08x}"
    except Exception:
        return None


# ═══════════════════════════════════════════════════════════
# RETENTION CONFIG
# ═══════════════════════════════════════════════════════════

def get_retention_days():
    v = get_meta("retention_days")
    try:
        d = int(v) if v else DEFAULT_RETENTION_DAYS
    except Exception:
        d = DEFAULT_RETENTION_DAYS
    return max(MIN_RETENTION_DAYS, min(MAX_RETENTION_DAYS, d))


def set_retention_days(days):
    d = max(MIN_RETENTION_DAYS, min(MAX_RETENTION_DAYS, int(days)))
    set_meta("retention_days", d)
    return d


# Toggle: salvataggio testi, payload, enrichment, per-canale exclude
def get_flag(name, default=True):
    v = get_meta(f"flag_{name}")
    if v is None:
        return default
    return str(v).lower() in ("1", "true", "yes", "on")


def set_flag(name, value):
    set_meta(f"flag_{name}", "1" if value else "0")


# ═══════════════════════════════════════════════════════════
# INSERT PACKET + UPSERT NODE
# ═══════════════════════════════════════════════════════════

_INSERT_PACKET_SQL = """
INSERT INTO packets(
    ts, from_node, to_node, channel_idx, channel_hash, channel_name, psk_match, network,
    portnum, port_name, payload_text, payload_len,
    rssi, snr, hop_start, hop_limit, packet_id,
    is_encrypted, is_compressed, fw_type, fw_flags, source, encrypted_hex,
    -- H2 v2: 22 nuove colonne
    telemetry_json, position_quality_json,
    position_lat, position_lon, position_alt, position_sats, position_pdop,
    decoded_meta_json, request_id, reply_id, emoji, want_response,
    radio_control_json, next_hop, relay_node, hops_away,
    via_mqtt, want_ack, priority,
    raw_protobuf_b64, public_key_hex, pki_encrypted
) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,
          ?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
"""

_UPSERT_NODE_SQL = """
INSERT INTO nodes(
    node_id, node_hex, short_name, long_name, hw_model,
    first_seen, last_seen, network, fw_type, fw_flags,
    total_packets, rssi_sum, rssi_n, snr_sum, snr_n,
    stealth_suspect, used_compression,
    -- H2 v2: 16 nuove colonne
    macaddr, role, is_licensed, is_stealth, is_unmessagable, public_key_hex,
    firmware_version, region, modem_preset, hops_away, via_mqtt_last,
    last_battery, last_voltage, last_ch_util, last_tx_util, last_uptime
) VALUES (?,?,?,?,?,?,?,?,?,?,1,?,?,?,?,?,?,
          ?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
ON CONFLICT(node_id) DO UPDATE SET
    short_name   = COALESCE(excluded.short_name, nodes.short_name),
    long_name    = COALESCE(excluded.long_name,  nodes.long_name),
    hw_model     = COALESCE(excluded.hw_model,   nodes.hw_model),
    last_seen    = MAX(nodes.last_seen, excluded.last_seen),
    network      = CASE WHEN excluded.network != 'unknown' THEN excluded.network ELSE nodes.network END,
    fw_type      = CASE WHEN excluded.fw_type IS NOT NULL AND excluded.fw_type != 'unknown' THEN excluded.fw_type ELSE nodes.fw_type END,
    fw_flags     = COALESCE(excluded.fw_flags, nodes.fw_flags),
    total_packets= nodes.total_packets + 1,
    rssi_sum     = nodes.rssi_sum + excluded.rssi_sum,
    rssi_n       = nodes.rssi_n + excluded.rssi_n,
    snr_sum      = nodes.snr_sum + excluded.snr_sum,
    snr_n        = nodes.snr_n + excluded.snr_n,
    stealth_suspect  = MAX(nodes.stealth_suspect, excluded.stealth_suspect),
    used_compression = MAX(nodes.used_compression, excluded.used_compression),
    -- H2 v2: 16 nuove colonne (COALESCE = nuovo valore se presente, else vecchio)
    macaddr           = COALESCE(excluded.macaddr, nodes.macaddr),
    role              = COALESCE(excluded.role, nodes.role),
    is_licensed       = COALESCE(NULLIF(excluded.is_licensed, 0), nodes.is_licensed),
    is_stealth        = COALESCE(NULLIF(excluded.is_stealth, 0), nodes.is_stealth),
    is_unmessagable   = COALESCE(NULLIF(excluded.is_unmessagable, 0), nodes.is_unmessagable),
    public_key_hex    = COALESCE(excluded.public_key_hex, nodes.public_key_hex),
    firmware_version  = COALESCE(excluded.firmware_version, nodes.firmware_version),
    region            = COALESCE(excluded.region, nodes.region),
    modem_preset      = COALESCE(excluded.modem_preset, nodes.modem_preset),
    hops_away         = COALESCE(excluded.hops_away, nodes.hops_away),
    via_mqtt_last     = excluded.via_mqtt_last,
    last_battery      = COALESCE(excluded.last_battery, nodes.last_battery),
    last_voltage      = COALESCE(excluded.last_voltage, nodes.last_voltage),
    last_ch_util      = COALESCE(excluded.last_ch_util, nodes.last_ch_util),
    last_tx_util      = COALESCE(excluded.last_tx_util, nodes.last_tx_util),
    last_uptime       = COALESCE(excluded.last_uptime, nodes.last_uptime)
"""


def _js(v):
    """Helper JSON serializer: None → None, dict/list → stringa compatta."""
    if v is None:
        return None
    if isinstance(v, str):
        return v
    try:
        return json.dumps(v, separators=(",", ":"), default=str)
    except Exception:
        return None


def _bool_int(v):
    """None → None, bool/int/str → 0/1. None preserva NULL nel DB."""
    if v is None:
        return None
    return 1 if v else 0


def insert_packet(data):
    """Inserisce un pacchetto + upsert nodo mittente. Accetta dict con chiavi:
      ts, from_node (int o !hex), to_node, channel_idx, channel_name, psk_match,
      network, portnum, port_name, payload_text, payload_len,
      rssi, snr, hop_start, hop_limit, packet_id, is_encrypted, is_compressed,
      fw_type, fw_flags, source, short_name, long_name, hw_model, stealth_suspect

    Ritorna lastrowid o None in caso di errore (loggato ma non propagato).
    """
    try:
        from_int = _node_int(data.get("from_node"))
        if from_int is None:
            return None
        ts = int(data.get("ts") or _now_ms())
        # Normalizza testo: se flag save_text OFF → None anche se passato
        if not get_flag("save_text", True):
            payload_text = None
        else:
            payload_text = data.get("payload_text")
        if not get_flag("save_payload", True):
            payload_len = None
        else:
            payload_len = data.get("payload_len")

        network = data.get("network") or "unknown"
        fw_type = data.get("fw_type") or "unknown"
        fw_flags = data.get("fw_flags")
        if isinstance(fw_flags, dict):
            fw_flags = json.dumps(fw_flags, separators=(",", ":"))

        is_compressed = 1 if data.get("is_compressed") else 0
        is_encrypted = 1 if data.get("is_encrypted") else 0
        # Storicizza l'encrypted_hex SOLO per pacchetti cifrati (rematch futuro)
        enc_hex_store = None
        if is_encrypted:
            eh = data.get("encrypted_hex") or ""
            if eh and len(eh) <= 2000:  # cap 1000 bytes payload, evita abuse
                enc_hex_store = eh

        # H2 v2 — Estrazione e normalizzazione campi nuovi
        # Telemetry + position_quality: passati come dict → JSON compatto
        telemetry_json = _js(data.get("telemetry"))
        position_quality_json = _js(data.get("position_quality"))
        decoded_meta_json = _js(data.get("decoded_meta"))
        radio_control_json = _js(data.get("radio_control"))
        # Position scalari denormalizzate (per index + fast query)
        pos_lat = data.get("position_lat") if data.get("position_lat") is not None else data.get("latitude")
        pos_lon = data.get("position_lon") if data.get("position_lon") is not None else data.get("longitude")
        pos_alt = data.get("position_alt") if data.get("position_alt") is not None else data.get("altitude")
        # cast safe
        try:
            pos_lat = float(pos_lat) if pos_lat is not None else None
            pos_lon = float(pos_lon) if pos_lon is not None else None
        except Exception:
            pos_lat, pos_lon = None, None
        try:
            pos_alt = int(pos_alt) if pos_alt is not None else None
        except Exception:
            pos_alt = None
        # sanity GPS
        if pos_lat is not None and pos_lon is not None:
            if not (-90.0 <= pos_lat <= 90.0 and -180.0 <= pos_lon <= 180.0) \
                    or (abs(pos_lat) < 1e-6 and abs(pos_lon) < 1e-6):
                pos_lat, pos_lon, pos_alt = None, None, None

        pos_sats = data.get("position_sats") or data.get("sats_in_view")
        pos_pdop = data.get("position_pdop") or data.get("pdop")
        try:
            pos_sats = int(pos_sats) if pos_sats is not None else None
        except Exception:
            pos_sats = None
        try:
            pos_pdop = float(pos_pdop) if pos_pdop is not None else None
        except Exception:
            pos_pdop = None

        # Decoded meta scalar (dal decoded_meta dict)
        dmeta = data.get("decoded_meta") or {}
        if not isinstance(dmeta, dict):
            dmeta = {}
        request_id = data.get("request_id") or dmeta.get("request_id")
        reply_id = data.get("reply_id") or dmeta.get("reply_id")
        emoji = data.get("emoji") or dmeta.get("emoji")
        want_response = _bool_int(data.get("want_response") if data.get("want_response") is not None else dmeta.get("want_response"))

        # Radio control
        rctl = data.get("radio_control") or {}
        if not isinstance(rctl, dict):
            rctl = {}
        next_hop = data.get("next_hop") or rctl.get("next_hop")
        relay_node = data.get("relay_node") or rctl.get("relay_node")
        hops_away_pkt = data.get("hops_away") if data.get("hops_away") is not None else rctl.get("hops_away")
        via_mqtt = _bool_int(data.get("via_mqtt"))
        want_ack = _bool_int(data.get("want_ack"))
        priority_val = data.get("priority_num") if data.get("priority_num") is not None else None
        try:
            priority_val = int(priority_val) if priority_val is not None else None
        except Exception:
            priority_val = None

        # Recovery 100%
        raw_protobuf_b64 = data.get("raw_protobuf_b64")
        public_key_hex = data.get("public_key_hex")
        pki_encrypted = _bool_int(data.get("pki_encrypted"))

        # cast safe per campi int/str
        try:
            request_id = int(request_id) if request_id is not None else None
        except Exception:
            request_id = None
        try:
            reply_id = int(reply_id) if reply_id is not None else None
        except Exception:
            reply_id = None
        try:
            emoji = int(emoji) if emoji is not None else None
        except Exception:
            emoji = None
        try:
            next_hop = int(next_hop) if next_hop is not None else None
        except Exception:
            next_hop = None
        try:
            relay_node = int(relay_node) if relay_node is not None else None
        except Exception:
            relay_node = None
        try:
            hops_away_pkt = int(hops_away_pkt) if hops_away_pkt is not None else None
        except Exception:
            hops_away_pkt = None

        conn = _connect()
        try:
            conn.execute(_INSERT_PACKET_SQL, (
                ts,
                from_int,
                _node_int(data.get("to_node")),
                data.get("channel_idx"),
                # FASE 15: channel_hash 8-bit (range 0-255) per disambiguazione PSK condivise
                data.get("channel_hash"),
                data.get("channel_name"),
                data.get("psk_match"),
                network,
                data.get("portnum"),
                data.get("port_name"),
                payload_text,
                payload_len,
                data.get("rssi"),
                data.get("snr"),
                data.get("hop_start"),
                data.get("hop_limit"),
                data.get("packet_id"),
                is_encrypted,
                is_compressed,
                fw_type,
                fw_flags,
                data.get("source"),
                enc_hex_store,
                # H2 v2: 22 nuove colonne
                telemetry_json,
                position_quality_json,
                pos_lat, pos_lon, pos_alt, pos_sats, pos_pdop,
                decoded_meta_json,
                request_id, reply_id, emoji, want_response,
                radio_control_json,
                next_hop, relay_node, hops_away_pkt,
                via_mqtt if via_mqtt is not None else 0,
                want_ack if want_ack is not None else 0,
                priority_val,
                raw_protobuf_b64,
                public_key_hex,
                pki_encrypted if pki_encrypted is not None else 0,
            ))

            # H2 v2 — FTS5 insert incrementale (parallela a packets INSERT)
            if get_meta("fts5_available") == "1":
                try:
                    conn.execute(
                        "INSERT INTO packets_fts(rowid, payload_text, port_name, "
                        "channel_name, short_name, long_name, from_hex) "
                        "VALUES ((SELECT last_insert_rowid()), ?, ?, ?, ?, ?, ?)",
                        (
                            payload_text or "",
                            data.get("port_name") or "",
                            data.get("channel_name") or "",
                            data.get("short_name") or "",
                            data.get("long_name") or "",
                            _node_hex(from_int) or "",
                        ),
                    )
                except Exception:
                    pass

            rssi_val = data.get("rssi")
            snr_val = data.get("snr")
            rssi_sum = float(rssi_val) if isinstance(rssi_val, (int, float)) and rssi_val != 0 else 0.0
            rssi_n = 1 if rssi_sum else 0
            snr_sum = float(snr_val) if isinstance(snr_val, (int, float)) else 0.0
            snr_n = 1 if snr_val is not None else 0

            # H2 v2 — Nuovi campi nodes dal packet
            # macaddr, role, public_key_hex arrivano solo da NODEINFO_APP + MAP_REPORT_APP
            _node_macaddr = data.get("macaddr")
            _node_role = data.get("role")  # es. "CLIENT", "ROUTER" (stringa enum)
            _node_is_licensed = _bool_int(data.get("is_licensed")) or 0
            _node_is_stealth = _bool_int(data.get("is_stealth")) or 0
            _node_is_unmsg = _bool_int(data.get("is_unmessagable")) or 0
            _node_pkhex = data.get("public_key_hex")
            _node_fw_ver = data.get("firmware_version")
            _node_region = data.get("region")
            _node_preset = data.get("modem_preset")
            _node_hops = hops_away_pkt
            _node_via_mqtt = via_mqtt if via_mqtt is not None else 0
            # Telemetry snapshot
            tel = data.get("telemetry") if isinstance(data.get("telemetry"), dict) else {}
            dev_metrics = tel.get("device") if isinstance(tel.get("device"), dict) else {}
            _last_battery = dev_metrics.get("battery_level") or dev_metrics.get("batteryLevel")
            _last_voltage = dev_metrics.get("voltage")
            _last_ch_util = dev_metrics.get("channel_utilization") or dev_metrics.get("channelUtilization")
            _last_tx_util = dev_metrics.get("air_util_tx") or dev_metrics.get("airUtilTx")
            _last_uptime = dev_metrics.get("uptime_seconds") or dev_metrics.get("uptimeSeconds")
            # cast safe
            try:
                _last_battery = int(_last_battery) if _last_battery is not None else None
            except Exception:
                _last_battery = None
            try:
                _last_voltage = float(_last_voltage) if _last_voltage is not None else None
            except Exception:
                _last_voltage = None
            try:
                _last_ch_util = float(_last_ch_util) if _last_ch_util is not None else None
            except Exception:
                _last_ch_util = None
            try:
                _last_tx_util = float(_last_tx_util) if _last_tx_util is not None else None
            except Exception:
                _last_tx_util = None
            try:
                _last_uptime = int(_last_uptime) if _last_uptime is not None else None
            except Exception:
                _last_uptime = None

            conn.execute(_UPSERT_NODE_SQL, (
                from_int,
                _node_hex(from_int),
                data.get("short_name"),
                data.get("long_name"),
                data.get("hw_model"),
                ts,                       # first_seen iniziale
                ts,                       # last_seen
                network,
                fw_type,
                fw_flags,
                rssi_sum, rssi_n,
                snr_sum, snr_n,
                1 if data.get("stealth_suspect") else 0,
                is_compressed,
                # H2 v2: 16 nuove colonne
                _node_macaddr,
                _node_role,
                _node_is_licensed,
                _node_is_stealth,
                _node_is_unmsg,
                _node_pkhex,
                _node_fw_ver,
                _node_region,
                _node_preset,
                _node_hops,
                _node_via_mqtt,
                _last_battery,
                _last_voltage,
                _last_ch_util,
                _last_tx_util,
                _last_uptime,
            ))

            # STEP F4 — aggiorna posizione GPS del nodo se il pacchetto la include
            lat = data.get("latitude")
            lon = data.get("longitude")
            if lat is not None and lon is not None:
                try:
                    lat_f = float(lat)
                    lon_f = float(lon)
                    # sanity: scarta coordinate fuori range o zero/zero
                    if -90.0 <= lat_f <= 90.0 and -180.0 <= lon_f <= 180.0 \
                            and not (abs(lat_f) < 1e-6 and abs(lon_f) < 1e-6):
                        alt_raw = data.get("altitude")
                        try:
                            alt_i = int(alt_raw) if alt_raw is not None else None
                        except Exception:
                            alt_i = None
                        conn.execute(
                            "UPDATE nodes SET latitude=?, longitude=?, altitude=?, pos_ts=? "
                            "WHERE node_id=?",
                            (lat_f, lon_f, alt_i, ts, from_int),
                        )
                except Exception:
                    pass
        finally:
            conn.close()
        return True
    except Exception as e:
        # DB errors devono essere silenti: il monitor non deve morire per un DB down
        try:
            sys.stderr.write(f"[monitor_db] insert_packet error: {e}\n")
        except Exception:
            pass
        return None


# ═══════════════════════════════════════════════════════════
# CLEANUP / VACUUM
# ═══════════════════════════════════════════════════════════

def cleanup_old(retention_days=None):
    """Cancella pacchetti più vecchi di N giorni. Cancella anche nodi mai più
    visti per > 2×retention. Ritorna (deleted_packets, deleted_nodes)."""
    days = retention_days if retention_days is not None else get_retention_days()
    cutoff_pkt = _now_ms() - int(days) * 86400 * 1000
    cutoff_node = _now_ms() - int(days) * 2 * 86400 * 1000
    cutoff_daily = _now_ms() - STATS_DAILY_RETENTION_DAYS * 86400 * 1000
    cutoff_daily_date = datetime.datetime.utcfromtimestamp(cutoff_daily / 1000).strftime("%Y-%m-%d")
    conn = _connect()
    try:
        c1 = conn.execute("DELETE FROM packets WHERE ts < ?", (cutoff_pkt,)).rowcount
        c2 = conn.execute("DELETE FROM nodes WHERE last_seen < ?", (cutoff_node,)).rowcount
        conn.execute("DELETE FROM stats_daily WHERE date < ?", (cutoff_daily_date,))
        return int(c1 or 0), int(c2 or 0)
    finally:
        conn.close()


def vacuum():
    """VACUUM — compatta il DB. Costoso, eseguire al più settimanalmente."""
    conn = _connect()
    try:
        conn.execute("VACUUM")
    finally:
        conn.close()


def purge_all():
    """Cancella TUTTI i dati (reset totale). Mantiene schema e retention_days."""
    conn = _connect()
    try:
        conn.execute("DELETE FROM packets")
        conn.execute("DELETE FROM nodes")
        conn.execute("DELETE FROM stats_daily")
    finally:
        conn.close()
    vacuum()


def db_info():
    """Info sintetiche per UI: dimensione, count, oldest/newest ts."""
    path = get_db_path()
    try:
        size = os.path.getsize(path)
    except Exception:
        size = 0
    conn = _connect()
    try:
        total = conn.execute("SELECT COUNT(*) AS c FROM packets").fetchone()["c"]
        nodes = conn.execute("SELECT COUNT(*) AS c FROM nodes").fetchone()["c"]
        oldest = conn.execute("SELECT MIN(ts) AS t FROM packets").fetchone()["t"]
        newest = conn.execute("SELECT MAX(ts) AS t FROM packets").fetchone()["t"]
    finally:
        conn.close()
    return {
        "path": path,
        "size_bytes": int(size),
        "total_packets": int(total or 0),
        "total_nodes": int(nodes or 0),
        "oldest_ts": int(oldest) if oldest else None,
        "newest_ts": int(newest) if newest else None,
        "retention_days": get_retention_days(),
        "schema_version": SCHEMA_VERSION,
    }


# ═══════════════════════════════════════════════════════════
# FILTRI WHERE — costruzione sicura (whitelist-only)
# ═══════════════════════════════════════════════════════════

_ALLOWED_NETWORKS = {"min", "mesh_italia", "unknown"}
_ALLOWED_FW = {"stock", "fork_a", "fork_b", "stealth", "builder", "unknown"}


def _build_where(window, filters):
    """Costruisce (where_clause, params) — prepared statements, niente injection.
    filters: dict con chiavi whitelistate: network, fw_type, channel, portnum, node_id
    """
    parts = []
    params = []
    win_s = WINDOW_MAP.get(window, WINDOW_MAP["7d"])
    cutoff = _now_ms() - win_s * 1000
    parts.append("ts >= ?")
    params.append(cutoff)

    if filters:
        net = filters.get("network")
        if net in _ALLOWED_NETWORKS:
            parts.append("network = ?")
            params.append(net)
        fw = filters.get("fw_type")
        if fw in _ALLOWED_FW:
            parts.append("fw_type = ?")
            params.append(fw)
        ch = filters.get("channel")
        if ch and isinstance(ch, str) and len(ch) < 64:
            parts.append("channel_name = ?")
            params.append(ch)
        pn = filters.get("portnum")
        if isinstance(pn, int):
            parts.append("portnum = ?")
            params.append(pn)
        node = filters.get("node_id")
        node_int = _node_int(node) if node else None
        if node_int is not None:
            parts.append("from_node = ?")
            params.append(node_int)
    where = " WHERE " + " AND ".join(parts)
    return where, params


# ═══════════════════════════════════════════════════════════
# LEADERBOARD QUERIES
# ═══════════════════════════════════════════════════════════

def query_leaderboard(kind, window="7d", filters=None, limit=LEADERBOARD_DEFAULT_LIMIT):
    """Ritorna list[dict] per la classifica richiesta.
    kind: vedi LEADERBOARD_TYPES. window: 1h/6h/24h/3d/7d/30d."""
    if kind not in LEADERBOARD_TYPES:
        return []
    limit = max(1, min(int(limit), 100))
    where, params = _build_where(window, filters)

    if kind == "top_nodes":
        sql = (
            "SELECT p.from_node AS node_id, "
            "       COUNT(*) AS packets, "
            "       MAX(p.network) AS network, "
            "       MAX(p.fw_type) AS fw_type, "
            "       AVG(p.rssi) AS avg_rssi, "
            "       AVG(p.snr) AS avg_snr, "
            "       MAX(p.ts) AS last_seen, "
            "       (SELECT short_name FROM nodes WHERE node_id=p.from_node) AS short_name, "
            "       (SELECT long_name  FROM nodes WHERE node_id=p.from_node) AS long_name "
            "FROM packets p " + where +
            " GROUP BY p.from_node ORDER BY packets DESC LIMIT ?"
        )
        return _run_rows(sql, params + [limit])

    if kind == "top_channels":
        sql = (
            "SELECT channel_name AS channel, COUNT(*) AS packets, "
            "       MAX(network) AS network "
            "FROM packets " + where +
            " AND channel_name IS NOT NULL "
            "GROUP BY channel_name ORDER BY packets DESC LIMIT ?"
        )
        return _run_rows(sql, params + [limit])

    if kind == "top_portnums":
        sql = (
            "SELECT portnum, port_name, COUNT(*) AS packets "
            "FROM packets " + where +
            " GROUP BY portnum, port_name ORDER BY packets DESC LIMIT ?"
        )
        return _run_rows(sql, params + [limit])

    if kind == "by_network":
        sql = (
            "SELECT network, COUNT(*) AS packets "
            "FROM packets " + where +
            " GROUP BY network ORDER BY packets DESC"
        )
        return _run_rows(sql, params)

    if kind == "by_firmware":
        sql = (
            "SELECT fw_type, COUNT(*) AS packets "
            "FROM packets " + where +
            " GROUP BY fw_type ORDER BY packets DESC"
        )
        return _run_rows(sql, params)

    if kind == "best_signal":
        sql = (
            "SELECT p.from_node AS node_id, "
            "       AVG(p.rssi) AS avg_rssi, "
            "       AVG(p.snr) AS avg_snr, "
            "       COUNT(*) AS packets, "
            "       (SELECT short_name FROM nodes WHERE node_id=p.from_node) AS short_name "
            "FROM packets p " + where +
            " AND p.rssi != 0 "
            "GROUP BY p.from_node "
            "HAVING COUNT(*) >= 5 "
            "ORDER BY avg_rssi DESC LIMIT ?"
        )
        return _run_rows(sql, params + [limit])

    if kind == "new_nodes":
        # Nodi first_seen dentro la finestra
        win_s = WINDOW_MAP.get(window, WINDOW_MAP["7d"])
        cutoff = _now_ms() - win_s * 1000
        sql = (
            "SELECT node_id, node_hex, short_name, long_name, "
            "       first_seen, last_seen, network, fw_type, total_packets "
            "FROM nodes WHERE first_seen >= ? "
            "ORDER BY first_seen DESC LIMIT ?"
        )
        return _run_rows(sql, [cutoff, limit])

    if kind == "silent_nodes":
        # Nodi visti prima ma non negli ultimi 24h (silenziati)
        now = _now_ms()
        cutoff_silent = now - 24 * 3600 * 1000
        win_s = WINDOW_MAP.get(window, WINDOW_MAP["7d"])
        cutoff_window = now - win_s * 1000
        sql = (
            "SELECT node_id, node_hex, short_name, long_name, "
            "       last_seen, network, fw_type, total_packets "
            "FROM nodes WHERE last_seen BETWEEN ? AND ? "
            "ORDER BY last_seen DESC LIMIT ?"
        )
        return _run_rows(sql, [cutoff_window, cutoff_silent, limit])

    if kind == "compressed_nodes":
        sql = (
            "SELECT p.from_node AS node_id, "
            "       COUNT(*) AS compressed_packets, "
            "       MAX(p.ts) AS last_seen, "
            "       (SELECT short_name FROM nodes WHERE node_id=p.from_node) AS short_name, "
            "       (SELECT long_name  FROM nodes WHERE node_id=p.from_node) AS long_name "
            "FROM packets p " + where +
            " AND p.is_compressed = 1 "
            "GROUP BY p.from_node ORDER BY compressed_packets DESC LIMIT ?"
        )
        return _run_rows(sql, params + [limit])

    if kind == "hourly_heatmap":
        # Ritorna 7×24 (giorno della settimana × ora) conteggio
        sql = (
            "SELECT strftime('%w', datetime(ts/1000, 'unixepoch')) AS dow, "
            "       strftime('%H', datetime(ts/1000, 'unixepoch')) AS hour, "
            "       COUNT(*) AS packets "
            "FROM packets " + where +
            " GROUP BY dow, hour"
        )
        rows = _run_rows(sql, params)
        # Espandi in matrice 7×24
        matrix = [[0] * 24 for _ in range(7)]
        for r in rows:
            try:
                d = int(r["dow"])
                h = int(r["hour"])
                matrix[d][h] = int(r["packets"])
            except Exception:
                pass
        return {"matrix": matrix}

    return []


def _run_rows(sql, params):
    """Esegue query e ritorna list[dict]."""
    conn = _connect()
    try:
        cur = conn.execute(sql, params)
        return [dict(r) for r in cur.fetchall()]
    finally:
        conn.close()


# ═══════════════════════════════════════════════════════════
# TIMELINE
# ═══════════════════════════════════════════════════════════

def query_timeline(window="7d", bucket="1h", filters=None):
    """Ritorna serie temporale {bucket_ts: count} sulla finestra richiesta."""
    where, params = _build_where(window, filters)
    bucket_sec = {"5m": 300, "15m": 900, "1h": 3600, "6h": 21600, "1d": 86400}.get(bucket, 3600)
    sql = (
        f"SELECT (ts / {bucket_sec * 1000}) * {bucket_sec * 1000} AS bucket, "
        "       COUNT(*) AS packets, "
        "       SUM(is_encrypted) AS enc, "
        "       SUM(is_compressed) AS compr "
        "FROM packets " + where +
        " GROUP BY bucket ORDER BY bucket ASC"
    )
    return _run_rows(sql, params)


# ═══════════════════════════════════════════════════════════
# STATS DAILY (aggregato per retention estesa 30gg)
# ═══════════════════════════════════════════════════════════

def recompute_stats_daily(days=7):
    """Ricalcola stats_daily per gli ultimi N giorni. Idempotente (UPSERT)."""
    conn = _connect()
    try:
        for offset in range(days):
            day = (datetime.datetime.utcnow() - datetime.timedelta(days=offset)).strftime("%Y-%m-%d")
            start = int(datetime.datetime.strptime(day, "%Y-%m-%d").replace(tzinfo=datetime.timezone.utc).timestamp() * 1000)
            end = start + 86400 * 1000

            row = conn.execute(
                "SELECT COUNT(*) AS total, COUNT(DISTINCT from_node) AS uniq "
                "FROM packets WHERE ts >= ? AND ts < ?",
                (start, end),
            ).fetchone()
            total = int(row["total"] or 0)
            uniq = int(row["uniq"] or 0)

            def _group(col):
                rows = conn.execute(
                    f"SELECT {col} AS k, COUNT(*) AS c FROM packets "
                    "WHERE ts >= ? AND ts < ? GROUP BY k",
                    (start, end),
                ).fetchall()
                return {(r["k"] or "_"): int(r["c"]) for r in rows}

            by_network = _group("network")
            by_fw = _group("fw_type")
            by_pn = _group("port_name")
            by_ch = _group("channel_name")

            hours = [0] * 24
            for r in conn.execute(
                "SELECT strftime('%H', datetime(ts/1000, 'unixepoch')) AS h, COUNT(*) AS c "
                "FROM packets WHERE ts >= ? AND ts < ? GROUP BY h",
                (start, end),
            ).fetchall():
                try:
                    hours[int(r["h"])] = int(r["c"])
                except Exception:
                    pass

            conn.execute(
                "INSERT INTO stats_daily(date, total_packets, unique_nodes, "
                "  by_network, by_firmware, by_portnum, by_channel, by_hour, updated_ts) "
                "VALUES(?,?,?,?,?,?,?,?,?) "
                "ON CONFLICT(date) DO UPDATE SET "
                "  total_packets=excluded.total_packets, unique_nodes=excluded.unique_nodes, "
                "  by_network=excluded.by_network, by_firmware=excluded.by_firmware, "
                "  by_portnum=excluded.by_portnum, by_channel=excluded.by_channel, "
                "  by_hour=excluded.by_hour, updated_ts=excluded.updated_ts",
                (
                    day, total, uniq,
                    json.dumps(by_network, ensure_ascii=False),
                    json.dumps(by_fw, ensure_ascii=False),
                    json.dumps(by_pn, ensure_ascii=False),
                    json.dumps(by_ch, ensure_ascii=False),
                    json.dumps(hours),
                    _now_ms(),
                ),
            )
    finally:
        conn.close()


# ═══════════════════════════════════════════════════════════
# EXPORT: CSV / JSON / MARKDOWN
# ═══════════════════════════════════════════════════════════

def export_leaderboard(kind, fmt="csv", window="7d", filters=None, limit=LEADERBOARD_DEFAULT_LIMIT):
    """Export classifica in formato richiesto. Ritorna (bytes, mime, filename)."""
    if fmt not in EXPORT_FORMATS:
        raise ValueError("bad_format")
    rows = query_leaderboard(kind, window=window, filters=filters, limit=limit)
    ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    base = f"monitor_{kind}_{window}_{ts}"

    if fmt == "json":
        data = json.dumps({
            "kind": kind, "window": window, "filters": filters or {}, "rows": rows
        }, ensure_ascii=False, indent=2)
        return data.encode("utf-8"), "application/json", base + ".json"

    if fmt == "csv":
        buf = io.StringIO()
        if isinstance(rows, list) and rows and isinstance(rows[0], dict):
            writer = csv.DictWriter(buf, fieldnames=list(rows[0].keys()), extrasaction="ignore")
            writer.writeheader()
            for r in rows:
                writer.writerow(r)
        elif isinstance(rows, dict) and "matrix" in rows:
            buf.write("dow,hour,packets\n")
            for d, row in enumerate(rows["matrix"]):
                for h, c in enumerate(row):
                    buf.write(f"{d},{h},{c}\n")
        return buf.getvalue().encode("utf-8"), "text/csv", base + ".csv"

    if fmt == "md":
        lines = [f"# Monitor — {kind} ({window})", ""]
        if filters:
            lines.append("**Filtri:** " + ", ".join(f"{k}={v}" for k, v in filters.items() if v))
            lines.append("")
        if isinstance(rows, list) and rows and isinstance(rows[0], dict):
            headers = list(rows[0].keys())
            lines.append("| " + " | ".join(headers) + " |")
            lines.append("|" + "|".join(["---"] * len(headers)) + "|")
            for r in rows:
                lines.append("| " + " | ".join(str(r.get(h, "")) for h in headers) + " |")
        elif isinstance(rows, dict) and "matrix" in rows:
            lines.append("| Day | " + " | ".join(str(h) for h in range(24)) + " |")
            lines.append("|---|" + "|".join(["---"] * 24) + "|")
            day_names = ["Dom", "Lun", "Mar", "Mer", "Gio", "Ven", "Sab"]
            for d, row in enumerate(rows["matrix"]):
                lines.append(f"| {day_names[d]} | " + " | ".join(str(c) for c in row) + " |")
        return ("\n".join(lines) + "\n").encode("utf-8"), "text/markdown", base + ".md"

    return b"", "text/plain", base + ".txt"


# ═══════════════════════════════════════════════════════════
# PSK MANAGER — chiavi pubbliche/private per decrittazione
# Le PSK sono salvate in chiaro in SQLite locale. Il DB vive in una
# cartella utente (AppData / Library / .config) non in cloud.
# ═══════════════════════════════════════════════════════════

_PSK_KINDS = {"public", "private"}


def psk_list(enabled_only=False, with_pkt_count=False, window_days=7):
    """Ritorna tutte le PSK salvate (opzionalmente solo enabled).

    FASE 16c (2026-05-05): se with_pkt_count=True, arricchisce con:
      - pkt_count: COUNT(*) FROM packets WHERE channel_name = psk.channel_name
      - pkt_count_window: idem ma negli ultimi `window_days` giorni
    Calcolato via subquery (lento per cataloghi grandi, idempotente).
    """
    try:
        conn = _connect()
        try:
            if enabled_only:
                rows = conn.execute(
                    "SELECT id,label,channel_name,psk_b64,kind,enabled,match_count,last_match_ts,created_ts,notes "
                    "FROM psk_keys WHERE enabled=1 ORDER BY id ASC"
                ).fetchall()
            else:
                rows = conn.execute(
                    "SELECT id,label,channel_name,psk_b64,kind,enabled,match_count,last_match_ts,created_ts,notes "
                    "FROM psk_keys ORDER BY id ASC"
                ).fetchall()
            keys = [
                "id", "label", "channel_name", "psk_b64", "kind",
                "enabled", "match_count", "last_match_ts", "created_ts", "notes",
            ]
            out = [dict(zip(keys, r)) for r in rows]

            if with_pkt_count and out:
                # FASE 16c: arricchimento pkt_count per channel_name
                cutoff_ms = _now_ms() - int(window_days) * 86400 * 1000
                # Raggruppo channel_name distinct
                channels = sorted(set(p["channel_name"] for p in out if p.get("channel_name")))
                # Una sola query batch via IN (...)
                if channels:
                    placeholders = ",".join("?" * len(channels))
                    # Total
                    tot_q = conn.execute(
                        f"SELECT channel_name, COUNT(*) AS c FROM packets "
                        f"WHERE channel_name IN ({placeholders}) GROUP BY channel_name",
                        tuple(channels)
                    ).fetchall()
                    tot_map = {r["channel_name"]: int(r["c"]) for r in tot_q}
                    # Window
                    win_q = conn.execute(
                        f"SELECT channel_name, COUNT(*) AS c FROM packets "
                        f"WHERE ts >= ? AND channel_name IN ({placeholders}) GROUP BY channel_name",
                        (cutoff_ms,) + tuple(channels)
                    ).fetchall()
                    win_map = {r["channel_name"]: int(r["c"]) for r in win_q}
                    for p in out:
                        cn = p.get("channel_name")
                        p["pkt_count"] = tot_map.get(cn, 0)
                        p["pkt_count_window"] = win_map.get(cn, 0)
                else:
                    for p in out:
                        p["pkt_count"] = 0
                        p["pkt_count_window"] = 0
            return out
        finally:
            conn.close()
    except Exception:
        return []


def psk_add(label, psk_b64, kind="public", channel_name=None, notes=None):
    """Inserisce una PSK. Ritorna dict con id o error."""
    if not label or not psk_b64:
        return {"error": "missing_fields"}
    kind = (kind or "public").lower()
    if kind not in _PSK_KINDS:
        return {"error": "bad_kind"}
    try:
        conn = _connect()
        try:
            cur = conn.execute(
                "INSERT INTO psk_keys(label,channel_name,psk_b64,kind,enabled,match_count,created_ts,notes) "
                "VALUES (?,?,?,?,1,0,?,?)",
                (label[:80], channel_name[:60] if channel_name else None,
                 psk_b64.strip()[:200], kind, _now_ms(), (notes or "")[:200]),
            )
            return {"id": cur.lastrowid}
        finally:
            conn.close()
    except Exception as e:
        return {"error": "db", "message": str(e)}


def psk_update(psk_id, **fields):
    """Aggiorna campi PSK (label, psk_b64, channel_name, kind, enabled, notes)."""
    allowed = {"label", "psk_b64", "channel_name", "kind", "enabled", "notes"}
    sets = []
    vals = []
    for k, v in fields.items():
        if k not in allowed:
            continue
        if k == "enabled":
            v = 1 if v else 0
        elif k == "kind" and (v or "") not in _PSK_KINDS:
            continue
        sets.append(f"{k}=?")
        vals.append(v)
    if not sets:
        return {"error": "no_fields"}
    vals.append(int(psk_id))
    try:
        conn = _connect()
        try:
            conn.execute(f"UPDATE psk_keys SET {','.join(sets)} WHERE id=?", vals)
            return {"ok": True}
        finally:
            conn.close()
    except Exception as e:
        return {"error": "db", "message": str(e)}


def psk_delete(psk_id):
    try:
        conn = _connect()
        try:
            conn.execute("DELETE FROM psk_keys WHERE id=?", (int(psk_id),))
            return {"ok": True}
        finally:
            conn.close()
    except Exception as e:
        return {"error": "db", "message": str(e)}


def psk_bump_match(psk_id):
    """Incrementa il contatore match + aggiorna timestamp (chiamato dopo decrypt OK)."""
    try:
        conn = _connect()
        try:
            conn.execute(
                "UPDATE psk_keys SET match_count=match_count+1, last_match_ts=? WHERE id=?",
                (_now_ms(), int(psk_id)),
            )
        finally:
            conn.close()
    except Exception:
        pass


# ═══════════════════════════════════════════════════════════
# H4.3-T1 — CRUD per pki_keys (X25519 DM decrypt)
# ═══════════════════════════════════════════════════════════

_PKI_SOURCES = {"manual", "node_usb", "imported_file", "discovered"}


def _hex_normalize(s):
    """Normalizza una hex string: strip, lower, no 0x, solo [0-9a-f], validate."""
    if not s:
        return None
    v = str(s).strip().lower()
    if v.startswith("0x"):
        v = v[2:]
    # Solo chars hex validi
    import re as _re
    if not _re.fullmatch(r"[0-9a-f]+", v):
        return None
    # Deve essere pari
    if len(v) % 2 != 0:
        return None
    return v


def _derive_pub_from_priv_hex(priv_hex):
    """Deriva public key X25519 (32B hex) da private key X25519 (32B hex).
    Ritorna hex lowercase o None se errore."""
    try:
        if not priv_hex or len(priv_hex) != 64:
            return None
        from cryptography.hazmat.primitives.asymmetric.x25519 import X25519PrivateKey
        from cryptography.hazmat.primitives import serialization as _ser
        priv_bytes = bytes.fromhex(priv_hex)
        k = X25519PrivateKey.from_private_bytes(priv_bytes)
        pub_bytes = k.public_key().public_bytes(
            encoding=_ser.Encoding.Raw,
            format=_ser.PublicFormat.Raw,
        )
        return pub_bytes.hex()
    except Exception:
        return None


def pki_list(enabled_only=False, device_own_only=False):
    """Ritorna tutte le PKI salvate (filtri opzionali: enabled / device_own)."""
    try:
        conn = _connect()
        try:
            where = []
            if enabled_only:
                where.append("enabled=1")
            if device_own_only:
                where.append("is_device_own=1")
            sql = (
                "SELECT id,label,my_priv_hex,my_pub_hex,their_pub_hex,source,"
                "is_device_own,enabled,match_count,last_match_ts,created_ts,notes "
                "FROM pki_keys"
            )
            if where:
                sql += " WHERE " + " AND ".join(where)
            sql += " ORDER BY id ASC"
            rows = conn.execute(sql).fetchall()
            keys = [
                "id", "label", "my_priv_hex", "my_pub_hex", "their_pub_hex",
                "source", "is_device_own", "enabled", "match_count",
                "last_match_ts", "created_ts", "notes",
            ]
            return [dict(zip(keys, r)) for r in rows]
        finally:
            conn.close()
    except Exception:
        return []


def pki_get(pki_id):
    """Ritorna singola entry PKI o None."""
    try:
        conn = _connect()
        try:
            r = conn.execute(
                "SELECT id,label,my_priv_hex,my_pub_hex,their_pub_hex,source,"
                "is_device_own,enabled,match_count,last_match_ts,created_ts,notes "
                "FROM pki_keys WHERE id=?", (int(pki_id),)
            ).fetchone()
            if not r:
                return None
            keys = [
                "id", "label", "my_priv_hex", "my_pub_hex", "their_pub_hex",
                "source", "is_device_own", "enabled", "match_count",
                "last_match_ts", "created_ts", "notes",
            ]
            return dict(zip(keys, r))
        finally:
            conn.close()
    except Exception:
        return None


def pki_add(label, my_priv_hex, their_pub_hex=None, my_pub_hex=None,
            source="manual", is_device_own=0, notes=None):
    """Inserisce una chiave PKI. Deriva auto my_pub_hex se mancante.
    Ritorna dict con id o error.
    Validation:
      - label non vuoto
      - my_priv_hex esattamente 64 hex chars (32 bytes X25519)
      - their_pub_hex opzionale: se presente deve essere 64 hex chars
      - source ∈ {manual, node_usb, imported_file, discovered}
      - UNIQUE (my_priv_hex, their_pub_hex)
    """
    if not label or not my_priv_hex:
        return {"error": "missing_fields"}
    priv_hex = _hex_normalize(my_priv_hex)
    if not priv_hex or len(priv_hex) != 64:
        return {"error": "bad_priv_hex", "detail": "must be 64 hex chars (32 bytes)"}
    peer_hex = None
    if their_pub_hex:
        peer_hex = _hex_normalize(their_pub_hex)
        if not peer_hex or len(peer_hex) != 64:
            return {"error": "bad_their_pub_hex"}
    pub_hex = _hex_normalize(my_pub_hex) if my_pub_hex else None
    if not pub_hex:
        pub_hex = _derive_pub_from_priv_hex(priv_hex)
    if source not in _PKI_SOURCES:
        return {"error": "bad_source", "allowed": sorted(_PKI_SOURCES)}
    try:
        conn = _connect()
        try:
            cur = conn.execute(
                "INSERT INTO pki_keys(label,my_priv_hex,my_pub_hex,their_pub_hex,"
                "source,is_device_own,enabled,match_count,created_ts,notes) "
                "VALUES (?,?,?,?,?,?,1,0,?,?)",
                (label[:80], priv_hex, pub_hex, peer_hex, source,
                 1 if is_device_own else 0, _now_ms(), (notes or "")[:200]),
            )
            return {"id": cur.lastrowid, "my_pub_hex": pub_hex}
        finally:
            conn.close()
    except sqlite3.IntegrityError as e:
        return {"error": "duplicate", "message": str(e)}
    except Exception as e:
        return {"error": "db", "message": str(e)}


def pki_update(pki_id, **fields):
    """Aggiorna campi PKI consentiti."""
    allowed = {"label", "their_pub_hex", "enabled", "notes", "is_device_own"}
    sets = []
    vals = []
    for k, v in fields.items():
        if k not in allowed:
            continue
        if k in ("enabled", "is_device_own"):
            v = 1 if v else 0
        elif k == "their_pub_hex" and v:
            v = _hex_normalize(v)
            if not v or len(v) != 64:
                continue
        sets.append(f"{k}=?")
        vals.append(v)
    if not sets:
        return {"error": "no_fields"}
    vals.append(int(pki_id))
    try:
        conn = _connect()
        try:
            conn.execute(f"UPDATE pki_keys SET {','.join(sets)} WHERE id=?", vals)
            return {"ok": True}
        finally:
            conn.close()
    except Exception as e:
        return {"error": "db", "message": str(e)}


def pki_delete(pki_id):
    try:
        conn = _connect()
        try:
            conn.execute("DELETE FROM pki_keys WHERE id=?", (int(pki_id),))
            return {"ok": True}
        finally:
            conn.close()
    except Exception as e:
        return {"error": "db", "message": str(e)}


def pki_bump_match(pki_id):
    """Incrementa contatore match + aggiorna timestamp (post decrypt PKI OK)."""
    try:
        conn = _connect()
        try:
            conn.execute(
                "UPDATE pki_keys SET match_count=match_count+1, last_match_ts=? WHERE id=?",
                (_now_ms(), int(pki_id)),
            )
        finally:
            conn.close()
    except Exception:
        pass


def pki_find_by_priv(my_priv_hex, their_pub_hex=None):
    """Cerca entry con stessa (my_priv_hex, their_pub_hex). Ritorna id o None."""
    priv_hex = _hex_normalize(my_priv_hex)
    if not priv_hex:
        return None
    peer_hex = _hex_normalize(their_pub_hex) if their_pub_hex else None
    try:
        conn = _connect()
        try:
            if peer_hex is None:
                r = conn.execute(
                    "SELECT id FROM pki_keys WHERE my_priv_hex=? AND their_pub_hex IS NULL",
                    (priv_hex,)
                ).fetchone()
            else:
                r = conn.execute(
                    "SELECT id FROM pki_keys WHERE my_priv_hex=? AND their_pub_hex=?",
                    (priv_hex, peer_hex)
                ).fetchone()
            return r[0] if r else None
        finally:
            conn.close()
    except Exception:
        return None


def rematch_update_packet(packet_id=None, from_int=None, port_name=None,
                          portnum=None, payload_text=None, psk_label=None,
                          channel_name=None):
    """STEP B — Aggiorna una row 'packets' dopo una decifratura riuscita.

    Cerca per (packet_id, from_node) e imposta is_encrypted=0, port_name, portnum,
    payload_text, psk_match, channel_name. Se non trova, no-op.

    FASE 1 fix (2026-05-05): aggiunto parametro channel_name. Quando una PSK
    decifra il pacchetto, scrivi anche il channel_name della PSK matchata, cosi'
    l'Analyst non lo classifica piu' come canale "silente".
    Ritorna {"updated": N}.
    """
    if packet_id is None or from_int is None:
        return {"updated": 0}
    try:
        conn = _connect()
        try:
            # Se channel_name fornito, lo includiamo nell'UPDATE; altrimenti
            # manteniamo il valore esistente con COALESCE.
            cur = conn.execute(
                "UPDATE packets SET is_encrypted=0, port_name=?, portnum=?, "
                "payload_text=?, psk_match=?, "
                "channel_name=COALESCE(?, channel_name) "
                "WHERE packet_id=? AND from_node=? AND is_encrypted=1",
                (port_name, portnum, payload_text, psk_label,
                 channel_name,
                 int(packet_id), int(from_int)),
            )
            return {"updated": cur.rowcount}
        finally:
            conn.close()
    except Exception:
        return {"updated": 0, "error": "db"}


def rematch_db_packets(psks=None, window_days=30, crypto_mod=None, limit=10000):
    """STEP B — Scansiona la tabella 'packets' negli ultimi N giorni e ritenta
    decifratura con le PSK fornite. Aggiorna le row matchate (is_encrypted=0 + metadata).

    Ritorna {"tried": N, "matched": N}.
    """
    if not psks or not crypto_mod:
        return {"tried": 0, "matched": 0}
    try:
        cutoff = _now_ms() - int(window_days) * 86400 * 1000
        conn = _connect()
        try:
            rows = conn.execute(
                "SELECT id, packet_id, from_node, encrypted_hex, "
                "  COALESCE(channel_hash, channel_idx) AS channel_hash "
                "FROM packets WHERE is_encrypted=1 AND encrypted_hex IS NOT NULL "
                "AND encrypted_hex!='' AND ts >= ? "
                "ORDER BY ts DESC LIMIT ?",
                (cutoff, int(limit)),
            ).fetchall()
            tried = 0
            matched = 0
            for r in rows:
                tried += 1
                try:
                    # FASE 14: disambiguazione PSK condivise via packet_channel_hash
                    _ph = None
                    try:
                        _ph = int(r["channel_hash"]) if r["channel_hash"] is not None else None
                    except Exception:
                        _ph = None
                    m = crypto_mod.try_all_psk(
                        r["encrypted_hex"] or "",
                        int(r["packet_id"] or 0),
                        int(r["from_node"] or 0),
                        psks,
                        packet_channel_hash=_ph,
                    )
                except Exception:
                    m = None
                if not m:
                    continue
                matched += 1
                pn = m.get("portnum")
                port_name = None
                try:
                    # import lazy PORTNUM_MAP via monitor
                    import monitor as _mon
                    port_name = _mon.PORTNUM_MAP.get(int(pn), f"PORT_{pn}") if pn is not None else None
                except Exception:
                    pass
                pb = m.get("payload_bytes") or b""
                payload_text = None
                try:
                    if pn is not None and int(pn) == 1 and pb:
                        payload_text = pb.decode("utf-8", errors="replace")
                except Exception:
                    pass
                try:
                    # FASE 1: aggiunto channel_name per backfill da PSK matchata
                    conn.execute(
                        "UPDATE packets SET is_encrypted=0, port_name=?, portnum=?, "
                        "payload_text=?, psk_match=?, "
                        "channel_name=COALESCE(?, channel_name) WHERE id=?",
                        (port_name,
                         int(pn) if pn is not None else None,
                         payload_text,
                         m.get("label"),
                         m.get("channel_name"),
                         int(r["id"])),
                    )
                    try:
                        conn.execute(
                            "UPDATE psk_keys SET match_count=match_count+1, last_match_ts=? WHERE id=?",
                            (_now_ms(), int(m.get("psk_id") or 0)),
                        )
                    except Exception:
                        pass
                except Exception:
                    pass
            return {"tried": tried, "matched": matched}
        finally:
            conn.close()
    except Exception as e:
        return {"tried": 0, "matched": 0, "error": str(e)}


def hunter_scan_db(psks=None, window_days=30, crypto_mod=None, limit=2000,
                   include_decrypted=False):
    """Crypto Hunter — brute-force decrypt sul buffer DB con breakdown per-PSK.

    A differenza di rematch_db_packets, questa funzione:
      - Ritorna statistiche per-PSK (quante chiavi hanno match quanti pacchetti)
      - Ritorna una lista di risultati dettagliati (packet_id, PSK usata, portnum, snippet payload)
      - Aggiorna le row matchate nel DB (come rematch_db_packets)
      - Se include_decrypted=True include anche i pacchetti già decrittati (per preview)

    Args:
      psks: lista dict [{'id','label','psk_b64','kind','enabled'}, ...]
      window_days: finestra temporale (giorni)
      crypto_mod: modulo meshtastic_crypto
      limit: massimo pacchetti da esaminare
      include_decrypted: se True include anche is_encrypted=0 (no-op, preview)

    Ritorna:
      {
        "scanned": N,           # pacchetti esaminati
        "decrypted": N,         # pacchetti decifrati in questo run
        "already_clear": N,     # pacchetti già in chiaro nel DB
        "per_psk": [            # breakdown per chiave usata
          {"psk_id":..., "label":..., "matches":...},
          ...
        ],
        "results": [            # sample dei match (max 50)
          {"packet_id":..., "from_node":..., "psk_id":..., "psk_label":...,
           "portnum":..., "port_name":..., "snippet":...},
          ...
        ],
        "reasons": {            # breakdown motivi di fallimento (Task #66)
          "pki_encrypted": N,        # DB flag pki_encrypted=1 (PKI DM, PSK non serve)
          "zero_packetid": N,        # packet_id=0 (MQTT relay strippa nonce)
          "zero_from": N,            # from_node=0 (nonce incompleto)
          "decrypt_fail_all_psk": N, # nessuna PSK testata ha matchato
        },
        "errors": 0,
      }
    """
    out = {
        "scanned": 0, "decrypted": 0, "already_clear": 0,
        "per_psk": [], "results": [], "errors": 0,
        "reasons": {
            "pki_encrypted": 0,
            "zero_packetid": 0,
            "zero_from": 0,
            "decrypt_fail_all_psk": 0,
        },
    }
    if not psks or not crypto_mod:
        return out
    try:
        cutoff = _now_ms() - int(window_days) * 86400 * 1000
        per_psk_count = {}  # {psk_id: matches}
        results_sample = []  # max 50

        conn = _connect()
        try:
            where_enc = "is_encrypted=1" if not include_decrypted else "1=1"
            rows = conn.execute(
                f"SELECT id, packet_id, from_node, encrypted_hex, is_encrypted, "
                f"payload_text, port_name, portnum, psk_match, pki_encrypted "
                f"FROM packets WHERE {where_enc} AND encrypted_hex IS NOT NULL "
                f"AND encrypted_hex!='' AND ts >= ? "
                f"ORDER BY ts DESC LIMIT ?",
                (cutoff, int(limit)),
            ).fetchall()

            for r in rows:
                out["scanned"] += 1
                if not r["is_encrypted"]:
                    out["already_clear"] += 1
                    continue
                # Task #66 — breakdown motivi di fallimento
                # Check pki_encrypted flag PRIMA del tentativo (PSK non serve su PKI DM)
                try:
                    _pki_flag = int(r["pki_encrypted"] or 0)
                except Exception:
                    _pki_flag = 0
                if _pki_flag:
                    out["reasons"]["pki_encrypted"] += 1
                    continue
                # Controlli nonce: packet_id=0 o from_node=0 → nonce incompleto
                _pid_raw = int(r["packet_id"] or 0)
                _from_raw = int(r["from_node"] or 0)
                if _pid_raw == 0:
                    out["reasons"]["zero_packetid"] += 1
                    continue
                if _from_raw == 0:
                    out["reasons"]["zero_from"] += 1
                    continue
                try:
                    # FASE 14: channel_hash per disambiguazione PSK condivise
                    _ph_db = None
                    try:
                        _ph_db = int(r["channel_hash"]) if r["channel_hash"] is not None else None
                    except Exception:
                        _ph_db = None
                    m = crypto_mod.try_all_psk(
                        r["encrypted_hex"] or "",
                        _pid_raw,
                        _from_raw,
                        psks,
                        packet_channel_hash=_ph_db,
                    )
                except Exception:
                    out["errors"] += 1
                    continue
                if not m:
                    out["reasons"]["decrypt_fail_all_psk"] += 1
                    continue

                # Decrypted!
                out["decrypted"] += 1
                pid_psk = int(m.get("psk_id") or 0)
                per_psk_count[pid_psk] = per_psk_count.get(pid_psk, 0) + 1

                pn = m.get("portnum")
                port_name = None
                try:
                    import monitor as _mon
                    port_name = (_mon.PORTNUM_MAP.get(int(pn), f"PORT_{pn}")
                                 if pn is not None else None)
                except Exception:
                    pass

                pb = m.get("payload_bytes") or b""
                payload_text = None
                try:
                    if pn is not None and int(pn) == 1 and pb:
                        payload_text = pb.decode("utf-8", errors="replace")
                except Exception:
                    pass

                # Sample risultato (max 50)
                if len(results_sample) < 50:
                    snippet = ""
                    try:
                        if payload_text:
                            snippet = payload_text[:80]
                        elif pb:
                            snippet = pb.hex()[:80]
                    except Exception:
                        pass
                    results_sample.append({
                        "packet_id": int(r["packet_id"] or 0),
                        "from_node": int(r["from_node"] or 0),
                        "psk_id": pid_psk,
                        "psk_label": m.get("label"),
                        "portnum": int(pn) if pn is not None else None,
                        "port_name": port_name,
                        "snippet": snippet,
                    })

                # Update DB row come in rematch
                try:
                    # FASE 1: aggiunto channel_name per backfill da PSK matchata
                    conn.execute(
                        "UPDATE packets SET is_encrypted=0, port_name=?, portnum=?, "
                        "payload_text=?, psk_match=?, "
                        "channel_name=COALESCE(?, channel_name) WHERE id=?",
                        (port_name,
                         int(pn) if pn is not None else None,
                         payload_text,
                         m.get("label"),
                         m.get("channel_name"),
                         int(r["id"])),
                    )
                    conn.execute(
                        "UPDATE psk_keys SET match_count=match_count+1, last_match_ts=? WHERE id=?",
                        (_now_ms(), pid_psk),
                    )
                except Exception:
                    pass

            # Build per_psk breakdown con label
            psk_map = {int(p.get("id") or 0): p.get("label") for p in psks}
            out["per_psk"] = [
                {"psk_id": pid, "label": psk_map.get(pid, f"PSK#{pid}"),
                 "matches": cnt}
                for pid, cnt in sorted(per_psk_count.items(),
                                       key=lambda kv: kv[1], reverse=True)
            ]
            out["results"] = results_sample
        finally:
            conn.close()
    except Exception as e:
        out["errors"] += 1
        out["error"] = str(e)
    return out


def psk_add_or_update(label, psk_b64, kind="private", channel_name=None, notes=None):
    """Upsert PSK per label.

    - Se label esiste: aggiorna psk_b64/kind/channel_name/notes, abilita.
      Ritorna {"updated": id} se cambia, {"unchanged": id} se già uguale.
    - Se label non esiste: inserisce e ritorna {"added": id}.
    - In caso di errore: {"error": "..."}.
    """
    if not label or not psk_b64:
        return {"error": "missing_fields"}
    kind = (kind or "private").lower()
    if kind not in _PSK_KINDS:
        return {"error": "bad_kind"}
    label = str(label)[:80]
    psk_b64 = str(psk_b64).strip()[:200]
    channel_name = channel_name[:60] if channel_name else None
    notes = (notes or "")[:200]
    try:
        conn = _connect()
        try:
            row = conn.execute(
                "SELECT id,psk_b64,kind,channel_name,notes,enabled FROM psk_keys WHERE label=? LIMIT 1",
                (label,),
            ).fetchone()
            if row:
                psk_id = int(row["id"])
                changed = (
                    (row["psk_b64"] or "") != psk_b64
                    or (row["kind"] or "") != kind
                    or (row["channel_name"] or "") != (channel_name or "")
                    or (row["notes"] or "") != notes
                    or int(row["enabled"] or 0) != 1
                )
                if changed:
                    conn.execute(
                        "UPDATE psk_keys SET psk_b64=?, kind=?, channel_name=?, notes=?, enabled=1 WHERE id=?",
                        (psk_b64, kind, channel_name, notes, psk_id),
                    )
                    return {"updated": psk_id}
                return {"unchanged": psk_id}
            cur = conn.execute(
                "INSERT INTO psk_keys(label,channel_name,psk_b64,kind,enabled,match_count,created_ts,notes) "
                "VALUES (?,?,?,?,1,0,?,?)",
                (label, channel_name, psk_b64, kind, _now_ms(), notes),
            )
            return {"added": cur.lastrowid}
        finally:
            conn.close()
    except Exception as e:
        return {"error": "db", "message": str(e)}


# ═══════════════════════════════════════════════════════════
# STEP 2 Hunter — channel_map helpers (hash8 → canale)
# ═══════════════════════════════════════════════════════════

def channel_map_upsert(slots):
    """Upsert atomico della tabella channel_map dagli 8 slot del nodo.

    - slots: lista di dict {hash8, idx, name, short_name, role, psk_b64, default_psk}
    Ritorna {"ok": True, "written": N} o {"ok": False, "error": "..."}.
    Upsert puro per hash8: sovrascrive i campi se già presente, altrimenti inserisce.
    """
    if not isinstance(slots, (list, tuple)):
        return {"ok": False, "error": "bad_slots"}
    if len(slots) == 0:
        return {"ok": True, "written": 0}
    now = _now_ms()
    written = 0
    try:
        conn = _connect()
        try:
            for _s in slots:
                if not isinstance(_s, dict):
                    continue
                try:
                    _h = int(_s.get("hash8", 0) or 0) & 0xFF
                except Exception:
                    continue
                _idx = _s.get("idx", -1)
                try:
                    _idx = int(_idx)
                except Exception:
                    _idx = -1
                _nm = (_s.get("name") or "")[:60]
                _sn = (_s.get("short_name") or "")[:8]
                _rl = (_s.get("role") or "UNKNOWN")[:16]
                _pb = (_s.get("psk_b64") or "")[:200]
                _dp = 1 if _s.get("default_psk") else 0
                conn.execute(
                    "INSERT INTO channel_map(hash8, idx, name, short_name, role, psk_b64, default_psk, updated_ts) "
                    "VALUES (?,?,?,?,?,?,?,?) "
                    "ON CONFLICT(hash8) DO UPDATE SET "
                    "idx=excluded.idx, name=excluded.name, short_name=excluded.short_name, "
                    "role=excluded.role, psk_b64=excluded.psk_b64, default_psk=excluded.default_psk, "
                    "updated_ts=excluded.updated_ts",
                    (_h, _idx, _nm, _sn, _rl, _pb, _dp, now),
                )
                written += 1
            return {"ok": True, "written": written}
        finally:
            conn.close()
    except Exception as e:
        return {"ok": False, "error": str(e)}


def channel_map_all():
    """Ritorna tutte le entry di channel_map come lista di dict, ordinate per idx.

    Output: [{hash8, idx, name, short_name, role, psk_b64, default_psk, updated_ts}, ...]
    """
    try:
        conn = _connect()
        try:
            rows = conn.execute(
                "SELECT hash8, idx, name, short_name, role, psk_b64, default_psk, updated_ts "
                "FROM channel_map ORDER BY CASE WHEN idx < 0 THEN 99 ELSE idx END ASC, hash8 ASC"
            ).fetchall()
            return [dict(r) for r in rows]
        finally:
            conn.close()
    except Exception:
        return []


def channel_map_get(hash8):
    """Lookup singolo per hash8 → dict o None."""
    try:
        _h = int(hash8) & 0xFF
    except Exception:
        return None
    try:
        conn = _connect()
        try:
            row = conn.execute(
                "SELECT hash8, idx, name, short_name, role, psk_b64, default_psk, updated_ts "
                "FROM channel_map WHERE hash8=? LIMIT 1",
                (_h,),
            ).fetchone()
            return dict(row) if row else None
        finally:
            conn.close()
    except Exception:
        return None


def channel_map_harvest(hash8, name, short_name=None):
    """STEP 4 — Harvest MQTT: popola channel_map da sorgenti non-USB.

    Strategia sicura (non sovrascrive mai dati USB autoritativi):
      - Se hash8 non è presente → INSERT minimale (idx=-1, psk vuoto, role='MQTT')
      - Se hash8 presente E name attuale è vuoto → UPDATE solo il name
      - Altrimenti → NO-OP (preserva il lavoro di sync_psks_from_node)

    Ritorna dict {action: 'inserted'|'updated_name'|'noop', hash8, name}.
    """
    try:
        _h = int(hash8) & 0xFF
    except Exception:
        return {"action": "noop", "hash8": None, "reason": "bad_hash8"}
    _nm = (str(name) if name else "").strip()[:60]
    if not _nm:
        return {"action": "noop", "hash8": _h, "reason": "empty_name"}
    _sn = (str(short_name) if short_name else "").strip()[:8]
    now = _now_ms()
    try:
        conn = _connect()
        try:
            existing = conn.execute(
                "SELECT hash8, name FROM channel_map WHERE hash8=? LIMIT 1",
                (_h,),
            ).fetchone()
            if existing is None:
                conn.execute(
                    "INSERT INTO channel_map(hash8, idx, name, short_name, role, "
                    "psk_b64, default_psk, updated_ts) VALUES (?,?,?,?,?,?,?,?)",
                    (_h, -1, _nm, _sn, "MQTT", "", 0, now),
                )
                return {"action": "inserted", "hash8": _h, "name": _nm}
            _cur_name = (existing["name"] or "").strip()
            if not _cur_name:
                conn.execute(
                    "UPDATE channel_map SET name=?, short_name=?, updated_ts=? "
                    "WHERE hash8=?",
                    (_nm, _sn or (existing["short_name"] or ""), now, _h),
                )
                return {"action": "updated_name", "hash8": _h, "name": _nm}
            return {"action": "noop", "hash8": _h, "reason": "name_present"}
        finally:
            conn.close()
    except Exception as e:
        return {"action": "noop", "hash8": _h, "reason": str(e)[:60]}


# ═══════════════════════════════════════════════════════════
# STEP 5 — Node public-key harvester (X25519 pubkeys osservate)
# Popola node_pubkeys da ogni pacchetto con public_key_hex.
# Mai sovrascrive: usa UNIQUE(node_id, public_key_hex).
# ═══════════════════════════════════════════════════════════

def node_pubkey_harvest(node_id, public_key_hex, node_num=None, source="rf"):
    """Registra la chiave pubblica osservata per un nodo (silent, best-effort).

    Strategia idempotente:
      - (node_id, pubkey) nuovo → INSERT con seen_count=1
      - (node_id, pubkey) esistente → UPDATE last_seen_ts + seen_count++
      - input vuoto / non-hex → noop

    Ritorna dict {action, node_id, [count]}.
    """
    if not node_id or not public_key_hex:
        return {"action": "noop", "reason": "missing_fields"}
    _nid = str(node_id).strip()
    _pk = str(public_key_hex).strip().lower()
    if not _nid or len(_pk) < 32:
        return {"action": "noop", "reason": "bad_pubkey_len"}
    try:
        int(_pk, 16)
    except Exception:
        return {"action": "noop", "reason": "bad_pubkey_hex"}
    try:
        _num = int(node_num) if node_num is not None else None
    except Exception:
        _num = None
    _src = str(source or "rf").strip().lower()[:16]
    now = _now_ms()
    try:
        conn = _connect()
        try:
            row = conn.execute(
                "SELECT id, seen_count FROM node_pubkeys "
                "WHERE node_id=? AND public_key_hex=? LIMIT 1",
                (_nid, _pk),
            ).fetchone()
            if row is None:
                conn.execute(
                    "INSERT INTO node_pubkeys(node_id, node_num, public_key_hex, "
                    "first_seen_ts, last_seen_ts, seen_count, source) "
                    "VALUES (?,?,?,?,?,?,?)",
                    (_nid, _num, _pk, now, now, 1, _src),
                )
                return {"action": "inserted", "node_id": _nid}
            conn.execute(
                "UPDATE node_pubkeys SET last_seen_ts=?, seen_count=seen_count+1 "
                "WHERE id=?",
                (now, row["id"]),
            )
            return {"action": "bumped", "node_id": _nid,
                    "count": int(row["seen_count"] or 0) + 1}
        finally:
            conn.close()
    except Exception as e:
        return {"action": "noop", "reason": str(e)[:60]}


def node_pubkey_get(node_id):
    """Ritorna la chiave più recente per un nodo, o None."""
    if not node_id:
        return None
    try:
        conn = _connect()
        try:
            row = conn.execute(
                "SELECT node_id, node_num, public_key_hex, first_seen_ts, "
                "last_seen_ts, seen_count, source FROM node_pubkeys "
                "WHERE node_id=? ORDER BY last_seen_ts DESC LIMIT 1",
                (str(node_id),),
            ).fetchone()
            return dict(row) if row else None
        finally:
            conn.close()
    except Exception:
        return None


def node_pubkey_count():
    """Ritorna contatori aggregati: {unique_nodes, unique_keys, total_rows}."""
    try:
        conn = _connect()
        try:
            row = conn.execute(
                "SELECT COUNT(DISTINCT node_id) AS unique_nodes, "
                "COUNT(DISTINCT public_key_hex) AS unique_keys, "
                "COUNT(*) AS total_rows FROM node_pubkeys"
            ).fetchone()
            return {
                "unique_nodes": int(row["unique_nodes"] or 0),
                "unique_keys": int(row["unique_keys"] or 0),
                "total_rows": int(row["total_rows"] or 0),
            }
        finally:
            conn.close()
    except Exception:
        return {"unique_nodes": 0, "unique_keys": 0, "total_rows": 0}


def node_pubkeys_list(limit=200):
    """Lista entry ordinate per last_seen_ts DESC."""
    try:
        _lim = max(1, min(int(limit), 1000))
    except Exception:
        _lim = 200
    try:
        conn = _connect()
        try:
            rows = conn.execute(
                "SELECT node_id, node_num, public_key_hex, first_seen_ts, "
                "last_seen_ts, seen_count, source FROM node_pubkeys "
                "ORDER BY last_seen_ts DESC LIMIT ?",
                (_lim,),
            ).fetchall()
            return [dict(r) for r in rows]
        finally:
            conn.close()
    except Exception:
        return []


# ═══════════════════════════════════════════════════════════
# HISTORY — leggere tutti i messaggi salvati nel DB 7gg
# Usato dal Monitor per backfill all'apertura della sezione.
# ═══════════════════════════════════════════════════════════

def history_packets(limit=500, window="7d", portnum=None, network=None, fw_type=None):
    """Ritorna gli ultimi N pacchetti dal DB, più recenti prima."""
    try:
        limit = int(limit)
    except Exception:
        limit = 500
    limit = max(1, min(5000, limit))
    win_ms = WINDOW_MAP.get(window, WINDOW_MAP["7d"])
    cutoff = _now_ms() - win_ms
    where = ["ts >= ?"]
    params = [cutoff]
    if network in _ALLOWED_NETWORKS:
        where.append("network = ?")
        params.append(network)
    if fw_type in _ALLOWED_FW:
        where.append("fw_type = ?")
        params.append(fw_type)
    if portnum:
        where.append("port_name = ?")
        params.append(portnum[:40])
    sql = (
        "SELECT p.ts,p.from_node,p.to_node,p.channel_idx,p.channel_name,p.psk_match,"
        "p.network,p.portnum,p.port_name,p.payload_text,p.payload_len,p.rssi,p.snr,"
        "p.hop_start,p.hop_limit,p.packet_id,p.is_encrypted,p.is_compressed,"
        "p.fw_type,p.fw_flags,p.source,"
        "n.short_name,n.long_name,n.hw_model "
        "FROM packets p LEFT JOIN nodes n ON n.node_id = p.from_node "
        "WHERE " + " AND ".join(where) + " ORDER BY p.ts DESC LIMIT ?"
    )
    params.append(limit)
    try:
        conn = _connect()
        try:
            rows = conn.execute(sql, params).fetchall()
            cols = ["ts", "from_node", "to_node", "channel_idx", "channel_name", "psk_match",
                    "network", "portnum", "port_name", "payload_text", "payload_len",
                    "rssi", "snr", "hop_start", "hop_limit", "packet_id",
                    "is_encrypted", "is_compressed", "fw_type", "fw_flags", "source",
                    "short_name", "long_name", "hw_model"]
            return [dict(zip(cols, r)) for r in rows]
        finally:
            conn.close()
    except Exception:
        return []


# ═══════════════════════════════════════════════════════════
# NODE PROFILE — scheda tecnica completa del singolo nodo
# ═══════════════════════════════════════════════════════════

def node_profile(node_id, window="7d"):
    """Costruisce il profilo completo di un nodo: info base + stats + timeline.

    H3 v2 (2026-04-18): legge tutte le 37 cols v2 + snapshot ultime 10 righe
    da topology/traceroutes/map_reports/waypoints/storeforward_stats/node_metadata.
    """
    try:
        nid = _node_int(node_id)
        if nid is None:
            return None
        win_ms = WINDOW_MAP.get(window, WINDOW_MAP["7d"])
        cutoff = _now_ms() - win_ms
        conn = _connect()
        try:
            # Info base nodo — v2 (37 cols: 21 v1 + 16 H1)
            n_row = conn.execute(
                "SELECT node_id,node_hex,short_name,long_name,hw_model,first_seen,last_seen,"
                "network,fw_type,fw_flags,total_packets,rssi_sum,rssi_n,snr_sum,snr_n,"
                "stealth_suspect,used_compression,"
                # H1 v2 extras
                "macaddr,role,is_licensed,is_stealth,is_unmessagable,public_key_hex,"
                "firmware_version,region,modem_preset,hops_away,via_mqtt_last,"
                "last_battery,last_voltage,last_ch_util,last_tx_util,last_uptime "
                "FROM nodes WHERE node_id=?",
                (nid,),
            ).fetchone()
            if not n_row:
                return None
            node = {
                "node_id": n_row[0], "node_hex": n_row[1],
                "short_name": n_row[2], "long_name": n_row[3],
                "hw_model": n_row[4],
                "first_seen": n_row[5], "last_seen": n_row[6],
                "network": n_row[7], "fw_type": n_row[8],
                "fw_flags": _safe_json_loads(n_row[9]),
                "total_packets": n_row[10],
                "rssi_avg": (n_row[11] / n_row[12]) if n_row[12] else None,
                "snr_avg":  (n_row[13] / n_row[14]) if n_row[14] else None,
                "stealth_suspect": bool(n_row[15]),
                "used_compression": bool(n_row[16]),
                # H1 v2 — metadati completi sticky
                "macaddr": n_row[17],
                "role": n_row[18],
                "is_licensed": (None if n_row[19] is None else bool(n_row[19])),
                "is_stealth":  (None if n_row[20] is None else bool(n_row[20])),
                "is_unmessagable": (None if n_row[21] is None else bool(n_row[21])),
                "public_key_hex": n_row[22],
                "firmware_version": n_row[23],
                "region": n_row[24],
                "modem_preset": n_row[25],
                "hops_away": n_row[26],
                "via_mqtt_last": (None if n_row[27] is None else bool(n_row[27])),
                "last_battery": n_row[28],
                "last_voltage": n_row[29],
                "last_ch_util": n_row[30],
                "last_tx_util": n_row[31],
                "last_uptime": n_row[32],
            }
            # Breakdown per portnum
            pn_rows = conn.execute(
                "SELECT COALESCE(port_name,'UNKNOWN') AS pn, COUNT(*) "
                "FROM packets WHERE from_node=? AND ts>=? GROUP BY pn ORDER BY 2 DESC",
                (nid, cutoff),
            ).fetchall()
            node["by_portnum"] = [{"port_name": r[0], "count": r[1]} for r in pn_rows]
            # Breakdown per canale
            ch_rows = conn.execute(
                "SELECT COALESCE(channel_name,'?'), COUNT(*) "
                "FROM packets WHERE from_node=? AND ts>=? GROUP BY 1 ORDER BY 2 DESC",
                (nid, cutoff),
            ).fetchall()
            node["by_channel"] = [{"channel_name": r[0], "count": r[1]} for r in ch_rows]
            # Source breakdown
            src_rows = conn.execute(
                "SELECT COALESCE(source,'rf'), COUNT(*) FROM packets "
                "WHERE from_node=? AND ts>=? GROUP BY 1",
                (nid, cutoff),
            ).fetchall()
            node["by_source"] = {r[0]: r[1] for r in src_rows}
            # Best RSSI/SNR
            best = conn.execute(
                "SELECT MAX(rssi), MAX(snr), MIN(rssi), MIN(snr) FROM packets "
                "WHERE from_node=? AND ts>=? AND source='rf'",
                (nid, cutoff),
            ).fetchone()
            node["rssi_best"], node["snr_best"] = best[0], best[1]
            node["rssi_worst"], node["snr_worst"] = best[2], best[3]
            # Ultimi 20 pacchetti
            rc = conn.execute(
                "SELECT ts, port_name, channel_name, rssi, snr, payload_text, "
                "hop_start, hop_limit, source, is_encrypted, is_compressed, packet_id "
                "FROM packets WHERE from_node=? AND ts>=? ORDER BY ts DESC LIMIT 20",
                (nid, cutoff),
            ).fetchall()
            node["recent"] = [
                {
                    "ts": r[0], "port_name": r[1], "channel_name": r[2],
                    "rssi": r[3], "snr": r[4], "payload_text": r[5],
                    "hop_start": r[6], "hop_limit": r[7], "source": r[8],
                    "is_encrypted": bool(r[9]), "is_compressed": bool(r[10]),
                    "packet_id": r[11],
                }
                for r in rc
            ]
            # Counters nelle ultime 1h / 24h (per rilevamento spam)
            h1 = _now_ms() - 3600 * 1000
            h24 = _now_ms() - 24 * 3600 * 1000
            c1 = conn.execute("SELECT COUNT(*) FROM packets WHERE from_node=? AND ts>=?", (nid, h1)).fetchone()[0]
            c24 = conn.execute("SELECT COUNT(*) FROM packets WHERE from_node=? AND ts>=?", (nid, h24)).fetchone()[0]
            node["pkt_1h"] = c1
            node["pkt_24h"] = c24
            # Rate (pkt/min) media finestra 7gg
            n_total = conn.execute(
                "SELECT COUNT(*) FROM packets WHERE from_node=? AND ts>=?",
                (nid, cutoff),
            ).fetchone()[0]
            minutes = max(1, (win_ms // 60000))
            node["rate_pkt_per_min"] = round(n_total / minutes, 3)
            # Ruolo dedotto (euristica semplice; Batch 3 lo affina)
            node["role_inferred"] = _infer_role(node)

            # H3 v2 — Snapshot ultime righe tabelle correlate
            try:
                nbrs = conn.execute(
                    "SELECT ts, neighbor_id, snr, last_rx_time, "
                    "node_broadcast_interval_secs FROM topology "
                    "WHERE node_id=? AND ts>=? ORDER BY ts DESC LIMIT 50",
                    (nid, cutoff),
                ).fetchall()
                node["neighbors"] = [dict(r) for r in nbrs]
            except Exception:
                node["neighbors"] = []
            try:
                trs = conn.execute(
                    "SELECT ts, from_node, to_node, route_forward_json, route_back_json, "
                    "snr_forward_json, snr_back_json, hop_count, is_response, packet_id, source "
                    "FROM traceroutes WHERE (from_node=? OR to_node=?) AND ts>=? "
                    "ORDER BY ts DESC LIMIT 10",
                    (nid, nid, cutoff),
                ).fetchall()
                _tr_out = []
                for r in trs:
                    d = dict(r)
                    d["route_forward"] = _safe_json_loads(d.pop("route_forward_json"))
                    d["route_back"]    = _safe_json_loads(d.pop("route_back_json"))
                    d["snr_forward"]   = _safe_json_loads(d.pop("snr_forward_json"))
                    d["snr_back"]      = _safe_json_loads(d.pop("snr_back_json"))
                    _tr_out.append(d)
                node["traceroutes"] = _tr_out
            except Exception:
                node["traceroutes"] = []
            try:
                mrs = conn.execute(
                    "SELECT * FROM map_reports WHERE node_id=? AND ts>=? "
                    "ORDER BY ts DESC LIMIT 5",
                    (nid, cutoff),
                ).fetchall()
                node["map_reports"] = [dict(r) for r in mrs]
            except Exception:
                node["map_reports"] = []
            try:
                wps = conn.execute(
                    "SELECT * FROM waypoints WHERE from_node=? AND ts>=? "
                    "ORDER BY ts DESC LIMIT 20",
                    (nid, cutoff),
                ).fetchall()
                node["waypoints"] = [dict(r) for r in wps]
            except Exception:
                node["waypoints"] = []
            try:
                sf = conn.execute(
                    "SELECT * FROM storeforward_stats WHERE node_id=? AND ts>=? "
                    "ORDER BY ts DESC LIMIT 5",
                    (nid, cutoff),
                ).fetchall()
                node["storeforward_stats"] = [dict(r) for r in sf]
            except Exception:
                node["storeforward_stats"] = []
            try:
                mdrows = conn.execute(
                    "SELECT * FROM node_metadata WHERE node_id=? "
                    "ORDER BY ts DESC LIMIT 20",
                    (nid,),
                ).fetchall()
                node["metadata_history"] = [dict(r) for r in mdrows]
            except Exception:
                node["metadata_history"] = []

            # H3 v2 — Telemetria cruda (ultimi 50 pacchetti TELEMETRY con JSON parsed)
            try:
                tlm = conn.execute(
                    "SELECT ts, telemetry_json, rssi, snr, source FROM packets "
                    "WHERE from_node=? AND port_name='TELEMETRY_APP' "
                    "AND ts>=? AND telemetry_json IS NOT NULL "
                    "ORDER BY ts DESC LIMIT 50",
                    (nid, cutoff),
                ).fetchall()
                _tlm_out = []
                for r in tlm:
                    d = dict(r)
                    d["telemetry"] = _safe_json_loads(d.pop("telemetry_json"))
                    _tlm_out.append(d)
                node["telemetry_timeseries"] = _tlm_out
            except Exception:
                node["telemetry_timeseries"] = []

            # H3 v2 — Ultima posizione GPS
            try:
                pos = conn.execute(
                    "SELECT ts, position_lat, position_lon, position_alt, "
                    "position_sats, position_pdop, position_quality_json "
                    "FROM packets WHERE from_node=? AND position_lat IS NOT NULL "
                    "AND ts>=? ORDER BY ts DESC LIMIT 1",
                    (nid, cutoff),
                ).fetchone()
                if pos:
                    d = dict(pos)
                    d["position_quality"] = _safe_json_loads(d.pop("position_quality_json"))
                    node["last_position"] = d
                else:
                    node["last_position"] = None
            except Exception:
                node["last_position"] = None

            return node
        finally:
            conn.close()
    except Exception:
        return None


def _safe_json_loads(s):
    try:
        return json.loads(s) if s else None
    except Exception:
        return None


def _infer_role(node):
    """Euristica semplice sul ruolo: gateway/client/router/tracker/spam/silent."""
    total = node.get("total_packets", 0) or 0
    by_pn = {r["port_name"]: r["count"] for r in (node.get("by_portnum") or [])}
    text = by_pn.get("TEXT_MESSAGE_APP", 0) + by_pn.get("TEXT_MESSAGE_COMPRESSED_APP", 0)
    pos = by_pn.get("POSITION_APP", 0)
    tlm = by_pn.get("TELEMETRY_APP", 0)
    nbr = by_pn.get("NEIGHBORINFO_APP", 0)
    rt = by_pn.get("ROUTING_APP", 0)
    src = node.get("by_source") or {}
    mqtt = src.get("mqtt", 0)
    rf = src.get("rf", 0)
    pkt_1h = node.get("pkt_1h", 0) or 0
    # Spam: >60 pkt/h con >50% TEXT
    if pkt_1h > 60 and text > pkt_1h * 0.5:
        return "spam"
    if node.get("stealth_suspect"):
        return "stealth"
    if mqtt > rf * 3:
        return "gateway_mqtt"
    if rt > total * 0.4:
        return "router"
    if pos > total * 0.4:
        return "tracker"
    if tlm > total * 0.4:
        return "telemetry"
    if text > total * 0.4:
        return "chatty"
    if nbr > total * 0.4:
        return "neighbor_map"
    if total == 0:
        return "silent"
    return "client"


# ═══════════════════════════════════════════════════════════
# SELF-TEST (richiamabile da CLI per diagnostica)
# ═══════════════════════════════════════════════════════════

def _self_test():
    """Inserisce 100 pacchetti fake e verifica query. Ritorna dict esito."""
    init_db()
    import random
    rnd = random.Random(42)
    nets = ["min", "mesh_italia", "unknown"]
    fws = ["stock", "fork_a", "fork_b", "stealth", "builder", "unknown"]
    ports = [("TEXT_MESSAGE_APP", 1), ("POSITION_APP", 3), ("NODEINFO_APP", 4),
             ("TELEMETRY_APP", 67), ("TEXT_MESSAGE_COMPRESSED_APP", 7)]
    chs = ["MediumFast", "LongFast", "Test", "NewsFeed", None]
    for i in range(100):
        port = rnd.choice(ports)
        insert_packet({
            "ts": _now_ms() - rnd.randint(0, 7 * 86400 * 1000),
            "from_node": 0x10000000 + rnd.randint(0, 20),
            "to_node": 0xFFFFFFFF,
            "channel_idx": rnd.randint(0, 7),
            "channel_name": rnd.choice(chs),
            "psk_match": rnd.choice(["default", "min_regional", "other"]),
            "network": rnd.choice(nets),
            "portnum": port[1],
            "port_name": port[0],
            "payload_text": "test msg " + str(i) if port[1] == 1 else None,
            "payload_len": rnd.randint(10, 200),
            "rssi": -60 - rnd.randint(0, 50),
            "snr": rnd.uniform(-15, 10),
            "hop_start": 3,
            "hop_limit": rnd.randint(0, 3),
            "packet_id": rnd.randint(1, 2**31),
            "is_encrypted": rnd.random() < 0.1,
            "is_compressed": port[1] == 7,
            "fw_type": rnd.choice(fws),
            "source": rnd.choice(["rf", "mqtt"]),
            "short_name": f"NOD{i:02d}",
        })
    out = {
        "db_info": db_info(),
        "top_nodes": query_leaderboard("top_nodes", "7d", limit=5),
        "by_network": query_leaderboard("by_network", "7d"),
        "by_firmware": query_leaderboard("by_firmware", "7d"),
    }
    return out


# ═══════════════════════════════════════════════════════════
# STEP F4 — LISTA NODI CON GPS (per mappa Google Maps)
# ═══════════════════════════════════════════════════════════

def list_gps_nodes(hours=24, limit=500):
    """Ritorna la lista di nodi con coordinate GPS viste negli ultimi N ore.

    Campi per ogni nodo:
      - node_id (int), node_hex (!hex)
      - short_name, long_name, hw_model
      - latitude, longitude, altitude
      - pos_ts (ms), last_seen (ms)
      - snr_avg (media SNR su finestra), total_packets

    Ordinato per pos_ts DESC (più recenti in cima).
    """
    try:
        cutoff = _now_ms() - int(max(1, hours)) * 3600 * 1000
        conn = _connect()
        try:
            rows = conn.execute(
                "SELECT node_id, node_hex, short_name, long_name, hw_model, "
                "       latitude, longitude, altitude, pos_ts, last_seen, "
                "       total_packets, "
                "       CASE WHEN snr_n > 0 THEN snr_sum*1.0/snr_n ELSE NULL END AS snr_avg, "
                "       network, fw_type "
                "FROM nodes "
                "WHERE latitude IS NOT NULL AND longitude IS NOT NULL "
                "  AND pos_ts IS NOT NULL AND pos_ts >= ? "
                "ORDER BY pos_ts DESC "
                "LIMIT ?",
                (cutoff, int(limit)),
            ).fetchall()
        finally:
            conn.close()
        out = []
        for r in rows:
            d = dict(r)
            # arrotonda float per presentazione
            if d.get("latitude") is not None:
                d["latitude"] = round(float(d["latitude"]), 6)
            if d.get("longitude") is not None:
                d["longitude"] = round(float(d["longitude"]), 6)
            if d.get("snr_avg") is not None:
                d["snr_avg"] = round(float(d["snr_avg"]), 1)
            out.append(d)
        return out
    except Exception as e:
        try:
            sys.stderr.write(f"[monitor_db] list_gps_nodes error: {e}\n")
        except Exception:
            pass
        return []


# ═══════════════════════════════════════════════════════════
# H1 v2 — INSERT HELPERS per le 6 nuove tabelle
# Tutte idempotenti-soft: silenti su errore (il Monitor non
# deve morire per un write su tabella opzionale).
# ═══════════════════════════════════════════════════════════

def insert_topology(data):
    """NEIGHBORINFO_APP edge — una riga per vicino.
    data: { ts, node_id, neighbor_id, snr, last_rx_time,
            node_broadcast_interval_secs, source }
    """
    try:
        node = _node_int(data.get("node_id"))
        neigh = _node_int(data.get("neighbor_id"))
        if node is None or neigh is None:
            return None
        ts = int(data.get("ts") or _now_ms())
        conn = _connect()
        try:
            conn.execute(
                "INSERT INTO topology(ts, node_id, neighbor_id, snr, last_rx_time, "
                "node_broadcast_interval_secs, source) VALUES (?,?,?,?,?,?,?)",
                (
                    ts, node, neigh,
                    data.get("snr"),
                    data.get("last_rx_time"),
                    data.get("node_broadcast_interval_secs"),
                    data.get("source"),
                ),
            )
        finally:
            conn.close()
        return True
    except Exception as e:
        try:
            sys.stderr.write(f"[monitor_db] insert_topology error: {e}\n")
        except Exception:
            pass
        return None


def insert_traceroute(data):
    """TRACEROUTE_APP — path forward+back con SNR per hop.
    data: { ts, from_node, to_node, route_forward (list), route_back (list),
            snr_forward (list), snr_back (list), hop_count, is_response,
            packet_id, source }
    """
    try:
        fn = _node_int(data.get("from_node"))
        tn = _node_int(data.get("to_node"))
        if fn is None:
            return None
        ts = int(data.get("ts") or _now_ms())

        def _js(v):
            if v is None:
                return None
            try:
                return json.dumps(v, separators=(",", ":"))
            except Exception:
                return None

        conn = _connect()
        try:
            conn.execute(
                "INSERT INTO traceroutes(ts, from_node, to_node, "
                "route_forward_json, route_back_json, "
                "snr_forward_json, snr_back_json, "
                "hop_count, is_response, packet_id, source) "
                "VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                (
                    ts, fn, tn,
                    _js(data.get("route_forward")),
                    _js(data.get("route_back")),
                    _js(data.get("snr_forward")),
                    _js(data.get("snr_back")),
                    data.get("hop_count"),
                    1 if data.get("is_response") else 0,
                    data.get("packet_id"),
                    data.get("source"),
                ),
            )
        finally:
            conn.close()
        return True
    except Exception as e:
        try:
            sys.stderr.write(f"[monitor_db] insert_traceroute error: {e}\n")
        except Exception:
            pass
        return None


def insert_map_report(data):
    """MAP_REPORT_APP — snapshot metadata broadcast dal nodo.
    data: { ts, node_id, long_name, short_name, role, hw_model,
            firmware_version, region, modem_preset, has_default_channel,
            latitude_i, longitude_i, altitude, position_precision,
            num_online_local_nodes, has_opted_report_location, source }
    """
    try:
        node = _node_int(data.get("node_id"))
        if node is None:
            return None
        ts = int(data.get("ts") or _now_ms())
        conn = _connect()
        try:
            conn.execute(
                "INSERT INTO map_reports(ts, node_id, long_name, short_name, role, "
                "hw_model, firmware_version, region, modem_preset, has_default_channel, "
                "latitude_i, longitude_i, altitude, position_precision, "
                "num_online_local_nodes, has_opted_report_location, source) "
                "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (
                    ts, node,
                    data.get("long_name"),
                    data.get("short_name"),
                    data.get("role"),
                    data.get("hw_model"),
                    data.get("firmware_version"),
                    data.get("region"),
                    data.get("modem_preset"),
                    1 if data.get("has_default_channel") else 0,
                    data.get("latitude_i"),
                    data.get("longitude_i"),
                    data.get("altitude"),
                    data.get("position_precision"),
                    data.get("num_online_local_nodes"),
                    1 if data.get("has_opted_report_location") else 0,
                    data.get("source"),
                ),
            )
        finally:
            conn.close()
        return True
    except Exception as e:
        try:
            sys.stderr.write(f"[monitor_db] insert_map_report error: {e}\n")
        except Exception:
            pass
        return None


def insert_waypoint(data):
    """WAYPOINT_APP — POI condivisi in rete."""
    try:
        fn = _node_int(data.get("from_node"))
        wid = data.get("waypoint_id")
        if fn is None or wid is None:
            return None
        ts = int(data.get("ts") or _now_ms())
        conn = _connect()
        try:
            conn.execute(
                "INSERT INTO waypoints(ts, waypoint_id, from_node, "
                "latitude_i, longitude_i, expire, locked_to, "
                "name, description, icon, source) "
                "VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                (
                    ts, int(wid), fn,
                    data.get("latitude_i"),
                    data.get("longitude_i"),
                    data.get("expire"),
                    _node_int(data.get("locked_to")),
                    (data.get("name") or "")[:120],
                    (data.get("description") or "")[:500],
                    data.get("icon"),
                    data.get("source"),
                ),
            )
        finally:
            conn.close()
        return True
    except Exception as e:
        try:
            sys.stderr.write(f"[monitor_db] insert_waypoint error: {e}\n")
        except Exception:
            pass
        return None


def insert_storeforward_stats(data):
    """STORE_FORWARD_APP — heartbeat/history/stats.
    data: { ts, node_id, rr_type, messages_total, messages_saved, ...,
            source }
    """
    try:
        node = _node_int(data.get("node_id"))
        if node is None:
            return None
        ts = int(data.get("ts") or _now_ms())
        conn = _connect()
        try:
            conn.execute(
                "INSERT INTO storeforward_stats(ts, node_id, rr_type, "
                "messages_total, messages_saved, messages_max, up_time, "
                "requests, requests_history, heartbeat, return_max, return_window, "
                "history_messages, history_window, history_last_request, source) "
                "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (
                    ts, node,
                    data.get("rr_type"),
                    data.get("messages_total"),
                    data.get("messages_saved"),
                    data.get("messages_max"),
                    data.get("up_time"),
                    data.get("requests"),
                    data.get("requests_history"),
                    1 if data.get("heartbeat") else 0,
                    data.get("return_max"),
                    data.get("return_window"),
                    data.get("history_messages"),
                    data.get("history_window"),
                    data.get("history_last_request"),
                    data.get("source"),
                ),
            )
        finally:
            conn.close()
        return True
    except Exception as e:
        try:
            sys.stderr.write(f"[monitor_db] insert_storeforward_stats error: {e}\n")
        except Exception:
            pass
        return None


def insert_node_metadata(data):
    """MyNodeInfo + DeviceMetadata snapshot — una riga per update."""
    try:
        node = _node_int(data.get("node_id"))
        if node is None:
            return None
        ts = int(data.get("ts") or _now_ms())
        conn = _connect()
        try:
            conn.execute(
                "INSERT INTO node_metadata(ts, node_id, firmware_version, "
                "device_state_version, canShutdown, hasWifi, hasBluetooth, hasEthernet, "
                "role, position_flags, hw_model, hasRemoteHardware, hasPKC, "
                "excluded_modules, reboot_count, min_app_version, pio_env, "
                "device_id_hex, source) "
                "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (
                    ts, node,
                    data.get("firmware_version"),
                    data.get("device_state_version"),
                    1 if data.get("canShutdown") else 0,
                    1 if data.get("hasWifi") else 0,
                    1 if data.get("hasBluetooth") else 0,
                    1 if data.get("hasEthernet") else 0,
                    data.get("role"),
                    data.get("position_flags"),
                    data.get("hw_model"),
                    1 if data.get("hasRemoteHardware") else 0,
                    1 if data.get("hasPKC") else 0,
                    data.get("excluded_modules"),
                    data.get("reboot_count"),
                    data.get("min_app_version"),
                    data.get("pio_env"),
                    data.get("device_id_hex"),
                    data.get("source"),
                ),
            )
        finally:
            conn.close()
        return True
    except Exception as e:
        try:
            sys.stderr.write(f"[monitor_db] insert_node_metadata error: {e}\n")
        except Exception:
            pass
        return None


# ═══════════════════════════════════════════════════════════
# H1 v2 — READ HELPERS per Hub Monitor Scanner
# ═══════════════════════════════════════════════════════════

def list_topology(limit=500, window="7d", node_id=None):
    """Edge list (source, target, snr, ts) per grafo topologia."""
    try:
        limit = max(1, min(int(limit), 5000))
        win_s = WINDOW_MAP.get(window, WINDOW_MAP["7d"])
        cutoff = _now_ms() - win_s * 1000
        conn = _connect()
        try:
            if node_id is not None:
                nid = _node_int(node_id)
                rows = conn.execute(
                    "SELECT ts, node_id, neighbor_id, snr, last_rx_time, "
                    "node_broadcast_interval_secs, source "
                    "FROM topology WHERE ts>=? AND (node_id=? OR neighbor_id=?) "
                    "ORDER BY ts DESC LIMIT ?",
                    (cutoff, nid, nid, limit),
                ).fetchall()
            else:
                rows = conn.execute(
                    "SELECT ts, node_id, neighbor_id, snr, last_rx_time, "
                    "node_broadcast_interval_secs, source "
                    "FROM topology WHERE ts>=? "
                    "ORDER BY ts DESC LIMIT ?",
                    (cutoff, limit),
                ).fetchall()
            return [dict(r) for r in rows]
        finally:
            conn.close()
    except Exception:
        return []


def list_traceroutes(limit=100, window="7d", from_node=None, to_node=None):
    """Traceroute recenti — ritorna con route e SNR decodificati."""
    try:
        limit = max(1, min(int(limit), 500))
        win_s = WINDOW_MAP.get(window, WINDOW_MAP["7d"])
        cutoff = _now_ms() - win_s * 1000
        where = ["ts >= ?"]
        params = [cutoff]
        if from_node is not None:
            fn = _node_int(from_node)
            if fn is not None:
                where.append("from_node = ?")
                params.append(fn)
        if to_node is not None:
            tn = _node_int(to_node)
            if tn is not None:
                where.append("to_node = ?")
                params.append(tn)
        sql = (
            "SELECT ts, from_node, to_node, route_forward_json, route_back_json, "
            "snr_forward_json, snr_back_json, hop_count, is_response, packet_id, source "
            "FROM traceroutes WHERE " + " AND ".join(where) +
            " ORDER BY ts DESC LIMIT ?"
        )
        params.append(limit)
        conn = _connect()
        try:
            rows = conn.execute(sql, params).fetchall()
            out = []
            for r in rows:
                d = dict(r)
                d["route_forward"] = _safe_json_loads(d.pop("route_forward_json"))
                d["route_back"] = _safe_json_loads(d.pop("route_back_json"))
                d["snr_forward"] = _safe_json_loads(d.pop("snr_forward_json"))
                d["snr_back"] = _safe_json_loads(d.pop("snr_back_json"))
                out.append(d)
            return out
        finally:
            conn.close()
    except Exception:
        return []


def list_map_reports(limit=500, window="7d", node_id=None):
    """Map reports recenti — snapshot metadata broadcast."""
    try:
        limit = max(1, min(int(limit), 2000))
        win_s = WINDOW_MAP.get(window, WINDOW_MAP["7d"])
        cutoff = _now_ms() - win_s * 1000
        conn = _connect()
        try:
            if node_id is not None:
                nid = _node_int(node_id)
                rows = conn.execute(
                    "SELECT * FROM map_reports WHERE ts>=? AND node_id=? "
                    "ORDER BY ts DESC LIMIT ?",
                    (cutoff, nid, limit),
                ).fetchall()
            else:
                rows = conn.execute(
                    "SELECT * FROM map_reports WHERE ts>=? "
                    "ORDER BY ts DESC LIMIT ?",
                    (cutoff, limit),
                ).fetchall()
            return [dict(r) for r in rows]
        finally:
            conn.close()
    except Exception:
        return []


def list_waypoints(limit=500, window="7d"):
    """Waypoints attivi (expire futuro o null) entro finestra."""
    try:
        limit = max(1, min(int(limit), 2000))
        win_s = WINDOW_MAP.get(window, WINDOW_MAP["7d"])
        cutoff = _now_ms() - win_s * 1000
        now_s = int(time.time())
        conn = _connect()
        try:
            rows = conn.execute(
                "SELECT * FROM waypoints WHERE ts>=? "
                "AND (expire IS NULL OR expire=0 OR expire>=?) "
                "ORDER BY ts DESC LIMIT ?",
                (cutoff, now_s, limit),
            ).fetchall()
            return [dict(r) for r in rows]
        finally:
            conn.close()
    except Exception:
        return []


def list_node_metadata(node_id, limit=20):
    """Storico snapshot metadata di un nodo (firmware/role/flags)."""
    try:
        nid = _node_int(node_id)
        if nid is None:
            return []
        limit = max(1, min(int(limit), 200))
        conn = _connect()
        try:
            rows = conn.execute(
                "SELECT * FROM node_metadata WHERE node_id=? "
                "ORDER BY ts DESC LIMIT ?",
                (nid, limit),
            ).fetchall()
            return [dict(r) for r in rows]
        finally:
            conn.close()
    except Exception:
        return []


def list_storeforward_stats(limit=100, window="7d", node_id=None):
    """Storico Store&Forward stats."""
    try:
        limit = max(1, min(int(limit), 1000))
        win_s = WINDOW_MAP.get(window, WINDOW_MAP["7d"])
        cutoff = _now_ms() - win_s * 1000
        conn = _connect()
        try:
            if node_id is not None:
                nid = _node_int(node_id)
                rows = conn.execute(
                    "SELECT * FROM storeforward_stats WHERE ts>=? AND node_id=? "
                    "ORDER BY ts DESC LIMIT ?",
                    (cutoff, nid, limit),
                ).fetchall()
            else:
                rows = conn.execute(
                    "SELECT * FROM storeforward_stats WHERE ts>=? "
                    "ORDER BY ts DESC LIMIT ?",
                    (cutoff, limit),
                ).fetchall()
            return [dict(r) for r in rows]
        finally:
            conn.close()
    except Exception:
        return []


# ═══════════════════════════════════════════════════════════
# H1 v2 — RICERCA GLOBALE (FTS5 con fallback LIKE)
# Hub Monitor Scanner: barra di ricerca su TUTTI i pacchetti
# ═══════════════════════════════════════════════════════════

def search_fts(query, limit=200, window="7d"):
    """Ricerca full-text globale su payload_text + port_name + channel_name +
    short_name + long_name + from_hex.

    Usa FTS5 se disponibile, altrimenti fallback LIKE su colonne essenziali.
    Ritorna list[dict] ordinato per ts DESC (più recenti prima).
    """
    try:
        q = (query or "").strip()
        if not q or len(q) > 200:
            return []
        limit = max(1, min(int(limit), 1000))
        win_s = WINDOW_MAP.get(window, WINDOW_MAP["7d"])
        cutoff = _now_ms() - win_s * 1000

        fts_ok = get_meta("fts5_available") == "1"
        conn = _connect()
        try:
            if fts_ok:
                # Tenta FTS5 query
                try:
                    # MATCH su tutti i campi indicizzati; rowid = packets.id
                    rows = conn.execute(
                        "SELECT p.ts, p.from_node, p.to_node, p.channel_name, "
                        "       p.network, p.portnum, p.port_name, p.payload_text, "
                        "       p.rssi, p.snr, p.packet_id, p.is_encrypted, p.is_compressed, "
                        "       p.fw_type, p.source, "
                        "       n.short_name, n.long_name, n.hw_model "
                        "FROM packets_fts fts "
                        "JOIN packets p ON p.rowid = fts.rowid "
                        "LEFT JOIN nodes n ON n.node_id = p.from_node "
                        "WHERE packets_fts MATCH ? AND p.ts >= ? "
                        "ORDER BY p.ts DESC LIMIT ?",
                        (q, cutoff, limit),
                    ).fetchall()
                    return [dict(r) for r in rows]
                except Exception:
                    # Se MATCH fallisce (syntax error), fallback LIKE
                    pass

            # Fallback LIKE — non efficiente ma funziona
            like = f"%{q}%"
            rows = conn.execute(
                "SELECT p.ts, p.from_node, p.to_node, p.channel_name, "
                "       p.network, p.portnum, p.port_name, p.payload_text, "
                "       p.rssi, p.snr, p.packet_id, p.is_encrypted, p.is_compressed, "
                "       p.fw_type, p.source, "
                "       n.short_name, n.long_name, n.hw_model "
                "FROM packets p LEFT JOIN nodes n ON n.node_id = p.from_node "
                "WHERE p.ts >= ? AND ("
                "       p.payload_text LIKE ? OR p.port_name LIKE ? OR "
                "       p.channel_name LIKE ? OR n.short_name LIKE ? OR "
                "       n.long_name LIKE ?) "
                "ORDER BY p.ts DESC LIMIT ?",
                (cutoff, like, like, like, like, like, limit),
            ).fetchall()
            return [dict(r) for r in rows]
        finally:
            conn.close()
    except Exception as e:
        try:
            sys.stderr.write(f"[monitor_db] search_fts error: {e}\n")
        except Exception:
            pass
        return []


def fts_rebuild_from_packets():
    """Ri-popola packets_fts da zero a partire da tutti i packets esistenti.
    Da chiamare quando FTS5 viene attivato per la prima volta su un DB v1
    già popolato, o dopo purge_all. Non fa nulla se FTS5 non è disponibile.
    """
    try:
        if get_meta("fts5_available") != "1":
            return {"skipped": "fts5 not available"}
        conn = _connect()
        try:
            # Svuota prima
            try:
                conn.execute("DELETE FROM packets_fts")
            except Exception:
                pass
            # Popola
            conn.execute(
                "INSERT INTO packets_fts(rowid, payload_text, port_name, channel_name, "
                "short_name, long_name, from_hex) "
                "SELECT p.id, "
                "       COALESCE(p.payload_text,''), "
                "       COALESCE(p.port_name,''), "
                "       COALESCE(p.channel_name,''), "
                "       COALESCE(n.short_name,''), "
                "       COALESCE(n.long_name,''), "
                "       COALESCE('!' || printf('%08x', p.from_node), '') "
                "FROM packets p LEFT JOIN nodes n ON n.node_id = p.from_node"
            )
            count = conn.execute("SELECT COUNT(*) AS c FROM packets_fts").fetchone()["c"]
            return {"rebuilt": int(count or 0)}
        finally:
            conn.close()
    except Exception as e:
        return {"error": str(e)}


# ═══════════════════════════════════════════════════════════
# H3 v2 — HUB MONITOR SCANNER: list_nodes() v2 (37 cols)
# ═══════════════════════════════════════════════════════════

def list_nodes(limit=500, window="7d", network=None, fw_type=None, role=None):
    """Lista nodi con tutti i metadati v2 (37 colonne) + aggregati.

    Filtra per finestra (ultimi N giorni), rete, firmware, ruolo.
    Ritorna dict per nodo con:
      - ID: node_id, node_hex, short_name, long_name, hw_model
      - Temporali: first_seen, last_seen, total_packets
      - Aggregati: rssi_avg, snr_avg, rssi_best, snr_best, pkt_1h, pkt_24h
      - Classificazione: network, fw_type, role, role_inferred, stealth_suspect
      - H1 v2: macaddr, is_licensed, is_stealth, is_unmessagable, public_key_hex,
               firmware_version, region, modem_preset, hops_away, via_mqtt_last,
               last_battery, last_voltage, last_ch_util, last_tx_util, last_uptime
    """
    try:
        limit = max(1, min(int(limit), 5000))
        win_ms = WINDOW_MAP.get(window, WINDOW_MAP["7d"])
        cutoff = _now_ms() - win_ms
        conn = _connect()
        try:
            where = ["last_seen >= ?"]
            params = [cutoff]
            if network:
                where.append("network = ?")
                params.append(network)
            if fw_type:
                where.append("fw_type = ?")
                params.append(fw_type)
            if role:
                where.append("role = ?")
                params.append(role)
            sql = (
                "SELECT * FROM nodes WHERE " + " AND ".join(where) +
                " ORDER BY last_seen DESC LIMIT ?"
            )
            params.append(limit)
            rows = conn.execute(sql, params).fetchall()
            now_ms = _now_ms()
            ms_1h = now_ms - 3600 * 1000
            ms_24h = now_ms - 86400 * 1000
            out = []
            for r in rows:
                d = dict(r)
                # Medie RSSI/SNR senza ZeroDivisionError
                try:
                    _rn = int(d.get("rssi_n") or 0)
                    d["rssi_avg"] = (float(d.get("rssi_sum") or 0) / _rn) if _rn > 0 else None
                except Exception:
                    d["rssi_avg"] = None
                try:
                    _sn = int(d.get("snr_n") or 0)
                    d["snr_avg"] = (float(d.get("snr_sum") or 0) / _sn) if _sn > 0 else None
                except Exception:
                    d["snr_avg"] = None
                # pkt_1h / pkt_24h da packets (best-effort)
                try:
                    _nid = int(d.get("node_id") or 0)
                    if _nid:
                        d["pkt_1h"] = int(conn.execute(
                            "SELECT COUNT(*) AS c FROM packets WHERE from_node=? AND ts>=?",
                            (_nid, ms_1h),
                        ).fetchone()["c"] or 0)
                        d["pkt_24h"] = int(conn.execute(
                            "SELECT COUNT(*) AS c FROM packets WHERE from_node=? AND ts>=?",
                            (_nid, ms_24h),
                        ).fetchone()["c"] or 0)
                    else:
                        d["pkt_1h"] = 0
                        d["pkt_24h"] = 0
                except Exception:
                    d["pkt_1h"] = 0
                    d["pkt_24h"] = 0
                out.append(d)
            return out
        finally:
            conn.close()
    except Exception as e:
        try:
            sys.stderr.write(f"[monitor_db] list_nodes error: {e}\n")
        except Exception:
            pass
        return []


if __name__ == "__main__":
    # python monitor_db.py -> self-test
    try:
        print(json.dumps(_self_test(), indent=2, default=str))
    except Exception as _e:
        print(f"self-test failed: {_e}")
