# -*- coding: utf-8 -*-
"""
tune_node.py — Auto-Tune Node per Monitor LoRa
════════════════════════════════════════════════════════════════════

STEP D — Regola i parametri del nodo Meshtastic per massimizzare i dati
monitorabili, usando ESCLUSIVAMENTE la API Python di meshtastic sulla
interfaccia già attiva del Monitor. NIENTE shell=True, NIENTE subprocess.

WHITELIST:
    - lora.tx_power                       → 30 dBm (max EU)
    - mqtt.enabled                        → True  (ricevi anche pacchetti MQTT)
    - position.position_broadcast_secs    → 900s  (15 min)
    - position.gps_update_interval        → 60s
    - telemetry.device_update_interval    → 600s  (10 min)

BLACKLIST (MAI toccare):
    - factory-reset, begin-edit-settings senza conferma
    - Canali PSK (legge solo, mai scrive)
    - Chiavi private utente

Flusso UI:
    1. GET /api/monitor/tune/preview → ritorna {current, target, diff}
    2. L'utente legge, poi conferma
    3. POST /api/monitor/tune/apply  con {"confirm": true}
    4. Backend applica settings e risponde {applied, errors, new_state}

© 2026 MANGOLINK — tutti i diritti riservati.
"""

# Parametri target raccomandati per nodo Monitor
TUNE_TARGETS = {
    "lora.tx_power": 30,
    "mqtt.enabled": True,
    "position.position_broadcast_secs": 900,
    "position.gps_update_interval": 60,
    "telemetry.device_update_interval": 600,
}

# Whitelist: solo questi path sono modificabili tramite questo modulo
_ALLOWED_PATHS = set(TUNE_TARGETS.keys())


def _read_path(iface, path):
    """Legge un valore dalla config del nodo in base a path dot-notation.

    Es: 'lora.tx_power' → iface.localNode.localConfig.lora.tx_power
    Es: 'mqtt.enabled'  → iface.localNode.moduleConfig.mqtt.enabled

    Ritorna il valore o None se non leggibile.
    """
    if path not in _ALLOWED_PATHS:
        return None
    try:
        localNode = getattr(iface, "localNode", None)
        if not localNode:
            return None
        parts = path.split(".")
        # Decide se leggere da localConfig (lora, position, network...) o da moduleConfig (mqtt, telemetry...)
        module_level = parts[0]
        if module_level in ("mqtt", "telemetry", "serial", "store_forward", "neighbor_info",
                             "ambient_lighting", "detection_sensor", "paxcounter", "external_notification"):
            root = getattr(localNode, "moduleConfig", None)
        else:
            root = getattr(localNode, "localConfig", None)
        if root is None:
            return None
        obj = root
        for p in parts:
            obj = getattr(obj, p, None)
            if obj is None:
                return None
        return obj
    except Exception:
        return None


def _write_path(iface, path, value):
    """Scrive un valore tramite la API Meshtastic.

    Dopo scrittura chiama writeConfig(modulo) per commitare.
    Ritorna (ok: bool, msg: str).
    """
    if path not in _ALLOWED_PATHS:
        return False, "not_allowed"
    try:
        localNode = getattr(iface, "localNode", None)
        if not localNode:
            return False, "no_local_node"
        parts = path.split(".")
        module_level = parts[0]
        is_module = module_level in (
            "mqtt", "telemetry", "serial", "store_forward", "neighbor_info",
            "ambient_lighting", "detection_sensor", "paxcounter", "external_notification",
        )
        if is_module:
            root = getattr(localNode, "moduleConfig", None)
        else:
            root = getattr(localNode, "localConfig", None)
        if root is None:
            return False, "no_config_root"
        obj = root
        for p in parts[:-1]:
            obj = getattr(obj, p, None)
            if obj is None:
                return False, f"missing_sub:{p}"
        field = parts[-1]
        if not hasattr(obj, field):
            return False, f"unknown_field:{field}"
        # Type-coerce
        try:
            cur = getattr(obj, field)
            if isinstance(cur, bool) or (cur is None and isinstance(value, bool)):
                setattr(obj, field, bool(value))
            elif isinstance(cur, int) or (cur is None and isinstance(value, int)):
                setattr(obj, field, int(value))
            else:
                setattr(obj, field, value)
        except Exception as e:
            return False, f"set_fail:{e}"
        # Commit: scrive la sezione corrispondente
        try:
            if is_module:
                localNode.writeConfig(module_level)
            else:
                localNode.writeConfig(module_level)
        except Exception as e:
            return False, f"write_fail:{e}"
        return True, "ok"
    except Exception as e:
        return False, f"exc:{e}"


def preview(iface, targets=None):
    """Confronta stato attuale con target. Ritorna dict con 'current', 'target', 'diff'.

    targets: opzionale dict {path: value}; default = TUNE_TARGETS.
    """
    tgt = dict(targets) if targets else dict(TUNE_TARGETS)
    # Filtra solo whitelist
    tgt = {k: v for k, v in tgt.items() if k in _ALLOWED_PATHS}
    current = {}
    diff = []
    for path, want in tgt.items():
        cur = _read_path(iface, path)
        current[path] = cur
        if cur != want:
            diff.append({
                "path": path,
                "current": cur,
                "target": want,
            })
    return {
        "ok": True,
        "current": current,
        "target": tgt,
        "diff": diff,
        "changes_needed": len(diff),
    }


def apply(iface, targets=None, confirm=False):
    """Applica i target sul nodo. Richiede confirm=True esplicito.

    Ritorna dict con 'applied', 'errors', 'new_state'.
    """
    if not confirm:
        return {"ok": False, "error": "confirm_required",
                "message": "Il cambio parametri richiede confirm=true esplicito."}
    tgt = dict(targets) if targets else dict(TUNE_TARGETS)
    tgt = {k: v for k, v in tgt.items() if k in _ALLOWED_PATHS}
    applied = []
    errors = []
    for path, want in tgt.items():
        cur = _read_path(iface, path)
        if cur == want:
            applied.append({"path": path, "status": "unchanged", "value": cur})
            continue
        ok, msg = _write_path(iface, path, want)
        if ok:
            applied.append({"path": path, "status": "applied", "old": cur, "new": want})
        else:
            errors.append({"path": path, "error": msg})
    # Rileggi stato finale
    new_state = {p: _read_path(iface, p) for p in tgt.keys()}
    return {
        "ok": len(errors) == 0,
        "applied": applied,
        "errors": errors,
        "new_state": new_state,
    }
