const I18N = {
current: 'it',
translations: {},
flags: { it:'🇮🇹', en:'🇬🇧', es:'🇪🇸', fr:'🇫🇷', de:'🇩🇪' },
isItalian: true,
_observer: null,
_reapplyTimer: null,
_isApplying: false,
_safeMapCache: {},
};
async function loadLanguage(lang) {
if (!I18N.translations[lang]) {
try {
const r = await fetch(`/static/${lang}.json`);
if (!r.ok) throw new Error(r.status);
I18N.translations[lang] = await r.json();
} catch (e) {
console.warn(`Lingua ${lang} non caricata`, e);
return false;
}
}
return true;
}
async function setLanguage(lang) {
const ind = document.getElementById('lang-loading');
if (ind) ind.style.display = 'inline';
if (lang === I18N.current) {
if (ind) ind.style.display = 'none';
return;
}
if (lang === 'it') {
try { localStorage.setItem('mesh_lang', 'it'); } catch(e) {}
location.reload();
return;
}
if (!I18N.isItalian && I18N.current !== 'it') {
try { localStorage.setItem('mesh_lang', lang); } catch(e) {}
location.reload();
return;
}
const ok = await loadLanguage(lang);
if (!ok) { if (ind) ind.style.display = 'none'; return; }
I18N.current = lang;
I18N.isItalian = false;
applyDataI18n(lang);
applyTextMap(lang);
updateProLangIndicator();
document.querySelectorAll('.lang-flag').forEach(f => {
f.classList.toggle('active', f.dataset.lang === lang);
});
document.documentElement.dataset.translated = 'true';
_startObserver();
try { localStorage.setItem('mesh_lang', lang); } catch(e) {}
if (ind) ind.style.display = 'none';
setTimeout(() => { if(typeof initTooltips==='function') initTooltips(); if(typeof initCopyButtons==='function') initCopyButtons(); }, 200);
}
function t(str) {
if (I18N.isItalian || !str) return str;
const tr = I18N.translations[I18N.current];
if (!tr || !tr.text_map) return str;
if (tr.text_map[str] !== undefined) return tr.text_map[str];
const { safe, regex } = _getSafeMap(I18N.current);
let result = str;
let changed = false;
for (const [key, val] of Object.entries(safe)) {
if (result.includes(key)) {
result = result.split(key).join(val);
changed = true;
}
}
for (const entry of regex) {
if (entry.rx.test(result)) {
entry.rx.lastIndex = 0;
result = result.replace(entry.rx, entry.val);
changed = true;
}
}
return changed ? result : str;
}
function applyDataI18n(lang) {
const tr = I18N.isItalian ? null : I18N.translations[lang];
if (!tr) return;
document.querySelectorAll('[data-i18n]').forEach(el => {
const key = el.getAttribute('data-i18n');
const val = _nested(tr, key);
if (val !== undefined) el.innerHTML = val;
});
document.querySelectorAll('[data-i18n-ph]').forEach(el => {
const val = _nested(tr, el.getAttribute('data-i18n-ph'));
if (val !== undefined) el.placeholder = val;
});
}
function _getSafeMap(lang) {
if (I18N._safeMapCache[lang]) return I18N._safeMapCache[lang];
const tr = I18N.translations[lang];
if (!tr || !tr.text_map) return { safe: {}, regex: [] };
const safe = {};
const regex = [];
for (const [key, val] of Object.entries(tr.text_map)) {
if (key === val) continue;
if (val.includes(key)) {
try {
const escaped = key.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
const extraChars = val.slice(key.length);
const escapedExtra = extraChars.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
const rx = new RegExp(escaped + '(?!' + escapedExtra + ')', 'g');
regex.push({ key, val, rx });
} catch(e) {
console.warn(`i18n: skipped recursive entry "${key}" → "${val}"`);
}
} else {
safe[key] = val;
}
}
I18N._safeMapCache[lang] = { safe, regex };
return { safe, regex };
}
function applyTextMap(lang) {
lang = lang || I18N.current;
const tr = I18N.translations[lang];
if (!tr || !tr.text_map) return;
if (I18N._isApplying) return;
I18N._isApplying = true;
if (I18N._observer) {
I18N._observer.disconnect();
}
try {
const { safe, regex } = _getSafeMap(lang);
const walker = document.createTreeWalker(
document.body, NodeFilter.SHOW_TEXT, null, false
);
const nodes = [];
let node;
while (node = walker.nextNode()) {
if (node.textContent.trim().length > 1) nodes.push(node);
}
for (const tn of nodes) {
let text = tn.textContent;
let changed = false;
for (const [key, val] of Object.entries(safe)) {
if (text.includes(key)) {
text = text.split(key).join(val);
changed = true;
}
}
for (const entry of regex) {
if (entry.rx.test(text)) {
entry.rx.lastIndex = 0;
text = text.replace(entry.rx, entry.val);
changed = true;
}
}
if (changed) tn.textContent = text;
}
document.querySelectorAll('input[placeholder], textarea[placeholder]').forEach(el => {
let ph = el.placeholder;
for (const [key, val] of Object.entries(safe)) {
if (ph.includes(key)) ph = ph.split(key).join(val);
}
for (const entry of regex) {
if (entry.rx.test(ph)) { entry.rx.lastIndex = 0; ph = ph.replace(entry.rx, entry.val); }
}
el.placeholder = ph;
});
document.querySelectorAll('option').forEach(opt => {
let text = opt.textContent;
let changed = false;
for (const [key, val] of Object.entries(safe)) {
if (text.includes(key)) { text = text.split(key).join(val); changed = true; }
}
for (const entry of regex) {
if (entry.rx.test(text)) { entry.rx.lastIndex = 0; text = text.replace(entry.rx, entry.val); changed = true; }
}
if (changed) opt.textContent = text;
});
document.querySelectorAll('button').forEach(btn => {
if (btn.querySelector('input')) return;
let html = btn.innerHTML;
let changed = false;
for (const [key, val] of Object.entries(safe)) {
if (html.includes(key)) { html = html.split(key).join(val); changed = true; }
}
for (const entry of regex) {
if (entry.rx.test(html)) { entry.rx.lastIndex = 0; html = html.replace(entry.rx, entry.val); changed = true; }
}
if (changed) btn.innerHTML = html;
});
} finally {
I18N._isApplying = false;
if (I18N._observer) {
I18N._observer.observe(document.body, {
childList: true, subtree: true, characterData: true,
});
}
}
}
function _startObserver() {
if (I18N._observer) return;
I18N._observer = new MutationObserver((mutations) => {
if (I18N.isItalian) return;
if (I18N._isApplying) return;
let hasNewText = false;
for (const m of mutations) {
if (m.addedNodes.length > 0) { hasNewText = true; break; }
if (m.type === 'characterData') { hasNewText = true; break; }
}
if (!hasNewText) return;
clearTimeout(I18N._reapplyTimer);
I18N._reapplyTimer = setTimeout(() => {
applyTextMap(I18N.current);
}, 250);
});
I18N._observer.observe(document.body, {
childList: true,
subtree: true,
characterData: true,
});
}
function _nested(obj, path) {
return path.split('.').reduce((o, k) => (o && o[k] !== undefined) ? o[k] : undefined, obj);
}
function updateProLangIndicator() {
const _el = document.getElementById('pro-current-lang');
if (!_el) return;
const langNames = { it:'🇮🇹 Italiano', en:'🇬🇧 English', fr:'🇫🇷 Français', de:'🇩🇪 Deutsch', es:'🇪🇸 Español' };
_el.textContent = langNames[I18N.current] || langNames.it;
}
async function initI18n() {
let saved = 'it';
try { saved = localStorage.getItem('mesh_lang') || 'it'; } catch(e) {}
if (saved !== 'it') {
await setLanguage(saved);
} else {
document.querySelectorAll('.lang-flag').forEach(f => {
f.classList.toggle('active', f.dataset.lang === 'it');
});
updateProLangIndicator();
}
}