═══════════════════════════════════════════════════════════
  📡 MESHTASTIC ITALIA NETWORK APP v1.2.0
  © 2026 MANGOLINK — Tutti i diritti riservati
═══════════════════════════════════════════════════════════

NOVITÀ v1.2.0:
  ⭐ NUOVA SEZIONE MONITOR — Scanner della rete LoRa
     (opt-in, passivo, 18 feature: Live Scanner, Mappa Nodi,
      Stats Traffico, Crypto Agent, Soglie & Preset FW, ecc.)
  ⭐ Guida utente multilingua aggiornata (IT/EN/FR/DE/ES, 112 pag)
  ⭐ Crypto Hunter + PSK catalog Italia integrato
  ⭐ Admin Control Suite — 30 comandi AdminMessage Meshtastic

AVVIO RAPIDO:
  Windows  →  doppio-click su  app/start_app.bat
  macOS    →  apri terminale e:  python3 app/start_app.py
  Linux    →  apri terminale e:  python3 app/start_app.py

L'app si avvia su:  http://localhost:5555
Browser si apre automaticamente.

REQUISITI:
  • Python 3.9+ (consigliato 3.11)
  • Cavo USB DATI (non solo ricarica!)
  • Browser moderno (Chrome/Firefox/Edge)

LICENZA:
  Versione FREE: Guida, Links, Tecnica, Flash
  Versione PRO:  + Config, CLI, Assistente, Nodo, MONITOR
  Per attivare: vedi GUIDA_UTENTE_v1.2.0_MULTILANG.pdf  →  cap. 16

DOCUMENTAZIONE:
  • GUIDA_APP.html                       — guida installazione rapida
  • GUIDA_UTENTE_v1.2.0_MULTILANG.pdf    — guida completa 5 lingue

CONTATTI:
  Telegram: t.me/MeshtasticItalia (MANGOLINK_LATINA)
  Email:    info@meshtasticitalia.it
  Discord:  discord.gg/Rbhwf54nB3

═══════════════════════════════════════════════════════════
  Generato: 2026-05-09 13:15:11
═══════════════════════════════════════════════════════════
