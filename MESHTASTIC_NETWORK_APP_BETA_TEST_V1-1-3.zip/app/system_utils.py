# -*- coding: utf-8 -*-
"""
🔧 System Utils — Rilevamento OS, porte seriali, driver, info sistema.
Funziona su Windows, macOS e Linux senza dipendenze extra.
"""

import os
import sys
import platform
import subprocess
import webbrowser
import shutil

def detect_os():
    """Rileva il sistema operativo. Ritorna: 'windows', 'macos', 'linux'"""
    s = platform.system().lower()
    if s == "darwin":
        return "macos"
    return s  # 'windows' o 'linux'

def get_os_info():
    """Info dettagliate sul sistema operativo"""
    return {
        "os": detect_os(),
        "os_name": platform.system(),
        "os_version": platform.version(),
        "os_release": platform.release(),
        "architecture": platform.machine(),
        "processor": platform.processor(),
        "hostname": platform.node(),
        "python_version": platform.python_version(),
        "python_path": sys.executable,
    }

def list_serial_ports():
    """Lista tutte le porte seriali disponibili con info"""
    ports = []
    try:
        import serial.tools.list_ports
        for port in serial.tools.list_ports.comports():
            ports.append({
                "port": port.device,
                "description": port.description,
                "hwid": port.hwid,
                "manufacturer": port.manufacturer or "Sconosciuto",
                "product": port.product or "",
                "vid": port.vid,
                "pid": port.pid,
            })
    except ImportError:
        # pyserial non installato, prova metodo manuale
        current_os = detect_os()
        if current_os == "windows":
            # Prova con mode command
            try:
                result = subprocess.run(["mode"], capture_output=True, text=True, timeout=5)
                for line in result.stdout.split("\n"):
                    if "COM" in line:
                        port_name = line.strip().rstrip(":")
                        ports.append({"port": port_name, "description": "Porta seriale", "hwid": ""})
            except Exception:
                pass
        elif current_os == "linux":
            import glob
            for p in glob.glob("/dev/ttyUSB*") + glob.glob("/dev/ttyACM*"):
                ports.append({"port": p, "description": "Porta seriale USB", "hwid": ""})
        elif current_os == "macos":
            import glob
            for p in glob.glob("/dev/cu.usb*") + glob.glob("/dev/cu.wch*"):
                ports.append({"port": p, "description": "Porta seriale USB", "hwid": ""})
    except Exception:
        pass
    return ports

def check_driver_installed():
    """Verifica se i driver USB seriali sono installati"""
    current_os = detect_os()
    drivers = {"cp210x": False, "ch340": False}
    
    try:
        if current_os == "windows":
            result = subprocess.run(
                ["pnputil", "/enum-drivers"],
                capture_output=True, text=True, timeout=10
            )
            output = result.stdout.lower()
            drivers["cp210x"] = "silabser" in output or "cp210x" in output
            drivers["ch340"] = "ch341" in output or "ch340" in output
            
        elif current_os == "linux":
            result = subprocess.run(
                ["lsmod"], capture_output=True, text=True, timeout=5
            )
            output = result.stdout.lower()
            drivers["cp210x"] = "cp210x" in output
            drivers["ch340"] = "ch341" in output
            
        elif current_os == "macos":
            # Su macOS moderno (Big Sur+) kextstat è deprecato
            # Controlliamo se esistono le porte seriali tipiche
            import glob
            usb_ports = glob.glob("/dev/cu.usb*") + glob.glob("/dev/cu.wch*") + glob.glob("/dev/cu.SLAB*")
            drivers["cp210x"] = any("SLAB" in p or "usbserial" in p for p in usb_ports)
            drivers["ch340"] = any("wch" in p for p in usb_ports)
            # Prova anche system_profiler
            try:
                result = subprocess.run(
                    ["system_profiler", "SPUSBDataType"],
                    capture_output=True, text=True, timeout=10
                )
                output = result.stdout.lower()
                if "silicon labs" in output or "cp210" in output:
                    drivers["cp210x"] = True
                if "wch" in output or "ch34" in output:
                    drivers["ch340"] = True
            except Exception:
                pass
    except Exception:
        pass
    
    return drivers

def check_python_info():
    """Verifica versione Python e pip"""
    info = {
        "python_installed": True,
        "python_version": platform.python_version(),
        "python_path": sys.executable,
        "pip_installed": False,
        "pip_version": None,
        "meshtastic_cli": False,
        "meshtastic_version": None,
    }
    
    # Check pip
    try:
        result = subprocess.run(
            [sys.executable, "-m", "pip", "--version"],
            capture_output=True, text=True, timeout=10
        )
        if result.returncode == 0:
            info["pip_installed"] = True
            info["pip_version"] = result.stdout.split()[1] if result.stdout else None
    except Exception:
        pass
    
    # Check meshtastic CLI — cerca in tutti i percorsi possibili
    try:
        cli_path = shutil.which("meshtastic")
        if not cli_path:
            # Fallback Windows: Scripts
            scripts_dir = os.path.join(os.path.dirname(sys.executable), "Scripts")
            win_path = os.path.join(scripts_dir, "meshtastic.exe")
            if os.path.exists(win_path):
                cli_path = win_path
        if not cli_path:
            # Fallback Linux/Mac: ~/.local/bin
            local_path = os.path.expanduser("~/.local/bin/meshtastic")
            if os.path.exists(local_path):
                cli_path = local_path
        
        if cli_path:
            result = subprocess.run(
                [cli_path, "--version"],
                capture_output=True, text=True, timeout=10
            )
            if result.returncode == 0:
                info["meshtastic_cli"] = True
                info["meshtastic_version"] = result.stdout.strip() or result.stderr.strip()
                info["meshtastic_path"] = cli_path
    except Exception:
        pass
    
    return info

def open_url(url):
    """Apre un URL nel browser predefinito"""
    try:
        webbrowser.open(url)
        return True
    except Exception:
        return False

def check_port_available(port=5555):
    """Verifica se una porta TCP è disponibile"""
    import socket
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        try:
            s.bind(("127.0.0.1", port))
            return True
        except OSError:
            return False

def find_available_port(start=5555, max_tries=10):
    """Trova la prima porta disponibile partendo da start"""
    for i in range(max_tries):
        if check_port_available(start + i):
            return start + i
    return None
