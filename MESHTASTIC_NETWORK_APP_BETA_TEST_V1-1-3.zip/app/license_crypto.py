# -*- coding: utf-8 -*-
"""
🔐 Meshtastic Italia Network App v1.1.0 — Modulo Crittografia v2
Ed25519 Digital Signature + AES-256-GCM + PBKDF2-HMAC-SHA512
© 2026 🌐🥭MANGOLINK🥭🌐 — Tutti i diritti riservati
"""

import os, json, hashlib, hmac, base64, secrets, struct
from datetime import datetime

PBKDF2_ITERATIONS = 600_000
KEY_LENGTH = 32
NONCE_LENGTH = 12
SALT_LENGTH = 32
ED25519_SIG_LENGTH = 64
HEADER_MAGIC = b'MSHIT02\x00'
SEED_WORDS_COUNT = 24

# ── XOR Obfuscation ──
_OBF_KEY_SEED = b'MANGOLINK_MESH_IT_2026_XOR_v2'
_OBF_APP_SECRET = bytes([
    0x7a, 0x3f, 0x91, 0xc4, 0x55, 0xe8, 0x12, 0xab,
    0xf6, 0x03, 0xd7, 0x68, 0x2e, 0x9c, 0x41, 0xb5,
    0x83, 0x17, 0xfa, 0x6d, 0xc9, 0x34, 0x0e, 0xa2,
    0x5b, 0x8f, 0x70, 0x1c, 0xe3, 0x46, 0xbd, 0x29
])

def _xor_bytes(data, key):
    kl = len(key)
    return bytes(b ^ key[i % kl] for i, b in enumerate(data))

def _obfuscate(data, key_seed):
    return _xor_bytes(data, hashlib.sha256(key_seed).digest())

def _deobfuscate(data, key_seed):
    return _obfuscate(data, key_seed)

def _get_app_encryption_key():
    raw = _deobfuscate(_OBF_APP_SECRET, _OBF_KEY_SEED)
    return hashlib.pbkdf2_hmac('sha512', raw, _OBF_KEY_SEED, 100_000, dklen=KEY_LENGTH)

# ── Seed Phrase ──
SEED_WORDLIST = [
    "antenna","banda","canale","drone","energia","frequenza","gateway","hertz",
    "impulso","joule","kilowatt","lora","mesh","nodo","onda","potenza",
    "quarzo","radio","segnale","torre","ultra","volt","watt","xeno",
    "albero","bussola","cielo","delta","eco","fiamma","goccia","isola",
    "lago","monte","neve","oceano","ponte","quercia","roccia","stella",
    "terra","uragano","vento","zattera","aquila","balena","cervo","delfino",
    "elefante","falco","gatto","ippopotamo","koala","leone","medusa","narvalo",
    "orso","panda","quaglia","riccio","serpente","tigre","unicorno","volpe",
    "acciaio","bronzo","carbonio","diamante","ferro","grafene","iridio","jade",
    "krypton","litio","magnesio","nichel","oro","platino","rame","silicio",
    "titanio","uranio","vanadio","zinco","aurora","brezza","cascata","destino",
    "estate","fulmine","ghiaccio","inverno","lampo","mare","notte","pioggia",
    "quiete","rugiada","sole","tuono","ombra","alba","brina","cenere",
    "foschia","grandine","luce","muschio","nebbia","orizonte","polvere","sabbia",
    "tramonto","vapore","zaffiro","amico","bravo","coraggio","dignita","eroe",
    "forza","gioia","onore","liberta","merito","nobile","pace","rispetto",
    "salute","tenacia","unione","vigore","ancora","barca","corda","drizza",
    "equipaggio","faro","golfo","helm","ingresso","jolly","kappa","lamina",
    "motore","navigare","operare","pilota","quartiere","rotta","scafo","timone",
    "uniforme","veliero","waypoint","yacht","alpino","bivacco","cresta","dosso",
    "escursione","fortezza","guglia","halt","itinerario","jungla","kursaal","larice",
    "malgara","nucleo","osservare","picco","quota","rifugio","sentiero","trincea",
    "utensile","vedetta","wanderer","xerox","zona","zenit","apice","base",
    "codice","dato","errore","flag","gruppo","hash","indice","java",
    "kernel","log","modulo","network","output","pixel","query","registro",
    "sistema","token","upload","versione","widget","xml","yaml","zero",
]

def generate_seed_phrase():
    indices = [secrets.randbelow(len(SEED_WORDLIST)) for _ in range(SEED_WORDS_COUNT)]
    return [SEED_WORDLIST[i] for i in indices], indices

def seed_phrase_to_ed25519_seed(words):
    try:
        indices = [SEED_WORDLIST.index(w.lower().strip()) for w in words]
    except ValueError as e:
        raise ValueError(f"Parola non valida nella seed phrase: {e}")
    seed_bytes = b''.join(struct.pack('>H', i) for i in indices)
    salt = hashlib.sha256(b'MANGOLINK_SEED_SALT_v2_ED25519' + seed_bytes[:16]).digest()
    return hashlib.pbkdf2_hmac('sha512', seed_bytes, salt, PBKDF2_ITERATIONS, dklen=32)

def generate_ed25519_keypair(words=None):
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    from cryptography.hazmat.primitives.serialization import Encoding, PublicFormat, PrivateFormat, NoEncryption
    if words:
        seed = seed_phrase_to_ed25519_seed(words)
    else:
        words, _ = generate_seed_phrase()
        seed = seed_phrase_to_ed25519_seed(words)
    private_key = Ed25519PrivateKey.from_private_bytes(seed)
    public_key = private_key.public_key()
    priv_bytes = private_key.private_bytes(Encoding.Raw, PrivateFormat.Raw, NoEncryption())
    pub_bytes = public_key.public_bytes(Encoding.Raw, PublicFormat.Raw)
    return priv_bytes, pub_bytes, words

# ── Encrypt + Sign ──
def _derive_encryption_key(salt):
    app_key = _get_app_encryption_key()
    return hashlib.pbkdf2_hmac('sha512', app_key + b'license_v2_encryption', salt, PBKDF2_ITERATIONS, dklen=KEY_LENGTH)

def encrypt_and_sign_license(data_dict, ed25519_private_key_bytes):
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    plaintext = json.dumps(data_dict, ensure_ascii=False).encode('utf-8')
    salt = os.urandom(SALT_LENGTH)
    enc_key = _derive_encryption_key(salt)
    nonce = os.urandom(NONCE_LENGTH)
    aesgcm = AESGCM(enc_key)
    ciphertext = aesgcm.encrypt(nonce, plaintext, HEADER_MAGIC)
    signed_payload = HEADER_MAGIC + salt + nonce + ciphertext
    private_key = Ed25519PrivateKey.from_private_bytes(ed25519_private_key_bytes)
    signature = private_key.sign(signed_payload)
    file_data = HEADER_MAGIC + signature + salt + nonce + ciphertext
    app_key = _get_app_encryption_key()
    file_hmac = hmac.new(app_key, file_data, hashlib.sha256).digest()
    return file_data + file_hmac

def verify_and_decrypt_license(file_data, ed25519_public_key_bytes):
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
    try:
        min_size = 8 + 64 + 32 + 12 + 16 + 32
        if len(file_data) < min_size:
            return None
        file_hmac = file_data[-32:]
        file_body = file_data[:-32]
        app_key = _get_app_encryption_key()
        expected_hmac = hmac.new(app_key, file_body, hashlib.sha256).digest()
        if not hmac.compare_digest(file_hmac, expected_hmac):
            return None
        pos = 0
        header = file_body[pos:pos+8]; pos += 8
        if header != HEADER_MAGIC:
            return None
        signature = file_body[pos:pos+ED25519_SIG_LENGTH]; pos += ED25519_SIG_LENGTH
        salt = file_body[pos:pos+SALT_LENGTH]; pos += SALT_LENGTH
        nonce = file_body[pos:pos+NONCE_LENGTH]; pos += NONCE_LENGTH
        ciphertext = file_body[pos:]
        signed_payload = HEADER_MAGIC + salt + nonce + ciphertext
        public_key = Ed25519PublicKey.from_public_bytes(ed25519_public_key_bytes)
        try:
            public_key.verify(signature, signed_payload)
        except Exception:
            return None
        enc_key = _derive_encryption_key(salt)
        aesgcm = AESGCM(enc_key)
        plaintext = aesgcm.decrypt(nonce, ciphertext, HEADER_MAGIC)
        return json.loads(plaintext.decode('utf-8'))
    except Exception:
        return None

def decrypt_license_v1(file_data, master_key):
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    try:
        OLD_MAGIC = b'MSHIT01\x00'
        if len(file_data) < 100 or file_data[:8] != OLD_MAGIC:
            return None
        file_hmac = file_data[-32:]
        file_body = file_data[:-32]
        expected_hmac = hmac.new(master_key, file_body, hashlib.sha256).digest()
        if not hmac.compare_digest(file_hmac, expected_hmac):
            return None
        pos = 8
        salt = file_body[pos:pos+32]; pos += 32
        nonce = file_body[pos:pos+12]; pos += 12
        ciphertext = file_body[pos:]
        enc_key = hashlib.pbkdf2_hmac('sha512', master_key + b'license_encryption', salt, PBKDF2_ITERATIONS, dklen=KEY_LENGTH)
        aesgcm = AESGCM(enc_key)
        plaintext = aesgcm.decrypt(nonce, ciphertext, OLD_MAGIC)
        return json.loads(plaintext.decode('utf-8'))
    except Exception:
        return None

# ── Utility ──
def save_private_key(key_bytes, filepath):
    with open(filepath, 'w', encoding='utf-8') as f:
        f.write(f"# MANGOLINK Ed25519 Private Key — NON CONDIVIDERE MAI!\n")
        f.write(f"# Generata: {datetime.now().isoformat()}\n")
        f.write(base64.b64encode(key_bytes).decode('ascii') + "\n")

def save_public_key(key_bytes, filepath):
    with open(filepath, 'w', encoding='utf-8') as f:
        f.write(f"# MANGOLINK Ed25519 Public Key\n")
        f.write(f"# Generata: {datetime.now().isoformat()}\n")
        f.write(base64.b64encode(key_bytes).decode('ascii') + "\n")

def load_key_from_file(filepath):
    with open(filepath, 'r', encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith('#'):
                return base64.b64decode(line)
    return None

def key_checksum(key_bytes):
    return hashlib.sha256(key_bytes + b'CHECKSUM_v2').hexdigest()[:8].upper()

def obfuscate_public_key(pub_bytes):
    obfuscated = _obfuscate(pub_bytes, _OBF_KEY_SEED)
    return ', '.join(f'0x{b:02x}' for b in obfuscated)

def deobfuscate_public_key(obf_bytes):
    return _deobfuscate(obf_bytes, _OBF_KEY_SEED)

# ── Encrypted Cache ──
def encrypt_cache(data_dict, fingerprint_raw):
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    plaintext = json.dumps(data_dict, ensure_ascii=False).encode('utf-8')
    salt = hashlib.sha256(b'CACHE_SALT_v2_' + fingerprint_raw.encode()).digest()
    cache_key = hashlib.pbkdf2_hmac('sha512', fingerprint_raw.encode(), salt, 100_000, dklen=KEY_LENGTH)
    nonce = os.urandom(NONCE_LENGTH)
    aesgcm = AESGCM(cache_key)
    ciphertext = aesgcm.encrypt(nonce, plaintext, b'MESHCACHE')
    return salt + nonce + ciphertext

def decrypt_cache(raw_data, fingerprint_raw):
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    try:
        salt = raw_data[:32]
        nonce = raw_data[32:44]
        ciphertext = raw_data[44:]
        cache_key = hashlib.pbkdf2_hmac('sha512', fingerprint_raw.encode(), salt, 100_000, dklen=KEY_LENGTH)
        aesgcm = AESGCM(cache_key)
        plaintext = aesgcm.decrypt(nonce, ciphertext, b'MESHCACHE')
        return json.loads(plaintext.decode('utf-8'))
    except Exception:
        return None
