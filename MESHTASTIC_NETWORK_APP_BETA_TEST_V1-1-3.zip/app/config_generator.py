# -*- coding: utf-8 -*-
"""
⚙️ Config Generator — Genera comandi CLI, config YAML, QR code.
Cuore della configurazione automatica e manuale.
"""

import json
import re
import base64
from io import BytesIO
from app.network_params import NETWORK_CONFIG, CHANNELS, AUTOCONFIG_URL, DEVICE_ROLES

def _sanitize_cli_input(value, max_len=64):
    """Sanitizza input utente per comandi CLI — previene command injection."""
    if not isinstance(value, str):
        return str(value)[:max_len]
    # Rimuovi caratteri pericolosi per shell
    value = re.sub(r'[;&|`$(){}!<>\\\n\r\x00]', '', value)
    # Rimuovi sequenze di escape
    value = value.replace('"', '').replace("'", '')
    return value.strip()[:max_len]

def generate_channel_url(params):
    """
    Genera un URL Meshtastic (https://meshtastic.org/e/#...) dai canali personalizzati.
    Encoder protobuf nativo — nessuna dipendenza dal package meshtastic.
    Formato: ChannelSet { repeated ChannelSettings (field 1), LoRaConfig (field 2) }
    Ritorna: stringa URL o None se errore/nessun canale.
    """
    custom_channels = params.get("custom_channels", [])
    if not custom_channels:
        return None

    try:
        channel_set = b''

        # ── Canali (field 1 di ChannelSet, tipo embedded message) ──
        for ch_data in custom_channels:
            ch_bytes = b''
            name = _sanitize_cli_input(ch_data.get("name", ""), max_len=11)
            psk_b64 = ch_data.get("psk", "")

            # field 2: psk (bytes)
            psk = b'\x01'  # Default: public
            if psk_b64:
                try:
                    padded = psk_b64 + "=" * (4 - len(psk_b64) % 4) if len(psk_b64) % 4 else psk_b64
                    psk = base64.b64decode(padded)
                except Exception:
                    pass
            ch_bytes += _pb_bytes_field(2, psk)

            # field 3: name (string) — max 11 caratteri Meshtastic
            if name:
                ch_bytes += _pb_bytes_field(3, name.encode('utf-8'))

            # field 5: uplink_enabled (bool)
            if ch_data.get("uplink", True):
                ch_bytes += _pb_varint_field(5, 1)

            # field 6: downlink_enabled (bool)
            if ch_data.get("downlink", True):
                ch_bytes += _pb_varint_field(6, 1)

            channel_set += _pb_bytes_field(1, ch_bytes)

        # ── LoRa Config (field 2 di ChannelSet, tipo embedded message) ──
        # Enum values da meshtastic.proto (RegionCode, ModemPreset)
        region_map = {
            "UNSET": 0, "US": 1, "EU_433": 2, "EU_868": 3, "CN": 4,
            "JP": 5, "ANZ": 6, "KR": 7, "TW": 8, "RU": 9,
            "IN": 10, "NZ_865": 11, "TH": 12, "LORA_24": 13,
        }
        preset_map = {
            "LONG_FAST": 0, "LONG_SLOW": 1, "VERY_LONG_SLOW": 2,
            "MEDIUM_SLOW": 3, "MEDIUM_FAST": 4, "SHORT_SLOW": 5,
            "SHORT_FAST": 6, "LONG_MODERATE": 7,
        }

        region_val = region_map.get(params.get("region", "EU_868"), 3)
        preset_val = preset_map.get(params.get("modem_preset", "MEDIUM_FAST"), 4)
        hop_limit = max(1, min(7, int(params.get("hop_limit", 3))))
        tx_power = max(1, min(30, int(params.get("tx_power", 27))))

        lora = b''
        lora += _pb_varint_field(1, 1)           # use_preset = true
        lora += _pb_varint_field(2, preset_val)   # modem_preset
        lora += _pb_varint_field(7, region_val)   # region
        lora += _pb_varint_field(8, hop_limit)    # hop_limit
        lora += _pb_varint_field(9, 1)            # tx_enabled = true
        lora += _pb_varint_field(10, tx_power)    # tx_power

        channel_set += _pb_bytes_field(2, lora)

        # URL-safe base64 senza padding
        b64 = base64.urlsafe_b64encode(channel_set).decode().rstrip('=')
        return f"https://meshtastic.org/e/#{b64}"

    except Exception:
        return None


# ── Protobuf Encoder Minimo (wire format) ──────────────────────
# Supporta solo i tipi necessari: varint (int/bool/enum) e bytes/string

def _pb_varint(value):
    """Codifica un intero come protobuf varint."""
    if value == 0:
        return b'\x00'
    result = bytearray()
    while value > 0x7f:
        result.append((value & 0x7f) | 0x80)
        value >>= 7
    result.append(value & 0x7f)
    return bytes(result)

def _pb_varint_field(field_number, value):
    """Campo protobuf di tipo varint (wire type 0): int, bool, enum."""
    tag = _pb_varint((field_number << 3) | 0)
    return tag + _pb_varint(value)

def _pb_bytes_field(field_number, data):
    """Campo protobuf length-delimited (wire type 2): bytes, string, embedded message."""
    tag = _pb_varint((field_number << 3) | 2)
    return tag + _pb_varint(len(data)) + data


def generate_auto_config():
    """Ritorna i dati per la configurazione automatica 1-click"""
    return {
        "url": AUTOCONFIG_URL,
        "cli_command": f'meshtastic --ch-set-url "{AUTOCONFIG_URL}"',
        "description": "Configura tutti gli 8 canali del Meshtastic Italia Network in un click",
        "channels": CHANNELS,
        "region": NETWORK_CONFIG["region"],
        "preset": NETWORK_CONFIG["modem_preset"],
    }

def generate_cli_commands(params):
    """
    Genera una lista di comandi CLI Meshtastic basati sui parametri scelti.
    params: dict con le opzioni scelte dall'utente
    Ritorna: lista di dict {command, description, category}
    """
    commands = []
    
    # 1. Regione (obbligatorio — validata contro whitelist)
    VALID_REGIONS = ['EU_868', 'US', 'CN', 'JP', 'ANZ', 'KR', 'TW', 'RU', 'IN', 'NZ_865', 'TH', 'LORA_24', 'UA_868', 'MY_919', 'SG_923']
    region = params.get("region", "EU_868")
    if region not in VALID_REGIONS:
        region = "EU_868"
    commands.append({
        "command": f"meshtastic --set lora.region {region}",
        "description": f"Imposta la regione LoRa su {region}",
        "category": "radio"
    })
    
    # 2. Preset modem (validato contro whitelist)
    VALID_PRESETS = ['SHORT_FAST', 'SHORT_SLOW', 'MEDIUM_FAST', 'MEDIUM_SLOW', 'LONG_FAST', 'LONG_MODERATE', 'LONG_SLOW', 'VERY_LONG_SLOW']
    preset = params.get("modem_preset", "MEDIUM_FAST")
    if preset not in VALID_PRESETS:
        preset = "MEDIUM_FAST"
    commands.append({
        "command": f"meshtastic --set lora.modem_preset {preset}",
        "description": f"Imposta il preset radio su {preset}",
        "category": "radio"
    })
    
    # 3. Nome nodo
    long_name = _sanitize_cli_input(params.get("long_name", ""), max_len=35)
    if long_name:
        commands.append({
            "command": f'meshtastic --set-owner "{long_name}"',
            "description": f"Imposta il nome lungo del nodo: {long_name}",
            "category": "identity"
        })
    
    short_name = _sanitize_cli_input(params.get("short_name", ""), max_len=4)
    if short_name:
        commands.append({
            "command": f'meshtastic --set-owner-short "{short_name}"',
            "description": f"Imposta il nome corto (4 char): {short_name}",
            "category": "identity"
        })
    
    # 4. Ruolo
    role = params.get("role", "CLIENT")
    if role in DEVICE_ROLES:
        commands.append({
            "command": DEVICE_ROLES[role]["command"],
            "description": f"Imposta il ruolo del dispositivo: {DEVICE_ROLES[role]['name']}",
            "category": "device"
        })
    
    # 5. Canali — metodo URL se automatico, singoli se personalizzati
    use_autoconfig = params.get("use_autoconfig", True)
    custom_channels = params.get("custom_channels", [])
    
    if use_autoconfig:
        commands.append({
            "command": f'meshtastic --ch-set-url "{AUTOCONFIG_URL}"',
            "description": "Configura tutti gli 8 canali del network Italia in automatico",
            "category": "channels"
        })
    elif custom_channels:
        # Genera comandi per ogni canale personalizzato
        for ch in custom_channels:
            idx = ch.get("index", 0)
            name = _sanitize_cli_input(ch.get("name", ""), max_len=11)
            psk = _sanitize_cli_input(ch.get("psk", ""), max_len=64)
            uplink = ch.get("uplink", True)
            downlink = ch.get("downlink", True)
            
            if name:
                commands.append({
                    "command": f'meshtastic --ch-set name "{name}" --ch-index {idx}',
                    "description": f"Imposta nome canale {idx}: {name}",
                    "category": "channels"
                })
            if psk:
                commands.append({
                    "command": f'meshtastic --ch-set psk "base64:{psk}" --ch-index {idx}',
                    "description": f"Imposta PSK canale {idx}",
                    "category": "channels"
                })
            if uplink:
                commands.append({
                    "command": f'meshtastic --ch-set uplink_enabled true --ch-index {idx}',
                    "description": f"Abilita uplink MQTT canale {idx}",
                    "category": "channels"
                })
            if downlink:
                commands.append({
                    "command": f'meshtastic --ch-set downlink_enabled true --ch-index {idx}',
                    "description": f"Abilita downlink MQTT canale {idx}",
                    "category": "channels"
                })
    
    # 6. MQTT
    mqtt_enabled = params.get("mqtt_enabled", True)
    if mqtt_enabled:
        commands.append({
            "command": "meshtastic --set mqtt.enabled true",
            "description": "Abilita il bridge MQTT verso internet",
            "category": "mqtt"
        })
        commands.append({
            "command": f'meshtastic --set mqtt.address "{NETWORK_CONFIG["mqtt_server"]}"',
            "description": f"Imposta il server MQTT: {NETWORK_CONFIG['mqtt_server']}",
            "category": "mqtt"
        })
        commands.append({
            "command": f'meshtastic --set mqtt.root "{NETWORK_CONFIG["mqtt_root_topic"]}"',
            "description": f"Imposta il root topic: {NETWORK_CONFIG['mqtt_root_topic']}",
            "category": "mqtt"
        })
        commands.append({
            "command": "meshtastic --set mqtt.encryption_enabled true",
            "description": "Abilita crittografia MQTT",
            "category": "mqtt"
        })
    
    # 7. Hop limit
    hop_limit = params.get("hop_limit")
    # 7. Hop limit (validato 1-7)
    hop_limit = params.get("hop_limit")
    try: hop_limit = int(hop_limit)
    except (TypeError, ValueError): hop_limit = None
    if hop_limit and 1 <= hop_limit <= 7 and hop_limit != 3:
        commands.append({
            "command": f"meshtastic --set lora.hop_limit {hop_limit}",
            "description": f"Imposta il limite di salti (hop) a {hop_limit}",
            "category": "radio"
        })
    
    # 8. TX Power (validato 0-30)
    tx_power = params.get("tx_power")
    try: tx_power = int(tx_power)
    except (TypeError, ValueError): tx_power = None
    if tx_power is not None and 0 <= tx_power <= 30:
        commands.append({
            "command": f"meshtastic --set lora.tx_power {tx_power}",
            "description": f"Imposta la potenza di trasmissione a {tx_power} dBm",
            "category": "radio"
        })
    
    # 8b. Rebroadcast mode
    rebroadcast = params.get("rebroadcast_mode")
    if rebroadcast and rebroadcast != "ALL":
        commands.append({
            "command": f"meshtastic --set device.rebroadcast_mode {rebroadcast}",
            "description": f"Imposta modalità ritrasmissione: {rebroadcast}",
            "category": "device"
        })
    
    # 8c. GPS
    gps_enabled = params.get("gps_enabled")
    if gps_enabled == "false":
        commands.append({
            "command": "meshtastic --set position.gps_enabled false",
            "description": "Disabilita GPS",
            "category": "position"
        })
    elif gps_enabled == "not_present":
        commands.append({
            "command": "meshtastic --set position.gps_mode NOT_PRESENT",
            "description": "GPS non presente sul dispositivo",
            "category": "position"
        })
    
    # 8d. Smart Position
    smart_pos = params.get("smart_position")
    if smart_pos == "false":
        commands.append({
            "command": "meshtastic --set position.position_broadcast_smart_enabled false",
            "description": "Disabilita Smart Position",
            "category": "position"
        })
    
    # 8e. Position Broadcast
    pos_bcast = params.get("position_broadcast_secs")
    if pos_bcast and pos_bcast != "900":
        commands.append({
            "command": f"meshtastic --set position.position_broadcast_secs {pos_bcast}",
            "description": f"Intervallo broadcast posizione: {pos_bcast}s",
            "category": "position"
        })
    
    # 8f. GPS Update Interval
    gps_int = params.get("gps_update_interval")
    if gps_int and gps_int != "120":
        commands.append({
            "command": f"meshtastic --set position.gps_update_interval {gps_int}",
            "description": f"Intervallo aggiornamento GPS: {gps_int}s",
            "category": "position"
        })
    
    # 8g. MQTT Encryption
    mqtt_enc = params.get("mqtt_encryption")
    if mqtt_enc is False:
        commands.append({
            "command": "meshtastic --set mqtt.encryption_enabled false",
            "description": "Disabilita crittografia MQTT",
            "category": "mqtt"
        })
    
    # 8h. Bluetooth
    ble = params.get("bluetooth_enabled")
    if ble == "false":
        commands.append({
            "command": "meshtastic --set bluetooth.enabled false",
            "description": "Disabilita Bluetooth BLE",
            "category": "connectivity"
        })
    
    # 8i. WiFi
    wifi = params.get("wifi_enabled")
    if wifi == "true":
        commands.append({
            "command": "meshtastic --set network.wifi_enabled true",
            "description": "Abilita WiFi (solo ESP32)",
            "category": "connectivity"
        })
    
    # 8j. Screen
    screen = params.get("screen_on_secs")
    if screen and screen != "60":
        if screen == "off":
            commands.append({
                "command": "meshtastic --set display.screen_on_secs 1",
                "description": "Schermo spento (1s auto-off)",
                "category": "display"
            })
        else:
            commands.append({
                "command": f"meshtastic --set display.screen_on_secs {screen}",
                "description": f"Display auto-off dopo {screen}s" if screen != "0" else "Display sempre acceso",
                "category": "display"
            })
    
    # 8k. Telemetria device
    telem_dev = params.get("telemetry_device_interval")
    if telem_dev and telem_dev != "900":
        commands.append({
            "command": f"meshtastic --set telemetry.device_update_interval {telem_dev}",
            "description": f"Telemetria dispositivo ogni {telem_dev}s" if telem_dev != "0" else "Telemetria dispositivo disabilitata",
            "category": "telemetry"
        })
    
    # 8l. Telemetria ambientale
    telem_env = params.get("telemetry_environment")
    if telem_env == "true":
        commands.append({
            "command": "meshtastic --set telemetry.environment_measurement_enabled true",
            "description": "Abilita sensori ambientali (BME280/680/SHT)",
            "category": "telemetry"
        })
    
    # 8m. Power saving
    power_save = params.get("power_saving")
    if power_save == "true":
        commands.append({
            "command": "meshtastic --set power.is_power_saving true",
            "description": "Abilita risparmio energetico",
            "category": "power"
        })
    
    # 8n. LED
    led_off = params.get("led_disabled")
    if led_off == "true":
        commands.append({
            "command": "meshtastic --set device.led_heartbeat_disabled true",
            "description": "Disabilita LED heartbeat",
            "category": "device"
        })
    
    # 8o. Moduli
    if params.get("neighbor_info"):
        commands.append({
            "command": "meshtastic --set neighbor_info.enabled true",
            "description": "Abilita Neighbor Info",
            "category": "modules"
        })
    if params.get("store_forward"):
        commands.append({
            "command": "meshtastic --set store_forward.enabled true",
            "description": "Abilita Store & Forward",
            "category": "modules"
        })
    if params.get("range_test"):
        commands.append({
            "command": "meshtastic --set range_test.enabled true",
            "description": "Abilita Range Test (disabilita dopo l'uso!)",
            "category": "modules"
        })
    
    # 9. Posizione fissa
    lat = params.get("latitude")
    lon = params.get("longitude")
    alt = params.get("altitude")
    if lat and lon:
        cmd = f"meshtastic --setlat {lat} --setlon {lon}"
        if alt:
            cmd += f" --setalt {alt}"
        commands.append({
            "command": cmd,
            "description": f"Imposta posizione fissa: {lat}, {lon}" + (f", {alt}m" if alt else ""),
            "category": "position"
        })
    
    # 10. Verifica finale
    commands.append({
        "command": "meshtastic --info",
        "description": "Verifica la configurazione applicata",
        "category": "verify"
    })
    
    return commands

def generate_qr_code(url=None):
    """Genera un QR code PNG come stringa base64"""
    if url is None:
        url = AUTOCONFIG_URL
    try:
        import qrcode
        from PIL import Image
        qr = qrcode.QRCode(version=1, box_size=8, border=2)
        qr.add_data(url)
        qr.make(fit=True)
        img = qr.make_image(fill_color="#00ff88", back_color="#0a0e14")
        buffer = BytesIO()
        img.save(buffer, format="PNG")
        buffer.seek(0)
        return base64.b64encode(buffer.getvalue()).decode("utf-8")
    except Exception:
        # Qualsiasi errore (ImportError, PIL mancante, ecc.) → ritorna None
        return None

def validate_params(params):
    """Valida i parametri di configurazione e ritorna eventuali errori"""
    errors = []
    warnings = []
    
    # Regione
    region = params.get("region", "EU_868")
    if region != "EU_868":
        errors.append(f"⚠️ Regione {region} non valida per l'Italia! Usa EU_868.")
    
    # Preset
    preset = params.get("modem_preset", "MEDIUM_FAST")
    if preset != "MEDIUM_FAST":
        warnings.append(f"Il preset {preset} non è lo standard Italia (MEDIUM_FAST). Potresti non comunicare con altri nodi del network.")
    
    # Ruolo
    role = params.get("role", "CLIENT")
    if role == "ROUTER_CLIENT":
        errors.append("ROUTER_CLIENT è DEPRECATO dal firmware 2.3.15. Usa CLIENT_BASE o ROUTER_LATE.")
    if role == "ROUTER":
        warnings.append("Il ruolo ROUTER va usato SOLO su posizioni eccezionali (cima montagna, torre). Un Router mal posizionato danneggia l'intera rete.")
    
    # TX Power
    tx_power = params.get("tx_power")
    if tx_power and int(tx_power) > 27:
        errors.append(f"Potenza TX {tx_power} dBm supera il limite legale EU di 27 dBm (500 mW ERP)!")
    
    # Nome
    long_name = params.get("long_name", "")
    if long_name and len(long_name) > 35:
        warnings.append(f"Nome lungo troppo lungo ({len(long_name)} char). Max consigliato: 35.")
    
    short_name = params.get("short_name", "")
    if short_name and len(short_name) > 4:
        errors.append(f"Nome corto troppo lungo ({len(short_name)} char). Max: 4.")
    
    return {"errors": errors, "warnings": warnings, "valid": len(errors) == 0}

def get_script_completo(params):
    """Genera lo script completo di configurazione come testo unico"""
    commands = generate_cli_commands(params)
    lines = ["# 🇮🇹 Configurazione Meshtastic Italia Network", "# Esegui questi comandi in sequenza con il nodo collegato via USB", ""]
    for cmd in commands:
        lines.append(f"# {cmd['description']}")
        lines.append(cmd["command"])
        lines.append("")
    return "\n".join(lines)
