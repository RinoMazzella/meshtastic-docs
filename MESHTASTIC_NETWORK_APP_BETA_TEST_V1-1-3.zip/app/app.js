/* ═══════════════════════════════════════════════════════════
   📡 MESHTASTIC ITALIA NETWORK APP v1.1.0 — JavaScript v5
   Sistema Licenze + USB + Terminali + QR + Assistente + MOD Firmware
   © 2026 🌐🥭MANGOLINK🥭🌐 — Tutti i diritti riservati
   ═══════════════════════════════════════════════════════════ */

const APP = { currentSection:'guida', systemInfo:null, configMode:null, paramsInfo:{}, selectedPort:null, license:null };

// ══════════════════════════════════════════════════════════════
// 🔐 LICENSE MANAGEMENT
// ══════════════════════════════════════════════════════════════

async function checkLicense(){
    try{
        const d=await apiFetch('license/status');
        if(!d){
            // Retry once after 2s if server is slow at startup
            setTimeout(async()=>{
                const _retry=await apiFetch('license/status');
                if(_retry){APP.license=_retry;applyLicenseUI(_retry);}
            },2000);
            return;
        }
        APP.license=d;
        applyLicenseUI(d);
    }catch(e){console.log('License check failed',e);}
}

// ══════════════════════════════════════════════════════════════
// 🔐 REVOCATION POLLING — Check periodico ogni 30 minuti
// ══════════════════════════════════════════════════════════════

let _revocationInterval = null;
const _REVOKE_POLL_MS = 30 * 60 * 1000; // 30 minuti

function startRevocationPolling(){
    if(_revocationInterval) clearInterval(_revocationInterval);
    _revocationInterval = setInterval(async()=>{
        try{
            const _lic = await apiFetch('license/status');
            if(!_lic) return;
            // Se lo status è cambiato a revoked o invalid durante la sessione
            if(_lic.status==='revoked'){
                APP.license = _lic;
                applyLicenseUI(_lic);
                showRevokedOverlay();
            }else if(_lic.status==='invalid' && APP.license && APP.license.status!=='free'){
                APP.license = _lic;
                applyLicenseUI(_lic);
                showToast(t('⚠️ Licenza non valida — verifica la connessione internet'));
            }else{
                // Aggiorna silenziosamente lo stato cache/grace
                APP.license = _lic;
            }
        }catch(_e){/* Polling silenzioso — non mostrare errori */}
    }, _REVOKE_POLL_MS);
}

function showRevokedOverlay(){
    // Se l'overlay esiste già, non crearlo di nuovo
    if(document.getElementById('revoked-overlay')) return;
    const _ov = document.createElement('div');
    _ov.id = 'revoked-overlay';
    _ov.style.cssText = 'position:fixed;top:0;left:0;width:100vw;height:100vh;background:rgba(0,0,0,0.92);z-index:99999;display:flex;align-items:center;justify-content:center;flex-direction:column;';
    _ov.innerHTML = '<div style="text-align:center;max-width:500px;padding:2rem;">'
        +'<div style="font-size:4rem;margin-bottom:1rem;">🚫</div>'
        +'<h2 style="color:var(--danger,#ff4444);font-size:1.5rem;margin-bottom:1rem;">'+t('Licenza Revocata')+'</h2>'
        +'<p style="color:#ccc;font-size:1rem;margin-bottom:1.5rem;">'+t('La tua licenza è stata revocata dall\'amministratore.')+'<br>'
        +t('Contatta la community per assistenza.')+'</p>'
        +'<p style="color:var(--text-muted,#888);font-size:0.8rem;">'+t('L\'app verrà riavviata al prossimo avvio con licenza FREE.')+'</p>'
        +'</div>';
    document.body.appendChild(_ov);
    // Disabilita TUTTA la navigazione
    document.querySelectorAll('.nav-tab').forEach(_tab=>{
        _tab.classList.add('nav-locked');
        _tab.style.pointerEvents='none';
    });
}

async function resetLicenseCache(){
    if(!confirm(t('Vuoi resettare la cache licenza?')+'\n\n'+t('Questo cancella i file di cache anti-tampering e revoca.')+'\n'+t('La licenza NON viene cancellata.')+'\n\n'+t('Dopo il reset, clicca "Verifica Licenza".'))){return;}
    showToast(t('🗑️ Reset cache in corso...'));
    const d=await apiFetch('license/reset-cache',{method:'POST',body:'{}'});
    if(!d){showToast(t('❌ Errore connessione al server'));return;}
    const _vr=document.getElementById('verify-result');
    if(_vr){
        _vr.style.display='block';
        _vr.style.background='rgba(0,255,136,0.08)';
        _vr.style.border='1px solid var(--accent)';
        _vr.style.color='var(--accent)';
        let _detail='✅ '+t('Cache resettata')+'\n';
        if(d.results){
            for(const _r of d.results){
                _detail+=(_r.deleted?'  ✅ ':'  ⬜ ')+_r.file+(_r.reason?' ('+t(_r.reason)+')':'')+'\n';
            }
        }
        _detail+='\n'+t('Clicca "🔄 Verifica Licenza" per riprovare.');
        _vr.innerHTML='<pre style="margin:0;font-family:var(--font-display);font-size:0.75rem;text-align:left;">'+_detail+'</pre>';
    }
    showToast(t('Cache resettata')+'. '+t('Clicca "🔄 Verifica Licenza" per riprovare.'));
}

function applyLicenseUI(lic){
    if(!lic)return;
    const badge=document.getElementById('license-badge');
    const detail=document.getElementById('license-detail');
    
    // ── Badge + Detail text ──
    if(badge){
        if(lic.status==='pro_mod'){
            badge.className='license-badge pro';
            badge.innerHTML=t('🔧 PRO+MOD');
        }else if(lic.status==='pro'){
            badge.className='license-badge pro';
            badge.innerHTML=t('⭐ PRO ATTIVATA');
        }else if(lic.status==='base'){
            badge.className='license-badge base';
            badge.innerHTML=t('🟢 BASE');
        }else if(lic.status==='expired'){
            badge.className='license-badge expired';
            badge.innerHTML=t('⚠️ SCADUTA');
        }else if(lic.status==='revoked'){
            badge.className='license-badge revoked';
            badge.innerHTML=t('🚫 REVOCATA');
        }else{
            badge.className='license-badge free';
            badge.innerHTML=t('🔒 FREE');
        }
    }
    if(detail){
        if(lic.status==='pro'||lic.status==='base'||lic.status==='pro_mod'){
            if(lic.days_left===-1){
                detail.innerHTML='<span style="color:var(--accent);">'+t('♾️ Illimitata')+'</span>';
            }else if(lic.days_left>30){
                detail.innerHTML='<span style="color:var(--accent);">📅 '+lic.days_left+' '+t('giorni')+'</span>';
            }else if(lic.days_left>7){
                detail.innerHTML='<span style="color:var(--warning);">📅 '+lic.days_left+' '+t('giorni')+'</span>';
            }else if(lic.days_left>0){
                detail.innerHTML='<span style="color:var(--danger);">⚠️ '+lic.days_left+' '+t('giorni')+'!</span>';
            }else{
                detail.innerHTML='<span style="color:var(--danger);">'+t('⚠️ Scade oggi!')+'</span>';
            }
        }else if(lic.status==='expired'){
            detail.innerHTML='<span style="color:var(--danger);">'+t('Rinnova la licenza')+'</span>';
        }else if(lic.status==='revoked'){
            detail.innerHTML='<span style="color:var(--danger);">'+t('Contatta la community')+'</span>';
        }else{
            detail.textContent='';
        }
    }
    
    // ── Offline counter bar ──
    const offBar=document.getElementById('offline-bar');
    if(offBar){
        const _grace=lic.grace_days_left;
        const _graceTotal=10;
        const _showOffline=(!lic.online_verified && lic.status!=='free' && _grace!==undefined && _grace<_graceTotal);
        const _hasWarning=lic.offline_warning;
        if(_hasWarning||_showOffline){
            offBar.style.display='block';
            const _remaining=_grace!==undefined?_grace:0;
            const _offText=document.getElementById('offline-text');
            if(_offText) _offText.textContent=t('⚠️ Offline — verifica licenza tra')+' '+_remaining+' '+t('giorni')+'. '+t('Connetti a internet.');
            // Grace period progress bar
            const _graceBar=document.getElementById('grace-bar');
            const _graceFill=document.getElementById('grace-fill');
            if(_graceBar&&_graceFill&&_remaining<_graceTotal){
                _graceBar.style.display='block';
                const _pct=Math.round((_remaining/_graceTotal)*100);
                _graceFill.style.width=_pct+'%';
                _graceFill.style.background=_pct>50?'#000':(_pct>20?'#663300':'#cc0000');
            }
        }else{offBar.style.display='none';}
    }
    
    // ── Lock nav tabs ──
    const secs=lic.sections||{};
    document.querySelectorAll('.nav-tab').forEach(tab=>{
        const s=tab.dataset.section;
        let ok=true;
        if(s==='cli'||s==='nodo'||s==='dev') ok=secs.cli||false;
        if(s==='config') ok=secs.config_auto||false;
        tab.classList.toggle('nav-locked',!ok);
        tab.title=ok?'':t('🔒 Richiede licenza');
    });
    
    // ── Activation panel ──
    const ap=document.getElementById('activation-panel');
    if(ap) ap.style.display=['free','invalid','expired','revoked'].includes(lic.status)?'block':'none';
    
    // ── Fingerprint ──
    const fp=document.getElementById('fp-display');
    if(fp&&lic.fingerprint) fp.textContent=lic.fingerprint;
    
    // ── Config PRO lock ──
    const pl=document.getElementById('pro-lock-overlay');
    if(pl) pl.style.display=(lic.status==='pro'||lic.status==='pro_mod')?'none':'flex';
    
    // ── Config MOD lock ──
    const ml=document.getElementById('mod-lock-overlay');
    if(ml) ml.style.display=lic.status==='pro_mod'?'none':'flex';
    const modToggle=document.getElementById('toggle-mod');
    if(modToggle&&lic.status!=='pro_mod') modToggle.disabled=true;
}

function navigateWithLicense(id){
    if(!APP.license)return navigateTo(id);
    const s=APP.license.sections||{};
    let ok=true;
    if(id==='cli'||id==='nodo'||id==='dev') ok=s.cli||false;
    if(id==='config') ok=s.config_auto||false;
    if(!ok){showToast(t('🔒 Richiede licenza BASE o PRO'));return;}
    navigateTo(id);
}

async function reloadLicense(){
    showToast(t('🔄 Verifica licenza...'));
    const _vr=document.getElementById('verify-result');
    if(_vr){_vr.style.display='block';_vr.style.background='var(--bg-input)';_vr.style.border='1px solid var(--border)';_vr.style.color='var(--text-muted)';_vr.textContent=t('🔄 Verifica licenza...');}
    const d=await apiFetch('license/reload',{method:'POST',body:'{}'});
    if(!d){
        showToast(t('❌ Errore connessione al server'));
        if(_vr){_vr.style.border='1px solid var(--danger)';_vr.style.color='var(--danger)';_vr.textContent=t('❌ Errore connessione al server');}
        return;
    }
    APP.license=d;
    applyLicenseUI(d);
    // Build translated message from status
    const _lvlLabels={'BASE':t('🟢 Licenza BASE attivata'),'PRO':t('⭐ Licenza PRO attivata'),'PRO_MOD':t('🔧 Licenza PRO+MOD attivata')};
    let _msg='';
    let _isOk=false;
    if(d.status==='pro'||d.status==='base'||d.status==='pro_mod'){
        _msg=_lvlLabels[d.level]||_lvlLabels['BASE'];
        if(d.security_version==='v2-ed25519') _msg+=' '+t('— Firma digitale verificata ✓');
        _isOk=true;
    }else if(d.status==='free'){
        _msg=t('Nessuna licenza trovata. Modalità FREE.');
    }else if(d.status==='expired'){
        _msg=t('⚠️ SCADUTA')+' — '+t('Rinnova la licenza');
    }else if(d.status==='revoked'){
        _msg=t('🚫 REVOCATA')+' — '+t('Contatta la community');
    }else if(d.status==='tampered'){
        _msg=t("⚠️ Integrità del codice compromessa. Reinstalla l'app.");
    }else if(d.status==='invalid'){
        _msg=t(d.message||'Firma digitale non valida. File licenza corrotto o contraffatto.');
    }else{
        _msg=t(d.message||'Verificato');
    }
    showToast(_msg);
    // Visual feedback in panel
    if(_vr){
        if(_isOk){
            _vr.style.background='rgba(0,255,136,0.08)';_vr.style.border='1px solid var(--accent)';_vr.style.color='var(--accent)';
            _vr.innerHTML='✅ '+_msg;
        }else{
            _vr.style.background='rgba(255,68,68,0.08)';_vr.style.border='1px solid var(--danger)';_vr.style.color='var(--danger)';
            _vr.innerHTML='❌ '+_msg+'<br><span style="font-size:0.72rem;color:var(--text-muted);">'+t('Usa "🔧 Diagnostica Licenza" per dettagli')+'</span>';
        }
    }
}

async function openAppFolder(){
    await apiFetch('license/open-folder',{method:'POST',body:'{}'});
    showToast(t('📂 Cartella aperta'));
}

async function runDiagnostics(){
    const _out=document.getElementById('diag-output');
    const _btn=document.getElementById('diag-btn');
    if(!_out||!_btn)return;
    _btn.disabled=true;
    _btn.textContent=t('⏳ Diagnostica in corso...');
    _out.style.display='block';
    _out.innerHTML='<span style="color:var(--accent);">'+t('🔍 Avvio diagnostica licenza...')+'</span>\n';

    try{
        const d=await apiFetch('license/diagnose');
        if(!d||!d.steps){
            _out.innerHTML+='<span style="color:var(--danger);">'+t('❌ Errore: nessuna risposta dal server')+'</span>';
            return;
        }
        _out.innerHTML='';

        // Header
        _out.innerHTML+='<span style="color:var(--accent);font-weight:700;">'+t('🔐 DIAGNOSTICA LICENZA')+'</span>\n';
        _out.innerHTML+='<span style="color:var(--text-muted);">'+t('Fingerprint')+': <span style="color:var(--accent);">'+d.fingerprint+'</span></span>\n';
        _out.innerHTML+='<span style="color:var(--border);">────────────────────────────────────</span>\n';

        // Steps
        for(const _step of d.steps){
            const icon=_step.ok?'<span style="color:var(--accent);">✅</span>':'<span style="color:var(--danger);">❌</span>';
            const labelColor=_step.ok?'var(--text-primary)':'var(--danger)';
            _out.innerHTML+=icon+' <span style="color:'+labelColor+';">'+t(_step.label)+'</span>\n';
            _out.innerHTML+='   <span style="color:var(--text-muted);font-size:0.72rem;">→ '+t(_step.detail)+'</span>\n';
        }

        // Summary
        _out.innerHTML+='<span style="color:var(--border);">────────────────────────────────────</span>\n';
        const allOk=d.steps.every(function(_s){return _s.ok;});
        if(allOk){
            const lvl=d.level||'BASE';
            const lvlLabels={'BASE':'🟢 BASE','PRO':'⭐ PRO','PRO_MOD':'🔧 PRO+MOD'};
            _out.innerHTML+='<span style="color:var(--accent);font-weight:700;">✅ '+t('Licenza valida')+' — '+(lvlLabels[lvl]||lvl)+'</span>\n';
            if(d.expires&&d.expires!=='unlimited'){
                _out.innerHTML+='<span style="color:var(--text-muted);">📅 '+t('Scadenza')+': '+d.expires.split('T')[0]+' ('+d.days_left+' '+t('giorni')+')</span>\n';
            }else if(d.expires==='unlimited'){
                _out.innerHTML+='<span style="color:var(--text-muted);">♾️ '+t('Licenza illimitata')+'</span>\n';
            }
            if(d.user){
                _out.innerHTML+='<span style="color:var(--text-muted);">👤 '+d.user+'</span>\n';
            }
            _out.innerHTML+='<span style="color:var(--text-muted);">🔐 '+d.crypto_version+'</span>\n';
        }else{
            const failedSteps=d.steps.filter(function(_s){return !_s.ok;});
            _out.innerHTML+='<span style="color:var(--danger);font-weight:700;">❌ '+t('Attivazione fallita')+'</span>\n';
            _out.innerHTML+='<span style="color:var(--warning);">'+t('Primo errore')+': '+t(failedSteps[0].label)+'</span>\n';
            _out.innerHTML+='<span style="color:var(--text-muted);">💡 '+t(failedSteps[0].detail)+'</span>\n';
        }

        // Dopo diagnostica, aggiorna anche la UI licenza
        if(allOk){
            const ld=await apiFetch('license/reload',{method:'POST',body:'{}'});
            if(ld){APP.license=ld;applyLicenseUI(ld);}
        }
    }catch(e){
        _out.innerHTML+='<span style="color:var(--danger);">'+t('❌ Errore connessione al server')+': '+e.message+'</span>';
    }finally{
        _btn.disabled=false;
        _btn.textContent=t('🔧 Diagnostica Licenza');
    }
}

// ══════════════════════════════════════════════════════════════
// 🔌 USB PORT MANAGEMENT — Globale per tutta l'app
// ══════════════════════════════════════════════════════════════

function toggleUsbPanel(){
    const panel=document.getElementById('usb-panel');
    if(!panel)return;
    if(panel.style.display==='none'){
        panel.style.display='block';
        scanUsbPorts();
        showUsbOsHint();
        // Chiudi cliccando fuori
        setTimeout(()=>document.addEventListener('click',_closeUsbPanelOutside),100);
    }else{
        panel.style.display='none';
        document.removeEventListener('click',_closeUsbPanelOutside);
    }
}
function _closeUsbPanelOutside(e){
    const panel=document.getElementById('usb-panel');
    const sel=document.getElementById('usb-selector');
    if(panel&&sel&&!sel.contains(e.target)){
        panel.style.display='none';
        document.removeEventListener('click',_closeUsbPanelOutside);
    }
}

function showUsbOsHint(){
    const el=document.getElementById('usb-os-hint');
    if(!el)return;
    const ua=navigator.userAgent.toLowerCase();
    if(ua.includes('win')){
        el.innerHTML=t('🪟 <b>Windows</b>: le porte appaiono come <b>COM3</b>, <b>COM4</b>...<br>Se non vedi porte → installa driver <b>CP210x</b> o <b>CH340</b>');
    }else if(ua.includes('mac')){
        el.innerHTML=t('🍎 <b>macOS</b>: le porte appaiono come <b>/dev/cu.usbserial-XXX</b><br>Se non vedi porte → installa driver da Silicon Labs + Riavvia');
    }else{
        el.innerHTML=t('🐧 <b>Linux</b>: le porte appaiono come <b>/dev/ttyUSB0</b> o <b>/dev/ttyACM0</b><br>Se non vedi porte →') + ' <code>sudo usermod -a -G dialout $USER</code> ' + t('e rilogga');
    }
}

// ═══ USB Auto-Refresh ═══
let _usbPollTimer=null;
function startUsbPolling(){
    if(_usbPollTimer)return;
    _usbPollTimer=setInterval(async()=>{
        const d=await apiFetch('system/ports');
        const ports=(d&&d.ports)?d.ports:[];
        const dot=document.getElementById('usb-dot');
        if(APP.selectedPort){
            const stillThere=ports.some(p=>p.port===APP.selectedPort);
            if(!stillThere){
                APP.selectedPort=null;
                updateUsbIndicator();
                showToast(t('⚠️ Dispositivo USB disconnesso'));
            }
        }else if(ports.length>0&&!APP.selectedPort){
            if(dot)dot.className='usb-dot available';
        }
    },5000);
}
function stopUsbPolling(){if(_usbPollTimer){clearInterval(_usbPollTimer);_usbPollTimer=null;}}

async function scanUsbPorts(){
    const list=document.getElementById('usb-ports-list');
    const dot=document.getElementById('usb-dot');
    if(!list)return;
    if(dot)dot.className='usb-dot scanning';
    list.innerHTML='<div style="color:var(--text-muted);font-size:0.75rem;text-align:center;padding:0.5rem;">🔍 Scansione porte USB...</div>';
    
    const d=await apiFetch('system/ports');
    const ports=(d&&d.ports)?d.ports:[];
    
    if(ports.length===0){
        list.innerHTML='<div style="color:var(--warning);font-size:0.75rem;padding:0.5rem;">⚠️ Nessuna porta trovata.<br><br>Verifica:<br>• Cavo USB <b>dati</b> (non solo ricarica)<br>• Driver <b>CP210x</b> o <b>CH340</b> installati<br>• Dispositivo <b>acceso</b></div>';
        if(dot)dot.className='usb-dot disconnected';
        return;
    }
    
    list.innerHTML='';
    ports.forEach(p=>{
        const item=document.createElement('div');
        item.className='usb-port-item'+(APP.selectedPort===p.port?' selected':'');
        item.innerHTML=`<span class="port-name">🔌 ${p.port}</span><span class="port-desc">${p.description||''}${p.manufacturer?' — '+p.manufacturer:''}</span>`;
        item.onclick=()=>selectUsbPort(p.port, p.description);
        list.appendChild(item);
    });
    
    // Se non c'è una porta selezionata e ce n'è solo una, selezionala automaticamente
    if(!APP.selectedPort&&ports.length===1){
        selectUsbPort(ports[0].port, ports[0].description);
    }
    
    updateUsbIndicator();
}

function selectUsbPort(port, desc){
    APP.selectedPort=port;
    
    // Aggiorna UI lista
    document.querySelectorAll('.usb-port-item').forEach(el=>{
        el.classList.toggle('selected', el.querySelector('.port-name').textContent.includes(port));
    });
    
    // Aggiorna info
    const info=document.getElementById('usb-selected-info');
    if(info) info.innerHTML=`✅ <b>${port}</b> selezionata — tutti i comandi useranno questa porta`;
    
    updateUsbIndicator();
    showToast(t('🔌 Porta') + ` ${port} ` + t('selezionata'));
    
    // Chiudi pannello
    setTimeout(()=>{
        const panel=document.getElementById('usb-panel');
        if(panel)panel.style.display='none';
    },800);
}

function deselectUsbPort(){
    APP.selectedPort=null;
    updateUsbIndicator();
    document.querySelectorAll('.usb-port-item').forEach(el=>el.classList.remove('selected'));
    const info=document.getElementById('usb-selected-info');
    if(info) info.innerHTML='';
}

function updateUsbIndicator(){
    const dot=document.getElementById('usb-dot');
    const label=document.getElementById('usb-label');
    if(APP.selectedPort){
        if(dot)dot.className='usb-dot connected';
        if(label)label.textContent=APP.selectedPort;
    }else{
        if(dot)dot.className='usb-dot disconnected';
        if(label)label.textContent=t('Nessuna porta');
    }
}

// Ritorna l'argomento --port da aggiungere ai comandi CLI
function getPortArg(){
    return APP.selectedPort ? `--port ${APP.selectedPort} ` : '';
}

// ── CARICA DATABASE INFO PARAMETRI ─────────────────────────
async function loadParamsInfo(){
    try{
        const r=await fetch('/api/data/params_info');
        APP.paramsInfo=await r.json();
    }catch(e){ console.log('params_info non caricato, uso fallback'); }
}

// ── NAVIGAZIONE SPA ────────────────────────────────────────
function navigateTo(id){
    document.querySelectorAll('.section').forEach(s=>s.classList.remove('active'));
    document.querySelectorAll('.nav-tab').forEach(t=>t.classList.remove('active'));
    const sec=document.getElementById('section-'+id);
    const tab=document.querySelector(`[data-section="${id}"]`);
    if(sec)sec.classList.add('active');
    if(tab)tab.classList.add('active');
    APP.currentSection=id;
    window.scrollTo({top:0,behavior:'smooth'});
    // Auto-azioni per sezioni specifiche
    if(id==='nodo'||id==='cli')setTimeout(checkCLI,300);
    if(id==='dev')setTimeout(()=>{detectPorts();initCopyButtons();initOsPlayButtons();},300);
    setTimeout(()=>{initTooltips();initCopyButtons();},200);
}

// ── INIT ───────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded',()=>{
    document.querySelectorAll('.nav-tab').forEach(t=>{
        t.addEventListener('click',()=>navigateWithLicense(t.dataset.section));
    });
    loadSystemInfo();
    loadParamsInfo();
    navigateTo('guida');
    initCopyButtons();
    initTooltips();
    // 🔐 Check licenza all'avvio
    checkLicense();
    // 🔐 Check periodico revoca in background (ogni 30 min)
    startRevocationPolling();
    // 🌐 Init multilingua
    if(typeof initI18n==='function') initI18n();
    // 🩺 Auto-diagnosi all'avvio (dopo 2s per non rallentare il caricamento)
    setTimeout(()=>runDiagnosisStartup(), 2000);
    // 📦 Check dipendenze all'avvio (dopo 4s — fallback se diagnosi non trova problemi)
    setTimeout(()=>checkDepsStartup(), 4000);
    // Auto-scan porte USB all'avvio (silenzioso)
    setTimeout(async ()=>{
        const d=await apiFetch('system/ports');
        if(d&&d.ports&&d.ports.length===1){
            selectUsbPort(d.ports[0].port, d.ports[0].description);
        }else if(d&&d.ports&&d.ports.length>1){
            updateUsbIndicator();
        }
        // Avvia USB auto-refresh polling (5s)
        startUsbPolling();
    }, 1000);
    // ⌨️ Terminal history: arrow keys per navigare comandi
    setTimeout(()=>{
        const termInput=document.getElementById('term-input');
        if(termInput)termInput.addEventListener('keydown',_termKeyHandler);
        const cliInput=document.getElementById('cli-term-input');
        if(cliInput)cliInput.addEventListener('keydown',function(e){
            if(e.key==='ArrowUp'){
                e.preventDefault();
                if(_cmdHistoryIdx>0){_cmdHistoryIdx--;cliInput.value=_cmdHistory[_cmdHistoryIdx];}
            }else if(e.key==='ArrowDown'){
                e.preventDefault();
                if(_cmdHistoryIdx<_cmdHistory.length-1){_cmdHistoryIdx++;cliInput.value=_cmdHistory[_cmdHistoryIdx];}
                else{_cmdHistoryIdx=_cmdHistory.length;cliInput.value='';}
            }else if(e.key==='Enter'){cliTermRunInput();}
        });
    },500);
});

// ── API ────────────────────────────────────────────────────
async function apiFetch(ep,opt={}){
    try{const r=await fetch('/api/'+ep,{headers:{'Content-Type':'application/json'},...opt});return await r.json();}
    catch(e){console.error('API:',e);return null;}
}

async function loadSystemInfo(){
    APP.systemInfo=await apiFetch('system/info');
    if(APP.systemInfo){
        const i=APP.systemInfo;
        const el=document.getElementById('sys-os');
        if(el&&i.os){const em={windows:'🪟',macos:'🍎',linux:'🐧'};el.textContent=`${em[i.os.os]||'💻'} ${i.os.os_name} ${i.os.os_release}`;}
        const py=document.getElementById('sys-python');
        if(py&&i.python)py.textContent=i.python.python_installed?`✅ Python ${i.python.python_version}`:'❌ Python non trovato';
    }
}

// ── TOOLTIP ℹ️ DINAMICO DAL JSON ───────────────────────────
function initTooltips(){
    document.querySelectorAll('.info-btn[data-param]').forEach(btn=>{
        if(btn.dataset.tooltipInit)return; // Skip se già inizializzato
        btn.dataset.tooltipInit='1';
        const param=btn.dataset.param;
        btn.addEventListener('mouseenter',(e)=>showTooltipHover(e,param));
        btn.addEventListener('mouseleave',hideTooltipHover);
    });
}

function showTooltipHover(e,paramId){
    hideTooltipHover();
    const info=APP.paramsInfo[paramId];
    if(!info)return;
    const tip=document.createElement('div');
    tip.id='hover-tooltip';
    // 🌐 Traduci i testi del tooltip tramite t()
    const _name = t(info.name||'');
    const _desc = t(info.desc||'');
    const _rec = t(info.recommended||'');
    const _recLabel = t('Consigliato');
    tip.innerHTML=`<strong style="color:var(--accent)">${_name}</strong><br><span style="font-size:0.8rem">${_desc}</span><br><span style="font-size:0.75rem;color:var(--text-muted)">⚙️ ${_recLabel}: ${_rec}</span>`;
    tip.style.cssText=`position:fixed;z-index:300;background:var(--bg-card);border:1px solid var(--accent);padding:0.8rem;border-radius:8px;max-width:320px;font-size:0.85rem;color:var(--text-primary);box-shadow:var(--glow-strong);pointer-events:none;`;
    document.body.appendChild(tip);
    const rect=e.target.getBoundingClientRect();
    tip.style.left=Math.min(rect.right+8,window.innerWidth-340)+'px';
    tip.style.top=Math.max(rect.top-20,8)+'px';
}

function hideTooltipHover(){
    const _tip=document.getElementById('hover-tooltip');
    if(_tip)_tip.remove();
}

function showInfo(paramId){
    const info=APP.paramsInfo[paramId];
    if(!info){
        // Fallback per parametri non nel JSON
        const fallbacks={
            region:{name:'Regione LoRa',desc:'Banda 868 MHz per Italia. OBBLIGATORIO EU_868.',recommended:'EU_868',warning:'Regione sbagliata = ILLEGALE!',tip:'Imposta subito dopo flash.',example:'meshtastic --set lora.region EU_868'},
        };
        const fb=fallbacks[paramId];
        if(fb)return showInfoModal(fb);  // showInfoModal ora traduce con t()
        return;
    }
    showInfoModal(info);  // showInfoModal ora traduce con t()
}

function showInfoModal(info){
    const o=document.getElementById('modal-overlay');if(!o)return;
    // 🌐 Traduci TUTTI i campi info tramite t() prima di inserirli nel DOM
    document.getElementById('modal-title').textContent='ℹ️ '+t(info.name||'');
    document.getElementById('modal-desc').textContent=t(info.desc||'');
    document.getElementById('modal-recommended').textContent=t(info.recommended||'—');
    document.getElementById('modal-warning').textContent=t(info.warning||'Nessun warning.');
    document.getElementById('modal-tip').textContent=t(info.tip||'—');
    const exEl=document.getElementById('modal-example');
    if(exEl)exEl.textContent=info.example||'';  // Esempi CLI: non tradurre
    o.classList.add('active');
}

function closeModal(){document.getElementById('modal-overlay')?.classList.remove('active');}
function closeInfoModal(){closeModal();}
function checkNode(){if(APP.selectedPort)cliRun('--info');else showToast(t('⚠️ Seleziona prima una porta USB'));}

// ── COPIA-INCOLLA ──────────────────────────────────────────
function initCopyButtons(){
    document.querySelectorAll('.cli-block').forEach(block=>{
        if(block.querySelector('.copy-btn'))return;
        const btn=document.createElement('button');
        btn.className='copy-btn';btn.textContent='📋 COPIA';
        btn.onclick=()=>copyCommand(block,btn);
        block.appendChild(btn);
    });
}

async function copyCommand(block,btn){
    const code=block.querySelector('code')?.textContent||block.textContent.replace('📋 COPIA','').trim();
    try{await navigator.clipboard.writeText(code);}
    catch(e){const ta=document.createElement('textarea');ta.value=code;document.body.appendChild(ta);ta.select();document.execCommand('copy');document.body.removeChild(ta);}
    btn.textContent='✅ Copiato!';btn.classList.add('copied');
    setTimeout(()=>{btn.textContent='📋 COPIA';btn.classList.remove('copied');},2000);
}

function copyText(text){
    navigator.clipboard.writeText(text).then(()=>showToast(t('📋 Copiato negli appunti!'))).catch(()=>{
        const ta=document.createElement('textarea');ta.value=text;document.body.appendChild(ta);ta.select();document.execCommand('copy');document.body.removeChild(ta);showToast(t('📋 Copiato!'));
    });
}

function showToast(msg,dur=2500){
    let _toast=document.getElementById('toast');
    if(!_toast){_toast=document.createElement('div');_toast.id='toast';_toast.style.cssText=`position:fixed;bottom:2rem;left:50%;transform:translateX(-50%);background:var(--accent);color:#000;padding:0.6rem 1.5rem;border-radius:8px;font-family:var(--font-display);font-size:0.85rem;font-weight:600;z-index:999;box-shadow:var(--glow-strong);transition:opacity 0.3s;opacity:0;`;document.body.appendChild(_toast);}
    _toast.textContent=msg;_toast.style.opacity='1';
    setTimeout(()=>_toast.style.opacity='0',dur);
}

// ── EXECUTION LOCK (previene doppio click) ─────────────────
let _execLock = false;

// ── RILEVA PORTE ───────────────────────────────────────────
// ── OS TAB SWITCH ──
function showOsTab(os){
    ['win','mac','linux'].forEach(id=>{
        const el=document.getElementById('os-'+id);
        const tab=document.getElementById('os-tab-'+id);
        if(el)el.style.display=id===os?'block':'none';
        if(tab){tab.className=id===os?'btn btn-primary':'btn btn-secondary';}
    });
}

// ── DEV TERMINAL: esegue comando di sistema nel terminale dev ──
async function devExec(cmd){
    if(_execLock)return;
    _execLock=true;
    try{
    const _term=document.getElementById('dev-terminal');
    if(!_term)return;
    _term.scrollIntoView({behavior:'smooth',block:'center'});
    
    // Comandi che richiedono admin (più precisi)
    const needsAdmin=cmd.match(/^(sudo |chkdsk|sfc |DISM |powercfg|netsh |Start-Mp|Update-Mp|Optimize-Volume|cleanmgr|diskutil|fsck|fstrim|systemctl mask|systemctl unmask|modprobe|udevadm|ufw |update-grub)/i)
        || cmd.match(/Remove-Item.*Windows\\Temp/i)
        || cmd.match(/Remove-Item.*C:\\Windows/i)
        || cmd.match(/netsh advfirewall/i);
    
    if(needsAdmin){
        termAppendTo('dev-terminal', `\n⚠️ RICHIEDE PRIVILEGI AMMINISTRATORE`, 'error');
        termAppendTo('dev-terminal', `$ ${cmd}`, 'prompt');
        if(!confirm(t('⚠️ Questo comando richiede i diritti di AMMINISTRATORE:')+`\n\n${cmd}\n\n`+t('🪟 Windows: Apri PowerShell come Admin')+`\n`+t('🍎 Mac: Il comando usa sudo (inserisci password)')+`\n`+t('🐧 Linux: Il comando usa sudo')+`\n\n`+t('Vuoi eseguirlo?'))){
            termAppendTo('dev-terminal', '❌ Annullato dall\'utente', 'info');
            return;
        }
    }else{
        termAppendTo('dev-terminal', `\n$ ${cmd}`, 'prompt');
    }
    
    termAppendTo('dev-terminal', '⏳ Esecuzione...', 'info');
    
    const d=await apiFetch('system/exec',{method:'POST',body:JSON.stringify({command:cmd})});
    // 🔧 FIX: usare _term (elemento terminale), NON t (funzione traduzione!)
    if(_term){const lines=_term.querySelectorAll('span');const last=lines[lines.length-1];if(last&&last.textContent.includes('⏳'))last.remove();}
    
    if(d){
        if(d.success){
            if(d.partial){
                termAppendTo('dev-terminal', d.stdout||t('⚠️ Completato parzialmente'), 'info');
            }else{
                termAppendTo('dev-terminal', d.stdout||t('✅ Eseguito'), 'output');
            }
            if(d.stderr&&d.stderr.length>0) termAppendTo('dev-terminal', d.stderr, 'error');
        }else if(d.error){
            termAppendTo('dev-terminal', '❌ '+t(d.error), 'error');
            if(d.stdout) termAppendTo('dev-terminal', d.stdout, 'output');
            if(d.needs_admin) termAppendTo('dev-terminal', t('💡 Esegui il terminale come Amministratore e riprova'), 'info');
        }
    }else{
        navigator.clipboard.writeText(cmd).catch(()=>{});
        termAppendTo('dev-terminal', '📋 Copiato negli appunti! Incolla nel tuo terminale.', 'info');
    }
    if(_term) _term.scrollTop=_term.scrollHeight;
    }finally{_execLock=false;}
}

// Wrappa ogni cli-block nelle sezioni OS in una riga con ▶ ESTERNO
function initOsPlayButtons(){
    ['os-win','os-mac','os-linux'].forEach(osId=>{
        const container=document.getElementById(osId);
        if(!container)return;
        container.querySelectorAll('.cli-block').forEach(block=>{
            if(block.parentElement.classList.contains('os-cmd-row'))return; // già wrappato
            const code=block.querySelector('code');
            if(!code)return;
            const cmd=code.textContent.trim();
            
            // Crea wrapper row
            const row=document.createElement('div');
            row.className='os-cmd-row';
            block.parentNode.insertBefore(row, block);
            row.appendChild(block); // sposta il block dentro la row
            
            // Crea ▶ button FUORI dal block
            const btn=document.createElement('button');
            btn.className='os-play';
            btn.textContent='▶';
            btn.title=t('Esegui comando');
            btn.onclick=()=>devExec(cmd);
            row.appendChild(btn);
        });
    });
}

async function detectPorts(){
    // Scrivi in tutte le sezioni che mostrano le porte
    const containers=[document.getElementById('ports-list'),document.getElementById('dev-ports-list')].filter(Boolean);
    containers.forEach(c=>c.innerHTML='<p style="color:var(--text-muted)">⏳ Rilevamento...</p>');
    const d=await apiFetch('system/ports');
    const html=d&&d.ports&&d.ports.length>0
        ? d.ports.map(p=>`<div class="card" style="padding:0.8rem;margin-bottom:0.5rem;"><span style="color:var(--accent);font-family:var(--font-display)">${p.port}</span> <span style="color:var(--text-secondary);font-size:0.8rem">${p.description}</span>${p.manufacturer?`<br><span style="color:var(--text-muted);font-size:0.75rem">${p.manufacturer}</span>`:''}</div>`).join('')
        : `<div class="alert alert-warning">${t("⚠️ Nessuna porta trovata.")} ${t("Verifica:")}<br>• ${t("Cavo USB")} <strong>${t("dati")}</strong> (${t("non solo ricarica")})<br>• ${t("Driver CP210x o CH340 installati")}<br>• ${t("Dispositivo acceso")}</div>`;
    containers.forEach(c=>c.innerHTML=html);
}

// ── SELEZIONA MODALITÀ CONFIG ──────────────────────────────
function selectConfigMode(mode){
    APP.configMode=mode;
    document.querySelectorAll('.mode-card').forEach(c=>c.classList.remove('active'));
    document.querySelector(`[data-mode="${mode}"]`)?.classList.add('active');
    ['auto','manual','pro'].forEach(m=>{
        const el=document.getElementById('config-'+m);
        if(el){el.style.display=m===mode?'block':'none';}
    });
    if(mode==='auto')generateConfig('auto');
    // Reinizializza tooltip e copy buttons sugli elementi appena resi visibili
    setTimeout(()=>{initTooltips();initCopyButtons();},100);
}

// ── GENERA CONFIGURAZIONE ──────────────────────────────────
// Canali standard Italia
const ITALIA_CHANNELS = [
    {name:'MediumFast', psk:'AQ=='},
    {name:'Ita-Nord', psk:'hJ7/x9L+qJ5kL2nF8dG7hJ1vK4xM3nB5vC6xZ1aS2dQ='},
    {name:'Ita-Centro', psk:'hJ7/x9L+qJ5kL2nF8dG7hJ1vK4xM3nB5vC6xZ1aS2dQ='},
    {name:'Ita-Sud', psk:'hJ7/x9L+qJ5kL2nF8dG7hJ1vK4xM3nB5vC6xZ1aS2dQ='},
    {name:'Ita-Help', psk:'hJ7/x9L+qJ5kL2nF8dG7hJ1vK4xM3nB5vC6xZ1aS2dQ='},
    {name:'Ita-Test', psk:'hJ7/x9L+qJ5kL2nF8dG7hJ1vK4xM3nB5vC6xZ1aS2dQ='},
    {name:'Ita-Shop', psk:'hJ7/x9L+qJ5kL2nF8dG7hJ1vK4xM3nB5vC6xZ1aS2dQ='},
    {name:'Italia', psk:'mQ=='}
];

function fillDefaultChannels(prefix){
    ITALIA_CHANNELS.forEach((ch,i)=>{
        const nameEl=document.getElementById(`${prefix}-ch${i}-name`);
        const pskEl=document.getElementById(`${prefix}-ch${i}-psk`);
        const upEl=document.getElementById(`${prefix}-ch${i}-up`);
        const dnEl=document.getElementById(`${prefix}-ch${i}-dn`);
        if(nameEl) nameEl.value=ch.name;
        if(pskEl) pskEl.value=ch.psk;
        if(upEl) upEl.checked=true;
        if(dnEl) dnEl.checked=true;
    });
    showToast(t('🔄 Canali standard Italia inseriti'));
}

function collectChannels(prefix){
    const channels=[];
    let truncated=false;
    for(let i=0;i<8;i++){
        let name=(document.getElementById(`${prefix}-ch${i}-name`)?.value||'').trim();
        const psk=(document.getElementById(`${prefix}-ch${i}-psk`)?.value||'').trim();
        const up=document.getElementById(`${prefix}-ch${i}-up`)?.checked??true;
        const dn=document.getElementById(`${prefix}-ch${i}-dn`)?.checked??true;
        // Meshtastic limita i nomi canale a 11 caratteri
        if(name.length>11){
            name=name.substring(0,11);
            const _nameEl=document.getElementById(`${prefix}-ch${i}-name`);
            if(_nameEl) _nameEl.value=name;
            truncated=true;
        }
        if(name||psk){
            channels.push({index:i, name, psk, uplink:up, downlink:dn});
        }
    }
    if(truncated) showToast(t('⚠️ Nomi canale troncati a 11 caratteri (limite Meshtastic)'));
    return channels;
}

async function generateConfig(mode){
    const p={region:"EU_868",modem_preset:"MEDIUM_FAST"};
    if(mode==='auto'){
        p.use_autoconfig=true;p.mqtt_enabled=true;p.role="CLIENT";
    }else if(mode==='manual'){
        p.long_name=document.getElementById('cfg-longname-man')?.value||'';
        p.short_name=document.getElementById('cfg-shortname-man')?.value||'';
        p.role=document.getElementById('cfg-role')?.value||'CLIENT';
        p.mqtt_enabled=document.getElementById('cfg-mqtt')?.checked??true;
        // Canali personalizzati manuale
        if(document.getElementById('cfg-man-use-custom-ch')?.checked){
            p.use_autoconfig=false;
            p.custom_channels=collectChannels('man');
        }else{
            p.use_autoconfig=true;
        }
    }else if(mode==='pro'){
        p.long_name=document.getElementById('cfg-longname')?.value||'';
        p.short_name=document.getElementById('cfg-shortname')?.value||'';
        p.role=document.getElementById('cfg-role-pro')?.value||'CLIENT';
        p.mqtt_enabled=document.getElementById('cfg-mqtt-pro')?.checked??true;
        p.hop_limit=parseInt(document.getElementById('cfg-hoplimit')?.value)||3;
        p.tx_power=parseInt(document.getElementById('cfg-txpower')?.value)||27;
        p.rebroadcast_mode=document.getElementById('cfg-rebroadcast')?.value||'ALL';
        // GPS
        p.gps_enabled=document.getElementById('cfg-gps')?.value||'true';
        p.smart_position=document.getElementById('cfg-smartpos')?.value||'true';
        p.position_broadcast_secs=document.getElementById('cfg-posbcast')?.value||'900';
        p.gps_update_interval=document.getElementById('cfg-gpsinterval')?.value||'120';
        // Fixed position
        const lat=document.getElementById('cfg-lat')?.value;
        const lon=document.getElementById('cfg-lon')?.value;
        if(lat&&lon){p.latitude=lat;p.longitude=lon;p.altitude=document.getElementById('cfg-alt')?.value||'';}
        // MQTT
        p.mqtt_encryption=document.getElementById('cfg-mqtt-enc')?.checked??true;
        // Connettività
        p.bluetooth_enabled=document.getElementById('cfg-ble')?.value||'true';
        p.wifi_enabled=document.getElementById('cfg-wifi')?.value||'false';
        p.screen_on_secs=document.getElementById('cfg-screen')?.value||'60';
        // Telemetria
        p.telemetry_device_interval=document.getElementById('cfg-telem-dev')?.value||'900';
        p.telemetry_environment=document.getElementById('cfg-telem-env')?.value||'false';
        // Energia
        p.power_saving=document.getElementById('cfg-powersave')?.value||'false';
        p.led_disabled=document.getElementById('cfg-led')?.value||'false';
        // Moduli
        p.neighbor_info=document.getElementById('cfg-neighbor')?.checked||false;
        p.store_forward=document.getElementById('cfg-storefw')?.checked||false;
        p.range_test=document.getElementById('cfg-rangetest')?.checked||false;
        // Canali personalizzati pro
        if(document.getElementById('cfg-pro-use-custom-ch')?.checked){
            p.use_autoconfig=false;
            p.custom_channels=collectChannels('pro');
        }else{
            p.use_autoconfig=true;
        }
    }
    const d=await apiFetch('config/commands',{method:'POST',body:JSON.stringify(p)});
    if(d)displayCommands(d);
}

function displayCommands(d){
    const c=document.getElementById('config-output');if(!c)return;
    let h='';
    if(d.validation){
        if(d.validation.errors.length)h+=d.validation.errors.map(e=>`<div class="alert alert-danger">${e}</div>`).join('');
        if(d.validation.warnings.length)h+=d.validation.warnings.map(w=>`<div class="alert alert-warning">${w}</div>`).join('');
    }
    if(d.commands){
        h+='<div class="card config-highlight"><div class="card-title">💻 Comandi CLI generati ✅</div>';
        d.commands.forEach(cmd=>{
            const cmdArg=cmd.command.replace('meshtastic ','').replace(/"/g,'&quot;').replace(/'/g,"\\'");
            h+=`<div class="cli-run-row">
                <span class="cli-desc">${cmd.description}</span>
                <div class="cli-block" style="margin:0;flex:1"><code>${cmd.command}</code></div>
                <button class="btn btn-sm btn-primary cli-exec" onclick="navigateTo('cli');setTimeout(()=>cliRun('${cmdArg}'),400)">▶</button>
            </div>`;
        });
        h+='</div>';
    }
    if(d.script){
        h+=`<div class="card config-highlight" style="margin-top:1rem"><div class="card-title">📋 Script completo (copia tutto)</div><div class="cli-block"><code>${d.script.replace(/\n/g,'<br>')}</code></div></div>`;
    }
    c.innerHTML=h;
    initCopyButtons();
    setTimeout(()=>c.scrollIntoView({behavior:'smooth',block:'start'}),200);
}

// ── QR CODE (cerca tutti i container) ───────────────────────
const AUTOCONFIG_URL="https://meshtastic.org/e/#CgsSAQEoATABOgIIIAo0EiCEnv_H0v6onmQvacXx0buEnW8rjEzecHm8LrFnVpLZ1BoISXRhLU5vcmQoATABOgIIIAo2EiCEnv_H0v6onmQvacXx0buEnW8rjEzecHm8LrFnVpLZ1BoKSXRhLUNlbnRybygBMAE6AgggCjMSIISe_8fS_qieZC9pxfHRu4SdbyuMTN5webwusWdWktnUGgdJdGEtU3VkKAEwAToCCCAKNBIghJ7_x9L-qJ5kL2nF8dG7hJ1vK4xM3nB5vC6xZ1aS2dQaCEl0YS1IZWxwKAEwAToCCCAKNBIghJ7_x9L-qJ5kL2nF8dG7hJ1vK4xM3nB5vC6xZ1aS2dQaCEl0YS1UZXN0KAEwAToCCCAKNBIghJ7_x9L-qJ5kL2nF8dG7hJ1vK4xM3nB5vC6xZ1aS2dQaCEl0YS1TaG9wKAEwAToCCCAKExIBmRoGSXRhbGlhKAEwAToCCCASGAgBEAQY-gEgCygFOANABEgBUBtoAcgGAQ";

async function generateQR(targetId){
    const containers=[targetId,'qr-container','qr-container-pro','qr-wizard'].map(id=>document.getElementById(id)).filter(Boolean);
    const c=containers[0];
    if(!c)return;
    c.innerHTML='<p style="color:var(--text-muted)">⏳ Generazione QR...</p>';

    // Raccogli configurazione canali: se l'utente ha canali custom, inviali
    const payload={region:"EU_868",modem_preset:"MEDIUM_FAST"};

    // Determina se siamo in Pro o Manual mode
    const proCustom=document.getElementById('cfg-pro-use-custom-ch')?.checked;
    const manCustom=document.getElementById('cfg-man-use-custom-ch')?.checked;

    if(proCustom){
        payload.custom_channels=collectChannels('pro');
        payload.hop_limit=parseInt(document.getElementById('cfg-hoplimit')?.value)||3;
        payload.tx_power=parseInt(document.getElementById('cfg-txpower')?.value)||27;
    }else if(manCustom){
        payload.custom_channels=collectChannels('man');
    }

    // Prova via server Python (genera URL protobuf dinamico)
    let useExternal=true;
    let qrUrl=AUTOCONFIG_URL;
    try{
        const d=await apiFetch('config/qrcode',{method:'POST',body:JSON.stringify(payload)});
        if(d&&d.url) qrUrl=d.url;
        if(d&&d.qr_code){
            c.innerHTML=_buildQrHtml(null, d.qr_code, qrUrl);
            useExternal=false;
        }
    }catch(e){}

    // Fallback: API esterna per generare QR
    if(useExternal){
        const encUrl=encodeURIComponent(qrUrl);
        c.innerHTML=_buildQrHtml(encUrl, null, qrUrl);
    }
}

function _buildQrHtml(encUrl, b64img, fullUrl){
    const imgTag=b64img
        ? `<img src="data:image/png;base64,${b64img}" alt="QR" style="max-width:200px;border:2px solid var(--accent);border-radius:8px;">`
        : `<img src="https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=${encUrl}&bgcolor=0a0e14&color=00ff88" alt="QR Code Meshtastic" style="max-width:200px;border:2px solid var(--accent);border-radius:8px;" onerror="this.style.display='none'">`;
    return `${imgTag}
        <p style="font-size:0.75rem;color:var(--text-muted);margin-top:0.5rem">${t('Scansiona con app Meshtastic per configurare')}</p>
        <div style="margin-top:0.8rem;display:flex;gap:0.4rem;justify-content:center;flex-wrap:wrap;">
            <a href="${fullUrl}" target="_blank" class="btn btn-sm btn-primary" style="font-size:0.72rem;">📱 ${t('Apri con App Meshtastic')}</a>
            <button class="btn btn-sm btn-secondary" onclick="copyText('${fullUrl.replace(/'/g,"\\'")}');" style="font-size:0.72rem;">📋 ${t('Copia Link')}</button>
        </div>
        <div style="margin-top:0.5rem;background:var(--bg-input);border:1px solid var(--border);border-radius:6px;padding:0.4rem 0.6rem;max-width:400px;margin-left:auto;margin-right:auto;">
            <code style="font-size:0.6rem;word-break:break-all;color:var(--accent);">${fullUrl.length>120?fullUrl.substring(0,120)+'...':fullUrl}</code>
        </div>`;
}

// ── CALCOLATORI ────────────────────────────────────────────
function calcBattery(){
    const mah=parseFloat(document.getElementById('calc-mah')?.value)||0;
    const ma=parseFloat(document.getElementById('calc-ma')?.value)||0;
    const r=document.getElementById('calc-battery-result');
    if(r&&mah>0&&ma>0){const h=(mah/ma).toFixed(1);r.innerHTML=`<strong style="color:var(--accent)">${h} ore</strong> (${(h/24).toFixed(1)} giorni)`;}
}
function calcRF(){
    const dbm=document.getElementById('calc-dbm'),mw=document.getElementById('calc-mw');
    if(!dbm||!mw)return;
    if(document.activeElement===dbm){const v=parseFloat(dbm.value);if(!isNaN(v))mw.value=Math.pow(10,v/10).toFixed(2);}
    else{const v=parseFloat(mw.value);if(!isNaN(v)&&v>0)dbm.value=(10*Math.log10(v)).toFixed(1);}
}
function calcAntenna(){
    const freq=parseFloat(document.getElementById('calc-freq')?.value)||868;
    const r=document.getElementById('calc-antenna-result');
    if(r){const q=((300/freq)*100/4).toFixed(1);const h=((300/freq)*100/2).toFixed(1);r.innerHTML=`λ/4 = <strong style="color:var(--accent)">${q} cm</strong> | λ/2 = <strong style="color:var(--accent)">${h} cm</strong>`;}
}

// ── ASSISTENTE IA ──────────────────────────────────────────
function getWizardQuestions(){return[
    {id:'location',q:t('Dove vuoi mettere il nodo?'),opts:[
        {val:'outdoor_high',label:t('🏔️ Montagna/torre/traliccio'),tip:t('Posizione elevata con vista a 360°')},
        {val:'rooftop',label:t('🏠 Tetto/mansarda di casa'),tip:t('Posizione fissa elevata in area urbana')},
        {val:'indoor',label:t('🏢 Dentro casa/ufficio'),tip:t('Posizione interna, segnale limitato')},
        {val:'mobile',label:t('🚶 Portatile (zaino/tasca)'),tip:t('In movimento, batteria importante')},
        {val:'vehicle',label:t('🚗 Veicolo (auto/bici/moto)'),tip:t('Tracking GPS in movimento')},
    ]},
    {id:'has_gps',q:t('Il tuo dispositivo ha il GPS integrato?'),opts:[
        {val:'yes',label:t('✅ Sì, ha il GPS')},
        {val:'no',label:t('❌ No, senza GPS')},
        {val:'unknown',label:t('🤷 Non lo so')},
    ]},
    {id:'power',q:t('Come viene alimentato?'),opts:[
        {val:'battery',label:t('🔋 Solo batteria')},
        {val:'solar',label:t('☀️ Solare + batteria')},
        {val:'usb',label:t('🔌 USB/rete elettrica 24/7')},
        {val:'battery_usb',label:t('🔋🔌 Batteria + ricarica USB')},
    ]},
    {id:'purpose',q:t('Qual è lo scopo principale?'),opts:[
        {val:'chat',label:t('💬 Chattare con altri')},
        {val:'relay',label:t('📡 Estendere la copertura')},
        {val:'track',label:t('📍 Tracciare posizione')},
        {val:'sensor',label:t('🌡️ Monitorare sensori')},
        {val:'emergency',label:t('🆘 Comunicazione emergenza')},
    ]},
    {id:'multi_node',q:t('Hai altri nodi Meshtastic?'),opts:[
        {val:'only_one',label:t('1️⃣ Questo è il mio unico nodo')},
        {val:'two_three',label:t('2️⃣ Ho 2-3 nodi')},
        {val:'many',label:t('🔢 Ho 4+ nodi')},
    ]},
];}

let wizardStep=0, wizardAnswers={};

function startWizard(){
    wizardStep=0;wizardAnswers={};
    renderWizardStep();
}

function renderWizardStep(){
    const c=document.getElementById('wizard-content');if(!c)return;
    const _wq=getWizardQuestions();
    if(wizardStep>=_wq.length){
        renderWizardResult();return;
    }
    const q=_wq[wizardStep];
    let h=`<div class="card" style="border-color:var(--accent)">`;
    h+=`<div class="card-title">${t('Domanda')} ${wizardStep+1}/${_wq.length}</div>`;
    h+=`<h3 style="color:var(--text-primary);margin-bottom:1rem">${q.q}</h3>`;
    h+=`<div class="grid-2">`;
    q.opts.forEach(o=>{
        h+=`<div class="role-card" onclick="wizardAnswer('${q.id}','${o.val}')" style="cursor:pointer">
            <div class="role-name">${o.label}</div>
            <div class="role-desc">${o.tip||''}</div>
        </div>`;
    });
    h+=`</div></div>`;
    c.innerHTML=h;
}

function wizardAnswer(id,val){
    wizardAnswers[id]=val;
    wizardStep++;
    renderWizardStep();
}

function renderWizardResult(){
    const a=wizardAnswers;
    const c=document.getElementById('wizard-content');if(!c)return;
    
    // Logica di raccomandazione
    let role='CLIENT', tips=[], warnings=[];
    
    // Ruolo basato su posizione e scopo
    if(a.location==='outdoor_high'&&a.purpose==='relay'&&a.power!=='battery'){
        role='ROUTER';
        tips.push(t('Posizione eccezionale + relay + alimentazione fissa = ROUTER è appropriato.'));
        warnings.push(t('Assicurati di avere vista a 360° libera. Se non è una vera cima, usa ROUTER_LATE.'));
    }else if(a.location==='rooftop'&&a.purpose==='relay'){
        role='ROUTER_LATE';
        tips.push(t('Tetto in città = ROUTER_LATE. Copre zone morte senza disturbare la rete.'));
    }else if(a.location==='rooftop'&&a.multi_node!=='only_one'){
        role='CLIENT_BASE';
        tips.push(t('Nodo sul tetto con altri nodi tuoi = CLIENT_BASE. Metti i tuoi nodi nei Preferiti.'));
    }else if(a.purpose==='track'||a.location==='vehicle'){
        role='TRACKER';
        tips.push(t('Tracking GPS = TRACKER. Si sveglia, invia posizione, dorme. Batteria lunga.'));
    }else if(a.purpose==='sensor'){
        role='SENSOR';
        tips.push(t('Monitoraggio sensori = SENSOR. Si sveglia, legge, invia, dorme.'));
    }else if(a.location==='outdoor_high'&&a.power==='solar'){
        role='REPEATER';
        tips.push(t('Solare su montagna = REPEATER. Invisibile, zero manutenzione, puro relay.'));
    }else{
        role='CLIENT';
        tips.push(t('CLIENT è il ruolo giusto per la maggior parte degli utenti.'));
    }

    // Consigli GPS
    let gpsAdvice='';
    if(a.has_gps==='yes'){
        gpsAdvice=t('✅ GPS: Abilita GPS e Smart Position.');
        tips.push(t('Con GPS attivo, abilita Smart Position per risparmiare airtime.'));
    }else if(a.has_gps==='no'){
        gpsAdvice=t('📍 GPS: Imposta posizione fissa con coordinate manuali.');
        tips.push(t('Senza GPS, imposta lat/lon/alt manualmente per apparire sulla mappa.'));
    }

    // Consigli energia
    let powerAdvice='';
    if(a.power==='battery'){
        powerAdvice=t('🔋 Abilita risparmio energetico. Riduci TX a 17-20 dBm.');
        tips.push(t('Con batteria: power.is_power_saving = true, tx_power = 17-20 dBm.'));
    }else if(a.power==='solar'){
        powerAdvice=t('☀️ Nodo solare: display off, BLE off, risparmio energetico attivo.');
    }else{
        powerAdvice=t('🔌 Alimentazione fissa: puoi usare TX max (27 dBm) e display sempre acceso.');
    }

    // Multi-nodo
    if(a.multi_node==='two_three'||a.multi_node==='many'){
        tips.push(t('Con più nodi: metti 1 su CLIENT/CLIENT_BASE, gli altri su CLIENT_MUTE.'));
    }
    
    // Rendering risultato
    let h=`<div class="card" style="border-color:var(--accent)">
        <div class="card-title">🎯 ${t('Configurazione Consigliata')}</div>
        <div style="text-align:center;padding:1rem">
            <div style="font-size:3rem;margin-bottom:0.5rem">${{CLIENT:'🟢',CLIENT_MUTE:'🟢',CLIENT_BASE:'🟡',TRACKER:'🔵',SENSOR:'🔵',ROUTER:'🔴',ROUTER_LATE:'🟡',REPEATER:'🔴'}[role]||'🟢'}</div>
            <div style="font-family:var(--font-display);font-size:1.5rem;color:var(--accent)">${role}</div>
        </div>
        <div style="margin:1rem 0">
            <div class="alert alert-success">📡 <strong>${t('Regione')}:</strong> EU_868 | <strong>Preset:</strong> MediumFast</div>
            <div class="alert alert-info">${gpsAdvice}</div>
            <div class="alert alert-info">${powerAdvice}</div>
        </div>`;

    tips.forEach(_tip=>{h+=`<p style="margin:0.5rem 0;font-size:0.9rem">💡 ${_tip}</p>`;});
    warnings.forEach(_wrn=>{h+=`<div class="alert alert-warning">⚠️ ${_wrn}</div>`;});

    h+=`<div style="margin-top:1.5rem;display:flex;gap:0.5rem;flex-wrap:wrap">
        <button class="btn btn-primary" onclick="applyWizardConfig('${role}')">⚙️ ${t('Genera comandi per')} ${role}</button>
        <button class="btn btn-secondary" onclick="startWizard()">🔄 ${t('Ricomincia')}</button>
    </div></div>`;
    
    c.innerHTML=h;
}

async function applyWizardConfig(role){
    const a=wizardAnswers;
    const c=document.getElementById('wizard-content');
    if(!c)return;
    
    // Aggiungi un container per i comandi sotto il risultato
    let outputDiv=document.getElementById('wizard-output');
    if(!outputDiv){
        outputDiv=document.createElement('div');
        outputDiv.id='wizard-output';
        c.appendChild(outputDiv);
    }
    outputDiv.innerHTML='<p style="color:var(--text-muted);margin:1rem 0">'+t('⏳ Generazione comandi in corso...')+'</p>';
    
    // Prepara parametri basati sulle risposte del wizard
    const params={
        region:'EU_868',
        modem_preset:'MEDIUM_FAST',
        role: role,
        use_autoconfig: true,
        mqtt_enabled: true,
        long_name: '',
        short_name: '',
    };
    
    // GPS
    if(a.has_gps==='no'){
        // suggerisci posizione fissa
    }
    
    // Potenza
    if(a.power==='battery'){
        params.tx_power=20;
    }
    
    // Genera comandi via API
    const d=await apiFetch('config/commands',{method:'POST',body:JSON.stringify(params)});
    
    if(!d){
        outputDiv.innerHTML='<div class="alert alert-danger">'+t('Errore nella generazione comandi')+'</div>';
        return;
    }
    
    let h='';
    
    // Titolo
    h+=`<div class="card config-highlight" style="border-color:var(--accent);margin-top:1.5rem;">
        <div class="card-title">💻 ${t('Comandi CLI per')} ${role} — ${t('Copia e Incolla nel Terminale')}</div>
        <p style="font-size:0.85rem;color:var(--text-secondary);margin-bottom:1rem;">${t('Collega il dispositivo via USB e esegui questi comandi uno alla volta nel terminale.')}</p>`;
    
    // Validazione
    if(d.validation){
        if(d.validation.errors.length)h+=d.validation.errors.map(e=>`<div class="alert alert-danger">${e}</div>`).join('');
        if(d.validation.warnings.length)h+=d.validation.warnings.map(w=>`<div class="alert alert-warning">${w}</div>`).join('');
    }
    
    // Comandi singoli con spiegazione
    if(d.commands){
        d.commands.forEach((cmd,i)=>{
            h+=`<div style="margin-top:1rem;">
                <p style="color:var(--text-secondary);font-size:0.82rem;"><strong>Step ${i+1}:</strong> ${cmd.description}</p>
                <div class="cli-block"><code>${cmd.command}</code></div>
            </div>`;
        });
    }
    h+=`</div>`;
    
    // Script completo copia tutto
    if(d.script){
        h+=`<div class="card config-highlight" style="margin-top:1rem;">
            <div class="card-title">📋 ${t('Script Completo — Copia Tutto in Un Colpo')}</div>
            <p style="font-size:0.8rem;color:var(--text-secondary);margin-bottom:0.5rem;">${t('Copia e incolla TUTTO nel terminale (ogni riga viene eseguita in sequenza):')}</p>
            <div class="cli-block"><code>${d.script.replace(/\n/g,'<br>')}</code></div>
        </div>`;
    }
    
    // Link autoconfigurazione + QR Code
    h+=`<div class="card" style="margin-top:1rem;">
        <div class="card-title">📱 ${t('Configurazione Rapida via App')}</div>
        <p style="font-size:0.85rem;color:var(--text-secondary);margin-bottom:1rem;">${t('In alternativa al CLI, puoi configurare i canali direttamente dall\'app Meshtastic sul telefono:')}</p>
        <div style="display:flex;gap:0.5rem;flex-wrap:wrap;margin-bottom:1rem;">
            <a href="${AUTOCONFIG_URL}" target="_blank" class="btn btn-primary">📱 ${t('Apri con App Meshtastic')}</a>
            <button class="btn btn-secondary" onclick="copyText(AUTOCONFIG_URL)">📋 ${t('Copia Link')}</button>
        </div>
        <div id="qr-wizard" style="text-align:center;"></div>
    </div>`;
    
    // Consigli aggiuntivi basati sulle risposte
    h+=`<div class="card" style="margin-top:1rem;">
        <div class="card-title">💡 ${t('Consigli per il Tuo Setup')}</div>`;

    // GPS advice
    if(a.has_gps==='yes'){
        h+=`<div class="alert alert-success">📍 <strong>GPS:</strong> ${t('Abilita GPS e Smart Position per aggiornare la posizione solo quando ti muovi.')}</div>
        <div class="cli-block"><code>meshtastic --set position.gps_enabled true</code></div>
        <div class="cli-block"><code>meshtastic --set position.position_broadcast_smart_enabled true</code></div>`;
    }else if(a.has_gps==='no'){
        h+=`<div class="alert alert-info">📍 <strong>${t('Senza GPS')}:</strong> ${t('Imposta una posizione fissa per apparire sulla mappa. Trova le coordinate su Google Maps (click destro → coordinate).')}</div>
        <div class="cli-block"><code>meshtastic --setlat TUA_LATITUDINE --setlon TUA_LONGITUDINE --setalt TUA_ALTITUDINE</code></div>`;
    }

    // Power advice
    if(a.power==='battery'){
        h+=`<div class="alert alert-info">🔋 <strong>${t('Batteria')}:</strong> ${t('Attiva risparmio energetico e riduci potenza TX.')}</div>
        <div class="cli-block"><code>meshtastic --set power.is_power_saving true</code></div>
        <div class="cli-block"><code>meshtastic --set lora.tx_power 20</code></div>`;
    }else if(a.power==='solar'){
        h+=`<div class="alert alert-info">☀️ <strong>${t('Solare')}:</strong> ${t('Disabilita display e BLE per massimo risparmio.')}</div>
        <div class="cli-block"><code>meshtastic --set power.is_power_saving true</code></div>
        <div class="cli-block"><code>meshtastic --set display.screen_on_secs 0</code></div>`;
    }

    // Multi-nodo advice
    if(a.multi_node==='two_three'||a.multi_node==='many'){
        h+=`<div class="alert alert-info">📡 <strong>Multi-nodo:</strong> ${t('Imposta gli altri nodi come CLIENT_MUTE per non congestionare la rete.')}</div>
        <div class="cli-block"><code>meshtastic --set device.role CLIENT_MUTE</code></div>`;
    }

    // Verifica finale
    h+=`<div style="margin-top:1rem;"><p style="color:var(--text-secondary);font-size:0.85rem;"><strong>${t('Ultimo step')}:</strong> ${t('Verifica che tutto sia configurato correttamente:')}</p>
        <div class="cli-block"><code>meshtastic --info</code></div>
    </div>`;
    
    h+=`</div>`;
    
    // Pulsanti azione finali
    h+=`<div style="margin-top:1.5rem;display:flex;gap:0.5rem;flex-wrap:wrap;">
        <button class="btn btn-secondary" onclick="startWizard()">🔄 ${t('Ricomincia Questionario')}</button>
        <button class="btn btn-secondary" onclick="navigateTo('nodo')">🔍 ${t('Testa con Terminale')}</button>
        <button class="btn btn-secondary" onclick="navigateTo('config')">⚙️ ${t('Vai alla Config Pro')}</button>
    </div>`;
    
    outputDiv.innerHTML=h;
    
    // Genera QR Code nel container dedicato
    setTimeout(()=>generateQR('qr-wizard'),500);
    
    // Inizializza copy buttons
    setTimeout(()=>{initCopyButtons();initTooltips();},300);
    
    // Scroll verso output
    setTimeout(()=>outputDiv.scrollIntoView({behavior:'smooth',block:'start'}),400);
}

// ── TERMINALE SEZIONE CLI (condivide logica con sezione Nodo) ────
function termAppendTo(termId, text, cls='output'){
    const _el=document.getElementById(termId);if(!_el)return;
    const line=document.createElement('span');
    line.className=cls;
    line.textContent=text+'\n';
    _el.appendChild(line);
    _el.scrollTop=_el.scrollHeight;
}

// Funzione UNIVERSALE — trova il terminale visibile e esegue lì
async function execCmd(cmd){
    if(_execLock)return;
    _execLock=true;
    try{
    // Comandi che modificano → chiedi conferma
    const modifyCmds=['--set ','--set-owner','--ch-set','--factory-reset','--reboot','--reset-nodedb','--remove-position','--setlat','--setlon','--configure'];
    const needsConfirm=modifyCmds.some(mc=>cmd.startsWith(mc));
    if(needsConfirm){
        const portInfo=APP.selectedPort?`\n🔌 Porta: ${APP.selectedPort}`:'';
        if(!confirm(t('⚠️ Vuoi eseguire questo comando?')+`\n\nmeshtastic ${cmd}${portInfo}\n\n`+t('⚡ Questo MODIFICHERÀ la configurazione del nodo.'))){_execLock=false;return;}
    }
    
    // Trova il terminale visibile
    let termId='cli-terminal';
    const nodoTerm=document.getElementById('terminal');
    const cliTerm=document.getElementById('cli-terminal');
    if(nodoTerm&&nodoTerm.offsetParent!==null) termId='terminal';
    else if(cliTerm&&cliTerm.offsetParent!==null) termId='cli-terminal';
    else{
        navigateTo('cli');
        await new Promise(r=>setTimeout(r,400));
        termId='cli-terminal';
    }
    
    const _el=document.getElementById(termId);
    if(_el)_el.scrollIntoView({behavior:'smooth',block:'center'});
    
    // Mostra comando con porta se selezionata
    const portDisplay=APP.selectedPort?` [${APP.selectedPort}]`:'';
    termAppendTo(termId, `\n$ meshtastic ${getPortArg()}${cmd}`, 'prompt');
    if(!APP.selectedPort) termAppendTo(termId, t('⚠️ Nessuna porta selezionata — verrà usata la porta auto-detect'), 'info');
    
    const check=await apiFetch('cli/check');
    if(check&&!check.installed){
        termAppendTo(termId, t('❌ Meshtastic CLI non installato!'),'error');
        termAppendTo(termId, t('   Installa: pip install --upgrade meshtastic'),'info');
        // Bottone installazione automatica nel terminale
        const _btn=document.createElement('span');
        _btn.className='output';
        _btn.innerHTML=`<button onclick="installCLI()" style="background:var(--accent);color:#000;border:none;padding:0.3rem 0.8rem;border-radius:4px;cursor:pointer;font-weight:bold;font-size:0.8rem;margin:0.3rem 0">📦 ${t('Installa automaticamente')}</button>`;
        const _termEl=document.getElementById(termId);
        if(_termEl)_termEl.appendChild(_btn);
        return;
    }
    termAppendTo(termId, '⏳ Esecuzione in corso...', 'info');
    // Invia comando + porta selezionata al server
    const payload={command:cmd};
    if(APP.selectedPort) payload.port=APP.selectedPort;
    const d=await apiFetch('cli/execute',{method:'POST',body:JSON.stringify(payload)});
    // 🔧 FIX: usare _el (elemento terminale), NON t (funzione traduzione!)
    if(_el){const lines=_el.querySelectorAll('span');const last=lines[lines.length-1];if(last&&last.textContent.includes('⏳'))last.remove();}

    if(d){
        if(d.success){termAppendTo(termId, d.stdout||t('✅ Comando eseguito'),'output');}
        else if(d.error){
            termAppendTo(termId, '❌ '+t(d.error),'error');
            if(d.install_command)termAppendTo(termId, '💡 '+d.install_command,'info');
            // 🩺 Smart error parsing — analizza e proponi fix
            const _errText = (d.error||'') + '\n' + (d.stderr||'') + '\n' + (d.stdout||'');
            await parseTerminalError(_errText, termId);
        }
        else{
            if(d.stdout)termAppendTo(termId, d.stdout,'output');
            if(d.stderr){
                termAppendTo(termId, d.stderr,'error');
                // 🩺 Smart error parsing per stderr
                await parseTerminalError(d.stderr, termId);
            }
        }
    }else{termAppendTo(termId, t('❌ Errore comunicazione'),'error');}
    if(_el)_el.scrollTop=_el.scrollHeight;
    }finally{_execLock=false;}
}

// cliRun = alias per compatibilità (pagina CLI)
async function cliRun(cmd){ return execCmd(cmd); }

function cliTermRunInput(){
    const input=document.getElementById('cli-term-input');
    if(!input||!input.value.trim())return;
    let cmd=input.value.trim();
    if(cmd && (_cmdHistory.length===0 || _cmdHistory[_cmdHistory.length-1]!==cmd)){
        _cmdHistory.push(cmd);
    }
    _cmdHistoryIdx=_cmdHistory.length;
    if(cmd.startsWith('meshtastic '))cmd=cmd.replace('meshtastic ','');
    cliRun(cmd);
    input.value='';input.focus();
}

// ── TERMINALE SEZIONE NODO ─────────────────────────────────
let terminalHistory = [];
let _cmdHistory = [];
let _cmdHistoryIdx = -1;

function termAppend(text, cls='output'){
    termAppendTo('terminal', text, cls);
}

async function checkCLI(){
    const s=document.getElementById('cli-status');
    if(!s)return;
    s.innerHTML='<span style="color:var(--text-muted)">⏳ Verifico installazione CLI...</span>';
    const d=await apiFetch('cli/check');
    if(d&&d.installed){
        s.innerHTML=`<span style="color:var(--accent)">✅ Meshtastic CLI installato — ${d.version||'trovato'} — Pronto per comunicare con il nodo!</span>`;
    }else{
        s.innerHTML=`<div class="alert alert-danger" style="margin:0.5rem 0">
            ❌ <strong>${t('Meshtastic CLI non installato!')}</strong><br>
            <span style="font-size:0.85rem">${t('Il terminale ha bisogno del CLI per comunicare con il nodo.')}</span>
        </div>
        <button onclick="installCLI()" style="background:var(--accent);color:#000;border:none;padding:0.5rem 1.2rem;border-radius:6px;cursor:pointer;font-weight:bold;font-size:0.9rem;margin:0.5rem 0">
            📦 ${t('Installa automaticamente')}
        </button>
        <p style="font-size:0.85rem;color:var(--text-secondary);margin:0.5rem 0">${t('Oppure installa manualmente con questo comando:')}</p>
        <div class="cli-block"><code>pip install --upgrade meshtastic</code></div>
        <p style="font-size:0.8rem;color:var(--text-muted);margin-top:0.5rem">${t('Dopo l\'installazione, clicca "🔄 Verifica CLI" per controllare.')}</p>`;
        initCopyButtons();
    }
}

async function installCLI(){
    const s=document.getElementById('cli-status');
    if(s) s.innerHTML=`<span style="color:var(--warning)">⏳ ${t('Installazione Meshtastic CLI in corso... attendere')}</span>`;
    // Mostra anche nel terminale visibile se presente
    const _term=document.getElementById('terminal');
    const _cliTerm=document.getElementById('cli-terminal');
    const _activeTerm=(_cliTerm&&_cliTerm.offsetParent!==null)?_cliTerm:_term;
    if(_activeTerm){
        termAppendTo(_activeTerm.id, `\n$ pip install --upgrade meshtastic`, 'prompt');
        termAppendTo(_activeTerm.id, t('⏳ Installazione in corso... può richiedere 1-2 minuti'), 'info');
    }
    const d=await apiFetch('cli/install',{method:'POST'});
    if(d&&d.success&&d.installed_now){
        if(s) s.innerHTML=`<span style="color:var(--accent)">✅ ${t('Meshtastic CLI installato con successo!')}</span>`;
        if(_activeTerm){
            termAppendTo(_activeTerm.id, t('✅ Installazione completata!'),'output');
            if(d.stdout){
                const _lastLine=(d.stdout.split('\n').pop()||'').trim();
                if(_lastLine) termAppendTo(_activeTerm.id, _lastLine,'output');
            }
        }
        // Re-verifica per mostrare la versione
        setTimeout(()=>checkCLI(), 1000);
    }else{
        const _errMsg=d?(d.error||d.stderr||t('Errore sconosciuto')):t('Errore comunicazione server');
        if(s) s.innerHTML=`<div class="alert alert-danger" style="margin:0.5rem 0">
            ❌ <strong>${t('Installazione fallita')}</strong><br>
            <span style="font-size:0.85rem">${_errMsg}</span><br>
            <span style="font-size:0.8rem;color:var(--text-muted)">${t('Prova manualmente: apri un terminale e scrivi')} <code>pip install --upgrade meshtastic</code></span>
        </div>`;
        if(_activeTerm){
            termAppendTo(_activeTerm.id, '❌ '+t('Installazione fallita')+': '+_errMsg,'error');
            termAppendTo(_activeTerm.id, t('💡 Prova manualmente: pip install --upgrade meshtastic'),'info');
        }
    }
}

// ═══════════════════════════════════════════════════════════
// 🩺 AUTO-DIAGNOSI RECOVERY — analisi errori smart + fix
// ═══════════════════════════════════════════════════════════

/**
 * Analizza output errore del terminale e mostra pulsanti fix se riconosciuto
 * @param {string} errorText - Testo stderr/stdout con errore
 * @param {string} termId - ID del terminale dove mostrare i fix
 * @returns {boolean} true se errore riconosciuto e fix proposto
 */
async function parseTerminalError(errorText, termId){
    if(!errorText || errorText.length < 20) return false;
    // Controlla se contiene un Traceback o pattern errore noto
    const _hasTraceback = /Traceback|Error:|Exception:|ModuleNotFoundError|ImportError|serial\.serialutil|TimeoutError|PermissionError/i.test(errorText);
    if(!_hasTraceback) return false;

    // Chiedi al server di analizzare l'errore
    const _diag = await apiFetch('error/analyze', {method:'POST', body:JSON.stringify({error: errorText})});
    if(!_diag || !_diag.found || !_diag.diagnoses || _diag.diagnoses.length === 0) return false;

    for(const _d of _diag.diagnoses){
        // Mostra diagnosi nel terminale
        termAppendTo(termId, '', 'output');
        termAppendTo(termId, '🩺 '+t('DIAGNOSI AUTOMATICA'), 'prompt');
        termAppendTo(termId, '   '+t('Problema')+': '+t(_d.title_it), 'error');

        if(_d.fix_action === 'serial_troubleshoot' || _d.fix_action === 'device_troubleshoot' || _d.fix_action === 'os_troubleshoot'){
            // Mostra step suggeriti (senza bottone auto-fix)
            if(_d.fix_steps){
                for(const _step of _d.fix_steps){
                    termAppendTo(termId, '   💡 '+t(_step), 'info');
                }
            }
        } else if(_d.fix_action === 'python_version_warning'){
            termAppendTo(termId, '   ⚠️ Python '+(_d.python_version||'')+' '+t('potrebbe non essere compatibile'), 'info');
            termAppendTo(termId, '   💡 '+t('Raccomandata: Python 3.11 o 3.12'), 'info');
            termAppendTo(termId, '   🔗 https://www.python.org/downloads/', 'info');
        } else if(_d.fix_package){
            // Mostra bottone fix con conferma si/no
            const _pkg = _d.fix_package;
            const _action = _d.fix_action || 'install';
            const _actionLabel = _action === 'reinstall' ? t('Reinstallare') :
                                 _action === 'upgrade' ? t('Aggiornare') : t('Installare');

            const _fixEl = document.createElement('div');
            _fixEl.style.cssText = 'margin:0.5rem 0;padding:0.5rem;background:rgba(0,255,136,0.08);border:1px solid var(--accent);border-radius:6px;';
            _fixEl.innerHTML = `
                <span style="color:var(--accent);font-weight:bold">🔧 ${t('Soluzione disponibile')}</span><br>
                <span style="font-size:0.85rem;color:var(--text-secondary)">${_actionLabel} <code>${_pkg}</code>?</span>
                <div style="margin-top:0.4rem;display:flex;gap:0.5rem">
                    <button onclick="fixPackage('${_pkg}','${_action}',this,'${termId}')" style="background:var(--accent);color:#000;border:none;padding:0.3rem 1rem;border-radius:4px;cursor:pointer;font-weight:bold;font-size:0.8rem">
                        ✅ ${t('Sì, correggi')}
                    </button>
                    <button onclick="this.parentElement.parentElement.remove()" style="background:transparent;color:var(--text-muted);border:1px solid #444;padding:0.3rem 0.8rem;border-radius:4px;cursor:pointer;font-size:0.8rem">
                        ❌ ${t('No')}
                    </button>
                </div>`;
            const _termEl = document.getElementById(termId);
            if(_termEl) _termEl.appendChild(_fixEl);
        }
    }
    return true;
}

/**
 * Esegue fix mirato su un pacchetto — chiamato dai bottoni nel terminale
 */
async function fixPackage(pkg, action, btnEl, termId){
    if(btnEl){
        const _parent = btnEl.parentElement.parentElement;
        _parent.innerHTML = `<span style="color:var(--warning)">⏳ ${t('Correzione in corso...')} ${pkg}</span>`;
    }
    termAppendTo(termId, `\n🔧 ${t('Fix in corso')}: ${action} ${pkg}...`, 'prompt');

    const _result = await apiFetch('deps/fix', {
        method: 'POST',
        body: JSON.stringify({action: action, package: pkg})
    });

    if(_result && _result.success){
        termAppendTo(termId, `✅ ${t('Fix completato con successo!')} ${pkg}`, 'output');
        if(_result.steps){
            for(const _s of _result.steps){
                if(_s.output) termAppendTo(termId, '   '+_s.output.split('\n').pop(), 'info');
            }
        }
        // Suggerisci di riprovare il comando
        termAppendTo(termId, `💡 ${t('Riprova il comando precedente.')}`, 'info');
        // Aggiorna stato CLI se era meshtastic
        if(pkg === 'meshtastic' && typeof checkCLI === 'function'){
            setTimeout(()=>checkCLI(), 1500);
        }
    } else {
        const _err = _result ? (_result.error || t('Errore sconosciuto')) : t('Errore comunicazione server');
        termAppendTo(termId, `❌ ${t('Fix fallito')}: ${_err}`, 'error');
        termAppendTo(termId, `💡 ${t('Prova manualmente')}: pip install --force-reinstall ${pkg}`, 'info');
    }
}

/**
 * Diagnosi completa — chiamata all'avvio o dal bottone Diagnosi
 */
async function runDiagnosisStartup(){
    const _diag = await apiFetch('deps/diagnose');
    if(!_diag) return;
    if(_diag.status === 'ok' && (!_diag.issues || _diag.issues.length === 0)){
        // Tutto OK — nessun modal
        return;
    }

    // Ci sono problemi — mostra modal diagnosi
    const _borderColor = _diag.status==='critical'?'var(--danger,#ff4444)':'var(--warning,#ffaa00)';
    let _html = `
    <div id="diag-modal-overlay" style="position:fixed;inset:0;background:rgba(0,0,0,0.88);z-index:99999;display:flex;align-items:center;justify-content:center;font-family:monospace">
    <div style="background:var(--bg-card,#1a1a2e);border:2px solid ${_borderColor};border-radius:12px;padding:2rem;max-width:720px;width:92%;max-height:88vh;overflow-y:auto;color:var(--text-primary,#e0e0e0)">
        <h2 style="color:${_borderColor};margin:0 0 0.5rem 0">
            🩺 ${t('Auto-Diagnosi Sistema')}
        </h2>
        <p style="font-size:0.85rem;color:var(--text-secondary,#aaa);margin:0 0 0.8rem 0">
            ${t('Score')}: <strong style="color:${_diag.score>=80?'var(--accent)':(_diag.score>=50?'var(--warning)':'var(--danger)')}">${_diag.score}/100</strong>
            &nbsp;—&nbsp; Python ${_diag.python_version || '?'} &nbsp;|&nbsp; CLI ${_diag.cli_version || t('non trovato')} &nbsp;|&nbsp; ${_diag.ports_count || 0} ${t('porte USB')}
        </p>`;

    // ── SEZIONE 1: INFO SISTEMA ──────────────────────────────
    _html += `<div style="margin-bottom:0.8rem;font-size:0.8rem;padding:0.5rem;background:rgba(255,255,255,0.03);border-radius:6px">`;
    for(const _i of (_diag.info || [])){
        const _icon = _i.ok ? '✅' : '❌';
        _html += `<div style="margin:0.2rem 0">${_icon} <strong>${_i.label}:</strong> ${_i.value}${_i.path ? ' <span style="color:var(--text-muted,#666)">'+_i.path+'</span>' : ''}${_i.error ? ' <span style="color:var(--danger,#f44)">— '+_i.error.substring(0,80)+'</span>' : ''}</div>`;
    }
    _html += `</div>`;

    // ── SEZIONE 2: PROBLEMI CRITICI (auto-fix) ───────────────
    if(_diag.issues && _diag.issues.length > 0){
        _html += `<h3 style="color:var(--danger,#ff4444);font-size:0.95rem;margin:0.8rem 0 0.4rem 0">❌ ${t('Problemi trovati')}</h3>`;
        for(const _issue of _diag.issues){
            const _sevColor = _issue.severity === 'critical' ? 'var(--danger,#ff4444)' : 'var(--warning,#ffaa00)';
            _html += `<div style="margin:0.4rem 0;padding:0.5rem;border-left:3px solid ${_sevColor};background:rgba(255,68,68,0.05);border-radius:0 6px 6px 0">
                <div style="color:${_sevColor};font-weight:bold;font-size:0.85rem">${_issue.title}</div>
                <div style="font-size:0.8rem;color:var(--text-muted,#888);margin:0.2rem 0">${_issue.detail || ''}</div>`;
            if(_issue.fix_package && _issue.fix_action !== 'upgrade_python' && _issue.fix_action !== 'downgrade_python'){
                _html += `<button onclick="diagFixPackage('${_issue.fix_package}','${_issue.fix_action || 'install'}',this)"
                    style="margin-top:0.3rem;background:var(--accent,#00ff88);color:#000;border:none;padding:0.25rem 0.8rem;border-radius:4px;cursor:pointer;font-weight:bold;font-size:0.78rem">
                    🔧 ${t('Correggi automaticamente')}
                </button>`;
            } else if(_issue.fix_url){
                _html += `<a href="${_issue.fix_url}" target="_blank" style="display:inline-block;margin-top:0.3rem;color:var(--accent);font-size:0.8rem;text-decoration:underline">
                    🔗 ${t('Scarica versione corretta')}
                </a>`;
            }
            _html += `</div>`;
        }
    }

    // ── SEZIONE 3: AVVISI ────────────────────────────────────
    if(_diag.warnings && _diag.warnings.length > 0){
        _html += `<h3 style="color:var(--warning,#ffaa00);font-size:0.95rem;margin:0.8rem 0 0.4rem 0">⚠️ ${t('Avvisi')}</h3>`;
        for(const _w of _diag.warnings){
            _html += `<div style="margin:0.3rem 0;padding:0.4rem;font-size:0.8rem;color:var(--text-secondary)">
                ⚠️ ${_w.title}${_w.detail ? ' — '+_w.detail : ''}
            </div>`;
        }
    }

    // ── BOTTONI FIX AUTOMATICO ────────────────────────────────
    _html += `
        <div style="display:flex;gap:0.8rem;flex-wrap:wrap;margin-top:1rem">
            <button id="diag-fix-all-btn" onclick="diagFixAll()" style="background:var(--accent,#00ff88);color:#000;border:none;padding:0.5rem 1.2rem;border-radius:6px;cursor:pointer;font-weight:bold;font-size:0.9rem;flex:1">
                🔧 ${t('Correggi tutto automaticamente')}
            </button>
            <button onclick="document.getElementById('diag-modal-overlay').remove()" style="background:transparent;color:var(--text-muted,#888);border:1px solid #444;padding:0.5rem 1rem;border-radius:6px;cursor:pointer;font-size:0.85rem">
                ${t('Ignora')}
            </button>
        </div>
        <p id="diag-status" style="font-size:0.8rem;color:var(--text-muted,#888);margin:0.8rem 0 0 0;min-height:1.2rem"></p>`;

    // ══════════════════════════════════════════════════════════
    // SEZIONE MANUALE — per utenti tecnici
    // ══════════════════════════════════════════════════════════
    _html += `
        <details style="margin-top:1.2rem;border-top:1px solid #333;padding-top:1rem">
            <summary style="cursor:pointer;color:var(--accent,#00ff88);font-weight:bold;font-size:0.9rem;user-select:none">
                🛠️ ${t('Sezione Manuale (utenti tecnici)')}
            </summary>
            <div style="margin-top:0.8rem">

            <!-- PYTHON VERSIONS -->
            <h4 style="color:var(--accent,#00ff88);font-size:0.88rem;margin:0.8rem 0 0.4rem 0">🐍 ${t('Versioni Python — Download')}</h4>
            <p style="font-size:0.78rem;color:var(--text-muted,#888);margin:0 0 0.5rem 0">
                ${t('Scegli la versione più adatta al tuo sistema. Le versioni raccomandate sono testate con meshtastic CLI.')}
            </p>
            <table style="width:100%;border-collapse:collapse;font-size:0.78rem;margin-bottom:0.8rem">
                <tr style="border-bottom:1px solid #333;color:var(--accent)">
                    <th style="text-align:left;padding:0.3rem">${t('Versione')}</th>
                    <th style="text-align:center;padding:0.3rem">${t('Stato')}</th>
                    <th style="text-align:left;padding:0.3rem">${t('Note')}</th>
                    <th style="text-align:center;padding:0.3rem">Link</th>
                </tr>
                <tr style="border-bottom:1px solid #222">
                    <td style="padding:0.3rem;color:var(--accent)"><strong>Python 3.12</strong></td>
                    <td style="text-align:center">⭐ ${t('Raccomandata')}</td>
                    <td style="padding:0.3rem;color:var(--text-secondary)">${t('Stabile, testata, compatibile con tutto')}</td>
                    <td style="text-align:center"><a href="https://www.python.org/downloads/release/python-3129/" target="_blank" style="color:var(--accent)">📥</a></td>
                </tr>
                <tr style="border-bottom:1px solid #222">
                    <td style="padding:0.3rem;color:var(--accent)"><strong>Python 3.11</strong></td>
                    <td style="text-align:center">✅ ${t('Ottima')}</td>
                    <td style="padding:0.3rem;color:var(--text-secondary)">${t('Veloce, molto stabile, supporto LTS')}</td>
                    <td style="text-align:center"><a href="https://www.python.org/downloads/release/python-31111/" target="_blank" style="color:var(--accent)">📥</a></td>
                </tr>
                <tr style="border-bottom:1px solid #222">
                    <td style="padding:0.3rem"><strong>Python 3.13</strong></td>
                    <td style="text-align:center">✅ ${t('Supportata')}</td>
                    <td style="padding:0.3rem;color:var(--text-secondary)">${t('Recente, compatibile con meshtastic')}</td>
                    <td style="text-align:center"><a href="https://www.python.org/downloads/release/python-3132/" target="_blank" style="color:var(--accent)">📥</a></td>
                </tr>
                <tr style="border-bottom:1px solid #222">
                    <td style="padding:0.3rem"><strong>Python 3.10</strong></td>
                    <td style="text-align:center">✅ ${t('Supportata')}</td>
                    <td style="padding:0.3rem;color:var(--text-secondary)">${t('Stabile ma più datata, funziona bene')}</td>
                    <td style="text-align:center"><a href="https://www.python.org/downloads/release/python-31016/" target="_blank" style="color:var(--accent)">📥</a></td>
                </tr>
                <tr style="border-bottom:1px solid #222">
                    <td style="padding:0.3rem"><strong>Python 3.9</strong></td>
                    <td style="text-align:center">⚠️ ${t('Minima')}</td>
                    <td style="padding:0.3rem;color:var(--text-muted)">${t('Versione minima supportata, fine vita 2025')}</td>
                    <td style="text-align:center"><a href="https://www.python.org/downloads/release/python-3922/" target="_blank" style="color:var(--accent)">📥</a></td>
                </tr>
                <tr style="border-bottom:1px solid #222;background:rgba(255,68,68,0.05)">
                    <td style="padding:0.3rem;color:var(--danger)"><strong>Python 3.14+</strong></td>
                    <td style="text-align:center">❌ ${t('Non testata')}</td>
                    <td style="padding:0.3rem;color:var(--danger)">${t('Troppo nuova — meshtastic potrebbe crashare')}</td>
                    <td style="text-align:center">—</td>
                </tr>
            </table>
            <p style="font-size:0.75rem;color:var(--text-muted,#666);margin:0 0 0.8rem 0">
                💡 ${t('Consiglio')}: ${t('Su Windows puoi avere più versioni Python installate. Usa il Python Launcher')} <code>py -3.12</code> ${t('per scegliere quale usare.')}
            </p>

            <!-- LIBRERIE PRINCIPALI -->
            <h4 style="color:var(--accent,#00ff88);font-size:0.88rem;margin:0.8rem 0 0.4rem 0">📦 ${t('Librerie Principali (richieste)')}</h4>
            <table style="width:100%;border-collapse:collapse;font-size:0.78rem;margin-bottom:0.8rem">
                <tr style="border-bottom:1px solid #333;color:var(--accent)">
                    <th style="text-align:left;padding:0.3rem">${t('Pacchetto')}</th>
                    <th style="text-align:left;padding:0.3rem">${t('Comando pip')}</th>
                    <th style="text-align:left;padding:0.3rem">${t('A cosa serve')}</th>
                </tr>
                <tr style="border-bottom:1px solid #222"><td style="padding:0.3rem"><strong>meshtastic</strong></td><td><code>pip install meshtastic</code></td><td style="color:var(--text-secondary)">${t('CLI + API per dispositivi LoRa')}</td></tr>
                <tr style="border-bottom:1px solid #222"><td style="padding:0.3rem"><strong>flask</strong></td><td><code>pip install flask</code></td><td style="color:var(--text-secondary)">${t('Web server locale dell\'app')}</td></tr>
                <tr style="border-bottom:1px solid #222"><td style="padding:0.3rem"><strong>flask-cors</strong></td><td><code>pip install flask-cors</code></td><td style="color:var(--text-secondary)">${t('Permessi cross-origin per API')}</td></tr>
                <tr style="border-bottom:1px solid #222"><td style="padding:0.3rem"><strong>pyserial</strong></td><td><code>pip install pyserial</code></td><td style="color:var(--text-secondary)">${t('Comunicazione USB seriale')}</td></tr>
                <tr style="border-bottom:1px solid #222"><td style="padding:0.3rem"><strong>cryptography</strong></td><td><code>pip install cryptography</code></td><td style="color:var(--text-secondary)">${t('Crittografia licenze Ed25519')}</td></tr>
                <tr style="border-bottom:1px solid #222"><td style="padding:0.3rem"><strong>qrcode + Pillow</strong></td><td><code>pip install qrcode[pil]</code></td><td style="color:var(--text-secondary)">${t('Generazione QR code canali')}</td></tr>
                <tr style="border-bottom:1px solid #222"><td style="padding:0.3rem"><strong>protobuf</strong></td><td><code>pip install protobuf</code></td><td style="color:var(--text-secondary)">${t('Serializzazione dati Meshtastic')}</td></tr>
            </table>

            <!-- LIBRERIE AGGIUNTIVE / OPZIONALI -->
            <h4 style="color:var(--accent,#00ff88);font-size:0.88rem;margin:0.8rem 0 0.4rem 0">🔌 ${t('Librerie Aggiuntive (opzionali)')}</h4>
            <table style="width:100%;border-collapse:collapse;font-size:0.78rem;margin-bottom:0.8rem">
                <tr style="border-bottom:1px solid #333;color:var(--accent)">
                    <th style="text-align:left;padding:0.3rem">${t('Pacchetto')}</th>
                    <th style="text-align:left;padding:0.3rem">${t('Comando pip')}</th>
                    <th style="text-align:left;padding:0.3rem">${t('A cosa serve')}</th>
                </tr>
                <tr style="border-bottom:1px solid #222"><td style="padding:0.3rem"><strong>esptool</strong></td><td><code>pip install esptool</code></td><td style="color:var(--text-secondary)">${t('Flash firmware ESP32 (sezione Flash)')}</td></tr>
                <tr style="border-bottom:1px solid #222"><td style="padding:0.3rem"><strong>bleak</strong></td><td><code>pip install bleak</code></td><td style="color:var(--text-secondary)">${t('Connessione Bluetooth BLE ai nodi')}</td></tr>
                <tr style="border-bottom:1px solid #222"><td style="padding:0.3rem"><strong>pyyaml</strong></td><td><code>pip install pyyaml</code></td><td style="color:var(--text-secondary)">${t('Export/import configurazioni YAML')}</td></tr>
                <tr style="border-bottom:1px solid #222"><td style="padding:0.3rem"><strong>tabulate</strong></td><td><code>pip install tabulate</code></td><td style="color:var(--text-secondary)">${t('Formattazione tabelle nel terminale')}</td></tr>
                <tr style="border-bottom:1px solid #222"><td style="padding:0.3rem"><strong>requests</strong></td><td><code>pip install requests</code></td><td style="color:var(--text-secondary)">${t('HTTP client per update e API remote')}</td></tr>
            </table>

            <!-- DRIVER USB -->
            <h4 style="color:var(--accent,#00ff88);font-size:0.88rem;margin:0.8rem 0 0.4rem 0">🔌 ${t('Driver USB (necessari per la comunicazione)')}</h4>
            <table style="width:100%;border-collapse:collapse;font-size:0.78rem;margin-bottom:0.8rem">
                <tr style="border-bottom:1px solid #333;color:var(--accent)">
                    <th style="text-align:left;padding:0.3rem">${t('Driver')}</th>
                    <th style="text-align:left;padding:0.3rem">${t('Dispositivi')}</th>
                    <th style="text-align:center;padding:0.3rem">Download</th>
                </tr>
                <tr style="border-bottom:1px solid #222">
                    <td style="padding:0.3rem"><strong>CP210x</strong> (Silicon Labs)</td>
                    <td style="color:var(--text-secondary)">${t('T-Beam, T-Lora, Heltec, LilyGO — la maggior parte dei dispositivi')}</td>
                    <td style="text-align:center"><a href="https://www.silabs.com/developers/usb-to-uart-bridge-vcp-drivers" target="_blank" style="color:var(--accent)">📥 ${t('Scarica')}</a></td>
                </tr>
                <tr style="border-bottom:1px solid #222">
                    <td style="padding:0.3rem"><strong>CH340/CH341</strong> (WCH)</td>
                    <td style="color:var(--text-secondary)">${t('Cloni economici, alcune schede WisBlock, NodeMCU')}</td>
                    <td style="text-align:center"><a href="https://www.wch-ic.com/downloads/CH341SER_EXE.html" target="_blank" style="color:var(--accent)">📥 ${t('Scarica')}</a></td>
                </tr>
            </table>
            <p style="font-size:0.75rem;color:var(--text-muted,#666);margin:0 0 0.5rem 0">
                💡 ${t('Dopo aver installato un driver, riavvia il PC e ricollega il dispositivo USB.')}
            </p>

            <!-- COMANDI UTILI -->
            <h4 style="color:var(--accent,#00ff88);font-size:0.88rem;margin:0.8rem 0 0.4rem 0">💻 ${t('Comandi Utili (terminale di sistema)')}</h4>
            <div style="font-size:0.78rem;background:rgba(0,0,0,0.3);border:1px solid #333;border-radius:6px;padding:0.6rem;margin-bottom:0.5rem">
                <div style="margin:0.2rem 0"><code style="color:var(--accent)">python --version</code> <span style="color:var(--text-muted)">— ${t('Verifica versione Python')}</span></div>
                <div style="margin:0.2rem 0"><code style="color:var(--accent)">pip --version</code> <span style="color:var(--text-muted)">— ${t('Verifica pip installato')}</span></div>
                <div style="margin:0.2rem 0"><code style="color:var(--accent)">meshtastic --version</code> <span style="color:var(--text-muted)">— ${t('Verifica meshtastic CLI')}</span></div>
                <div style="margin:0.2rem 0"><code style="color:var(--accent)">pip install --upgrade meshtastic</code> <span style="color:var(--text-muted)">— ${t('Aggiorna meshtastic all\'ultima versione')}</span></div>
                <div style="margin:0.2rem 0"><code style="color:var(--accent)">pip install --force-reinstall meshtastic</code> <span style="color:var(--text-muted)">— ${t('Reinstalla da zero (risolve molti problemi)')}</span></div>
                <div style="margin:0.2rem 0"><code style="color:var(--accent)">pip list</code> <span style="color:var(--text-muted)">— ${t('Mostra tutte le librerie installate')}</span></div>
                <div style="margin:0.2rem 0"><code style="color:var(--accent)">pip install --user meshtastic</code> <span style="color:var(--text-muted)">— ${t('Installa senza permessi admin')}</span></div>
            </div>
            <p style="font-size:0.75rem;color:var(--text-muted,#666);margin:0 0 0.5rem 0">
                🐧 <strong>Linux</strong>: ${t('Se le porte USB non compaiono')}: <code>sudo usermod -a -G dialout $USER</code> ${t('poi ri-login')}<br>
                🍎 <strong>macOS</strong>: ${t('Dopo l\'installazione driver, riavvia il Mac')}<br>
                🪟 <strong>Windows</strong>: ${t('Se pip non funziona, prova')}: <code>py -m pip install meshtastic</code>
            </p>

            <!-- BOTTONE INSTALLA SINGOLO -->
            <h4 style="color:var(--accent,#00ff88);font-size:0.88rem;margin:0.8rem 0 0.4rem 0">🔧 ${t('Installa Pacchetto Singolo')}</h4>
            <div style="display:flex;gap:0.5rem;align-items:center;margin-bottom:0.5rem">
                <select id="diag-manual-pkg" style="background:#111;color:var(--text-primary);border:1px solid #444;padding:0.3rem 0.6rem;border-radius:4px;font-size:0.8rem;font-family:monospace;flex:1">
                    <option value="meshtastic">meshtastic</option>
                    <option value="flask">flask</option>
                    <option value="flask-cors">flask-cors</option>
                    <option value="pyserial">pyserial</option>
                    <option value="cryptography">cryptography</option>
                    <option value="qrcode[pil]">qrcode[pil]</option>
                    <option value="Pillow">Pillow</option>
                    <option value="protobuf">protobuf</option>
                    <option value="esptool">esptool</option>
                    <option value="bleak">bleak</option>
                    <option value="pyyaml">pyyaml</option>
                    <option value="tabulate">tabulate</option>
                    <option value="requests">requests</option>
                </select>
                <select id="diag-manual-action" style="background:#111;color:var(--text-primary);border:1px solid #444;padding:0.3rem 0.5rem;border-radius:4px;font-size:0.8rem;font-family:monospace">
                    <option value="install">${t('Installa/Aggiorna')}</option>
                    <option value="reinstall">${t('Reinstalla da zero')}</option>
                </select>
                <button id="diag-manual-btn" onclick="diagManualInstall()" style="background:var(--accent,#00ff88);color:#000;border:none;padding:0.35rem 0.8rem;border-radius:4px;cursor:pointer;font-weight:bold;font-size:0.8rem;white-space:nowrap">
                    📦 ${t('Esegui')}
                </button>
            </div>
            <p id="diag-manual-status" style="font-size:0.78rem;color:var(--text-muted,#888);margin:0;min-height:1rem"></p>

            </div>
        </details>
    </div></div>`;

    document.body.insertAdjacentHTML('beforeend', _html);
}

/**
 * Installazione manuale singolo pacchetto dal dropdown nel modal diagnosi
 */
async function diagManualInstall(){
    const _pkg = document.getElementById('diag-manual-pkg');
    const _act = document.getElementById('diag-manual-action');
    const _btn = document.getElementById('diag-manual-btn');
    const _status = document.getElementById('diag-manual-status');
    if(!_pkg || !_act) return;

    const _pkgVal = _pkg.value;
    const _actVal = _act.value;

    if(_btn){_btn.disabled=true; _btn.innerHTML=`⏳ ...`; _btn.style.opacity='0.6';}
    if(_status) _status.innerHTML = `<span style="color:var(--warning)">⏳ ${t('Installazione')} ${_pkgVal}...</span>`;

    const _r = await apiFetch('deps/fix', {
        method:'POST',
        body:JSON.stringify({action: _actVal, package: _pkgVal})
    });

    if(_r && _r.success){
        if(_status) _status.innerHTML = `<span style="color:var(--accent)">✅ ${_pkgVal} ${t('installato con successo!')}</span>`;
    } else {
        const _err = _r ? (_r.error || t('Errore sconosciuto')) : t('Errore comunicazione server');
        if(_status) _status.innerHTML = `<span style="color:var(--danger)">❌ ${t('Fallito')}: ${_err.substring(0,120)}</span>`;
    }
    if(_btn){_btn.disabled=false; _btn.innerHTML=`📦 ${t('Esegui')}`; _btn.style.opacity='1';}
}

/**
 * Fix singolo pacchetto dal modal diagnosi
 */
async function diagFixPackage(pkg, action, btnEl){
    if(btnEl){
        btnEl.disabled = true;
        btnEl.innerHTML = `⏳ ${t('Correzione in corso...')}`;
        btnEl.style.opacity = '0.6';
    }
    const _result = await apiFetch('deps/fix', {
        method:'POST',
        body:JSON.stringify({action: action, package: pkg})
    });
    if(_result && _result.success){
        if(btnEl){
            btnEl.innerHTML = `✅ ${t('Corretto!')}`;
            btnEl.style.background = 'var(--accent)';
        }
    } else {
        if(btnEl){
            btnEl.innerHTML = `❌ ${t('Fallito')}`;
            btnEl.style.background = 'var(--danger)';
            btnEl.disabled = false;
            btnEl.style.opacity = '1';
        }
    }
}

/**
 * Fix tutti i problemi trovati dalla diagnosi
 */
async function diagFixAll(){
    const _btn = document.getElementById('diag-fix-all-btn');
    const _status = document.getElementById('diag-status');
    if(_btn){_btn.disabled=true; _btn.innerHTML=`⏳ ${t('Correzione in corso...')}`; _btn.style.opacity='0.6';}
    if(_status) _status.textContent = t('⏳ Analisi e correzione in corso... può richiedere 2-3 minuti');

    // Prima ottieni la diagnosi corrente
    const _diag = await apiFetch('deps/diagnose');
    if(!_diag || !_diag.issues || _diag.issues.length === 0){
        if(_status) _status.innerHTML = `<span style="color:var(--accent)">✅ ${t('Nessun problema da correggere!')}</span>`;
        if(_btn){_btn.innerHTML=`✅ ${t('Tutto OK!')}`;}
        return;
    }

    let _fixed = 0;
    let _failed = 0;
    // Fix ogni problema che ha un fix_package
    for(const _issue of _diag.issues){
        if(_issue.fix_package){
            if(_status) _status.textContent = `⏳ ${t('Correzione')}: ${_issue.fix_package}...`;
            const _r = await apiFetch('deps/fix', {
                method:'POST',
                body:JSON.stringify({action: _issue.fix_action || 'install', package: _issue.fix_package})
            });
            if(_r && _r.success) _fixed++;
            else _failed++;
        }
    }

    if(_status){
        if(_failed === 0){
            _status.innerHTML = `<span style="color:var(--accent)">✅ ${t('Tutti i problemi corretti!')} (${_fixed} fix)</span>`;
        } else {
            _status.innerHTML = `<span style="color:var(--warning)">⚠️ ${_fixed} ${t('corretti')}, ${_failed} ${t('falliti')}</span>`;
        }
    }
    if(_btn){
        _btn.innerHTML = _failed === 0 ? `✅ ${t('Completato!')}` : `⚠️ ${_fixed}/${_fixed+_failed} ${t('corretti')}`;
    }

    // Rimuovi modal dopo 3s se tutto OK
    if(_failed === 0){
        setTimeout(()=>{
            const _overlay = document.getElementById('diag-modal-overlay');
            if(_overlay) _overlay.remove();
            if(typeof checkCLI === 'function') checkCLI();
        }, 3000);
    }
}

// ═══════════════════════════════════════════════════════════
// CHECK DIPENDENZE ALL'AVVIO — verifica + auto-install
// ═══════════════════════════════════════════════════════════
async function checkDepsStartup(){
    const d=await apiFetch('deps/check');
    if(!d) return; // server non risponde — probabilmente deps OK (Flask gira)
    if(d.all_ok) return; // Tutto installato — nessun modal

    // Ci sono dipendenze mancanti — mostra modal
    const _missing=d.deps.filter(_dep=>_dep.required&&!_dep.installed);
    const _optional=d.deps.filter(_dep=>!_dep.required&&!_dep.installed);

    let _html=`
    <div id="deps-modal-overlay" style="position:fixed;inset:0;background:rgba(0,0,0,0.85);z-index:99999;display:flex;align-items:center;justify-content:center;font-family:monospace">
    <div style="background:var(--bg-card,#1a1a2e);border:2px solid var(--accent,#00ff88);border-radius:12px;padding:2rem;max-width:600px;width:90%;max-height:80vh;overflow-y:auto;color:var(--text-primary,#e0e0e0)">
        <h2 style="color:var(--accent,#00ff88);margin:0 0 0.5rem 0">📦 ${t('Dipendenze mancanti')}</h2>
        <p style="font-size:0.9rem;color:var(--text-secondary,#aaa);margin:0 0 1rem 0">
            ${t('Alcune librerie Python necessarie non sono installate.')}
        </p>
        <div style="margin-bottom:1rem">
            <p style="font-size:0.85rem;margin:0.3rem 0"><strong>Python:</strong> ${d.python_version} ${d.pip_available?'✅ pip '+d.pip_version:'❌ pip '+t('non trovato')}</p>
        </div>
        <table style="width:100%;border-collapse:collapse;font-size:0.85rem;margin-bottom:1rem">
        <tr style="border-bottom:1px solid #333;color:var(--accent,#00ff88)">
            <th style="text-align:left;padding:0.4rem">${t('Pacchetto')}</th>
            <th style="text-align:center;padding:0.4rem">${t('Stato')}</th>
            <th style="text-align:left;padding:0.4rem">${t('Versione')}</th>
        </tr>`;

    for(const _dep of d.deps){
        const _icon=_dep.installed?'✅':'❌';
        const _color=_dep.installed?'var(--accent,#00ff88)':'var(--danger,#ff4444)';
        const _ver=_dep.installed?(_dep.version||'?'):(_dep.required?t('MANCANTE'):t('opzionale'));
        _html+=`<tr style="border-bottom:1px solid #222">
            <td style="padding:0.4rem;color:${_color}">${_dep.label}</td>
            <td style="text-align:center;padding:0.4rem">${_icon}</td>
            <td style="padding:0.4rem;font-size:0.8rem;color:var(--text-muted,#888)">${_ver}</td>
        </tr>`;
    }

    _html+=`</table>
        <div style="display:flex;gap:0.8rem;flex-wrap:wrap">
            <button id="deps-install-btn" onclick="installAllDeps()" style="background:var(--accent,#00ff88);color:#000;border:none;padding:0.6rem 1.5rem;border-radius:6px;cursor:pointer;font-weight:bold;font-size:0.95rem;flex:1">
                📦 ${t('Installa tutto automaticamente')}
            </button>
            <button onclick="document.getElementById('deps-modal-overlay').remove()" style="background:transparent;color:var(--text-muted,#888);border:1px solid #444;padding:0.6rem 1rem;border-radius:6px;cursor:pointer;font-size:0.85rem">
                ${t('Ignora')}
            </button>
        </div>
        <p id="deps-status" style="font-size:0.8rem;color:var(--text-muted,#888);margin:0.8rem 0 0 0;min-height:1.2rem"></p>
    </div></div>`;

    document.body.insertAdjacentHTML('beforeend', _html);
}

async function installAllDeps(){
    const _btn=document.getElementById('deps-install-btn');
    const _status=document.getElementById('deps-status');
    if(_btn){
        _btn.disabled=true;
        _btn.innerHTML=`⏳ ${t('Installazione in corso...')}`;
        _btn.style.opacity='0.6';
    }
    if(_status) _status.textContent=t('⏳ Installazione in corso... può richiedere 1-2 minuti');

    const d=await apiFetch('deps/install',{method:'POST',body:JSON.stringify({})});
    if(d&&d.success){
        if(_status) _status.innerHTML=`<span style="color:var(--accent)">✅ ${t('Tutte le dipendenze installate!')}</span>`;
        if(_btn){
            _btn.innerHTML=`✅ ${t('Completato!')}`;
            _btn.style.background='var(--accent)';
        }
        // Rimuovi modal dopo 2s e aggiorna pagina
        setTimeout(()=>{
            const _overlay=document.getElementById('deps-modal-overlay');
            if(_overlay) _overlay.remove();
            // Aggiorna lo stato CLI se siamo nella pagina CLI
            if(typeof checkCLI==='function') checkCLI();
        }, 2000);
    }else{
        const _errMsg=d?(d.error||t('Errore sconosciuto')):t('Errore comunicazione server');
        if(_status) _status.innerHTML=`<span style="color:var(--danger)">❌ ${_errMsg}</span><br><span style="font-size:0.75rem">${t('Prova manualmente: apri un terminale e scrivi')} <code>pip install -r requirements.txt</code></span>`;
        if(_btn){
            _btn.disabled=false;
            _btn.innerHTML=`🔄 ${t('Riprova')}`;
            _btn.style.opacity='1';
        }
    }
}

async function termRun(cmd){
    if(_execLock)return;
    _execLock=true;
    try{
    const _term=document.getElementById('terminal');if(!_term)return;
    // Conferma per comandi che modificano
    const modifyCmds=['--set ','--set-owner','--ch-set','--factory-reset','--reboot','--reset-nodedb','--remove-position','--setlat','--setlon'];
    if(modifyCmds.some(mc=>cmd.startsWith(mc))){
        if(!confirm(t('⚠️ Vuoi eseguire questo comando?')+`\n\nmeshtastic ${cmd}\n\n`+t('⚡ Questo MODIFICHERÀ la configurazione del nodo.')))return;
    }
    _term.scrollIntoView({behavior:'smooth',block:'center'});
    termAppend(`\n$ meshtastic ${getPortArg()}${cmd}`, 'prompt');
    if(!APP.selectedPort) termAppend(t('⚠️ Nessuna porta selezionata — auto-detect'), 'info');
    
    // Prima controlla se CLI è installato
    const check=await apiFetch('cli/check');
    if(check&&!check.installed){
        termAppend(t('❌ Meshtastic CLI non è installato sul tuo PC!'),'error');
        termAppend('','output');
        termAppend(t('Per installarlo, apri un terminale e scrivi:'),'info');
        termAppend('  pip install --upgrade meshtastic','prompt');
        termAppend('','output');
        // Bottone installazione automatica
        const _btn=document.createElement('span');
        _btn.className='output';
        _btn.innerHTML=`<button onclick="installCLI()" style="background:var(--accent);color:#000;border:none;padding:0.3rem 0.8rem;border-radius:4px;cursor:pointer;font-weight:bold;font-size:0.8rem;margin:0.3rem 0">📦 ${t('Installa automaticamente')}</button> <span style="color:var(--text-muted);font-size:0.8rem">${t('oppure installa manualmente e riavvia')}</span>`;
        const _termNode=document.getElementById('terminal');
        if(_termNode)_termNode.appendChild(_btn);
        return;
    }
    
    termAppend('⏳ Esecuzione in corso...', 'info');
    
    const payload={command:cmd};
    if(APP.selectedPort) payload.port=APP.selectedPort;
    const d=await apiFetch('cli/execute',{method:'POST',body:JSON.stringify(payload)});
    
    // Rimuovi il messaggio "in corso"
    const lines=_term.querySelectorAll('span');
    const last=lines[lines.length-1];
    if(last&&last.textContent.includes('⏳'))last.remove();
    
    if(d){
        if(d.success){
            termAppend(d.stdout||t('(nessun output)'),'output');
            terminalHistory.push({cmd:cmd, output:d.stdout});
        }else if(d.error){
            termAppend('❌ '+t(d.error),'error');
            if(d.install_command){
                termAppend(t('💡 Installa con: ')+d.install_command,'info');
            }
            // 🩺 Smart error parsing
            const _errText = (d.error||'') + '\n' + (d.stderr||'') + '\n' + (d.stdout||'');
            await parseTerminalError(_errText, 'terminal');
        }else{
            if(d.stdout)termAppend(d.stdout,'output');
            if(d.stderr){
                termAppend(d.stderr,'error');
                await parseTerminalError(d.stderr, 'terminal');
            }
        }
    }else{
        termAppend(t('❌ Errore di comunicazione con il server'),'error');
    }
    }finally{_execLock=false;}
}

function termRunInput(){
    const input=document.getElementById('term-input');
    if(!input||!input.value.trim())return;
    let cmd=input.value.trim();
    // Salva nella cronologia
    if(cmd && (_cmdHistory.length===0 || _cmdHistory[_cmdHistory.length-1]!==cmd)){
        _cmdHistory.push(cmd);
    }
    _cmdHistoryIdx=_cmdHistory.length;
    // Rimuovi "meshtastic " se l'utente lo ha scritto
    if(cmd.startsWith('meshtastic '))cmd=cmd.replace('meshtastic ','');
    termRun(cmd);
    input.value='';
    input.focus();
}

// ── Arrow key history navigation per terminali ──
function _termKeyHandler(e){
    const input=e.target;
    if(e.key==='ArrowUp'){
        e.preventDefault();
        if(_cmdHistoryIdx>0){_cmdHistoryIdx--;input.value=_cmdHistory[_cmdHistoryIdx];}
    }else if(e.key==='ArrowDown'){
        e.preventDefault();
        if(_cmdHistoryIdx<_cmdHistory.length-1){_cmdHistoryIdx++;input.value=_cmdHistory[_cmdHistoryIdx];}
        else{_cmdHistoryIdx=_cmdHistory.length;input.value='';}
    }else if(e.key==='Enter'){
        termRunInput();
    }
}

function analyzeTerminalOutput(){
    const c=document.getElementById('node-analysis');if(!c)return;
    const _term=document.getElementById('terminal');
    const text=_term?_term.textContent:'';
    const tl=text.toLowerCase();
    
    if(text.length<200){
        c.innerHTML='<div class="alert alert-warning">'+t('⚠️ Esegui prima <strong>--info</strong> nel terminale per avere dati da analizzare.')+'</div>';
        return;
    }
    
    let s=[];
    
    // ═══ VERIFICA DATI RICEVUTI (punto 3: controlla che siano tutti usciti) ═══
    const dataChecks=[
        {key:'"firmwareVersion"',label:'Firmware',found:false},
        {key:'"hwModel"',label:'Hardware Model',found:false},
        {key:'"role"',label:'Ruolo dispositivo',found:false},
        {key:'"region"',label:'Regione LoRa',found:false},
        {key:'"modemPreset"',label:'Preset Modem',found:false},
        {key:'"hopLimit"',label:'Hop Limit',found:false},
        {key:'"txPower"',label:'TX Power',found:false},
        {key:'"batteryLevel"',label:'Livello Batteria',found:false},
        {key:'"channelUtilization"',label:'Channel Utilization',found:false},
        {key:'"airUtilTx"',label:'Airtime TX',found:false},
        {key:'gpsEnabled',label:'Stato GPS',found:false},
        {key:'gpsMode',label:'Modalità GPS',found:false},
        {key:'"wifiEnabled"',label:'Stato WiFi',found:false},
        {key:'"fixedPin"',label:'PIN Bluetooth',found:false},
        {key:'"positionBroadcastSmartEnabled"',label:'Smart Position',found:false},
        {key:'"mqtt"',label:'Configurazione MQTT',found:false},
        {key:'"neighborInfo"',label:'Neighbor Info',found:false},
        {key:'"telemetry"',label:'Telemetria',found:false},
        {key:'"storeForward"',label:'Store & Forward',found:false},
        {key:'Channels:',label:'Canali configurati',found:false},
        {key:'downlinkEnabled',label:'Downlink canali',found:false},
        {key:'uplinkEnabled',label:'Uplink canali',found:false},
        {key:'Complete URL',label:'URL configurazione completo',found:false},
    ];
    
    let foundCount=0;
    dataChecks.forEach(dc=>{
        if(text.includes(dc.key)){dc.found=true;foundCount++;}
    });
    
    s.push({t:foundCount>=20?'success':foundCount>=15?'warning':'danger',
        m:`📊 <strong>Dati ricevuti: ${foundCount}/${dataChecks.length}</strong> — ${foundCount>=20?'Output completo!':foundCount>=15?'Parziale, esegui anche --get all':'Incompleto, ripeti --info'}`});
    
    // Lista dati mancanti
    const missing=dataChecks.filter(dc=>!dc.found);
    if(missing.length>0&&missing.length<10){
        s.push({t:'info',m:'📋 <strong>Dati mancanti:</strong> '+missing.map(m=>m.label).join(', ')});
    }
    
    // ═══ ESTRAI E MOSTRA TUTTI I VALORI TROVATI ═══
    const fwMatch=text.match(/"firmwareVersion":\s*"([^"]+)"/);
    const hwMatch=text.match(/"hwModel":\s*"([^"]+)"/);
    const roleMatch=text.match(/"role":\s*"([^"]+)"/);
    const hopMatch=text.match(/"hopLimit":\s*(\d+)/);
    const txMatch=text.match(/"txPower":\s*(\d+)/);
    const batMatch=text.match(/"batteryLevel":\s*(\d+)/);
    const chUtil=text.match(/"channelUtilization":\s*([\d.]+)/);
    const airTx=text.match(/"airUtilTx":\s*([\d.]+)/);
    const nodeCount=(text.match(/"user":/g)||[]).length;
    const regionMatch=text.match(/"region":\s*"([^"]+)"/);
    const presetMatch=text.match(/"modemPreset":\s*"([^"]+)"/);
    
    if(fwMatch) s.push({t:'info',m:`📦 <strong>Firmware:</strong> ${fwMatch[1]}`});
    if(hwMatch) s.push({t:'info',m:`🔧 <strong>Hardware:</strong> ${hwMatch[1]}`});
    if(roleMatch) s.push({t:'info',m:`👤 <strong>Ruolo:</strong> ${roleMatch[1]}`});
    if(regionMatch) s.push({t:regionMatch[1]==='EU_868'?'success':'danger',m:`📡 <strong>Regione:</strong> ${regionMatch[1]}${regionMatch[1]!=='EU_868'?' — '+t('⚠️ NON è EU_868!')+'':''}`,fix:regionMatch[1]!=='EU_868'?'meshtastic --set lora.region EU_868':null});
    if(presetMatch) s.push({t:presetMatch[1]==='MEDIUM_FAST'?'success':'warning',m:`📻 <strong>Preset:</strong> ${presetMatch[1]}${presetMatch[1]!=='MEDIUM_FAST'?' — Non è lo standard Italia':''}`,fix:presetMatch[1]!=='MEDIUM_FAST'?'meshtastic --set lora.modem_preset MEDIUM_FAST':null});
    if(hopMatch){const h=parseInt(hopMatch[1]);s.push({t:h>5?'danger':h>3?'warning':'success',m:`🔄 <strong>Hop Limit:</strong> ${h}${h>5?' — TROPPO ALTO! Causa congestione':''}`,fix:h>3?'meshtastic --set lora.hop_limit 3':null});}
    if(txMatch){const tx=parseInt(txMatch[1]);s.push({t:tx>27?'danger':'success',m:`📡 <strong>TX Power:</strong> ${tx} dBm${tx>27?' — Supera limite legale EU!':''}`,fix:tx>27?'meshtastic --set lora.tx_power 27':null});}
    if(batMatch){const b=parseInt(batMatch[1]);s.push({t:b<=20?'danger':b<=50?'warning':'success',m:`🔋 <strong>Batteria:</strong> ${b}%`});}
    if(chUtil) s.push({t:parseFloat(chUtil[1])>30?'danger':parseFloat(chUtil[1])>15?'warning':'success',m:`📊 <strong>Channel Util:</strong> ${parseFloat(chUtil[1]).toFixed(1)}%`});
    if(airTx) s.push({t:parseFloat(airTx[1])>5?'danger':parseFloat(airTx[1])>2?'warning':'success',m:`📡 <strong>Airtime TX:</strong> ${parseFloat(airTx[1]).toFixed(2)}%`});
    if(nodeCount>0) s.push({t:'info',m:`👥 <strong>Nodi visibili:</strong> ${nodeCount}`});
    
    // ═══ PROBLEMI DA CORREGGERE ═══
    if(tl.includes('"gpsenabled": false')&&tl.includes('"gpsmode": "enabled"'))
        s.push({t:'warning',m:'⚠️ <strong>GPS contraddittorio</strong> — gpsEnabled=false ma gpsMode=ENABLED',fix:'meshtastic --set position.gps_enabled true'});
    if(tl.includes('"positionbroadcastsmartenabled": false'))
        s.push({t:'warning',m:'⚠️ <strong>Smart Position OFF</strong> — Abilita per risparmiare airtime',fix:'meshtastic --set position.position_broadcast_smart_enabled true'});
    if(tl.includes('"wifienabled": true')){
        s.push({t:'warning',m:'⚠️ <strong>WiFi abilitato</strong> — Consuma batteria',fix:'meshtastic --set network.wifi_enabled false'});
        const ssid=text.match(/"wifiSsid":\s*"([^"]+)"/);
        const psk=text.match(/"wifiPsk":\s*"([^"]+)"/);
        if(ssid&&psk) s.push({t:'danger',m:`🔐 <strong>SICUREZZA!</strong> Credenziali WiFi visibili: SSID="${ssid[1]}"`});
    }
    if(tl.includes('"fixedpin": 123456'))
        s.push({t:'warning',m:'⚠️ <strong>PIN BT default 123456</strong>',fix:'meshtastic --set bluetooth.fixed_pin 847291'});
    const dlOff=(text.match(/"downlinkEnabled": false/g)||[]).length;
    if(dlOff>4) s.push({t:'warning',m:`⚠️ <strong>Downlink OFF su ${dlOff} canali</strong>`,fix:'meshtastic --ch-set downlink_enabled true --ch-index 0'});
    if(tl.includes('"deviceupdateinterval": 0'))
        s.push({t:'warning',m:'⚠️ <strong>Telemetria device: intervallo 0</strong>',fix:'meshtastic --set telemetry.device_update_interval 900'});
    if(tl.includes('"environmentupdateinterval": 0')&&tl.includes('"environmentmeasurementenabled": true'))
        s.push({t:'warning',m:'⚠️ <strong>Telemetria env: intervallo 0</strong>',fix:'meshtastic --set telemetry.environment_update_interval 900'});
    const nameMatch=text.match(/"longName":\s*"Meshtastic \w+"/);
    if(nameMatch) s.push({t:'info',m:'ℹ️ <strong>Nome di default</strong> — Personalizza!',fix:'meshtastic --set-owner "TuoNome-Citta"'});
    
    // ═══ ESTRAI URL per QR (punto 5) ═══
    const urlMatch=text.match(/Complete URL[^:]*:\s*(https:\/\/meshtastic\.org\/e\/[^\s]+)/);
    if(urlMatch){
        s.push({t:'success',m:`🔗 <strong>URL Configurazione estratto</strong>`});
    }
    
    // Rendering
    let h='<div class="card config-highlight" style="border-color:var(--accent)"><div class="card-title">🔍 Analisi Completa — '+s.length+' elementi</div>';
    const order={danger:0,warning:1,info:2,success:3};
    s.sort((a,b)=>(order[a.t]||99)-(order[b.t]||99));
    s.forEach(item=>{
        h+=`<div class="alert alert-${item.t}" style="margin-bottom:0.5rem">${item.m}`;
        if(item.fix){
            h+=`<div class="cli-run-row" style="margin-top:0.3rem"><div class="cli-block" style="margin:0;flex:1"><code>${item.fix}</code></div><button class="btn btn-sm btn-primary cli-exec" onclick="execCmd('${item.fix.replace('meshtastic ','').replace(/'/g,"\\'")}')">▶</button></div>`;
        }
        h+=`</div>`;
    });
    
    // QR Code dal link estratto
    if(urlMatch){
        h+=`<div style="margin-top:1rem;display:flex;gap:0.5rem;flex-wrap:wrap;align-items:center">
            <a href="${urlMatch[1]}" target="_blank" class="btn btn-primary">📱 Apri Config nell'App</a>
            <button class="btn btn-secondary" onclick="copyText('${urlMatch[1]}')">📋 Copia Link</button>
            <button class="btn btn-secondary" onclick="generateQR('node-qr-result')">📱 Genera QR</button>
        </div><div id="node-qr-result" style="margin-top:0.5rem;text-align:center"></div>`;
    }
    
    h+='</div>';
    c.innerHTML=h;
    initCopyButtons();
    c.scrollIntoView({behavior:'smooth',block:'start'});
}

// ══════════════════════════════════════════════════════════════
// 🔐 GENERATORE PSK — Chiavi crittografiche per canali
// ══════════════════════════════════════════════════════════════

function generatePSK(){
    const type=document.getElementById('psk-type')?.value||'256';
    const target=document.getElementById('psk-target-ch')?.value||'none';
    const result=document.getElementById('psk-result');
    const output=document.getElementById('psk-output');
    const info=document.getElementById('psk-info');
    const cliDiv=document.getElementById('psk-cli');
    if(!result||!output)return;

    let bytes, pskB64, label, entropy;
    
    if(type==='1'){
        // Chiave pubblica (1 byte)
        pskB64='AQ==';
        label='🔓 Chiave Pubblica (1 byte) — Canale aperto, nessuna crittografia';
        entropy='0 bit (pubblica)';
    }else{
        // Genera chiave crittografica forte
        const len=type==='256'?32:16;
        const arr=new Uint8Array(len);
        crypto.getRandomValues(arr); // CSPRNG del browser
        // Base64 encode
        let binary='';
        arr.forEach(b=>binary+=String.fromCharCode(b));
        pskB64=btoa(binary);
        label=type==='256'
            ?'🔒 AES-256 (32 byte) — Massima sicurezza, chiave militare'
            :'🔑 AES-128 (16 byte) — Buona sicurezza, compatibilità massima';
        entropy=`${len*8} bit di entropia (CSPRNG)`;
    }
    
    output.textContent=pskB64;
    info.innerHTML=`${label}<br><span style="color:var(--accent);">Entropia: ${entropy}</span>`;
    result.style.display='block';
    
    // Applica a canale se selezionato
    if(target!=='none'){
        if(target==='all_secondary'){
            for(let i=1;i<=7;i++){
                const el=document.getElementById(`pro-ch${i}-psk`);
                if(el)el.value=pskB64;
            }
            showToast(t('🔐 PSK applicata a Ch1-Ch7'));
        }else{
            const el=document.getElementById(`pro-ch${target}-psk`);
            if(el)el.value=pskB64;
            showToast(t('🔐 PSK applicata a Ch') + target);
        }
    }
    
    // Mostra comando CLI
    if(target!=='none'&&target!=='all_secondary'){
        cliDiv.innerHTML=`<div class="cli-block" style="margin:0;font-size:0.72rem;"><code>meshtastic --ch-set psk "base64:${pskB64}" --ch-index ${target}</code></div>`;
        initCopyButtons();
    }else if(target==='all_secondary'){
        let cmds='';
        for(let i=1;i<=7;i++){
            cmds+=`meshtastic --ch-set psk "base64:${pskB64}" --ch-index ${i}\n`;
        }
        cliDiv.innerHTML=`<div class="cli-block" style="margin:0;font-size:0.72rem;"><code>${cmds.trim().replace(/\n/g,'<br>')}</code></div>`;
        initCopyButtons();
    }else{
        cliDiv.innerHTML='';
    }
}

// ══════════════════════════════════════════════════════════════
// 🔧 MOD FIRMWARE — Operazioni avanzate sul dispositivo
// ══════════════════════════════════════════════════════════════

function termAppendMod(msg,type){
    termAppendTo('mod-terminal',msg,type||'output');
}

async function modExec(args,termId){
    if(_execLock)return;
    _execLock=true;
    try{
    const _term=document.getElementById('mod-terminal');
    if(_term)_term.scrollIntoView({behavior:'smooth',block:'center'});
    
    const fullCmd=`meshtastic ${getPortArg()}${args}`;
    termAppendMod(`\n$ ${fullCmd}`,'prompt');
    termAppendMod(t('⏳ Esecuzione...'),'info');
    
    const timeout=args.includes('--export-config')||args.includes('--nodes')?120:60;
    const d=await apiFetch('cli/exec',{method:'POST',body:JSON.stringify({args:args,timeout:timeout,port:APP.selectedPort||''})});

    // 🔧 FIX: usare _term (elemento terminale), NON t (funzione traduzione!)
    if(_term){const lines=_term.querySelectorAll('span');const last=lines[lines.length-1];if(last&&last.textContent.includes('⏳'))last.remove();}

    if(d){
        if(d.not_found){
            termAppendMod(t('❌ meshtastic CLI non trovato — installa con: pip install meshtastic'),'error');
        }else{
            if(d.stdout)termAppendMod(d.stdout,'output');
            if(d.stderr){
                termAppendMod(d.stderr,'error');
                // 🩺 Smart error parsing per MOD terminal
                await parseTerminalError(d.stderr, 'mod-terminal');
            }
            if(!d.stdout&&!d.stderr)termAppendMod(t('✅ Eseguito (nessun output)'),'info');
            // Se returncode != 0 e c'è stdout con errore
            if(d.returncode && d.returncode !== 0 && d.stdout){
                await parseTerminalError(d.stdout, 'mod-terminal');
            }
        }
    }else{
        termAppendMod(t('❌ Errore comunicazione server'),'error');
    }
    if(_term)_term.scrollTop=_term.scrollHeight;
    }finally{_execLock=false;}
}

function modSetNodeId(){
    const id=(document.getElementById('mod-nodeid')?.value||'').trim();
    if(!id){showToast(t('⚠️ Inserisci un Node ID'));return;}
    // Validate hex format
    const clean=id.replace(/^!/,'');
    if(!/^[0-9a-fA-F]{8}$/.test(clean)){
        showToast(t('⚠️ Node ID deve essere 8 cifre hex (es. a1b2c3d4)'));
        return;
    }
    if(confirm(t('⚠️ CAMBIO NODE ID')+`\n\n`+t('Nuovo ID')+`: !${clean}\n\n`+t('ATTENZIONE:')+`\n• `+t('Il nodo apparirà come un NUOVO dispositivo nella rete mesh')+`\n• `+t('Gli altri nodi perderanno la connessione al vecchio ID')+`\n• `+t('Non c\u0027è modo di tornare indietro automaticamente')+`\n\n`+t('Confermi?'))){
        // meshtastic --set device.node_id 0xHEX + reboot
        modExec(`--set device.node_id 0x${clean}`,'mod');
        setTimeout(()=>{
            termAppendMod(t('⏳ Riavvio nodo per applicare nuovo ID...'),'info');
            modExec('--reboot','mod');
        },2000);
    }
}

function modSetHam(){
    const call=(document.getElementById('mod-hamcall')?.value||'').trim().toUpperCase();
    if(!call){showToast(t('⚠️ Inserisci un call sign'));return;}
    if(!/^[A-Z0-9]{3,8}$/.test(call)){
        showToast(t('⚠️ Call sign non valido (3-8 caratteri alfanumerici)'));
        return;
    }
    if(confirm(t('⚠️ SET HAM MODE')+`\n\nCall Sign: ${call}\n\n`+t('Questo comando:')+`\n• `+t('Imposta il call sign come nome lungo')+`\n• `+t('Abilita is_licensed = true')+`\n• `+t('La crittografia E2E viene disabilitata (obbligo HAM)')+`\n• `+t('PSK canale primario → AQ== (pubblico)')+`\n\n`+t('Confermi?'))){
        modExec(`--set-ham "${call}"`,'mod');
    }
}

function modGenerateRandomId(){
    const arr=new Uint8Array(4);
    crypto.getRandomValues(arr);
    const hex=Array.from(arr).map(b=>b.toString(16).padStart(2,'0')).join('');
    document.getElementById('mod-nodeid').value='!'+hex;
    showToast(t('🎲 ID generato: !') + hex);
}

async function modExportConfig(){
    termAppendMod('\n'+t('📤 Export configurazione YAML...'),'prompt');
    const d=await apiFetch('cli/exec',{method:'POST',body:JSON.stringify({args:'--export-config',timeout:120,port:APP.selectedPort||''})});
    if(d&&d.stdout){
        termAppendMod(t('✅ Config esportata (')+d.stdout.length+t(' caratteri)'),'info');
        // Download come file
        const blob=new Blob([d.stdout],{type:'text/yaml'});
        const url=URL.createObjectURL(blob);
        const a=document.createElement('a');
        a.href=url;
        a.download='meshtastic_config_backup.yaml';
        a.click();
        URL.revokeObjectURL(url);
        termAppendMod(t('💾 File meshtastic_config_backup.yaml scaricato'),'output');
    }else{
        termAppendMod(t('❌ Errore export config'),'error');
        if(d&&d.stderr)termAppendMod(d.stderr,'error');
    }
}

async function modImportConfig(){
    const fileInput=document.getElementById('mod-import-file');
    if(!fileInput||!fileInput.files||fileInput.files.length===0){
        showToast(t('⚠️ Seleziona un file YAML'));return;
    }
    const file=fileInput.files[0];
    if(!confirm(t('⚠️ IMPORT CONFIGURAZIONE')+`\n\nFile: ${file.name} (${(file.size/1024).toFixed(1)} KB)\n\n`+t('Questo SOVRASCRIVE TUTTA la configurazione attuale del nodo!')+`\n\n`+t('Confermi?'))){return;}
    
    termAppendMod(`\n📥 Import config da ${file.name}...`,'prompt');
    
    const text=await file.text();
    // Salva il file sul server per poi usare --configure
    const d=await apiFetch('mod/import-config',{method:'POST',body:JSON.stringify({yaml_content:text,filename:file.name})});
    if(d&&d.success){
        termAppendMod('✅ '+t(d.message),'output');
    }else{
        termAppendMod('❌ '+(d?.error||t('Errore import')),'error');
    }
}

async function modRawSet(){
    const path=(document.getElementById('mod-raw-path')?.value||'').trim();
    const value=(document.getElementById('mod-raw-value')?.value||'').trim();
    if(!path){showToast(t('⚠️ Inserisci il path del parametro'));return;}
    if(!value){showToast(t('⚠️ Inserisci il valore'));return;}
    await modSetAndVerify(path, value);
}

// ══════════════════════════════════════════════════════════════
// 🔧 SET + VERIFY + REBOOT — Il metodo forte
// ══════════════════════════════════════════════════════════════

async function modSetAndVerify(path, value, skipReboot) {
    // 1. SET
    termAppendMod(`\n⚡ SET: ${path} = ${value}`, 'prompt');
    await modExec(`--set ${path} ${value}`, 'mod');
    
    // 2. Pausa per lasciar scrivere il firmware
    await new Promise(r => setTimeout(r, 2000));
    
    // 3. VERIFY — leggi il valore appena scritto
    termAppendMod(t('🔍 Verifica...'), 'info');
    const d = await apiFetch('cli/exec', {
        method: 'POST',
        body: JSON.stringify({args: `--get ${path}`, timeout: 30, port: APP.selectedPort || ''})
    });
    
    if (d && d.stdout) {
        termAppendMod(d.stdout, 'output');
        
        // Controlla se il valore è stato applicato
        const output = d.stdout.toLowerCase();
        const setValue = value.toString().toLowerCase();
        
        if (output.includes(setValue) || output.includes(path.split('.').pop())) {
            // Check for clamping: value was set but firmware changed it
            const match = output.match(new RegExp(path.split('.').pop() + ':\\s*(.+)', 'i'));
            if (match) {
                const actualVal = match[1].trim();
                if (actualVal !== value && actualVal !== setValue) {
                    termAppendMod(t('⚠️ ATTENZIONE: hai impostato')+` ${value} `+t('ma il firmware ha applicato')+` ${actualVal}`, 'error');
                    termAppendMod(t('ℹ️ Il firmware ha dei limiti per la tua regione (EU_868: max 27 dBm, duty cycle 10%)'), 'info');
                    termAppendMod(t('ℹ️ Questo valore')+` (${actualVal}) `+t('è il massimo consentito dal firmware per la tua regione.'), 'info');
                    return false; // Clamped
                }
            }
        }
    }
    
    // 4. REBOOT se richiesto
    if (!skipReboot) {
        termAppendMod(t('🔄 Riavvio nodo per applicare le modifiche...'), 'info');
        await new Promise(r => setTimeout(r, 1000));
        await modExec('--reboot', 'mod');
        termAppendMod(t('✅ Nodo riavviato — la modifica è attiva.'), 'info');
    }
    return true;
}

function modRawGet(){
    const path=(document.getElementById('mod-raw-path')?.value||'').trim();
    if(!path){showToast(t('⚠️ Inserisci il path del parametro'));return;}
    modExec(`--get ${path}`,'mod');
}

async function modBatchExec(){
    const text=(document.getElementById('mod-raw-batch')?.value||'').trim();
    if(!text){showToast(t('⚠️ Inserisci almeno un comando'));return;}
    const lines=text.split('\n').map(l=>l.trim()).filter(l=>l&&!l.startsWith('#'));
    if(lines.length===0)return;
    
    const _preview=lines.slice(0,5).join('\n');
    const _moreText=lines.length>5?'\n... (+'+(lines.length-5)+' '+t('altri')+')':'';
    if(!confirm(t('⚠️ BATCH EXEC')+'\n\n'+t('Eseguirai')+' '+lines.length+' '+t('comandi in sequenza')+'.\n'+t('Alla fine il nodo verrà riavviato automaticamente per applicare TUTTE le modifiche.')+'\n\n'+_preview+_moreText+'\n\n'+t('Confermi?')))return;
    
    termAppendMod(`\n🔧 Batch: ${lines.length} comandi in sequenza`,'prompt');
    
    let setCount = 0;
    for(let i=0;i<lines.length;i++){
        let cmd=lines[i];
        if(cmd.startsWith('meshtastic '))cmd=cmd.replace('meshtastic ','');
        termAppendMod(`\n[${i+1}/${lines.length}] ${cmd}`,'prompt');
        
        const d=await apiFetch('cli/exec',{method:'POST',body:JSON.stringify({args:cmd,timeout:30,port:APP.selectedPort||''})});
        if(d){
            if(d.stdout)termAppendMod(d.stdout,'output');
            if(d.stderr)termAppendMod(d.stderr,'error');
            if(!d.stdout&&!d.stderr)termAppendMod(t('✅ OK'),'info');
        }else{
            termAppendMod(t('❌ Errore'),'error');
        }
        
        if(cmd.includes('--set'))setCount++;
        if(i<lines.length-1)await new Promise(r=>setTimeout(r,1500));
    }
    
    // Reboot automatico alla fine se ci sono stati dei --set
    if(setCount > 0){
        termAppendMod(`\n🔄 Riavvio nodo per applicare ${setCount} modifiche...`,'info');
        await new Promise(r=>setTimeout(r,1000));
        await modExec('--reboot','mod');
        termAppendMod('✅ Nodo riavviato — tutte le modifiche sono attive.','info');
        
        // Verifica dopo reboot
        termAppendMod(t('\n🔍 Verifica post-reboot (attendo avvio nodo 5s)...'),'info');
        await new Promise(r=>setTimeout(r,5000));
        await modExec('--get all','mod');
    }else{
        termAppendMod(`\n🏁 Batch completato: ${lines.length} comandi eseguiti`,'info');
    }
}

async function modEsptool(action){
    const port=APP.selectedPort;
    if(!port){showToast(t('⚠️ Seleziona una porta USB prima'));return;}
    
    let cmd='';
    let warn='';
    switch(action){
        case 'chip_id':
            cmd=`esptool.py --port ${port} chip_id`;
            break;
        case 'flash_id':
            cmd=`esptool.py --port ${port} flash_id`;
            break;
        case 'read_nvs':
            cmd=`esptool.py --port ${port} read_flash 0x9000 0x5000 nvs_backup.bin`;
            warn='Backup NVS (20KB) nella cartella dell\'app';
            break;
        case 'erase_flash':
            cmd=`esptool.py --port ${port} erase_flash`;
            warn=t('TUTTA la memoria flash verrà cancellata!');
            break;
    }
    
    if(warn){
        termAppendMod(`⚠️ ${warn}`,'error');
    }
    
    termAppendMod(`\n$ ${cmd}`,'prompt');
    termAppendMod('⏳ Esecuzione esptool...','info');
    
    const d=await apiFetch('system/exec',{method:'POST',body:JSON.stringify({command:cmd})});
    const _term=document.getElementById('mod-terminal');
    if(_term){const lines=_term.querySelectorAll('span');const last=lines[lines.length-1];if(last&&last.textContent.includes('⏳'))last.remove();}
    
    if(d){
        if(d.success){
            if(d.stdout)termAppendMod(d.stdout,'output');
        }else{
            termAppendMod(t(d.error||'❌ Errore esptool'),'error');
            if(d.stdout)termAppendMod(d.stdout,'output');
            if(!d.error||d.error.includes('not found')){
                termAppendMod(t('💡 Installa esptool: pip install esptool'),'info');
            }
        }
    }
    if(_term)_term.scrollTop=_term.scrollHeight;
}

async function modEsptoolCustom(){
    const args=(document.getElementById('mod-esptool-cmd')?.value||'').trim();
    if(!args){showToast(t('⚠️ Inserisci gli argomenti esptool'));return;}
    const cmd=`esptool.py ${args}`;
    termAppendMod(`\n$ ${cmd}`,'prompt');
    const d=await apiFetch('system/exec',{method:'POST',body:JSON.stringify({command:cmd})});
    if(d){
        if(d.stdout)termAppendMod(d.stdout,'output');
        if(d.stderr)termAppendMod(d.stderr,'error');
        if(!d.stdout&&!d.stderr&&d.error)termAppendMod(d.error,'error');
    }
}

// ══════════════════════════════════════════════════════════════
// 🧙 MOD WIZARD
// ══════════════════════════════════════════════════════════════

function wizToggle(id, show) {
    const el = document.getElementById(id);
    if (el) el.style.display = show ? 'block' : 'none';
}

function wizBuildCommands() {
    const cmds = [];
    const logoSteps = [];
    
    // Nome
    if (document.getElementById('wiz-name')?.checked) {
        const ln = document.getElementById('wiz-longname')?.value?.trim();
        const sn = document.getElementById('wiz-shortname')?.value?.trim();
        if (ln) cmds.push(`--set-owner "${ln}"`);
        if (sn) cmds.push(`--set-owner-short "${sn}"`);
    }
    
    // Node ID
    if (document.getElementById('wiz-id')?.checked) {
        const nid = document.getElementById('wiz-nodeid')?.value?.trim();
        if (nid) {
            const hex = nid.replace('!','');
            cmds.push(`--set device.node_id 0x${hex}`);
        }
    }
    
    // Ruolo
    if (document.getElementById('wiz-role')?.checked) {
        const role = document.getElementById('wiz-role-sel')?.value;
        if (role) cmds.push(`--set device.role ${role}`);
    }
    
    // TX Power
    if (document.getElementById('wiz-power')?.checked) {
        const pw = document.getElementById('wiz-power-sel')?.value;
        if (pw) cmds.push(`--set lora.tx_power ${pw}`);
    }
    
    // Regione
    if (document.getElementById('wiz-region')?.checked) {
        const reg = document.getElementById('wiz-region-sel')?.value;
        if (reg) cmds.push(`--set lora.region ${reg}`);
    }
    
    // ── Legacy / Firmware 2.7 fixes ──
    if (document.getElementById('wiz-telem')?.checked) {
        cmds.push('--set telemetry.device_update_interval 900');
        cmds.push('--set telemetry.environment_update_interval 900');
    }
    if (document.getElementById('wiz-mapReport')?.checked) {
        cmds.push('--set mqtt.map_report_enabled true');
    }
    if (document.getElementById('wiz-neighborInfo')?.checked) {
        cmds.push('--set neighbor_info.enabled true');
        cmds.push('--set neighbor_info.update_interval 900');
    }
    if (document.getElementById('wiz-timezone')?.checked) {
        cmds.push('--set device.tzdef CET-1CEST,M3.5.0,M10.5.0/3');
    }
    
    // Logo (genera istruzioni, non comandi CLI)
    if (document.getElementById('wiz-logo')?.checked) {
        const bt = document.getElementById('wiz-boottext')?.value?.trim() || '';
        const dev = document.getElementById('wiz-device')?.value || 'heltec-v3';
        logoSteps.push('# ══ LOGO PERSONALIZZATO (esegui nel tuo terminale) ══');
        logoSteps.push('pip install platformio');
        logoSteps.push('git clone https://github.com/meshtastic/firmware.git');
        logoSteps.push('cd firmware');
        logoSteps.push('# 1. Converti il tuo PNG (128x64, B/N) in XBM:');
        logoSteps.push('#    https://windows87.github.io/xbm-viewer-converter/');
        logoSteps.push('# 2. Copia il file XBM convertito:');
        logoSteps.push('#    cp tuo_logo.xbm src/graphics/img/icon.xbm');
        if (bt) {
            logoSteps.push(`# 3. In src/graphics/Screen.cpp cerca:`);
            logoSteps.push(`#    const char *title = "meshtastic.org";`);
            logoSteps.push(`#    Sostituisci con: const char *title = "${bt}";`);
        }
        logoSteps.push(`# Compila e flasha:`);
        logoSteps.push(`pio run -e ${dev}`);
        logoSteps.push(`pio run -e ${dev} --target upload`);
    }
    
    return { cmds, logoSteps };
}

function wizPreview() {
    const { cmds, logoSteps } = wizBuildCommands();
    const summary = document.getElementById('wiz-summary');
    const pre = document.getElementById('wiz-commands');
    
    if (cmds.length === 0 && logoSteps.length === 0) {
        pre.textContent = t('⚠️ Seleziona almeno una opzione e compila i campi!');
        summary.style.display = 'block';
        return;
    }
    
    let text = '';
    if (cmds.length > 0) {
        text += '# ══ COMANDI CLI (eseguiti automaticamente) ══\n';
        cmds.forEach(c => text += `meshtastic ${c}\n`);
    }
    if (logoSteps.length > 0) {
        if (text) text += '\n';
        text += logoSteps.join('\n') + '\n';
    }
    
    pre.textContent = text;
    summary.style.display = 'block';
}

async function wizExecute() {
    const { cmds, logoSteps } = wizBuildCommands();
    
    if (cmds.length === 0 && logoSteps.length === 0) {
        alert(t('Seleziona almeno una opzione e compila i campi!'));
        return;
    }
    
    if (!confirm(t('Verranno eseguiti')+` ${cmds.length} `+t('comandi CLI')+`.\n`+t('Dopo i comandi il nodo verrà riavviato automaticamente.')+`\n${logoSteps.length > 0 ? t('Le istruzioni per il logo verranno mostrate nel terminale.')+'\n' : ''}`+t('Continuare?'))) return;
    
    const _term = document.getElementById('mod-terminal');
    if (!_term) return;
    
    // Show logo instructions in terminal
    if (logoSteps.length > 0) {
        logoSteps.forEach(step => {
            const span = document.createElement('span');
            span.className = step.startsWith('#') ? 'info' : 'prompt';
            span.textContent = step;
            _term.appendChild(span);
        });
    }
    
    // Execute CLI commands sequentially (WITHOUT reboot after each - reboot at end)
    let setCount = 0;
    for (let i = 0; i < cmds.length; i++) {
        const cmd = cmds[i];
        const span = document.createElement('span');
        span.className = 'prompt';
        span.textContent = `[${i+1}/${cmds.length}] meshtastic ${cmd}`;
        _term.appendChild(span);
        _term.scrollTop = _term.scrollHeight;
        
        await modExec(cmd, 'mod');
        if (cmd.includes('--set')) setCount++;
        
        if (i < cmds.length - 1) {
            await new Promise(r => setTimeout(r, 2000));
        }
    }
    
    // Single reboot at the end to apply ALL changes
    if (setCount > 0) {
        const rSpan = document.createElement('span');
        rSpan.className = 'info';
        rSpan.textContent = t('🔄 Riavvio nodo per applicare') + ` ${setCount} ` + t('modifiche...');
        _term.appendChild(rSpan);
        
        await new Promise(r => setTimeout(r, 1000));
        await modExec('--reboot', 'mod');
        
        // Wait for node to come back
        const waitSpan = document.createElement('span');
        waitSpan.className = 'info';
        waitSpan.textContent = t('⏳ Attendo riavvio nodo (5 secondi)...');
        _term.appendChild(waitSpan);
        await new Promise(r => setTimeout(r, 5000));
        
        // Verify all changes
        const vSpan = document.createElement('span');
        vSpan.className = 'info';
        vSpan.textContent = t('🔍 Verifica configurazione post-reboot...');
        _term.appendChild(vSpan);
        await modExec('--get all', 'mod');
    }
    
    const done = document.createElement('span');
    done.className = 'info';
    done.textContent = t('✅ Wizard completato!') + ` ${cmds.length} ` + t('comandi eseguiti + reboot + verifica.');
    _term.appendChild(done);
    _term.scrollTop = _term.scrollHeight;
}

// ══════════════════════════════════════════════════════════════
// 🔓 SBLOCCA LIMITI FIRMWARE — Sequenze corrette con reboot
// ══════════════════════════════════════════════════════════════

async function unlockTxPower() {
    const power = document.getElementById('unlock-txpower')?.value || '30';
    
    if (!confirm(
        t('⚠️ SBLOCCO TX POWER A')+` ${power} dBm\n\n` +
        t('Questa operazione:')+`\n` +
        t('1. Attiva modalità HAM (is_licensed=true)')+`\n` +
        t('2. DISABILITA la crittografia E2E!')+`\n` +
        t('3. Riavvia il nodo')+`\n` +
        `4. `+t('Imposta TX power a')+` ${power} dBm\n` +
        t('5. Riavvia di nuovo per applicare')+`\n` +
        t('6. Verifica il valore effettivo')+`\n\n` +
        t('⚠️ I tuoi messaggi saranno in CHIARO!')+`\n` +
        t('⚠️ Oltre 27 dBm è ILLEGALE in EU senza licenza HAM!')+`\n\n` +
        t('Confermi?')
    )) return;
    
    termAppendMod('\n'+t('🔓 ═══ SBLOCCO TX POWER ═══'), 'prompt');
    
    // Step 1: Attiva is_licensed
    termAppendMod(t('\n[1/6] Attivazione modalità HAM (is_licensed=true)...'), 'info');
    await modExec('--set device.is_licensed true', 'mod');
    await new Promise(r => setTimeout(r, 2000));
    
    // Step 2: Primo reboot (il firmware deve leggere is_licensed al boot)
    termAppendMod('\n[2/6] Primo reboot (necessario per attivare HAM)...', 'info');
    await modExec('--reboot', 'mod');
    
    // Step 3: Attendi che il nodo torni online
    termAppendMod('\n[3/6] Attendo riavvio nodo (8 secondi)...', 'info');
    await new Promise(r => setTimeout(r, 8000));
    
    // Step 4: Ora imposta TX power (il firmware non clamperà perché is_licensed è attivo)
    termAppendMod(`\n[4/6] Impostazione TX power a ${power} dBm...`, 'info');
    await modExec(`--set lora.tx_power ${power}`, 'mod');
    await new Promise(r => setTimeout(r, 2000));
    
    // Step 5: Secondo reboot per applicare
    termAppendMod('\n[5/6] Secondo reboot per applicare TX power...', 'info');
    await modExec('--reboot', 'mod');
    await new Promise(r => setTimeout(r, 8000));
    
    // Step 6: Verifica
    termAppendMod(t('\n[6/6] Verifica valori effettivi...'), 'info');
    await modExec('--get lora.tx_power', 'mod');
    await new Promise(r => setTimeout(r, 1500));
    await modExec('--get device.is_licensed', 'mod');
    
    termAppendMod('\n🔓 ═══ SBLOCCO TX POWER COMPLETATO ═══', 'prompt');
    termAppendMod(t('⚠️ Ricorda: la crittografia E2E è ORA DISABILITATA'), 'error');
    termAppendMod(t('Per ripristinare: usa il pulsante "Ripristina limiti"'), 'info');
}

async function relockTxPower() {
    if (!confirm(
        t('Ripristino limiti:')+`\n\n` +
        t('1. Disattiva modalità HAM')+`\n` +
        t('2. Riporta TX power a 27 dBm')+`\n` +
        t('3. Riattiva la crittografia E2E')+`\n\n` +
        t('Confermi?')
    )) return;
    
    termAppendMod('\n'+t('🔒 ═══ RIPRISTINO LIMITI ═══'), 'prompt');
    
    await modExec('--set device.is_licensed false', 'mod');
    await new Promise(r => setTimeout(r, 1500));
    await modExec('--set lora.tx_power 27', 'mod');
    await new Promise(r => setTimeout(r, 1500));
    
    termAppendMod('\n🔄 Reboot per applicare...', 'info');
    await modExec('--reboot', 'mod');
    await new Promise(r => setTimeout(r, 8000));
    
    termAppendMod(t('\n🔍 Verifica...'), 'info');
    await modExec('--get lora.tx_power', 'mod');
    await new Promise(r => setTimeout(r, 1500));
    await modExec('--get device.is_licensed', 'mod');
    
    termAppendMod('\n🔒 ═══ LIMITI RIPRISTINATI ═══', 'prompt');
    termAppendMod('✅ Crittografia E2E riattivata', 'info');
}

async function unlockDutyCycle(enable) {
    const val = enable ? 'true' : 'false';
    const msg = enable
        ? t('⚠️ SBLOCCO DUTY CYCLE')+'\n\n'+t('Il nodo potrà trasmettere senza il limite del 10%.')+'\n'+t('Questo viola la normativa ETSI EN 300 220.')+'\n\n'+t('Confermi?')
        : t('Ripristina il duty cycle al 10% standard.')+'\n\n'+t('Confermi?');
    
    if (!confirm(msg)) return;
    
    termAppendMod(`\n${enable?'🔓':'🔒'} ${enable?'Sblocco':'Ripristino'} duty cycle...`, 'prompt');
    await modExec(`--set lora.override_duty_cycle ${val}`, 'mod');
    await new Promise(r => setTimeout(r, 2000));
    
    termAppendMod(t('🔄 Reboot per applicare...'), 'info');
    await modExec('--reboot', 'mod');
    await new Promise(r => setTimeout(r, 8000));
    
    termAppendMod('🔍 Verifica...', 'info');
    await modExec('--get lora.override_duty_cycle', 'mod');
    
    termAppendMod(`\n✅ Duty cycle ${enable?'SBLOCCATO — trasmissione continua':'RIPRISTINATO — limite 10%'}`, 'info');
}

async function unlockManualRadio(enable) {
    if (enable) {
        const bw = document.getElementById('unlock-bw')?.value || '250';
        const sf = document.getElementById('unlock-sf')?.value || '11';
        const cr = document.getElementById('unlock-cr')?.value || '5';
        
        if (!confirm(
            t('⚠️ RADIO MANUALE')+`\n\n` +
            t('Parametri')+`: BW=${bw}kHz, SF${sf}, CR=4/${cr}\n\n` +
            t('Il nodo NON comunicherà più con chi usa preset standard!')+`\n` +
            t('Tutti i nodi della rete devono avere gli stessi parametri.')+`\n\n` +
            t('Confermi?')
        )) return;
        
        termAppendMod('\n'+t('🔓 ═══ RADIO MANUALE ═══'), 'prompt');
        
        await modExec('--set lora.use_preset false', 'mod');
        await new Promise(r => setTimeout(r, 1500));
        await modExec(`--set lora.bandwidth ${bw}`, 'mod');
        await new Promise(r => setTimeout(r, 1500));
        await modExec(`--set lora.spread_factor ${sf}`, 'mod');
        await new Promise(r => setTimeout(r, 1500));
        await modExec(`--set lora.coding_rate ${cr}`, 'mod');
        await new Promise(r => setTimeout(r, 1500));
        
        termAppendMod('🔄 Reboot per applicare...', 'info');
        await modExec('--reboot', 'mod');
        await new Promise(r => setTimeout(r, 8000));
        
        termAppendMod('🔍 Verifica...', 'info');
        await modExec('--get lora', 'mod');
        
        termAppendMod(`\n✅ Radio manuale: BW=${bw}, SF${sf}, CR=4/${cr}`, 'info');
        termAppendMod('⚠️ Incompatibile con preset standard della mesh!', 'error');
    } else {
        if (!confirm(t('Torna al preset MediumFast standard?')+'\n\n'+t('Confermi?'))) return;
        
        termAppendMod('\n🔒 Ripristino preset MediumFast...', 'prompt');
        await modExec('--set lora.use_preset true', 'mod');
        await new Promise(r => setTimeout(r, 1500));
        await modExec('--set lora.modem_preset MEDIUM_FAST', 'mod');
        await new Promise(r => setTimeout(r, 1500));
        
        termAppendMod('🔄 Reboot per applicare...', 'info');
        await modExec('--reboot', 'mod');
        await new Promise(r => setTimeout(r, 8000));
        
        await modExec('--get lora', 'mod');
        termAppendMod('\n✅ Preset MediumFast ripristinato', 'info');
    }
}

async function unlockFrequency() {
    const freq = parseFloat(document.getElementById('unlock-freq')?.value || '0');
    if (!freq || freq < 100) {
        showToast(t('⚠️ Inserisci una frequenza valida (es. 869.525)'));
        return;
    }
    
    if (!confirm(
        t('⚠️ OVERRIDE FREQUENZA:')+` ${freq} MHz\n\n` +
        t('Il nodo trasmetterà su')+` ${freq} MHz `+t('indipendentemente dalla regione.')+`\n` +
        t('Trasmettere fuori dalla banda 868 MHz in EU è un REATO PENALE.')+`\n` +
        t('Il chip deve supportare fisicamente questa frequenza.')+`\n\n` +
        t('Confermi?')
    )) return;
    
    termAppendMod(`\n🔓 Override frequenza a ${freq} MHz...`, 'prompt');
    await modExec(`--set lora.override_frequency ${freq}`, 'mod');
    await new Promise(r => setTimeout(r, 2000));
    
    termAppendMod('🔄 Reboot per applicare...', 'info');
    await modExec('--reboot', 'mod');
    await new Promise(r => setTimeout(r, 8000));
    
    termAppendMod('🔍 Verifica...', 'info');
    await modExec('--get lora.override_frequency', 'mod');
    
    termAppendMod(`\n✅ Frequenza override: ${freq} MHz`, 'info');
}

// ══════════════════════════════════════════════════════════════
// 🔨 FIRMWARE CUSTOM BUILDER — Genera script PlatformIO
// ══════════════════════════════════════════════════════════════

function generateFirmwareScript() {
    const device = document.getElementById('fw-device')?.value || 'heltec-v3';
    const power = document.getElementById('fw-power')?.value || '30';
    const boottext = document.getElementById('fw-boottext')?.value?.trim() || '';
    const dutyOverride = document.getElementById('fw-duty')?.value === 'yes';
    
    const isWin = navigator.platform.indexOf('Win') > -1;
    const comment = isWin ? 'REM' : '#';
    const nl = '\n';
    
    let script = '';
    
    script += `${comment} ════════════════════════════════════════════════════════${nl}`;
    script += `${comment}  MESHTASTIC CUSTOM FIRMWARE BUILDER${nl}`;
    script += `${comment}  Generato da Meshtastic Italia Network App v1.1.0${nl}`;
    script += `${comment}  Dispositivo: ${device} | TX Power: ${power} dBm${nl}`;
    script += `${comment}  © 2026 MANGOLINK${nl}`;
    script += `${comment} ════════════════════════════════════════════════════════${nl}${nl}`;
    
    script += `${comment} STEP 1: Installa prerequisiti${nl}`;
    script += `pip install platformio${nl}`;
    script += `${nl}`;
    
    script += `${comment} STEP 2: Clona il firmware ufficiale Meshtastic${nl}`;
    script += `git clone https://github.com/meshtastic/firmware.git${nl}`;
    script += `cd firmware${nl}`;
    script += `git submodule update --init --recursive${nl}`;
    script += `${nl}`;
    
    script += `${comment} STEP 3: PATCH — Modifica power_limit EU868 da 27 a ${power}${nl}`;
    script += `${comment} File: src/mesh/RadioInterface.cpp${nl}`;
    script += `${comment} Cerca la riga: RDEF(EU868, 869.4f, 869.65f, 10, 0, 27, false, false, false)${nl}`;
    script += `${comment} Sostituisci 27 con ${power}${nl}`;
    
    if (isWin) {
        script += `powershell -Command "(Get-Content src\\mesh\\RadioInterface.cpp) -replace 'RDEF\\(EU868, 869.4f, 869.65f, 10, 0, 27,', 'RDEF(EU868, 869.4f, 869.65f, 10, 0, ${power},' | Set-Content src\\mesh\\RadioInterface.cpp"${nl}`;
    } else {
        script += `sed -i 's/RDEF(EU868, 869.4f, 869.65f, 10, 0, 27,/RDEF(EU868, 869.4f, 869.65f, 10, 0, ${power},/g' src/mesh/RadioInterface.cpp${nl}`;
    }
    script += `${nl}`;
    
    if (dutyOverride) {
        script += `${comment} STEP 3b: PATCH — Rimuovi duty cycle limit${nl}`;
        script += `${comment} Nella stessa riga RDEF, il primo numero dopo la frequenza (10) è il duty cycle %${nl}`;
        script += `${comment} Cambiarlo a 100 = nessun limite${nl}`;
        if (isWin) {
            script += `powershell -Command "(Get-Content src\\mesh\\RadioInterface.cpp) -replace 'RDEF\\(EU868, 869.4f, 869.65f, 10, 0, ${power},', 'RDEF(EU868, 869.4f, 869.65f, 100, 0, ${power},' | Set-Content src\\mesh\\RadioInterface.cpp"${nl}`;
        } else {
            script += `sed -i 's/RDEF(EU868, 869.4f, 869.65f, 10, 0, ${power},/RDEF(EU868, 869.4f, 869.65f, 100, 0, ${power},/g' src/mesh/RadioInterface.cpp${nl}`;
        }
        script += `${nl}`;
    }
    
    if (boottext) {
        script += `${comment} STEP 3c: PATCH — Cambia testo boot${nl}`;
        if (isWin) {
            script += `powershell -Command "(Get-Content src\\graphics\\Screen.cpp) -replace 'const char \\*title = \\x22meshtastic.org\\x22', 'const char *title = \\x22${boottext}\\x22' | Set-Content src\\graphics\\Screen.cpp"${nl}`;
        } else {
            script += `sed -i 's/const char \\*title = "meshtastic.org"/const char *title = "${boottext}"/g' src/graphics/Screen.cpp${nl}`;
        }
        script += `${nl}`;
    }
    
    script += `${comment} STEP 4: VERIFICA — Controlla che la patch sia applicata${nl}`;
    if (isWin) {
        script += `findstr "RDEF(EU868" src\\mesh\\RadioInterface.cpp${nl}`;
    } else {
        script += `grep "RDEF(EU868" src/mesh/RadioInterface.cpp${nl}`;
    }
    script += `${comment} Dovresti vedere: RDEF(EU868, 869.4f, 869.65f, ${dutyOverride?'100':'10'}, 0, ${power}, ...)${nl}`;
    script += `${nl}`;
    
    script += `${comment} STEP 5: COMPILA per ${device}${nl}`;
    script += `${comment} Questo scarica il toolchain (la prima volta richiede ~5 min)${nl}`;
    script += `pio run -e ${device}${nl}`;
    script += `${nl}`;
    
    script += `${comment} STEP 6: FLASHA sul dispositivo (collega USB prima!)${nl}`;
    script += `pio run -e ${device} --target upload${nl}`;
    script += `${nl}`;
    
    script += `${comment} STEP 7: VERIFICA — Dopo il flash, apri un terminale e controlla:${nl}`;
    script += `${comment} meshtastic --get lora.tx_power${nl}`;
    script += `${comment} Imposta il nuovo valore:${nl}`;
    script += `${comment} meshtastic --set lora.tx_power ${power}${nl}`;
    script += `${comment} meshtastic --reboot${nl}`;
    script += `${comment} meshtastic --get lora.tx_power${nl}`;
    script += `${comment} Se vedi ${power} = FUNZIONA!${nl}`;
    script += `${nl}`;
    
    script += `${comment} ════════════════════════════════════════════════════════${nl}`;
    script += `${comment} ATTENZIONE LEGALE:${nl}`;
    script += `${comment} TX power oltre 27 dBm in EU senza licenza HAM = ILLEGALE${nl}`;
    script += `${comment} D.Lgs 259/2003, sanzioni da 15.000 euro${nl}`;
    script += `${comment} L'utente è l'unico responsabile dell'uso${nl}`;
    script += `${comment} ════════════════════════════════════════════════════════${nl}`;
    
    // Show output
    const output = document.getElementById('fw-script-output');
    const pre = document.getElementById('fw-script-text');
    if (output && pre) {
        pre.textContent = script;
        output.style.display = 'block';
    }
    
    // Also show in MOD terminal
    termAppendMod('\n🔨 ═══ FIRMWARE CUSTOM SCRIPT GENERATO ═══', 'prompt');
    termAppendMod(`Dispositivo: ${device} | Power: ${power} dBm | Duty: ${dutyOverride?'OVERRIDE':'10%'}${boottext?' | Boot: '+boottext:''}`, 'info');
    termAppendMod(t('Lo script è visibile sopra. Copialo e incollalo nel tuo terminale.'), 'info');
    termAppendMod('⚠️ Devi avere Git e PlatformIO installati!', 'error');
    
    return script;
}

function copyFirmwareScript() {
    const pre = document.getElementById('fw-script-text');
    if (!pre || !pre.textContent) {
        showToast(t('⚠️ Prima genera lo script!'));
        return;
    }
    navigator.clipboard.writeText(pre.textContent).then(() => {
        showToast(t('✅ Script copiato negli appunti!'));
    }).catch(() => {
        // Fallback
        const ta = document.createElement('textarea');
        ta.value = pre.textContent;
        document.body.appendChild(ta);
        ta.select();
        document.execCommand('copy');
        document.body.removeChild(ta);
        showToast(t('✅ Script copiato!'));
    });
}

// ══════════════════════════════════════════════════════════════
// 🔍 AUTO-DETECT DISPOSITIVO — Legge --info e mappa hwModel
// ══════════════════════════════════════════════════════════════

const HW_MODEL_MAP = {
    // hwModel string → { pio: PlatformIO env, chip: radio chip, maxHwPower: max fisico dBm, pa: ha PA esterno }
    'HELTEC_V3':           { pio: 'heltec-v3',             chip: 'SX1262', maxHw: 22, pa: false },
    'HELTEC_V4':           { pio: 'heltec-v4',             chip: 'SX1262', maxHw: 30, pa: true, paNote: 'GC1109 PA' },
    'HELTEC_WIRELESS_TRACKER': { pio: 'heltec-wireless-tracker', chip: 'SX1262', maxHw: 22, pa: false },
    'HELTEC_WIRELESS_TRACKER_V2': { pio: 'heltec-wireless-tracker-V2', chip: 'SX1262', maxHw: 30, pa: true },
    'TBEAM':               { pio: 'tbeam',                 chip: 'SX1276', maxHw: 20, pa: false },
    'T_BEAM_S3_CORE':      { pio: 'tbeam-s3-core',         chip: 'SX1262', maxHw: 22, pa: false },
    'TLORA_V2_1_1_6':      { pio: 'tlora-v2-1-1_6',        chip: 'SX1262', maxHw: 22, pa: false },
    'T_DECK':              { pio: 't-deck',                 chip: 'SX1262', maxHw: 22, pa: false },
    'T_DECK_PLUS':         { pio: 't-deck-plus',            chip: 'SX1262', maxHw: 22, pa: false },
    'T_WATCH_S3':          { pio: 't-watch-s3',             chip: 'SX1262', maxHw: 22, pa: false },
    'STATION_G2':          { pio: 'station-g2',             chip: 'SX1262', maxHw: 33, pa: true, paNote: 'PA integrato 5W' },
    'RAK4631':             { pio: 'rak4631',                chip: 'SX1262', maxHw: 22, pa: false },
    'RAK11310':            { pio: 'rak11310',               chip: 'SX1262', maxHw: 22, pa: false },
    'WISMESH_TAP':         { pio: 'wismesh-tap',            chip: 'SX1262', maxHw: 22, pa: false },
    'NANO_G2_ULTRA':       { pio: 'nano-g2-ultra',          chip: 'SX1262', maxHw: 22, pa: false },
    'T_ECHO':              { pio: 't-echo',                 chip: 'SX1262', maxHw: 22, pa: false },
    'SENSECAP_INDICATOR':  { pio: 'seeed-sensecap-indicator',chip: 'SX1262', maxHw: 22, pa: false },
    'WIPHONE':             { pio: 'wiphone',                chip: 'SX1276', maxHw: 20, pa: false },
    'THINKNODE_M1':        { pio: 'thinknode-m1',           chip: 'SX1262', maxHw: 22, pa: false },
    'THINKNODE_M2':        { pio: 'thinknode-m2',           chip: 'SX1262', maxHw: 22, pa: false },
    'MUZI_R1_NEO':         { pio: 'muzi-r1-neo',            chip: 'SX1262', maxHw: 22, pa: false },
    'CANARY_ONE':          { pio: 'canary-one',             chip: 'SX1262', maxHw: 22, pa: false },
};

// Parametri bloccati dal firmware C++ (non modificabili via CLI)
const FW_CLAMPED_PARAMS = {
    'lora.tx_power': {
        clampedBy: 'RDEF power_limit in RadioInterface.cpp',
        euLimit: 27,
        bypass: 'Firmware custom con PlatformIO (modifica RDEF)',
        cliBypass: false
    },
    'lora.bandwidth': {
        clampedBy: 'bootstrapLoRaConfigFromPreset in NodeDB.cpp (se use_preset=true)',
        bypass: '--set lora.use_preset false prima di modificare',
        cliBypass: true
    },
    'lora.spread_factor': {
        clampedBy: 'bootstrapLoRaConfigFromPreset in NodeDB.cpp (se use_preset=true)',
        bypass: '--set lora.use_preset false prima di modificare',
        cliBypass: true
    },
    'lora.coding_rate': {
        clampedBy: 'bootstrapLoRaConfigFromPreset in NodeDB.cpp (se use_preset=true)',
        bypass: '--set lora.use_preset false prima di modificare',
        cliBypass: true
    },
};

async function autoDetectDevice() {
    termAppendMod('\n🔍 ═══ AUTO-DETECT DISPOSITIVO ═══', 'prompt');
    termAppendMod('Lettura info dal nodo...', 'info');
    
    const d = await apiFetch('cli/exec', {
        method: 'POST',
        body: JSON.stringify({args: '--info', timeout: 30, port: APP.selectedPort || ''})
    });
    
    if (!d || !d.stdout) {
        termAppendMod('❌ Impossibile leggere info dal nodo. Collega il dispositivo e seleziona la porta.', 'error');
        return null;
    }
    
    const output = d.stdout;
    termAppendMod(output, 'output');
    
    // Parse hwModel
    const hwMatch = output.match(/Hardware Model:\s*(\S+)/i) || output.match(/hwModel[=:\s]+(\S+)/i);
    const fwMatch = output.match(/Firmware Version:\s*([\d.]+)/i) || output.match(/firmware_version[=:\s]+([\d.]+)/i);
    const regionMatch = output.match(/lora\.region[=:\s]+(\S+)/i) || output.match(/Region:\s*(\S+)/i);
    const nodeMatch = output.match(/Num:\s*(0x[0-9a-fA-F]+)/i) || output.match(/my_node_num[=:\s]+(\d+)/i);
    const nameMatch = output.match(/Owner:\s*(.+)/i) || output.match(/long_name[=:\s]+(.+)/i);
    
    const hwModel = hwMatch ? hwMatch[1].toUpperCase().replace(/-/g, '_') : 'UNKNOWN';
    const fwVersion = fwMatch ? fwMatch[1] : 'unknown';
    const region = regionMatch ? regionMatch[1] : 'EU_868';
    const nodeName = nameMatch ? nameMatch[1].trim() : '';
    
    // Lookup in map
    const hwInfo = HW_MODEL_MAP[hwModel] || null;
    
    termAppendMod('\n📋 ═══ RISULTATO RILEVAMENTO ═══', 'prompt');
    termAppendMod(`📟 Modello: ${hwModel}`, 'info');
    termAppendMod(`📦 Firmware: ${fwVersion}`, 'info');
    termAppendMod(`🌍 Regione: ${region}`, 'info');
    if (nodeName) termAppendMod(`👤 Nome: ${nodeName}`, 'info');
    
    if (hwInfo) {
        termAppendMod(`🔧 PlatformIO env: ${hwInfo.pio}`, 'info');
        termAppendMod(`📡 Chip radio: ${hwInfo.chip}`, 'info');
        termAppendMod(`⚡ Max potenza hardware: ${hwInfo.maxHw} dBm${hwInfo.pa ? ' (con '+hwInfo.paNote+')' : ' (senza PA)'}`, 'info');
        
        // Auto-select in firmware builder dropdown
        const fwDevSelect = document.getElementById('fw-device');
        if (fwDevSelect) {
            for (let opt of fwDevSelect.options) {
                if (opt.value === hwInfo.pio) {
                    fwDevSelect.value = hwInfo.pio;
                    termAppendMod(`✅ Dispositivo auto-selezionato nel Firmware Builder: ${hwInfo.pio}`, 'info');
                    break;
                }
            }
        }
        
        // Warning about real power limits
        if (!hwInfo.pa && region.includes('EU')) {
            termAppendMod(`\n⚠️ ATTENZIONE: ${hwModel} con ${hwInfo.chip} ha un massimo FISICO di ${hwInfo.maxHw} dBm.`, 'error');
            termAppendMod(`Anche con firmware custom, il chip non può emettere più di ${hwInfo.maxHw} dBm.`, 'error');
            termAppendMod(`Per superare ${hwInfo.maxHw} dBm serve un dispositivo con PA esterno (RAK 1W, Station G2).`, 'info');
        }
    } else {
        termAppendMod(`⚠️ Modello ${hwModel} non nella mappa. Seleziona manualmente nel Firmware Builder.`, 'error');
    }
    
    // Check clamped params
    termAppendMod('\n📋 ═══ PARAMETRI BLOCCATI DAL FIRMWARE ═══', 'prompt');
    for (const [param, info] of Object.entries(FW_CLAMPED_PARAMS)) {
        const icon = info.cliBypass ? '🟡' : '🔴';
        termAppendMod(`${icon} ${param}: ${info.clampedBy}`, info.cliBypass ? 'info' : 'error');
        termAppendMod(`   Bypass: ${info.bypass}`, 'info');
    }
    
    return { hwModel, hwInfo, fwVersion, region, nodeName };
}
