# -*- coding: utf-8 -*-
"""
📡 Meshtastic Italia Network App v1.1.0 — Server Flask
API REST + Sistema Licenze Ed25519 + MOD Firmware + localhost:5555
© 2026 🌐🥭MANGOLINK🥭🌐 — Tutti i diritti riservati
"""

import os
import json
from flask import Flask, render_template, jsonify, request, send_from_directory
try:
    from flask_cors import CORS
except ImportError:
    CORS = None

from app.system_utils import (
    detect_os, get_os_info, list_serial_ports,
    check_driver_installed, check_python_info, open_url
)
from app.config_generator import (
    generate_auto_config, generate_cli_commands,
    generate_qr_code, validate_params, get_script_completo,
    generate_channel_url
)
from app.network_params import (
    NETWORK_CONFIG, CHANNELS, AUTOCONFIG_URL, DEVICE_ROLES,
    MODEM_PRESETS, DRIVER_LINKS, SUPPORTED_DEVICES, LINKS,
    FIRMWARE_INFO, BOOTLOADER_METHODS, DEPRECATED_ROLES
)
from app.license_manager import (
    generate_fingerprint, get_license_info, reload_license, get_license_path,
    diagnose_license, reset_license_cache
)

APP_VERSION = "1.1.3"

# ═══════════════════════════════════════════════════════════
# INIZIALIZZAZIONE APP
# ═══════════════════════════════════════════════════════════

# Path base = stessa cartella di server.py (struttura flat)
_base_dir = os.path.dirname(os.path.abspath(__file__))

app = Flask(
    __name__,
    static_folder=_base_dir,
    static_url_path='/static',
    template_folder=_base_dir
)
app.config['SECRET_KEY'] = os.urandom(32).hex()  # Random per sessione (localhost only)
if CORS:
    CORS(app)

# ═══════════════════════════════════════════════════════════
# PAGINA PRINCIPALE
# ═══════════════════════════════════════════════════════════

@app.route('/')
def index():
    """Serve la pagina HTML principale"""
    return render_template('index.html')

# ═══════════════════════════════════════════════════════════
# API SISTEMA
# ═══════════════════════════════════════════════════════════

@app.route('/api/system/info', methods=['GET'])
def api_system_info():
    """Info complete sul sistema: OS, Python, pip, meshtastic CLI"""
    return jsonify({
        "os": get_os_info(),
        "python": check_python_info(),
        "drivers": check_driver_installed(),
    })

@app.route('/api/system/ports', methods=['GET'])
def api_system_ports():
    """Lista porte seriali USB disponibili"""
    return jsonify({"ports": list_serial_ports()})

@app.route('/api/system/drivers', methods=['GET'])
def api_system_drivers():
    """Check driver USB installati + link download"""
    return jsonify({
        "installed": check_driver_installed(),
        "download_links": DRIVER_LINKS,
    })

@app.route('/api/deps/check', methods=['GET'])
def api_deps_check():
    """Verifica TUTTE le dipendenze Python richieste dall'app"""
    import sys
    deps = [
        {"module": "flask",        "pip": "flask",        "label": "Flask (web server)",        "required": True},
        {"module": "flask_cors",   "pip": "flask-cors",   "label": "Flask-CORS",                "required": True},
        {"module": "serial",       "pip": "pyserial",     "label": "PySerial (USB)",             "required": True},
        {"module": "meshtastic",   "pip": "meshtastic",   "label": "Meshtastic CLI + API",       "required": True},
        {"module": "cryptography", "pip": "cryptography", "label": "Cryptography (licenze)",     "required": True},
        {"module": "qrcode",       "pip": "qrcode[pil]",  "label": "QR Code",                    "required": True},
        {"module": "PIL",          "pip": "Pillow",       "label": "Pillow (immagini)",           "required": True},
        {"module": "esptool",      "pip": "esptool",      "label": "ESPTool (flash ESP32)",       "required": False},
    ]
    results = []
    for dep in deps:
        try:
            mod = __import__(dep["module"])
            version = getattr(mod, '__version__', getattr(mod, 'VERSION', '?'))
            results.append({**dep, "installed": True, "version": str(version)})
        except ImportError:
            results.append({**dep, "installed": False, "version": None})

    # Info Python + pip
    py_version = f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"
    pip_ok = False
    pip_version = None
    try:
        r = subprocess.run([sys.executable, '-m', 'pip', '--version'],
                           capture_output=True, text=True, timeout=10,
                           encoding='utf-8', errors='replace')
        if r.returncode == 0:
            pip_ok = True
            pip_version = (r.stdout or '').split(' ')[1] if r.stdout else '?'
    except Exception:
        pass

    all_required_ok = all(d["installed"] for d in results if d["required"])
    missing_required = [d for d in results if d["required"] and not d["installed"]]

    return jsonify({
        "python_version": py_version,
        "python_path": sys.executable,
        "pip_available": pip_ok,
        "pip_version": pip_version,
        "all_ok": all_required_ok,
        "missing_count": len(missing_required),
        "deps": results,
    })

@app.route('/api/deps/install', methods=['POST'])
def api_deps_install():
    """Installa TUTTE le dipendenze mancanti o un pacchetto specifico"""
    import sys
    data = request.get_json() or {}
    package = data.get("package", "")  # Pacchetto singolo, oppure vuoto = tutti

    ALLOWED = {"meshtastic", "flask", "flask-cors", "pyserial", "cryptography",
               "qrcode", "qrcode[pil]", "Pillow", "esptool", ""}
    if package and package not in ALLOWED:
        return jsonify({"success": False, "error": f"Pacchetto non consentito: {package}"}), 403

    import platform as _plat
    env = {**os.environ, 'PYTHONIOENCODING': 'utf-8'}
    base_kwargs = dict(
        capture_output=True, text=True,
        timeout=300,
        env=env,
        encoding='utf-8',
        errors='replace'
    )
    if _plat.system() == 'Windows':
        base_kwargs['creationflags'] = getattr(subprocess, 'CREATE_NO_WINDOW', 0)

    if package:
        # Installa singolo pacchetto
        packages = [package]
    else:
        # Installa tutti i mancanti da requirements.txt
        req_file = os.path.join(os.path.dirname(__file__), "requirements.txt")
        if os.path.exists(req_file):
            packages = ["-r", req_file]
        else:
            packages = ["flask", "flask-cors", "pyserial", "meshtastic",
                        "cryptography", "qrcode[pil]", "Pillow"]

    results = []
    try:
        # Tentativo 1: installazione normale
        cmd = [sys.executable, '-m', 'pip', 'install', '--upgrade'] + packages
        result = subprocess.run(cmd, **base_kwargs)
        stdout = (result.stdout or '').strip()
        stderr = (result.stderr or '').strip()

        if result.returncode == 0:
            return jsonify({
                "success": True,
                "stdout": stdout,
                "stderr": stderr,
                "method": "standard",
            })

        # Tentativo 2: con --user
        cmd_user = [sys.executable, '-m', 'pip', 'install', '--user', '--upgrade'] + packages
        result2 = subprocess.run(cmd_user, **base_kwargs)
        stdout2 = (result2.stdout or '').strip()
        stderr2 = (result2.stderr or '').strip()

        if result2.returncode == 0:
            return jsonify({
                "success": True,
                "stdout": stdout2,
                "stderr": stderr2,
                "method": "--user",
            })

        return jsonify({
            "success": False,
            "error": stderr or stderr2 or stdout or stdout2 or "Installazione fallita senza dettagli",
            "stdout": stdout or stdout2,
            "stderr": stderr or stderr2,
        })
    except subprocess.TimeoutExpired:
        return jsonify({"success": False, "error": "Timeout (300s) — connessione molto lenta"}), 504
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500

@app.route('/api/system/open-url', methods=['POST'])
def api_system_open_url():
    """Apre un URL nel browser dell'utente"""
    data = request.get_json()
    url = data.get("url", "")
    if url:
        success = open_url(url)
        return jsonify({"success": success, "url": url})
    return jsonify({"success": False, "error": "URL mancante"}), 400

@app.route('/api/system/exec', methods=['POST'])
def api_system_exec():
    """Esegue un comando di sistema con output REALE e timing"""
    import time as _time
    data = request.get_json() or {}
    cmd = data.get("command", "").strip()
    if not cmd:
        return jsonify({"error": "Comando vuoto"}), 400
    
    # Blocca comandi distruttivi
    blocked = ['rm -rf /', 'format c:', 'mkfs', ':(){', 'dd if=', '> /dev/sd', 
               'shutdown', 'halt', 'init 0', 'del /f /s /q c:\\',
               'curl | sh', 'curl |sh', 'curl|sh', 'curl|bash',
               'wget -O- |', 'wget -O-|', 'wget|sh', 'wget|bash',
               'python -c "import os', "python -c 'import os",
               'powershell -enc', 'powershell -e ', 'powershell -command',
               'eval ', 'exec(', '| bash', '|bash',
               'chmod 777 /', 'chown root', 'passwd',
               'netcat ', 'nc -l', 'ncat ',
               'rm -rf ~', 'rm -rf $HOME',
               'sudo rm -rf', 'reboot', 'kill -9 1', 'kill -9 -1',
               'pkill -9', 'killall ',
               'iptables -F', 'iptables --flush',
               'systemctl disable', 'systemctl mask',
               '>/dev/sda', '>/dev/nvme',
               'base64 -d|', 'base64 -d |',
               'xargs rm', 'find / -delete',
               'mkfs.ext', 'wipefs',
               'crontab -r', 'at -d']
    for b in blocked:
        if b.lower() in cmd.lower():
            return jsonify({"error": f"Comando bloccato per sicurezza: {b}", "success": False})
    
    try:
        import subprocess, platform, shutil
        env = os.environ.copy()
        env['PYTHONIOENCODING'] = 'utf-8'
        
        system = platform.system().lower()
        start_time = _time.time()
        
        # Pattern "cleanup" — comandi che possono avere exit code != 0 ma sono OK
        partial_ok_patterns = [
            'silentlycontinue', 'erroraction', '2>/dev/null', '2>&1',
            'remove-item', 'clear-recyclebin', 'cleanmgr',
            'rm -rf /tmp', 'rm -rf /private/var', 'rm -rf ~/library/caches',
            'rm -rf ~/library/logs', 'rm -rf ~/.cache',
            'apt autoremove', 'apt autoclean', 'apt clean',
            'journalctl --vacuum', 'pip cache purge', 'brew cleanup',
        ]
        is_partial_ok = any(p in cmd.lower() for p in partial_ok_patterns)
        
        if system == 'windows':
            cmd_clean = cmd.replace('sudo ', '')
            
            # Per comandi Remove-Item: mostra COSA è stato effettivamente cancellato
            if 'remove-item' in cmd_clean.lower() and 'silentlycontinue' in cmd_clean.lower():
                # Wrap: conta file prima, esegui, conta dopo, mostra differenza
                ps_script = f"""
$ErrorActionPreference = 'SilentlyContinue'
$target = {_extract_ps_path(cmd_clean)}
if (Test-Path $target) {{
    $before = (Get-ChildItem $target -Recurse -Force -ErrorAction SilentlyContinue | Measure-Object).Count
    $sizeBefore = (Get-ChildItem $target -Recurse -Force -ErrorAction SilentlyContinue | Measure-Object -Property Length -Sum -ErrorAction SilentlyContinue).Sum
    {cmd_clean}
    $after = (Get-ChildItem $target -Recurse -Force -ErrorAction SilentlyContinue | Measure-Object).Count
    $deleted = $before - $after
    $sizeFreed = $sizeBefore - (Get-ChildItem $target -Recurse -Force -ErrorAction SilentlyContinue | Measure-Object -Property Length -Sum -ErrorAction SilentlyContinue).Sum
    $sizeMB = [math]::Round($sizeFreed / 1MB, 2)
    Write-Output "Eliminati: $deleted file/cartelle | Liberati: $($sizeMB) MB"
    Write-Output "Rimanenti: $after (bloccati da programmi attivi)"
}} else {{
    Write-Output "Cartella vuota o non trovata"
}}
exit 0
"""
                cmd_final = ps_script
            elif is_partial_ok:
                # Altri comandi cleanup: esegui normalmente, ignora errori
                cmd_final = f'{cmd_clean}; if ($?) {{ Write-Output "OK" }} else {{ Write-Output "Completato con avvisi" }}; exit 0'
            else:
                cmd_final = cmd_clean
            
            ps = shutil.which('powershell') or shutil.which('pwsh') or 'powershell'
            result = subprocess.run(
                [ps, '-NoProfile', '-Command', cmd_final],
                capture_output=True, text=True, timeout=60, env=env,
                encoding='utf-8', errors='replace'
            )
        elif system == 'darwin':
            result = subprocess.run(
                ['/bin/bash', '-c', cmd],
                capture_output=True, text=True, timeout=60, env=env,
                encoding='utf-8', errors='replace'
            )
        else:
            result = subprocess.run(
                ['/bin/bash', '-c', cmd],
                capture_output=True, text=True, timeout=60, env=env,
                encoding='utf-8', errors='replace'
            )
        
        elapsed = round(_time.time() - start_time, 2)
        stdout = (result.stdout or '').strip()
        stderr = (result.stderr or '').strip()
        
        # Rileva se serve admin
        needs_admin = False
        admin_kw = ['access denied', 'permission denied', 'not recognized',
                    'operation not permitted', 'requires elevation', 
                    'must be run as administrator', 'permesso negato',
                    'accesso negato', 'privilegi insufficienti']
        combined = (stdout + ' ' + stderr).lower()
        for kw in admin_kw:
            if kw in combined:
                needs_admin = True
                break
        
        # Aggiungi timing all'output
        timing = f"⏱️ {elapsed}s"
        
        if result.returncode == 0:
            display = f"{stdout}\n{timing}" if stdout else f"✅ Eseguito | {timing}"
            return jsonify({"success": True, "stdout": display, "stderr": stderr, "elapsed": elapsed})
        elif is_partial_ok and not needs_admin:
            display = f"{stdout}\n{timing}" if stdout else f"⚠️ Completato parzialmente | {timing}"
            return jsonify({
                "success": True, "partial": True,
                "stdout": display, "stderr": stderr, "elapsed": elapsed
            })
        else:
            return jsonify({
                "success": False,
                "error": stderr or stdout or f"Errore (codice {result.returncode})",
                "stdout": stdout, "stderr": stderr, "needs_admin": needs_admin,
                "elapsed": elapsed
            })
    except subprocess.TimeoutExpired:
        return jsonify({"error": "Timeout (60s)", "success": False})
    except Exception as e:
        return jsonify({"error": str(e), "success": False})

def _extract_ps_path(cmd):
    """Estrae il path da un comando Remove-Item di PowerShell"""
    import re
    m = re.search(r'-Path\s+"([^"]+)"', cmd) or re.search(r'-Path\s+(\S+)', cmd)
    if m:
        path = m.group(1).rstrip('\\*').rstrip('/*')
        return f'"{path}"'
    return '"$env:TEMP"'

# ═══════════════════════════════════════════════════════════
# API LICENZA
# ═══════════════════════════════════════════════════════════

@app.route('/api/license/status', methods=['GET'])
def api_license_status():
    """Stato completo della licenza"""
    info = get_license_info()
    info["app_version"] = APP_VERSION
    return jsonify(info)

@app.route('/api/license/fingerprint', methods=['GET'])
def api_license_fingerprint():
    """Ritorna il fingerprint hardware del PC"""
    fp = generate_fingerprint()
    return jsonify({"fingerprint": fp})

@app.route('/api/license/reload', methods=['POST'])
def api_license_reload():
    """Ricarica la licenza (dopo che l'utente ha messo il file)"""
    info = reload_license()
    info["app_version"] = APP_VERSION
    return jsonify(info)

@app.route('/api/license/open-folder', methods=['POST'])
def api_license_open_folder():
    """Apre la cartella dell'app nel file manager"""
    app_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    return jsonify({"success": open_url(app_dir), "path": app_dir})

@app.route('/api/license/diagnose', methods=['GET'])
def api_license_diagnose():
    """Diagnostica step-by-step del processo di attivazione licenza"""
    try:
        report = diagnose_license()
        report["app_version"] = APP_VERSION
        return jsonify(report)
    except Exception as e:
        return jsonify({
            "error": str(e),
            "steps": [{"id": "exception", "ok": False, "label": "Errore diagnostica", "detail": str(e)}],
            "summary": "error"
        }), 500

@app.route('/api/license/reset-cache', methods=['POST'])
def api_license_reset_cache():
    """Resetta cache anti-tampering e revoca per forzare verifica pulita"""
    try:
        result = reset_license_cache()
        return jsonify(result)
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/api/license/force-revoke-check', methods=['POST'])
def api_license_force_revoke_check():
    """★ Forza un check di revoca immediato: cancella cache → ri-verifica online → ritorna stato"""
    try:
        # 1. Cancella cache per forzare verifica online
        cache_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                                   '.license_cache_v2')
        if os.path.exists(cache_path):
            try: os.remove(cache_path)
            except OSError: pass
        # 2. Verifica pulita (senza cache → forza check remoto)
        info = get_license_info()
        info["app_version"] = APP_VERSION
        info["force_checked"] = True
        info["check_time"] = __import__('datetime').datetime.now().isoformat()
        return jsonify(info)
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# ═══════════════════════════════════════════════════════════
# API CONFIGURAZIONE
# ═══════════════════════════════════════════════════════════

@app.route('/api/config/auto', methods=['GET'])
def api_config_auto():
    """Configurazione automatica: URL + comandi + canali"""
    return jsonify(generate_auto_config())

@app.route('/api/config/commands', methods=['POST'])
def api_config_commands():
    """Genera comandi CLI dai parametri scelti dall'utente"""
    params = request.get_json() or {}
    commands = generate_cli_commands(params)
    validation = validate_params(params)
    script = get_script_completo(params)
    return jsonify({
        "commands": commands,
        "validation": validation,
        "script": script,
    })

@app.route('/api/config/validate', methods=['POST'])
def api_config_validate():
    """Valida i parametri senza generare comandi"""
    params = request.get_json() or {}
    return jsonify(validate_params(params))

@app.route('/api/config/qrcode', methods=['POST'])
def api_config_qrcode():
    """Genera QR code PNG (base64) per configurazione canali.
    Se riceve custom_channels, genera URL protobuf dinamico.
    Altrimenti usa AUTOCONFIG_URL standard."""
    data = request.get_json() or {}

    # Se l'utente ha canali personalizzati, genera URL dinamico
    custom_channels = data.get("custom_channels")
    if custom_channels:
        dynamic_url = generate_channel_url(data)
        if dynamic_url:
            url = dynamic_url
        else:
            url = data.get("url", AUTOCONFIG_URL)
    else:
        url = data.get("url", AUTOCONFIG_URL)

    qr_base64 = generate_qr_code(url)
    if qr_base64:
        return jsonify({"qr_code": qr_base64, "url": url})
    # Non crash: ritorna ok con flag per far usare il fallback JS
    return jsonify({"qr_code": None, "url": url, "fallback": True})

# ═══════════════════════════════════════════════════════════
# API NETWORK (parametri, canali, link)
# ═══════════════════════════════════════════════════════════

@app.route('/api/network/params', methods=['GET'])
def api_network_params():
    """Tutti i parametri ufficiali del network"""
    return jsonify(NETWORK_CONFIG)

@app.route('/api/network/channels', methods=['GET'])
def api_network_channels():
    """Lista canali ufficiali"""
    return jsonify({"channels": CHANNELS, "autoconfig_url": AUTOCONFIG_URL})

@app.route('/api/network/links', methods=['GET'])
def api_network_links():
    """Tutti i link ufficiali organizzati per categoria"""
    return jsonify(LINKS)

@app.route('/api/network/roles', methods=['GET'])
def api_network_roles():
    """Tutti i 12 ruoli con descrizioni complete"""
    return jsonify({
        "roles": DEVICE_ROLES,
        "deprecated": DEPRECATED_ROLES,
    })

@app.route('/api/network/presets', methods=['GET'])
def api_network_presets():
    """Tutti i preset modem disponibili"""
    return jsonify(MODEM_PRESETS)

@app.route('/api/network/devices', methods=['GET'])
def api_network_devices():
    """Database dispositivi supportati"""
    return jsonify({"devices": SUPPORTED_DEVICES})

@app.route('/api/network/firmware', methods=['GET'])
def api_network_firmware():
    """Info firmware + bootloader"""
    return jsonify({
        "firmware": FIRMWARE_INFO,
        "bootloader": BOOTLOADER_METHODS,
    })

# ═══════════════════════════════════════════════════════════
# API DATI (params info, comandi CLI, guide)
# ═══════════════════════════════════════════════════════════

@app.route('/api/data/<filename>', methods=['GET'])
def api_data_file(filename):
    """Serve file JSON dalla cartella data/ (o stessa cartella se flat)"""
    # Prova prima data/ come sottocartella, poi stessa cartella (flat)
    data_dir = os.path.join(_base_dir, 'data')
    safe_name = os.path.basename(filename)
    if not safe_name.endswith('.json'):
        safe_name += '.json'
    filepath = os.path.join(data_dir, safe_name)
    if not os.path.exists(filepath):
        filepath = os.path.join(_base_dir, safe_name)
    if os.path.exists(filepath):
        with open(filepath, 'r', encoding='utf-8') as f:
            return jsonify(json.load(f))
    return jsonify({"error": f"File {safe_name} non trovato"}), 404

# ═══════════════════════════════════════════════════════════
# API MOD — Operazioni avanzate firmware
# ═══════════════════════════════════════════════════════════

@app.route('/api/mod/import-config', methods=['POST'])
def api_mod_import_config():
    """Importa configurazione YAML sul dispositivo via --configure"""
    import tempfile
    data = request.get_json() or {}
    yaml_content = data.get("yaml_content", "")
    if not yaml_content:
        return jsonify({"success": False, "error": "Contenuto YAML vuoto"})
    
    try:
        # Salva YAML in file temporaneo
        fd, tmp_path = tempfile.mkstemp(suffix='.yaml', prefix='mesh_config_')
        with os.fdopen(fd, 'w', encoding='utf-8') as f:
            f.write(yaml_content)
        
        # Esegui meshtastic --configure
        cli_path = _find_meshtastic_cli()
        if not cli_path:
            os.unlink(tmp_path)
            return jsonify({"success": False, "error": "meshtastic CLI non trovato"})
        
        import subprocess
        result = subprocess.run(
            [cli_path, '--configure', tmp_path],
            capture_output=True, text=True, timeout=120,
            env={**os.environ, 'PYTHONIOENCODING': 'utf-8'}
        )
        
        # Cleanup
        try:
            os.unlink(tmp_path)
        except:
            pass
        
        if result.returncode == 0:
            return jsonify({
                "success": True,
                "message": f"Configurazione importata con successo!\n{result.stdout}",
                "stdout": result.stdout
            })
        else:
            return jsonify({
                "success": False,
                "error": f"Errore import: {result.stderr or result.stdout}",
                "stdout": result.stdout,
                "stderr": result.stderr
            })
    except subprocess.TimeoutExpired:
        return jsonify({"success": False, "error": "Timeout (120s) — dispositivo non risponde"})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)})

# ═══════════════════════════════════════════════════════════
# API CLI — Esecuzione comandi Meshtastic reali
# ═══════════════════════════════════════════════════════════

import subprocess
import shutil
import shlex

def _find_meshtastic_cli():
    """Trova il percorso del CLI meshtastic, cross-platform"""
    path = shutil.which("meshtastic")
    if path:
        return path
    # Fallback Windows: cerca nel Python Scripts
    import sys
    scripts_dir = os.path.join(os.path.dirname(sys.executable), "Scripts")
    win_path = os.path.join(scripts_dir, "meshtastic.exe")
    if os.path.exists(win_path):
        return win_path
    # Fallback Linux/Mac: cerca in ~/.local/bin
    local_path = os.path.expanduser("~/.local/bin/meshtastic")
    if os.path.exists(local_path):
        return local_path
    return None

@app.route('/api/cli/execute', methods=['POST'])
def api_cli_execute():
    """Esegue un comando meshtastic CLI con porta opzionale"""
    data = request.get_json() or {}
    command = data.get("command", "").strip()
    port = data.get("port", "").strip()  # Porta USB selezionata dall'utente
    
    # Whitelist comandi sicuri
    SAFE_COMMANDS = [
        "--info", "--nodes", "--get all", "--export-config",
        "--version", "--noproto", "--ble-scan",
        "--factory-reset", "--reboot", "--reset-nodedb",
        "--listen", "--qr",
    ]
    SAFE_PREFIXES = [
        "--set ", "--set-owner", "--set-ham", "--ch-set", "--ch-set-url",
        "--setlat", "--setlon", "--setalt", "--sendtext",
        "--port ", "--get ", "--remove-position",
        "--configure ", "--dest ", "--ch-index",
    ]
    
    if not command:
        return jsonify({"error": "Comando vuoto"}), 400
    
    # Verifica che il comando sia sicuro
    is_safe = any(command == s or command.startswith(s) for s in SAFE_COMMANDS)
    if not is_safe:
        is_safe = any(command.startswith(p) for p in SAFE_PREFIXES)
    if not is_safe:
        return jsonify({"error": f"Comando non permesso: {command}"}), 403
    
    # Verifica CLI installato
    cli_path = _find_meshtastic_cli()
    if not cli_path:
        return jsonify({
            "error": "Meshtastic CLI non trovato! Installa con: pip install meshtastic",
            "install_command": "pip install --upgrade meshtastic"
        }), 404
    
    # Costruisci il comando — porta + comando
    try:
        cmd_parts = shlex.split(command)
    except ValueError:
        cmd_parts = command.split()
    
    # Prependi --port se specificata E il comando non ha già --port
    args = [cli_path]
    if port and '--port' not in command:
        args += ['--port', port]
    args += cmd_parts
    
    import time as _time
    start = _time.time()
    
    # Comandi pesanti che richiedono più tempo (200 nodi = ~60s)
    heavy_cmds = ['--export-config', '--nodes', '--info', '--get all', '--listen']
    timeout_secs = 90 if any(h in command for h in heavy_cmds) else 30
    
    try:
        # CRITICO su Windows: forzare encoding UTF-8 con errors=replace
        # Senza questo, nomi nodi con emoji (👮🌐🥭⚡) crashano con cp1252
        import platform as _plat
        env = {**os.environ, 'PYTHONIOENCODING': 'utf-8'}
        
        if _plat.system() == 'Windows':
            # Windows: usa CREATE_NO_WINDOW + encoding esplicito
            result = subprocess.run(
                args,
                capture_output=True, text=True,
                timeout=timeout_secs,
                env=env,
                encoding='utf-8',
                errors='replace',
                creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0)
            )
        else:
            result = subprocess.run(
                args,
                capture_output=True, text=True,
                timeout=timeout_secs,
                env=env,
                encoding='utf-8',
                errors='replace'
            )
        
        elapsed = round(_time.time() - start, 2)
        full_cmd = f"meshtastic {'--port '+port+' ' if port else ''}{command}"
        
        # None-safe: stdout/stderr possono essere None
        stdout = (result.stdout or '').strip()
        stderr = (result.stderr or '').strip()
        
        return jsonify({
            "command": full_cmd,
            "port": port or "auto-detect",
            "stdout": f"{stdout}\n⏱️ {elapsed}s" if stdout else f"(nessun output) ⏱️ {elapsed}s",
            "stderr": stderr,
            "returncode": result.returncode,
            "success": result.returncode == 0,
            "elapsed": elapsed,
        })
    except subprocess.TimeoutExpired:
        elapsed = round(_time.time() - start, 2)
        return jsonify({"error": f"Timeout ({timeout_secs}s). Il nodo ha molti dati — riprova o usa un comando più leggero.", "elapsed": elapsed}), 504
    except UnicodeDecodeError as e:
        # Fallback per encoding issues residui
        return jsonify({"error": f"Errore encoding: {str(e)}. Prova a riavviare l'app.", "success": False}), 500
    except Exception as e:
        return jsonify({"error": f"Errore: {str(e)}"}), 500

@app.route('/api/cli/check', methods=['GET'])
def api_cli_check():
    """Verifica se meshtastic CLI è installato"""
    cli_path = _find_meshtastic_cli()
    if cli_path:
        try:
            result = subprocess.run(
                [cli_path, "--version"],
                capture_output=True, text=True, timeout=5,
                env={**os.environ, 'PYTHONIOENCODING': 'utf-8'},
                encoding='utf-8', errors='replace'
            )
            stdout = (result.stdout or '').strip()
            stderr = (result.stderr or '').strip()
            return jsonify({
                "installed": True,
                "path": cli_path,
                "version": stdout or stderr or "trovato",
            })
        except Exception:
            return jsonify({"installed": True, "path": cli_path, "version": "trovato"})
    return jsonify({
        "installed": False,
        "install_command": "pip install --upgrade meshtastic",
    })

@app.route('/api/cli/install', methods=['POST'])
def api_cli_install():
    """Installa o aggiorna meshtastic CLI via pip (stesso Python dell'app)"""
    import sys

    python_exe = sys.executable
    if not python_exe:
        return jsonify({"success": False, "error": "Python interpreter non trovato"}), 500

    data = request.get_json() or {}
    package = data.get("package", "meshtastic")  # Supporta installazione di qualsiasi pacchetto
    # Whitelist pacchetti consentiti (sicurezza)
    ALLOWED = {"meshtastic", "flask", "flask-cors", "pyserial", "cryptography",
               "qrcode", "qrcode[pil]", "Pillow", "esptool"}
    if package not in ALLOWED:
        return jsonify({"success": False, "error": f"Pacchetto non consentito: {package}"}), 403

    import platform as _plat
    env = {**os.environ, 'PYTHONIOENCODING': 'utf-8'}
    base_kwargs = dict(
        capture_output=True, text=True,
        timeout=180,
        env=env,
        encoding='utf-8',
        errors='replace'
    )
    if _plat.system() == 'Windows':
        base_kwargs['creationflags'] = getattr(subprocess, 'CREATE_NO_WINDOW', 0)

    # ── Verifica che pip sia disponibile ──────────────────────
    try:
        subprocess.run([python_exe, '-m', 'pip', '--version'],
                       capture_output=True, timeout=10)
    except Exception:
        # pip non trovato — prova ensurepip
        try:
            subprocess.run([python_exe, '-m', 'ensurepip', '--upgrade'],
                           capture_output=True, timeout=60)
        except Exception:
            return jsonify({
                "success": False,
                "error": "pip non trovato e impossibile installarlo. Esegui: python -m ensurepip --upgrade"
            })

    # ── Tentativo 1: installazione normale ────────────────────
    cmd_args = [python_exe, '-m', 'pip', 'install', '--upgrade', package]
    try:
        result = subprocess.run(cmd_args, **base_kwargs)
        stdout = (result.stdout or '').strip()
        stderr = (result.stderr or '').strip()

        if result.returncode == 0:
            cli_path = _find_meshtastic_cli() if package == 'meshtastic' else None
            return jsonify({
                "success": True,
                "installed_now": True,
                "stdout": stdout,
                "stderr": stderr,
                "cli_path": cli_path or "",
            })

        # ── Tentativo 2: con --user (no permessi admin) ──────
        cmd_user = [python_exe, '-m', 'pip', 'install', '--user', '--upgrade', package]
        result2 = subprocess.run(cmd_user, **base_kwargs)
        stdout2 = (result2.stdout or '').strip()
        stderr2 = (result2.stderr or '').strip()

        if result2.returncode == 0:
            cli_path = _find_meshtastic_cli() if package == 'meshtastic' else None
            return jsonify({
                "success": True,
                "installed_now": True,
                "stdout": stdout2,
                "stderr": stderr2,
                "method": "--user",
                "cli_path": cli_path or "",
            })

        # Entrambi i tentativi falliti — restituisci errore dettagliato
        combined_err = stderr or stderr2 or stdout or stdout2 or "pip ha restituito errore senza dettagli"
        return jsonify({
            "success": False,
            "error": combined_err,
            "stdout": stdout or stdout2,
            "stderr": stderr or stderr2,
            "returncode": result.returncode,
        })

    except subprocess.TimeoutExpired:
        return jsonify({"success": False, "error": "Timeout (180s) — connessione lenta, riprova"}), 504
    except Exception as e:
        return jsonify({"success": False, "error": f"Errore: {str(e)}"}), 500

@app.route('/api/cli/exec', methods=['POST'])
def api_cli_exec():
    """Esegue un comando meshtastic CLI — endpoint MOD (accetta formato args)"""
    data = request.get_json() or {}
    args_str = data.get("args", "").strip()
    timeout_req = data.get("timeout", 60)
    
    if not args_str:
        return jsonify({"error": "Argomenti vuoti", "not_found": False}), 400
    
    cli_path = _find_meshtastic_cli()
    if not cli_path:
        return jsonify({
            "not_found": True,
            "error": "Meshtastic CLI non trovato! Installa con: pip install meshtastic",
        })
    
    # Costruisci comando
    try:
        cmd_parts = shlex.split(args_str)
    except ValueError:
        cmd_parts = args_str.split()
    
    args = [cli_path]
    # Aggiungi porta se selezionata e non già presente
    port = data.get("port", "")
    if not port:
        # Cerca nell'header o nei cookie — non c'è, usa dalla request
        pass
    if port and '--port' not in args_str:
        args += ['--port', port]
    args += cmd_parts
    
    import time as _time
    import platform as _plat
    start = _time.time()
    timeout_secs = min(max(int(timeout_req), 10), 300)  # 10-300 secondi
    
    try:
        env = {**os.environ, 'PYTHONIOENCODING': 'utf-8'}
        
        if _plat.system() == 'Windows':
            result = subprocess.run(
                args, capture_output=True, text=True,
                timeout=timeout_secs, env=env,
                encoding='utf-8', errors='replace',
                creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0)
            )
        else:
            result = subprocess.run(
                args, capture_output=True, text=True,
                timeout=timeout_secs, env=env,
                encoding='utf-8', errors='replace'
            )
        
        elapsed = round(_time.time() - start, 2)
        stdout = (result.stdout or '').strip()
        stderr = (result.stderr or '').strip()
        
        return jsonify({
            "stdout": f"{stdout}\n⏱️ {elapsed}s" if stdout else f"(nessun output) ⏱️ {elapsed}s",
            "stderr": stderr,
            "returncode": result.returncode,
            "success": result.returncode == 0,
            "elapsed": elapsed,
        })
    except subprocess.TimeoutExpired:
        return jsonify({"error": f"Timeout ({timeout_secs}s)", "stdout": "", "stderr": ""})
    except Exception as e:
        return jsonify({"error": str(e), "stdout": "", "stderr": ""})

# ═══════════════════════════════════════════════════════════
# 🩺 AUTO-DIAGNOSI & RECOVERY — Controllo compatibilità versioni
# ═══════════════════════════════════════════════════════════

# Versioni Python supportate (testate e funzionanti con meshtastic)
_PYTHON_MIN = (3, 9)
_PYTHON_MAX_TESTED = (3, 14)  # 3.14 funzionante con meshtastic CLI 2.7.x

# Versioni raccomandate per dipendenze critiche
_RECOMMENDED_VERSIONS = {
    "meshtastic": {"min": "2.3.0", "max_tested": "2.7.99", "recommended": "2.5.2"},
    "protobuf":   {"min": "4.21.0", "max_tested": "5.99.0", "recommended": ""},
    "pyserial":   {"min": "3.5",   "max_tested": "3.99", "recommended": ""},
    "cryptography": {"min": "3.4", "max_tested": "46.99", "recommended": ""},
    "flask":      {"min": "2.0",   "max_tested": "3.99", "recommended": ""},
}

def _parse_version(v_str):
    """Converte '2.3.1' → (2,3,1) per confronto"""
    try:
        parts = v_str.replace('rc','.',).replace('a','.',).replace('b','.',).split('.')
        return tuple(int(x) for x in parts[:3] if x.isdigit())
    except Exception:
        return (0,)

def _version_in_range(version_str, min_v, max_v):
    """Verifica se una versione è nel range accettabile"""
    v = _parse_version(version_str)
    vmin = _parse_version(min_v) if min_v else (0,)
    vmax = _parse_version(max_v) if max_v else (99, 99, 99)
    return vmin <= v <= vmax

# ── SMART ERROR PARSER — riconosce Traceback e suggerisce fix ──

_ERROR_PATTERNS = [
    {
        "pattern": r"ModuleNotFoundError: No module named '(\w+)'",
        "type": "missing_module",
        "title_it": "Modulo Python mancante",
        "title_en": "Missing Python module",
        "fix_type": "install_package",
    },
    {
        "pattern": r"ImportError: cannot import name '(\w+)' from '(\w+)'",
        "type": "import_error",
        "title_it": "Versione incompatibile",
        "title_en": "Incompatible version",
        "fix_type": "upgrade_package",
    },
    {
        "pattern": r"TypeError:.*unexpected keyword argument",
        "type": "api_mismatch",
        "title_it": "API incompatibile — versione libreria errata",
        "title_en": "Incompatible API — wrong library version",
        "fix_type": "reinstall_package",
    },
    {
        "pattern": r"google\.protobuf|protobuf",
        "type": "protobuf_error",
        "title_it": "Errore protobuf — versione incompatibile",
        "title_en": "Protobuf error — incompatible version",
        "fix_type": "fix_protobuf",
    },
    {
        "pattern": r"serial\.serialutil\.SerialException|could not open port|PermissionError.*serial|Access is denied",
        "type": "serial_error",
        "title_it": "Errore porta seriale",
        "title_en": "Serial port error",
        "fix_type": "serial_fix",
    },
    {
        "pattern": r"serial\.tools\.list_ports|No module named 'serial'",
        "type": "missing_serial",
        "title_it": "PySerial mancante",
        "title_en": "PySerial missing",
        "fix_type": "install_package",
    },
    {
        "pattern": r"FileNotFoundError.*meshtastic|meshtastic.*not found|No such file or directory.*meshtastic",
        "type": "cli_not_found",
        "title_it": "Meshtastic CLI non trovato",
        "title_en": "Meshtastic CLI not found",
        "fix_type": "install_package",
    },
    {
        "pattern": r"TimeoutError|timed out|Timeout waiting",
        "type": "timeout_error",
        "title_it": "Timeout comunicazione dispositivo",
        "title_en": "Device communication timeout",
        "fix_type": "device_fix",
    },
    {
        "pattern": r"Exception.*mesh_interface|mesh_interface.*Exception|common\(\)",
        "type": "mesh_interface_crash",
        "title_it": "Crash interfaccia Meshtastic — versione Python/libreria incompatibile",
        "title_en": "Meshtastic interface crash — incompatible Python/library version",
        "fix_type": "reinstall_meshtastic",
    },
    {
        "pattern": r"DeprecationWarning|SyntaxWarning.*invalid escape",
        "type": "deprecation_warning",
        "title_it": "Avvisi deprecazione — versione Python troppo nuova",
        "title_en": "Deprecation warnings — Python version too new",
        "fix_type": "check_python_version",
    },
    {
        "pattern": r"OSError.*WinError|OSError \[Errno|WindowsError",
        "type": "os_error",
        "title_it": "Errore di sistema operativo",
        "title_en": "Operating system error",
        "fix_type": "os_fix",
    },
    {
        "pattern": r"pip.*externally-managed|externally-managed-environment",
        "type": "pip_managed",
        "title_it": "Ambiente Python gestito dal sistema",
        "title_en": "System-managed Python environment",
        "fix_type": "pip_user_install",
    },
]

# Mappa moduli Python → pacchetti pip
_MODULE_TO_PIP = {
    "meshtastic": "meshtastic",
    "serial": "pyserial",
    "google.protobuf": "protobuf",
    "google": "protobuf",
    "protobuf": "protobuf",
    "yaml": "pyyaml",
    "PIL": "Pillow",
    "cryptography": "cryptography",
    "flask": "flask",
    "flask_cors": "flask-cors",
    "qrcode": "qrcode[pil]",
    "esptool": "esptool",
    "tabulate": "tabulate",
    "pypubsub": "pypubsub",
    "bleak": "bleak",
    "dotmap": "dotmap",
    "pexpect": "pexpect",
    "packaging": "packaging",
    "requests": "requests",
    "print_color": "print-color",
}

def _analyze_error(error_text):
    """Analizza un testo errore e ritorna diagnosi + fix suggeriti"""
    import re
    if not error_text:
        return None

    results = []
    for pattern_info in _ERROR_PATTERNS:
        match = re.search(pattern_info["pattern"], error_text, re.IGNORECASE | re.DOTALL)
        if match:
            diagnosis = {
                "type": pattern_info["type"],
                "title_it": pattern_info["title_it"],
                "title_en": pattern_info["title_en"],
                "fix_type": pattern_info["fix_type"],
                "match": match.group(0)[:200],
                "groups": list(match.groups()) if match.groups() else [],
            }

            # Genera fix specifici basati sul tipo
            if pattern_info["fix_type"] == "install_package":
                module_name = match.group(1) if match.lastindex else "meshtastic"
                pip_pkg = _MODULE_TO_PIP.get(module_name, module_name)
                diagnosis["fix_command"] = f"pip install --upgrade {pip_pkg}"
                diagnosis["fix_package"] = pip_pkg
                diagnosis["fix_action"] = "install"

            elif pattern_info["fix_type"] == "upgrade_package":
                module_name = match.group(2) if match.lastindex and match.lastindex >= 2 else "meshtastic"
                pip_pkg = _MODULE_TO_PIP.get(module_name, module_name)
                diagnosis["fix_command"] = f"pip install --upgrade {pip_pkg}"
                diagnosis["fix_package"] = pip_pkg
                diagnosis["fix_action"] = "upgrade"

            elif pattern_info["fix_type"] in ("reinstall_package", "reinstall_meshtastic"):
                diagnosis["fix_command"] = "pip install --force-reinstall meshtastic"
                diagnosis["fix_package"] = "meshtastic"
                diagnosis["fix_action"] = "reinstall"

            elif pattern_info["fix_type"] == "fix_protobuf":
                diagnosis["fix_command"] = "pip install --upgrade protobuf meshtastic"
                diagnosis["fix_package"] = "protobuf"
                diagnosis["fix_action"] = "upgrade"

            elif pattern_info["fix_type"] == "serial_fix":
                diagnosis["fix_action"] = "serial_troubleshoot"
                diagnosis["fix_steps"] = [
                    "Verifica cavo USB (dati, non solo ricarica)",
                    "Riavvia il dispositivo",
                    "Chiudi altri programmi che usano la porta",
                    "Installa driver CP210x o CH340",
                    "Linux: sudo usermod -a -G dialout $USER",
                ]

            elif pattern_info["fix_type"] == "device_fix":
                diagnosis["fix_action"] = "device_troubleshoot"
                diagnosis["fix_steps"] = [
                    "Riavvia il dispositivo Meshtastic",
                    "Prova un altro cavo USB",
                    "Reset NodeDB: meshtastic --reset-nodedb",
                    "Verifica porta USB selezionata",
                ]

            elif pattern_info["fix_type"] == "check_python_version":
                import sys
                diagnosis["fix_action"] = "python_version_warning"
                diagnosis["python_version"] = f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"

            elif pattern_info["fix_type"] == "pip_user_install":
                diagnosis["fix_command"] = "pip install --user --upgrade meshtastic"
                diagnosis["fix_package"] = "meshtastic"
                diagnosis["fix_action"] = "install_user"

            elif pattern_info["fix_type"] == "os_fix":
                diagnosis["fix_action"] = "os_troubleshoot"
                diagnosis["fix_steps"] = [
                    "Riavvia l'app come amministratore",
                    "Controlla permessi sulla cartella app",
                    "Verifica antivirus non blocchi l'accesso",
                ]

            results.append(diagnosis)

    return results if results else None


@app.route('/api/deps/diagnose', methods=['GET'])
def api_deps_diagnose():
    """Diagnosi COMPLETA: versioni Python, compatibilità librerie, driver USB, stato CLI"""
    import sys
    import re

    issues = []       # Problemi trovati
    warnings = []     # Avvisi non bloccanti
    info = []         # Info generali

    # ── 1. CHECK VERSIONE PYTHON ──────────────────────────────
    py_v = sys.version_info
    py_str = f"{py_v.major}.{py_v.minor}.{py_v.micro}"
    py_ok = True

    if py_v < _PYTHON_MIN:
        issues.append({
            "area": "python",
            "severity": "critical",
            "title": f"Python {py_str} troppo vecchio",
            "detail": f"Serve Python {_PYTHON_MIN[0]}.{_PYTHON_MIN[1]}+. Versione attuale: {py_str}",
            "fix_action": "upgrade_python",
            "fix_url": "https://www.python.org/downloads/",
        })
        py_ok = False
    elif (py_v.major, py_v.minor) > _PYTHON_MAX_TESTED:
        issues.append({
            "area": "python",
            "severity": "high",
            "title": f"Python {py_str} non ancora supportato da meshtastic",
            "detail": f"Python {py_str} potrebbe non essere compatibile con meshtastic CLI. Versione raccomandata: 3.11 o 3.12",
            "fix_action": "downgrade_python",
            "fix_url": "https://www.python.org/downloads/release/python-3120/",
        })

    info.append({"label": "Python", "value": py_str, "path": sys.executable, "ok": py_ok})

    # ── 2. CHECK VERSIONI LIBRERIE ────────────────────────────
    deps_status = []
    for dep_name, constraints in _RECOMMENDED_VERSIONS.items():
        try:
            if dep_name == "pyserial":
                mod = __import__("serial")
            elif dep_name == "protobuf":
                mod = __import__("google.protobuf")
                # __import__ restituisce il pacchetto top-level 'google',
                # quindi navighiamo al sotto-modulo corretto
                import importlib
                mod = importlib.import_module("google.protobuf")
            else:
                mod = __import__(dep_name)
            version = getattr(mod, '__version__', getattr(mod, 'VERSION', None))
            if version:
                version = str(version)
                in_range = _version_in_range(version, constraints["min"], constraints["max_tested"])
                dep_info = {"name": dep_name, "installed": True, "version": version, "ok": in_range}
                if not in_range:
                    if _parse_version(version) < _parse_version(constraints["min"]):
                        issues.append({
                            "area": "library",
                            "severity": "high",
                            "title": f"{dep_name} {version} troppo vecchio",
                            "detail": f"Versione minima richiesta: {constraints['min']}",
                            "fix_action": "upgrade",
                            "fix_package": _MODULE_TO_PIP.get(dep_name, dep_name),
                            "fix_command": f"pip install --upgrade {_MODULE_TO_PIP.get(dep_name, dep_name)}",
                        })
                    else:
                        warnings.append({
                            "area": "library",
                            "severity": "medium",
                            "title": f"{dep_name} {version} non testato",
                            "detail": f"Versione non verificata — potrebbe funzionare ma non è garantito",
                            "fix_action": "reinstall",
                            "fix_package": _MODULE_TO_PIP.get(dep_name, dep_name),
                        })
                deps_status.append(dep_info)
            else:
                deps_status.append({"name": dep_name, "installed": True, "version": "?", "ok": True})
        except ImportError:
            deps_status.append({"name": dep_name, "installed": False, "version": None, "ok": False})
            pip_pkg = _MODULE_TO_PIP.get(dep_name, dep_name)
            issues.append({
                "area": "library",
                "severity": "critical",
                "title": f"{dep_name} non installato",
                "detail": f"Libreria mancante: {dep_name}",
                "fix_action": "install",
                "fix_package": pip_pkg,
                "fix_command": f"pip install {pip_pkg}",
            })

    # ── 3. CHECK MESHTASTIC CLI — versione e funzionamento ────
    cli_path = _find_meshtastic_cli()
    cli_ok = False
    cli_version = None
    cli_error = None

    if cli_path:
        try:
            import platform as _plat
            env = {**os.environ, 'PYTHONIOENCODING': 'utf-8'}
            kwargs = dict(capture_output=True, text=True, timeout=10,
                         env=env, encoding='utf-8', errors='replace')
            if _plat.system() == 'Windows':
                kwargs['creationflags'] = getattr(subprocess, 'CREATE_NO_WINDOW', 0)

            result = subprocess.run([cli_path, "--version"], **kwargs)
            stdout = (result.stdout or '').strip()
            stderr = (result.stderr or '').strip()

            if result.returncode == 0:
                # Estrai versione da output
                ver_match = re.search(r'(\d+\.\d+\.\d+)', stdout or stderr)
                cli_version = ver_match.group(1) if ver_match else (stdout or stderr)
                cli_ok = True

                # Verifica compatibilità versione CLI
                if ver_match:
                    mesh_constraints = _RECOMMENDED_VERSIONS.get("meshtastic", {})
                    if not _version_in_range(ver_match.group(1),
                                             mesh_constraints.get("min", "2.0.0"),
                                             mesh_constraints.get("max_tested", "9.9.9")):
                        warnings.append({
                            "area": "cli",
                            "severity": "medium",
                            "title": f"Meshtastic CLI {ver_match.group(1)} — versione non testata",
                            "detail": "Potrebbe avere incompatibilità",
                            "fix_action": "reinstall",
                            "fix_package": "meshtastic",
                            "fix_command": "pip install --force-reinstall meshtastic",
                        })
            else:
                # CLI trovato ma errore all'esecuzione
                cli_error = stderr or stdout
                error_analysis = _analyze_error(cli_error)
                if error_analysis:
                    for diag in error_analysis:
                        issues.append({
                            "area": "cli",
                            "severity": "critical",
                            "title": diag["title_it"],
                            "detail": diag.get("match", "")[:200],
                            "fix_action": diag.get("fix_action", "reinstall"),
                            "fix_package": diag.get("fix_package", "meshtastic"),
                            "fix_command": diag.get("fix_command", "pip install --force-reinstall meshtastic"),
                        })
                else:
                    issues.append({
                        "area": "cli",
                        "severity": "critical",
                        "title": "Meshtastic CLI errore all'avvio",
                        "detail": (cli_error or "errore sconosciuto")[:300],
                        "fix_action": "reinstall",
                        "fix_package": "meshtastic",
                        "fix_command": "pip install --force-reinstall meshtastic",
                    })
        except subprocess.TimeoutExpired:
            cli_error = "Timeout (10s) verificando CLI"
            issues.append({
                "area": "cli",
                "severity": "high",
                "title": "Timeout verifica CLI",
                "detail": "meshtastic --version non risponde in 10 secondi",
                "fix_action": "reinstall",
                "fix_package": "meshtastic",
            })
        except Exception as e:
            cli_error = str(e)
    else:
        issues.append({
            "area": "cli",
            "severity": "critical",
            "title": "Meshtastic CLI non installato",
            "detail": "Il comando meshtastic non è stato trovato nel sistema",
            "fix_action": "install",
            "fix_package": "meshtastic",
            "fix_command": "pip install meshtastic",
        })

    info.append({"label": "Meshtastic CLI", "value": cli_version or "non trovato",
                 "path": cli_path or "", "ok": cli_ok, "error": cli_error})

    # ── 4. CHECK DRIVER USB ───────────────────────────────────
    driver_info = check_driver_installed()
    ports = list_serial_ports()
    info.append({"label": "Porte USB", "value": f"{len(ports)} trovate", "ok": len(ports) > 0})

    # ── 5. CHECK pip ──────────────────────────────────────────
    pip_ok = False
    pip_version = None
    try:
        r = subprocess.run([sys.executable, '-m', 'pip', '--version'],
                          capture_output=True, text=True, timeout=10,
                          encoding='utf-8', errors='replace')
        if r.returncode == 0:
            pip_ok = True
            pip_version = (r.stdout or '').split(' ')[1] if r.stdout else '?'
    except Exception:
        pass
    info.append({"label": "pip", "value": pip_version or "non trovato", "ok": pip_ok})

    # ── SCORE complessivo ─────────────────────────────────────
    critical_count = sum(1 for i in issues if i.get("severity") == "critical")
    high_count = sum(1 for i in issues if i.get("severity") == "high")
    score = 100 - (critical_count * 30) - (high_count * 15) - (len(warnings) * 5)
    score = max(0, min(100, score))

    status = "ok" if score >= 80 else ("warning" if score >= 50 else "critical")

    return jsonify({
        "status": status,
        "score": score,
        "issues": issues,
        "warnings": warnings,
        "info": info,
        "deps": deps_status,
        "python_version": py_str,
        "python_path": sys.executable,
        "cli_version": cli_version,
        "cli_path": cli_path,
        "cli_ok": cli_ok,
        "ports_count": len(ports),
        "pip_ok": pip_ok,
        "pip_version": pip_version,
    })


@app.route('/api/deps/fix', methods=['POST'])
def api_deps_fix():
    """Fix mirato: installa/aggiorna/reinstalla un pacchetto specifico con versione"""
    import sys
    data = request.get_json() or {}
    action = data.get("action", "install")     # install | upgrade | reinstall | uninstall_reinstall
    package = data.get("package", "meshtastic")
    version = data.get("version", "")          # Versione specifica opzionale

    ALLOWED = {"meshtastic", "flask", "flask-cors", "pyserial", "cryptography",
               "qrcode", "qrcode[pil]", "Pillow", "esptool", "protobuf",
               "pypubsub", "dotmap", "pexpect", "tabulate", "bleak",
               "packaging", "requests", "print-color", "pyyaml"}
    if package not in ALLOWED:
        return jsonify({"success": False, "error": f"Pacchetto non consentito: {package}"}), 403

    import platform as _plat
    env = {**os.environ, 'PYTHONIOENCODING': 'utf-8'}
    base_kwargs = dict(capture_output=True, text=True, timeout=300,
                      env=env, encoding='utf-8', errors='replace')
    if _plat.system() == 'Windows':
        base_kwargs['creationflags'] = getattr(subprocess, 'CREATE_NO_WINDOW', 0)

    steps = []
    success = False

    try:
        # Step 1: Se reinstall → prima disinstalla
        if action in ("reinstall", "uninstall_reinstall"):
            cmd_uninstall = [sys.executable, '-m', 'pip', 'uninstall', '-y', package]
            r = subprocess.run(cmd_uninstall, **base_kwargs)
            steps.append({
                "step": "uninstall",
                "command": ' '.join(cmd_uninstall),
                "success": r.returncode == 0,
                "output": ((r.stdout or '') + '\n' + (r.stderr or '')).strip()[:500],
            })

        # Step 2: Installa (con versione specifica se indicata)
        pkg_spec = f"{package}=={version}" if version else package
        cmd_install = [sys.executable, '-m', 'pip', 'install', '--upgrade', pkg_spec]
        if action == "reinstall":
            cmd_install = [sys.executable, '-m', 'pip', 'install', '--force-reinstall', pkg_spec]

        r = subprocess.run(cmd_install, **base_kwargs)
        stdout = (r.stdout or '').strip()
        stderr = (r.stderr or '').strip()

        if r.returncode == 0:
            success = True
            steps.append({
                "step": "install",
                "command": ' '.join(cmd_install),
                "success": True,
                "output": stdout[:500],
            })
        else:
            # Fallback --user
            cmd_user = cmd_install + ['--user'] if '--user' not in cmd_install else cmd_install
            cmd_user = [sys.executable, '-m', 'pip', 'install', '--user', '--upgrade', pkg_spec]
            r2 = subprocess.run(cmd_user, **base_kwargs)
            if r2.returncode == 0:
                success = True
                steps.append({
                    "step": "install_user",
                    "command": ' '.join(cmd_user),
                    "success": True,
                    "output": (r2.stdout or '').strip()[:500],
                })
            else:
                steps.append({
                    "step": "install_failed",
                    "command": ' '.join(cmd_install),
                    "success": False,
                    "output": (stderr or (r2.stderr or '') or "Installazione fallita")[:500],
                })

        # Step 3: Verifica post-install
        if success and package == "meshtastic":
            cli_path = _find_meshtastic_cli()
            if cli_path:
                try:
                    vr = subprocess.run([cli_path, "--version"],
                                       capture_output=True, text=True, timeout=10,
                                       encoding='utf-8', errors='replace')
                    steps.append({
                        "step": "verify",
                        "success": vr.returncode == 0,
                        "output": ((vr.stdout or '') + ' ' + (vr.stderr or '')).strip()[:200],
                    })
                except Exception:
                    pass

        return jsonify({
            "success": success,
            "action": action,
            "package": package,
            "version": version or "latest",
            "steps": steps,
        })

    except subprocess.TimeoutExpired:
        return jsonify({"success": False, "error": "Timeout (300s)", "steps": steps}), 504
    except Exception as e:
        return jsonify({"success": False, "error": str(e), "steps": steps}), 500


@app.route('/api/error/analyze', methods=['POST'])
def api_error_analyze():
    """Analizza un testo errore (Traceback) e suggerisce fix"""
    data = request.get_json() or {}
    error_text = data.get("error", "")

    if not error_text:
        return jsonify({"diagnoses": [], "message": "Nessun errore fornito"})

    diagnoses = _analyze_error(error_text)
    if diagnoses:
        return jsonify({
            "found": True,
            "diagnoses": diagnoses,
            "count": len(diagnoses),
        })
    else:
        return jsonify({
            "found": False,
            "diagnoses": [],
            "message": "Errore non riconosciuto — controlla manualmente",
        })


# ═══════════════════════════════════════════════════════════
# GESTIONE ERRORI
# ═══════════════════════════════════════════════════════════

@app.errorhandler(404)
def not_found(e):
    return jsonify({"error": "Endpoint non trovato"}), 404

@app.errorhandler(500)
def server_error(e):
    return jsonify({"error": "Errore interno del server"}), 500


def create_app(port=5555):
    """Crea e ritorna l'app Flask configurata"""
    app.config['PORT'] = port
    return app
