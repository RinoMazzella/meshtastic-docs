#!/bin/bash
# ═══════════════════════════════════════════════════════════
# 📡 Meshtastic Italia Network App v1.1.3 — Launcher (macOS/Linux)
# © 2026 MANGOLINK — Tutti i diritti riservati
# ═══════════════════════════════════════════════════════════

cd "$(dirname "$0")"

# Trova Python
PYTHON=""
for cmd in python3 python py; do
    if command -v "$cmd" &>/dev/null; then
        PYTHON="$cmd"
        break
    fi
done

if [ -z "$PYTHON" ]; then
    echo ""
    echo "  ❌ Python non trovato!"
    echo ""
    echo "  Installa Python 3.9+:"
    echo "    macOS:  brew install python"
    echo "    Linux:  sudo apt install python3 python3-pip"
    echo ""
    exit 1
fi

echo "  📡 Meshtastic Italia Network App v1.1.3"
echo "  Avvio con: $PYTHON"
echo ""

$PYTHON start_app.py
