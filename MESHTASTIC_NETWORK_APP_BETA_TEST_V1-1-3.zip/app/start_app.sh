#!/bin/bash
# ═══════════════════════════════════════════════════════════
# Meshtastic Italia Network App v1.1.3 — Launcher (macOS/Linux)
# © 2026 MANGOLINK — Tutti i diritti riservati
# ═══════════════════════════════════════════════════════════
# Auto-crea un virtual environment su macOS/Linux per evitare
# l'errore "externally-managed-environment" (PEP 668).
# L'utente deve solo fare doppio-click o eseguire ./start_app.sh
# ═══════════════════════════════════════════════════════════

cd "$(dirname "$0")"

# ── Colori terminale ──────────────────────────────────────
GREEN="\033[92m"
YELLOW="\033[93m"
RED="\033[91m"
CYAN="\033[96m"
BOLD="\033[1m"
RESET="\033[0m"

info()  { echo -e "  ${CYAN}i ${RESET}$1"; }
ok()    { echo -e "  ${GREEN}✅ ${RESET}$1"; }
warn()  { echo -e "  ${YELLOW}⚠  ${RESET}$1"; }
err()   { echo -e "  ${RED}❌ ${RESET}$1"; }

echo ""
echo -e "  ${GREEN}${BOLD}📡 Meshtastic Italia Network App v1.1.3${RESET}"
echo -e "  ${CYAN}© 2026 MANGOLINK${RESET}"
echo ""

# ── 1. Trova Python 3 ────────────────────────────────────
PYTHON=""
for cmd in python3 python py; do
    if command -v "$cmd" &>/dev/null; then
        # Verifica che sia Python 3.9+
        PY_VER=$("$cmd" -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')" 2>/dev/null)
        PY_MAJOR=$("$cmd" -c "import sys; print(sys.version_info.major)" 2>/dev/null)
        PY_MINOR=$("$cmd" -c "import sys; print(sys.version_info.minor)" 2>/dev/null)
        if [ "$PY_MAJOR" = "3" ] && [ "$PY_MINOR" -ge 9 ] 2>/dev/null; then
            PYTHON="$cmd"
            break
        fi
    fi
done

if [ -z "$PYTHON" ]; then
    echo ""
    err "Python 3.9+ non trovato!"
    echo ""
    echo "  Installa Python:"
    echo "    macOS:   brew install python"
    echo "    Linux:   sudo apt install python3 python3-pip python3-venv"
    echo "    Scarica: https://www.python.org/downloads/"
    echo ""
    read -p "  Premi INVIO per chiudere..." _
    exit 1
fi

ok "Python $PY_VER trovato ($PYTHON)"

# ── 2. Rileva sistema operativo ───────────────────────────
OS_NAME=$(uname -s)
case "$OS_NAME" in
    Darwin) info "Sistema: macOS" ;;
    Linux)  info "Sistema: Linux" ;;
    *)      info "Sistema: $OS_NAME" ;;
esac

# ── 3. Virtual Environment (auto-setup) ──────────────────
VENV_DIR="$(pwd)/venv"
VENV_PYTHON="$VENV_DIR/bin/python3"
VENV_PIP="$VENV_DIR/bin/pip3"

# Funzione: verifica se siamo già in un venv
in_venv() {
    "$PYTHON" -c "import sys; sys.exit(0 if (hasattr(sys,'real_prefix') or (hasattr(sys,'base_prefix') and sys.base_prefix!=sys.prefix)) else 1)" 2>/dev/null
}

# Se siamo già in un venv, non ne creiamo un altro
if in_venv; then
    ok "Virtual environment già attivo"
    VENV_PYTHON="$PYTHON"
else
    # Controlla se serve un venv (macOS Homebrew / Linux con PEP 668)
    NEEDS_VENV=false

    # Test: prova pip install --dry-run per vedere se fallisce
    "$PYTHON" -m pip install --dry-run flask -q 2>&1 | grep -qi "externally.managed" && NEEDS_VENV=true

    # Su macOS con Homebrew Python, serve quasi sempre
    if [ "$OS_NAME" = "Darwin" ]; then
        PYTHON_PATH=$(which "$PYTHON" 2>/dev/null)
        if echo "$PYTHON_PATH" | grep -qi "homebrew\|cellar\|linuxbrew"; then
            NEEDS_VENV=true
        fi
    fi

    if [ "$NEEDS_VENV" = true ] || [ -d "$VENV_DIR" ]; then
        if [ ! -d "$VENV_DIR" ]; then
            info "Creo ambiente virtuale Python (una tantum)..."

            # Verifica che il modulo venv sia disponibile
            if ! "$PYTHON" -m venv --help &>/dev/null; then
                err "Modulo 'venv' non disponibile!"
                echo ""
                echo "  Installa venv:"
                echo "    macOS:  (incluso con brew install python)"
                echo "    Linux:  sudo apt install python3-venv"
                echo ""
                read -p "  Premi INVIO per chiudere..." _
                exit 1
            fi

            "$PYTHON" -m venv "$VENV_DIR"
            if [ $? -ne 0 ]; then
                err "Errore nella creazione del virtual environment!"
                read -p "  Premi INVIO per chiudere..." _
                exit 1
            fi
            ok "Virtual environment creato in ./venv/"
        else
            ok "Virtual environment trovato in ./venv/"
        fi

        # Attiva il venv
        if [ -f "$VENV_DIR/bin/activate" ]; then
            source "$VENV_DIR/bin/activate"
            PYTHON="$VENV_PYTHON"
            ok "Virtual environment attivato"
        else
            err "File di attivazione venv non trovato!"
            read -p "  Premi INVIO per chiudere..." _
            exit 1
        fi

        # Aggiorna pip nel venv (silenzioso)
        "$PYTHON" -m pip install --upgrade pip -q 2>/dev/null
    fi
fi

# ── 4. Avvia l'app ───────────────────────────────────────
info "Avvio app con: $PYTHON"
echo ""

"$PYTHON" start_app.py
EXIT_CODE=$?

if [ $EXIT_CODE -ne 0 ]; then
    echo ""
    err "L'app si è chiusa con errore (codice: $EXIT_CODE)"
    echo ""
    echo "  Possibili soluzioni:"
    echo "    1. Riprova: ./start_app.sh"
    echo "    2. Cancella venv e ricrea: rm -rf venv && ./start_app.sh"
    echo "    3. Installa manualmente: $PYTHON -m pip install -r requirements.txt"
    echo ""
fi

read -p "  Premi INVIO per chiudere..." _
